/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import _ from 'lodash'
import performQuery from 'shared/api-conventions/mongo'
import performElasticsearchQuery from 'shared/api-conventions/elasticsearch'
import { defaultLogger as logger } from 'shared/logging'
import { getConnection } from 'shared/mongoose/pool'

export default function crud(options) {
  let role = options.role
  let getModel = options.getModel

  let saveMsgPattern = `role:${role},cmd:save`
  let loadMsgPattern = `role:${role},cmd:load`
  let listMsgPattern = `role:${role},cmd:list`
  let queryMsgPattern = `role:${role},cmd:query`
  let removeMsgPattern = `role:${role},cmd:remove`

  this.add(saveMsgPattern, (msg, respond) => {
    if (!msg.connectionKey) {
      throw new Error('connectionKey needed')
    }
    let Model = getModel(getConnection(msg.connectionKey))
    let { data, currentUser } = msg
    if (!currentUser) {
      throw new Error('user required to save data')
    }

    if (data.hasOwnProperty('id') == false) {
      let model = new Model(data)
      model.updatedBy = currentUser
      model
        .save((err, result) => {
          /* istanbul ignore next */
          if (err) {
            logger.debug(`Model.save err is ${JSON.stringify(err)}`, err)
          }
          respond(err, result && result.toJSON())
        })
        .catch(/* istanbul ignore next */ () => {})
      // TODO mongoose always returns promise with unhandled exception, even if
      // you pass in a callback.
    } else {
      Model.find(idCondition(data.id), (err, results) => {
        if (err || results.length === 0) {
          logger.debug(`Model.find err is ${JSON.stringify(err)}`, err)
          respond(err, null)
          return
        }
        let entity = results[0]
        updateFields(entity, data)
        entity.updatedBy = currentUser
        entity
          .save((error, result) => {
            respond(error, result && result.toJSON())
          })
          .catch(/* istanbul ignore next */ () => {})
        // TODO mongoose always returns promise with unhandled exception, even
        // if you pass in a callback.
      })
    }
  })

  this.add(loadMsgPattern, (msg, respond) => {
    if (!msg.connectionKey) {
      throw new Error('connectionKey needed')
    }
    let Model = getModel(getConnection(msg.connectionKey))
    const query = Object.assign({}, msg.query, idCondition(msg.id))
    Model.find(query, (err, result) => {
      if (!err && _.isEmpty(result)) {
        err = new Error('id not found')
      }
      respond(err, Array.isArray(result) && result[0] && result[0].toJSON())
    })
  })

  this.add(listMsgPattern, (msg, respond) => {
    if (!msg.connectionKey) {
      throw new Error('connectionKey needed')
    }
    let Model = getModel(getConnection(msg.connectionKey))
    Model.find(msg.options || {}, (err, result) => {
      respond(err, _.map(result, r => r.toJSON()))
    })
  })

  this.add(queryMsgPattern, async (msg, respond) => {
    if (!msg.connectionKey) {
      return respond(new Error('connectionKey needed'))
    }
    let Model = getModel(getConnection(msg.connectionKey))
    try {
      if (_.get(msg, 'opts.elasticsearch') && Model.esSearch) {
        const { res, count } = await performElasticsearchQuery(
          Model,
          msg.opts || /* istanbul ignore next */ {},
          msg.query
        )
        return respond(null, { count, result: res })
      }
      const { res, count } = await performQuery(
        Model,
        msg.opts || {},
        msg.query
      )
      return respond(null, { count, result: _.map(res, r => r.toJSON()) })
    } catch (e) {
      return respond(e)
    }
  })

  this.add(removeMsgPattern, (msg, respond) => {
    if (!msg.connectionKey) {
      throw new Error('connectionKey needed')
    }
    let Model = getModel(getConnection(msg.connectionKey))
    let { currentUser } = msg
    if (!currentUser) {
      throw new Error('user required to delete data')
    }
    Model.find(idCondition(msg.id), (err, results) => {
      /* istanbul ignore if */
      if (err || results.length === 0) {
        respond(err, { n: 0 })
        return
      }
      let entity = results[0]
      entity.updatedBy = currentUser
      entity.remove(idCondition(msg.id), (error, result) => {
        respond(error, result && result.toJSON())
      })
    })
  })
}

function idCondition(id) {
  // If id is all numbers and 19 chars long, then its a snowflakeId
  const snowflakeId = new RegExp(/^\d{19}$/)
  if (snowflakeId.test(id)) {
    return { snowflakeId: id }
  }
  return { _id: id }
}

function updateFields(updatee, updator) {
  for (let prop in updator) {
    if (updator.hasOwnProperty(prop)) {
      updatee[prop] = updator[prop]
    }
  }
}
