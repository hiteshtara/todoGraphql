/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import crud from 'shared/crud'
import mongoose from 'shared/mongoose'
import { getTestConnectionInfo } from 'shared/test-helpers'

let sandbox
const { connection, connectionKey } = getTestConnectionInfo()
let schema = mongoose.Schema({
  a: Number,
  b: Number,
  c: Number,
  snowflakeId: String
})
schema.methods = {
  toJSON() {
    let obj = this.toObject()
    obj.id = this._id
    delete obj._id
    delete obj.__v
    return obj
  }
}

describe('crud plugin |', () => {
  let Model
  beforeEach(() => {
    sandbox = sinon.sandbox.create()
    Model = connection.model('test', schema)
    Model.collection.drop()
    let getModel = () => Model
    seneca.use(crud, { role: 'test', getModel })
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('lists something', async () => {
    await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: { c: 1 },
      connectionKey })
    let res = await seneca.actAsync({ role: 'test', cmd: 'list',
      connectionKey })
    assert.equal(res.length, 1)
    assert.equal(res[0].c, 1)
    assert.notEqual(res[0].id, undefined)
  })

  it('list fails without connectionKey', async () => {
    await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: { c: 1 },
      connectionKey })
    try {
      await seneca.actAsync({ role: 'test', cmd: 'list' })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(ex)
    }
  })

  it('saves something', async () => {
    let res = await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: { a: 3 },
      connectionKey })
    assert.equal(res.a, 3)
  })

  it('fails to save something without a connectionKey', async () => {
    try {
      await seneca.actAsync({
        role: 'test',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { a: 3 }
      })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(ex)
    }
  })

  it('fails to save something without a user', async () => {
    try {
      await seneca.actAsync({ role: 'test', cmd: 'save', data: { a: 3 },
        connectionKey })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(ex)
    }
  })

  it('fails to save something', async () => {
    try {
      sandbox.stub(connection.Model, 'save').yields('error', null)
      await seneca.actAsync({ role: 'test', cmd: 'save',
        currentUser: { id: 'test' }, data: { a: 3 },
        connectionKey })
    } catch (ex) {
      assert(ex)
    }
  })

  it('updates something', async () => {
    let item = await seneca.actAsync({
      role: 'test',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: { b: 2, a: 1 },
      connectionKey
    })
    let res = await seneca.actAsync({
      role: 'test',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: { id: item.id, b: 3 },
      connectionKey
    })
    assert.equal(res.b, 3)
    assert.equal(res.a, 1)
  })

  it('returns error for update', async () => {
    let error = 'error'
    sandbox.stub(Model, 'findById').yields(error, null)

    try {
      await seneca.actAsync({ role: 'test', cmd: 'save',
        currentUser: { id: 'test' }, data: { id: '1', b: 3 },
        connectionKey })
    } catch (ex) {
      assert(ex)
    }
  })

  it('loads something', async () => {
    let item = await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: { b: 2 },
      connectionKey })
    let res = await seneca.actAsync({ role: 'test', cmd: 'load', id: item.id,
      connectionKey })
    assert.equal(res.b, 2)
  })

  it('load fails without connectionKey', async () => {
    try {
      await seneca.actAsync({
        role: 'test',
        cmd: 'load',
        id: '743c5be0ce1130c0c78b509f'
      })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(/connectionKey needed/.test(ex.message))
    }
  })

  it('load throws exception on id not found', async () => {
    try {
      await seneca.actAsync({
        role: 'test',
        cmd: 'load',
        id: '743c5be0ce1130c0c78b509f',
        connectionKey
      })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(/id not found/.test(ex.message))
    }
  })

  it('deletes something', async () => {
    let item = await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: { d: 1 },
      connectionKey })
    await seneca.actAsync({ role: 'test', cmd: 'remove',
      currentUser: { id: 'test' }, id: item.id,
      connectionKey })
    try {
      await seneca.actAsync({ role: 'test', cmd: 'load', id: item.id,
      connectionKey })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(/id not found/.test(ex.message))
    }
  })

  it('delete fails without connectionKey', async () => {
    try {
      await seneca.actAsync({ role: 'test', cmd: 'remove', id: 123 })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(ex)
    }
  })

  it('fails to delete something', async () => {
    let item = await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: { d: 1 },
      connectionKey })
    try {
      await seneca.actAsync({ role: 'test', cmd: 'remove', id: item.id,
      connectionKey })
    } catch (ex) {
      assert(ex)
      return
    }
    throw new Error('Exception not thrown')
  })

  it('only updates own properties', async () => {
    let BaseClass = function() {}
    BaseClass.prototype.c = 5
    let item = await seneca.actAsync({
      role: 'test',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: { b: 2, a: 1, c: 1 },
      connectionKey
    })
    let item2 = new BaseClass()
    item2.id = item.id
    item2.b = 3
    let res = await seneca.actAsync({ role: 'test', cmd: 'save',
      currentUser: { id: 'test' }, data: item2,
      connectionKey })
    assert.equal(res.b, 3)
    assert.equal(res.a, 1)
    assert.equal(res.c, 1)
  })

  it('query fails without connectionKey', async () => {
    try {
      await seneca.actAsync({ role: 'test', cmd: 'query' })
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(ex)
    }
  })

  it('returns error for queries', async () => {
    let error = 'error'
    sandbox.stub(Model, 'findById').yields(error, null)

    try {
      await seneca.actAsync({ role: 'test', cmd: 'query',
        data: { id: '1', b: 3 },
        connectionKey })
    } catch (ex) {
      assert(ex)
      return
    }
    assert.fail('error not returned')
  })

  describe('Snowflake backwards compatibility', () => {
    let objectId = '743c5be0ce1130c0c78b509f'
    let snowflakeId = '1346972247374804096'

    beforeEach(async () => {
      await seneca.actAsync({
        role: 'test',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          _id: objectId,
          snowflakeId
        },
        connectionKey
      })
    })

    describe('Load', () => {
      it('returns an item by _id', async () => {
        let item = await seneca.actAsync({
          role: 'test', cmd: 'load', id: objectId,
          connectionKey
        })
        assert.equal(item.id, objectId)
      })

      it('returns an item by snowflakeId', async () => {
        let item = await seneca.actAsync({
          role: 'test', cmd: 'load', id: snowflakeId,
          connectionKey
        })
        assert.equal(item.id, objectId)
      })
    })

    describe('Remove', () => {
      it('removes an item by _id', async () => {
        await seneca.actAsync({ role: 'test', cmd: 'remove',
          currentUser: { id: 'test' }, id: objectId, connectionKey })
        try {
          await seneca.actAsync({ role: 'test', cmd: 'load', id: objectId })
        } catch (ex) {
          assert.equal(ex instanceof Error, true)
        }
      })

      it('removes an item by snowflakeId', async () => {
        await seneca.actAsync({ role: 'test', cmd: 'remove',
          currentUser: { id: 'test' }, id: snowflakeId, connectionKey })
        try {
          await seneca.actAsync({ role: 'test', cmd: 'load', id: snowflakeId,
            connectionKey })
        } catch (ex) {
          assert.equal(ex instanceof Error, true)
        }
      })
    })

    describe('Save', () => {
      it('updates an item by _id', async () => {
        let item = await seneca.actAsync({
          role: 'test', cmd: 'save',
          currentUser: { id: 'test' }, data: { id: objectId, c: 5 },
          connectionKey
        })
        assert.equal(item.c, 5)
      })

      it('updates an item by snowflakeId', async () => {
        let item = await seneca.actAsync({
          role: 'test', cmd: 'save',
          currentUser: { id: 'test' }, data: { id: snowflakeId, c: 5 },
          connectionKey
        })
        assert.equal(item.c, 5)
      })
    })
  })
})
