/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/*
  Adds security headers to Express responses

  References
  Content Security Policy: http://content-security-policy.com
  Check your headers: http://cyh.herokuapp.com/cyh
  Helmet: https://github.com/helmetjs/helmet
*/

export default function secure(req, res, next) {
  setHeadersForAllResponses(res)

  if (isApiRoute(req)) {
    return next()
  }

  setHeadersForNonApiResponses(res)

  return next()
}

function isApiRoute(req) {
  let matchUrl = '/api'
  return (req.url.substring(0, matchUrl.length) === matchUrl)
}

function setHeadersForAllResponses(res) {
  res.removeHeader('Server')
  res.removeHeader('X-Powered-By')

  res.setHeader('Surrogate-Control', 'no-store')
  res.setHeader(
    'Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate'
  )
  res.setHeader('Pragma', 'no-cache')
  res.setHeader('Expires', '-1')
}

function setHeadersForNonApiResponses(res) {
  res.setHeader('X-Frame-Options', 'sameorigin')
  res.setHeader(
    'Strict-Transport-Security', 'max-age=31536000; includeSubDomains'
  )
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('X-XSS-Protection', '1; mode=block')
  res.setHeader('X-Download-Options', 'noopen')
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'master-only')

  let csp = ''.concat(
    "default-src 'self'; ",
    "script-src 'self' 'unsafe-inline' https://www.google-analytics.com https://cdn.polyfill.io https://cdn.segment.com http://cdn.segment.com https://widget.intercom.io; ", //eslint-disable-line max-len
    "connect-src 'self' https://api.segment.io http://api.segment.io https://app.launchdarkly.com https://clientstream.launchdarkly.com https://events.launchdarkly.com; ", //eslint-disable-line max-len
    "style-src 'self' 'unsafe-inline' fonts.googleapis.com; ",
    "img-src 'self' data: https://www.google-analytics.com; ",
    "font-src 'self' fonts.gstatic.com; ",
    'report-uri /apps/content-security-policy-violation'
  )

  res.setHeader('Content-Security-Policy', csp)
}
