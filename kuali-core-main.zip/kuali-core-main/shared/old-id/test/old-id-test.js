/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import mongoose from 'shared/mongoose'
import { getTestConnectionInfo } from 'shared/test-helpers'
import oldIdPlugin from '../'

let schema = mongoose.Schema({
  a: Number
})

schema.plugin(oldIdPlugin)
const { connection } = getTestConnectionInfo()
let Model = connection.model('TestOldIdMongooseShared', schema)

describe('old-id plugin', () => {

  beforeEach(async () => {
    await Model.collection.drop().catch((err) => {
      if (err.message !== 'ns not found') throw err
    })
  })

  it('allows query by id', async () => {
    let { id } = await Model.create({ a: 1, oldId: 'foo' })
    let model1 = await Model.find({ _id: id })
    expect(model1[0]).to.have.property('oldId', 'foo')
    let model2 = await Model.findOne({ _id: id })
    expect(model1[0].toJSON()).to.be.eql(model2.toJSON())
  })

  it('allows query by oldId with id key', async () => {
    let { oldId } = await Model.create({ a: 1, oldId: 'foo' })
    let model1 = await Model.find({ _id: oldId })
    expect(model1[0]).to.have.property('oldId', 'foo')
    let model2 = await Model.findOne({ _id: oldId })
    expect(model1[0].toJSON()).to.be.eql(model2.toJSON())
  })

  it('allows mongo id in oldId', async () => {
    let { oldId } = await Model.create({
      a: 1,
      oldId: new mongoose.Types.ObjectId().toString()
    })
    let model = await Model.findOne({ _id: oldId })
    expect(model.id).to.not.be.equal(oldId)
    expect(model.oldId).to.be.equal(oldId)
  })

  it('allows you to search by other things', async () => {
    let { oldId, id } = await Model.create({ a: 2, oldId: 'foo' })
    let model1 = await Model.findOne({ _id: oldId })
    expect(model1.id).to.not.be.equal(oldId)
    expect(model1.oldId).to.be.equal(oldId)
    let model2 = await Model.findOne({ _id: oldId, a: 1 })
    expect(model2).to.be.equal(null)
    let model3 = await Model.findOne({ _id: oldId, a: 2 })
    expect(model3.toJSON()).to.be.eql(model1.toJSON())
    let model4 = await Model.findOne({ _id: id, a: 1 })
    expect(model4).to.be.equal(null)
    let model5 = await Model.findOne({ _id: id, a: 2 })
    expect(model5.toJSON()).to.be.eql(model1.toJSON())
  })

})
