/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import compoundSparseIndex from 'shared/mongoose/plugins/compound-sparse-index'

export default (schema, options) => {
  options = Object.assign({
    id: '_id',
    oldId: 'oldId'
  }, options)

  schema.path(options.oldId, String)

  schema.plugin(compoundSparseIndex, {
    fields: {
      [options.oldId]: {
        sort: 1,
        sparse: true,
        filter: { $type: 'string' }
      }
    },
    opts: {
      unique: true
    }
  })

  schema.pre('find', modifyConditions)
  schema.pre('findOne', modifyConditions)
  schema.pre('findOneAndRemove', modifyConditions)
  schema.pre('findOneAndUpdate', modifyConditions)
  schema.pre('update', modifyConditions)

  function modifyConditions() {
    let id = this._conditions[options.id]
    if (!id || this._conditions[options.oldId]) return

    const hasCastError = this._castError && this._castError.path === options.id

    if (hasCastError) {
      this.where({ [options.oldId]: id })
      this._castError = null
    } else {
      this.or([
        { [options.id]: id },
        { [options.oldId]: id.toString() }
      ])
    }

    delete this._conditions[options.id]
  }
}
