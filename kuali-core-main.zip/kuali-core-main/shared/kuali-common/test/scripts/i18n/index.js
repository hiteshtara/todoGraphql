/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import i18n, {
  getLocale,
  getLocaleData
} from '../../../scripts/i18n'

const testLocaleData = {
  'en-US': {
    locales: 'en-US',
    name: 'English (US)',
    messages: {
      blue: 'blue',
      apple: 'apple'
    }
  },
  'es-MX': {
    locales: 'es-MX',
    name: 'Spanish (Mexico)',
    messages: {
      blue: 'azul',
      apple: 'monzana'
    }
  },
  'de-DE': {
    locales: 'de-DE',
    name: 'German',
    messages: {
      blue: 'blau',
      apple: 'apfel'
    }
  }
}


describe('i18n module', () => {
  it('does something', () => {
    const translate = i18n(testLocaleData)
    assert.equal(translate('blue', 'es-MX'), 'azul')
    assert.equal(translate('blue', 'de-DE'), 'blau')
  })

  it('no translation available', () => {
    const translate = i18n(testLocaleData)

    assert.equal(translate('ranch', 'en-US'), 'ranch')
  })

  describe('getLocaleData', () => {
    it('no locale', () => {
      global.window.location.hash = '#?locale=fr-FR'

      i18n({
        'fr-FR': {
          dog: 'chien'
        }
      })
      assert.equal(getLocaleData().dog, 'chien')
    })

    it('invalid locale', () => {
      i18n({
        'en-US': {
          dog: 'hound'
        }
      })
      assert.equal(getLocaleData('sd-RW').dog, 'hound')
    })

    it('valid locale', () => {
      i18n({
        'es-MX': {
          dog: 'perro'
        }
      })
      assert.equal(getLocaleData('es-MX').dog, 'perro')
    })
  })

  describe('getLocale', () => {
    it('no location object', () => {
      assert.equal(getLocale(), '')
    })

    it('no query string', () => {
      const locationObj = {
        hash: ''
      }

      assert.equal(getLocale(locationObj), 'en-US')
    })

    it('no hash', () => {
      const locationObj = {
        hash: 'bla?red=rover&hound=dog'
      }

      assert.equal(getLocale(locationObj), 'en-US')
    })

    it('hash present', () => {
      const locationObj = {
        hash: '#bla?red=rover&hound=dog'
      }

      assert.equal(getLocale(locationObj), 'en-US')
    })

    it('locale present', () => {
      const locationObj = {
        hash: '?locale=es-MX&red=rover&hound=dog'
      }

      assert.equal(getLocale(locationObj), 'es-MX')
    })
  })
})
