/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { shallow } from 'enzyme'
import React from 'react'
import { assert } from 'chai'

import { notAuthorized as NotAuthorized } from '../../../components/NotAuthorized403' // eslint-disable-line module-name/kebab-case, max-len

const ctx = { intl: { formatMessage: msg => msg.defaultMessage } }

describe('<NotAuthorized />', () => {

  it('renders correctly', () => {
    const el = shallow(<NotAuthorized {...ctx} />)
    assert(el.html())
  })
})
