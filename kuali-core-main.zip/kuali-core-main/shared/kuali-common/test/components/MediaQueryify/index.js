/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { mount, shallow } from 'enzyme'
import React from 'react'
import sinon from 'sinon'

import MediaQueryify from '../../../components/MediaQueryify' // eslint-disable-line module-name/kebab-case, max-len

function TestComponent() {
  return <div />
}
TestComponent.displayName = 'TestComponent'
const Component = MediaQueryify(TestComponent)

describe('MediaQueryify HOC', () => {

  it('passes props through to component and appends mq', () => {
    global.window.innerWidth = 100
    const el = shallow(<Component sup={5} woot="yay"/>)
    assert.equal(el.type(), TestComponent)
    assert.equal(el.prop('sup'), 5)
    assert.equal(el.prop('woot'), 'yay')
    assert.equal(el.prop('mq'), 'small')
  })

  it('make sure mq is set correctly based on window.innerWidth', () => {
    global.window.innerWidth = 750
    const el = shallow(<Component/>)
    assert.equal(el.prop('mq'), 'small')
    global.window.innerWidth = 900
    const el2 = shallow(<Component/>)
    assert.equal(el2.prop('mq'), 'medium')
    global.window.innerWidth = 1199
    const el3 = shallow(<Component/>)
    assert.equal(el3.prop('mq'), 'large')
    global.window.innerWidth = 1201
    const el4 = shallow(<Component/>)
    assert.equal(el4.prop('mq'), 'huge')
  })

  it('setupListeners is called on mount', () => {
    sinon.spy(Component.prototype, 'componentDidMount')
    sinon.spy(Component.prototype, 'setupListeners')
    mount(<Component/>)
    assert(Component.prototype.componentDidMount.calledOnce)
    assert(Component.prototype.setupListeners.calledOnce)
  })

  it('emit a resize event and make sure size gets set correctly', () => {
    global.window.innerWidth = 750
    const el = mount(<Component wut="hrrm"/>)
    assert.equal(el.state('mq'), 'small')
    global.window.innerWidth = 1100
    global.window.dispatchEvent(new window.Event('resize'))
    assert.equal(el.state('mq'), 'large')
  })

  it('removes the event listener when unmounted', () => {
    const component = new Component()
    sinon.spy(global.window, 'removeEventListener')
    component.componentWillUnmount()
    assert(global.window.removeEventListener.calledOnce)
    assert.equal(global.window.removeEventListener.args[0][0], 'resize')
  })

})
