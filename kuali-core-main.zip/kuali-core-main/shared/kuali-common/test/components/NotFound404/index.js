/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { shallow } from 'enzyme'
import React from 'react'
import { expect, assert } from 'chai'

import { notFound as NotFound } from '../../../components/NotFound404' // eslint-disable-line module-name/kebab-case, max-len

const ctx = { intl: { formatMessage: msg => msg.defaultMessage } }

describe('<NotFound />', () => {

  it('renders correctly', () => {
    const el = shallow(<NotFound {...ctx} />)
    assert(el.html())

    expect(el.find('FormattedMessage#notfound.content')).to.exist //eslint-disable-line max-len,no-unused-expressions
  })

})
