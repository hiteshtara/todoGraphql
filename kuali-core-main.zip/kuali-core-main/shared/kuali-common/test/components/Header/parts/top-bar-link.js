/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { shallow } from 'enzyme'
import React from 'react'

import TopBarLink from '../../../../components/Header/parts/top-bar-link' // eslint-disable-line module-name/kebab-case, max-len

const ctx = {
  intl: { formatMessage: msg => msg.defaultMessage },
  imgSrc: 'user',
  small: true,
  title: 'user'
}

describe('<TopBarLink />', () => {

  it('renders', () => {
    const el = shallow(<TopBarLink {...ctx} />)
    assert(el.html())
  })

  it('contains the CM test id', () => {
    const el = shallow(<TopBarLink {...ctx} />)
    assert(el.find('#user-menu').length === 1)
  })

})
