/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { shallow } from 'enzyme'
import React from 'react'

import TopBar from '../../../../components/Header/parts/top-bar' // eslint-disable-line module-name/kebab-case, max-len

function cx(className) {
  return `._shared_kuali_common_components_Header_parts_top_bar__${className}`
}

const props = {
  intl: { formatMessage: msg => msg.defaultMessage },
  leftContent: () => 'leftContent',
  links: () => 'links'
}

describe('<TopBar />', () => {

  it('renders', () => {
    const el = shallow(<TopBar {...props}/>)
    assert(el.html())
  })

  it('renders responsively', () => {
    const el = shallow(<TopBar mq="small" {...props}/>)
    assert.equal(el.find(cx('dropdown')).length, 0)
  })

  it('shows the links when hamburger is clicked', () => {
    const el = shallow(<TopBar mq="small" {...props}/>)
    el.find('button').simulate('click')
    assert.equal(el.find(cx('dropdown')).length, 1)
    assert.equal(el.find(cx('dropdown')).text(), 'links')
  })

})
