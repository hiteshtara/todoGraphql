/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { mount, shallow } from 'enzyme'
import React from 'react'

import AppMenu from '../../../../components/Header/parts/app-menu' // eslint-disable-line module-name/kebab-case, max-len

const ctx = { intl: { formatMessage: msg => msg.defaultMessage } }

describe('<AppMenu />', () => {

  it('renders', () => {
    const el = shallow(<AppMenu user={{ apps: {} }} {...ctx}/>)
    assert(el.html())
  })

  it('only shows cm and users with normal user', () => {
    const el =
      mount(<AppMenu user={{ apps: { users: true, cm: true } }} {...ctx}/>)
    const links = el.find('a')
    assert.equal(links.length, 2)
  })

  it('shows all 4 apps if is an admin', () => {
    const el = mount(<AppMenu user={{ apps: { users: true, cm: true,
      workflow: true, groups: true } }} {...ctx}/>)
    const links = el.find('a')
    assert.equal(links.length, 4)
  })

})
