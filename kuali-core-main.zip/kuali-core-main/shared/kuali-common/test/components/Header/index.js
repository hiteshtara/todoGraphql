/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { mount, shallow } from 'enzyme'
import React from 'react'

import { PureHeader } from '../../../components/Header' // eslint-disable-line module-name/kebab-case, max-len

const ctx = { intl: { formatMessage: msg => msg.defaultMessage } }

describe('<Header />', () => {

  it('renders', () => {
    const el = shallow(<PureHeader user={{}} {...ctx}/>)
    assert(el.html())
  })

  it('renders on small', () => {
    const el = shallow(<PureHeader mq="small" user={{}} {...ctx}/>)
    assert(el.html())
  })

  it('renders the username', () => {
    const el = mount(<PureHeader user={{ displayName: 'Bubba' }} {...ctx}/>)
    const profileEl = el.find({ 'aria-describedby': 'profilePopover' })
    assert.equal(profileEl.text().trim(), 'Bubba')
  })

  it('renders "profile" if no username is given', () => {
    const el = mount(<PureHeader user={{}} {...ctx}/>)
    const profileEl = el.find({ 'aria-describedby': 'profilePopover' })
    assert.equal(profileEl.text().trim(), 'Profile')
  })

  it('renders productTitle part of logo', () => {
    const el = mount(<PureHeader productTitle="Core" user={{}} {...ctx}/>)
    const headingEl = el.find('h1')
    assert.equal(headingEl.text().trim(), 'KualiCore')
  })

  it('renders title part of logo when smal', () => {
    const el = mount(<PureHeader mq="small" title="Core" user={{}} {...ctx}/>)
    const headingEl = el.find('h1')
    assert.equal(headingEl.text().trim(), 'KualiCore')
  })

  it('Action List link exists', () => {
    const el = mount(<PureHeader user={{}} {...ctx}/>)
    const actionsEl = el.find({ 'href': '/actions#/list' })
    assert.equal(actionsEl.text().trim(), 'Action List')
  })

  // need to figure out how to test these kinds of things (overlays, popups)
  it('opens app picker')
  it('opens app picker in mobile')
  it('can click on user context menu')

  it.skip('hamburger menu works in mobile', () => {
    const el = mount(<PureHeader mq="small" user={{}} {...ctx}/>)
    el.find({ alt: 'Open Nav Menu' }).simulate('click')
    const links = el.find('._shared_kuali_common_components_Header_style__link')
    assert.equal(links.length, 3)
  })

})
