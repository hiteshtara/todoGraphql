/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { mount, shallow } from 'enzyme'
import React from 'react'
import sinon from 'sinon'

import { PurePreloader } from '../../../components/Preloader' // eslint-disable-line module-name/kebab-case, max-len

const ctx = { intl: { formatMessage: msg => msg.defaultMessage } }

describe('<Preloader />', () => {

  it('renders correctly', () => {
    const el = shallow(<PurePreloader {...ctx}/>)
    assert(el.html())
    assert.equal(el.find('span').text(), 'Loading, please wait.')
  })

  it('componentDidMount and setHeight get called', () => {
    sinon.spy(PurePreloader.prototype, 'componentDidMount')
    sinon.spy(PurePreloader.prototype, 'setHeight')
    sinon.spy(PurePreloader.prototype, 'setState')
    mount(<PurePreloader {...ctx}/>)
    assert(PurePreloader.prototype.componentDidMount.calledOnce)
    assert(PurePreloader.prototype.setHeight.calledOnce)
    assert(PurePreloader.prototype.setState.calledOnce)
  })

  it('setHeight checks window and sets state correctly', () => {
    const component = new PurePreloader(null, ctx)
    component.refs = { me: { getBoundingClientRect: () => ({ top: 20 }) } }
    component.setState = sinon.spy()
    global.window.innerHeight = 100
    component.setHeight()
    assert(component.setState.calledOnce)
    assert.deepEqual(component.setState.args[0][0], { height: 80 })
  })

})
