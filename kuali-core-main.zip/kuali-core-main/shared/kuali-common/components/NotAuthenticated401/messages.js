/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

const messages = defineMessages({
  content: {
    id: 'notAuthenticated.content',
    description: 'Page content for 401 Not Authenticated',
    defaultMessage: 'We were unable to authenticate you successfully. Please try again.' //eslint-disable-line max-len
  },
  title: {
    id: 'notAuthenticated.title',
    description: 'Title content for 401 Not Authorized',
    defaultMessage: 'Not Authenticated (401)'
  }
})
export const { content, title } = messages
export default messages
