/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

const messages = defineMessages({
  content: {
    id: 'notfound.content',
    description: 'Page content for 404 Not Found',
    defaultMessage: 'Looks like you have found yourself between a rock and a hard place' //eslint-disable-line max-len
  }
})
export const { content } = messages
export default messages
