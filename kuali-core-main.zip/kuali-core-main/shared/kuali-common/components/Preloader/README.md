Preloader
=========

This is our default, full page loading spinner.

#### How to use:

```js
import Preloader from 'components/preloader'

render() {
  return <Preloader/>
}
```
