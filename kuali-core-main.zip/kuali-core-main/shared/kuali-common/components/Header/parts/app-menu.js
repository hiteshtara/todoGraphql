/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { intlShape } from 'react-intl'
import messages from 'shared/i18n'

import styles from './app-menu.css'
import Link from './app-menu-link'

export default class AppMenu extends Component {

  displayName: 'AppMenu';

  static propTypes = {
    intl: intlShape.isRequired,
    user: PropTypes.shape({
      displayName: PropTypes.string.isRequired,
      id: PropTypes.string.isRequired,
      role: PropTypes.oneOf([
        'admin',
        'user',
        'cmadmin',
        'external'
      ]).isRequired,
      apps: PropTypes.object.isRequired
    }).isRequired
  };

  render() {
    const { apps } = this.props.user
    let width = Object.keys(apps).length > 2 ? 300 : 150

    const fmt = this.props.intl.formatMessage
    return (
      <div className={styles.newAppMenu} style={{ width }}>
        {apps.cm && (<Link app="cm" name={fmt(messages.apps.curriculum)}
          to="/cm/"/>)}
        {apps.workflow && (<Link app="workflow"
          name={fmt(messages.apps.workflow)}
          to="/cm/workflow"/>)}
        {apps.groups && (<Link app="groups" name={fmt(messages.apps.groups)}/>)}
        {apps.users && (<Link app="users" name={fmt(messages.apps.users)}/>)}
      </div>
    )
  }

}
