/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import classNames from 'classnames/bind'
import React, { PropTypes } from 'react'

import styles from '../style.css'

const cx = classNames.bind(styles)

let TopBarLink = ({ imgSrc, small, title, to }) => (
  <a className={cx('link', { small })} href={to} id="user-menu">
    <img
      alt={title}
      className={styles.img}
      src={`/img/v1/top-bar/${imgSrc}.svg`}
    /> {title}
  </a>
)

TopBarLink.displayName = 'TopBarLink'

TopBarLink.propTypes = {
  imgSrc: PropTypes.string.isRequired,
  small: PropTypes.bool.isRequired,
  title: PropTypes.string.isRequired,
  to: PropTypes.string
}

export default TopBarLink
