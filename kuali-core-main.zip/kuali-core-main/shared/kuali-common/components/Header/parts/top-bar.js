/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import classNames from 'classnames/bind'
import React, { Component, PropTypes } from 'react'
import { intlShape } from 'react-intl'

import styles from './top-bar.css'
import messages from './messages'

const cx = classNames.bind(styles)

export default class TopBar extends Component {

  displayName: 'TopBar';

  static propTypes = {
    intl: intlShape.isRequired,
    leftContent: PropTypes.func.isRequired,
    links: PropTypes.func.isRequired,
    mq: PropTypes.oneOf(['small', 'medium', 'large', 'huge']).isRequired
  };

  constructor(props) {
    super(props)
    this.state = { open: false }
    this.toggleOpen = this.toggleOpen.bind(this)
  }

  toggleOpen() {
    this.setState({ open: !this.state.open })
  }

  isOpen() {
    return this.state.open && (this.props.mq == 'small')
  }

  render() {
    let small = this.props.mq == 'small'
    let links = this.props.links(small)
    let wrapperStyle = `navigation ${cx('wrapper', { small })}`
    return (
      <nav className={wrapperStyle}>
        <div className={styles.nav}>
          <div className={styles.leftContent}>
            {this.props.leftContent(small)}
          </div>
          {!small && links}
          {small && (
            <button className={styles.hamburger} onClick={this.toggleOpen}>
              <img alt={this.props.intl.formatMessage(messages.alt.nav)}
                src="/img/v1/top-bar/hamburger.svg"/>
            </button>
          )}
        </div>
        {this.isOpen() && <div className={styles.dropdown}>{links}</div>}
      </nav>
    )
  }

}
