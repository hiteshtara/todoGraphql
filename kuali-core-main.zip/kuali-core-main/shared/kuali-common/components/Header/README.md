Kuali Common Header
=============

This component renders the header used in all of our apps.

#### How to use:

```js
import Headerfhdjkfhdsjkfhdsjkfhdsjkfhdsjk from 'components/kuali-top-bar'

render() {
  return (
    <TopBar
      user={user}
      title="Groups"
      logo=""
    />
  );
}
```

#### Required Props

* `user` `Object`: The logged in user
* `title` `string`: The title of the app
* `logo` `string`: The url for the logo of the app
