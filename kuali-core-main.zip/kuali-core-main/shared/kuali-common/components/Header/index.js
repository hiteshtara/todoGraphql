/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { compact, map } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Popover } from 'react-bootstrap'
import { injectIntl, intlShape, FormattedMessage } from 'react-intl'
import sharedMsgs from 'shared/i18n'

import msgs from './messages'
import AppMenu from './parts/app-menu'
import Overlay from './parts/overlay'
import TopBar from './parts/top-bar'
import TopBarLink from './parts/top-bar-link'
import styles from './style.css'
import mediaQueryify from '../MediaQueryify' // eslint-disable-line module-name/kebab-case, max-len

class Header extends Component {

  displayName: 'Header';

  static propTypes = {
    intl: intlShape.isRequired,
    logo: PropTypes.string.isRequired,
    mq: PropTypes.oneOf(['small', 'medium', 'large', 'huge']).isRequired,
    productTitle: PropTypes.string,
    title: PropTypes.string.isRequired,
    user: PropTypes.shape({
      displayName: PropTypes.string.isRequired,
      id: PropTypes.string.isRequired,
      role: PropTypes.oneOf(['admin', 'user', 'cmadmin', 'external']).isRequired
    }).isRequired
  };

  constructor(props) {
    super(props)
    this.getLeftContent = this.getLeftContent.bind(this)
    this.getLinks = this.getLinks.bind(this)
  }

  getProfileTrigger(user, small) {
    let title = user.displayName
      || this.props.intl.formatMessage(msgs.labels.profile)
    let props = { small, title, imgSrc: 'profile' }
    return (
      <Overlay
        content={<div><TopBarLink {...props}/></div>}
        key="trigger"
        overlay={this.renderProfilePopover(user)}
      />
    )
  }

  renderProfilePopover(user) {
    return (
      <Popover id="profilePopover">
        <div style={{ margin: 10, marginBottom: 10 }}>
          <div><a href={`/users/#/${user.id}/details`}>
            <FormattedMessage {...msgs.links.settings}/>
          </a></div>
          <div><a href="/auth/signout">
            <FormattedMessage {...sharedMsgs.labels.signOut}/>
          </a></div>
        </div>
      </Popover>
    )
  }

  renderAppsPopover() {
    return (
      <Popover id="appsPopover">
        <AppMenu intl={this.props.intl} user={this.props.user}/>
      </Popover>
    )
  }

  getLeftContent(small) {
    const { title, productTitle } = this.props
    if (small) {
      return (
        <Overlay
          content={
            <h1 className={styles.logo}>
              Kuali{title && (<strong>{title}</strong>)}
            </h1>
          }
          overlay={this.renderAppsPopover()}
        />
      )
    }
    return (
      <div className={styles.container}>
        <h1 className={styles.logo}>
          Kuali{productTitle && (<strong>{productTitle}</strong>)}
        </h1>
        <div style={{ backgroundColor: '#d4d5d7', width: 1, height: 20 }} />
        <div style={{ fontSize: 20, marginLeft: 30 }}>
          <span style={{ fontWeight: 100 }}>{this.props.title}</span>
        </div>
        <Overlay
          content={
            <img
              alt={this.props.intl.formatMessage(msgs.alt.menu)}
              className={styles.squares}
              src="/img/v1/top-bar/squares.svg"
            />
          }
          overlay={this.renderAppsPopover()}
        />
      </div>
    )
  }

  getLinks(small) {
    let links = [
      {
        to: '/actions#/list',
        title: this.props.intl.formatMessage(msgs.links.actionList),
        imgSrc: 'action_list'
      },
      {
        hide: small,
        el: this.getProfileTrigger(this.props.user, small)
      },
      {
        hide: !small,
        to: `/users/#/${this.props.user.id}/details`,
        title: this.props.intl.formatMessage(msgs.links.settings),
        imgSrc: 'profile'
      },
      {
        hide: !small,
        to: '/auth/signout',
        title: this.props.intl.formatMessage(sharedMsgs.labels.signOut),
        imgSrc: 'sign-out'
      }
    ]

    return compact(map(links, ({ hide, el, ...link }) => {
      if (hide) return null
      if (el) return el
      return <TopBarLink key={link.to} small={small} {...link}/>
    }))
  }

  render() {
    return (
      <TopBar
        intl={this.props.intl}
        leftContent={this.getLeftContent}
        links={this.getLinks}
        mq={this.props.mq}
      />
    )
  }

}

export default injectIntl(mediaQueryify(Header))
export const PureHeader = Header
