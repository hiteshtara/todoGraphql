/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React from 'react'
import { intlShape, injectIntl } from 'react-intl'
import { labels } from 'shared/i18n'

import styles from './style'
import { content, title } from './messages'

export let notAuthorized = ({ intl }) => (
  <div className={styles.wrapper}>
    <div className={styles.title}>{intl.formatMessage(title)}</div>
    <div>{intl.formatMessage(content)}</div>
    <a href="/apps">{intl.formatMessage(labels.home)}</a>
  </div>
)

notAuthorized.displayName = '403NotAuthorized'

notAuthorized.propTypes = {
  intl: intlShape.isRequired
}

export default injectIntl(notAuthorized)
