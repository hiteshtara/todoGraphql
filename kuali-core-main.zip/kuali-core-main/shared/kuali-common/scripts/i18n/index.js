/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import qs from 'querystring'

let localeData

export function getLocale(locationObj) {
  if (typeof locationObj === 'undefined') {
    return ''
  }
  let i = locationObj.hash.indexOf('?')
  let query = locationObj.hash.substring(i + 1)
  return qs.parse(query).locale || 'en-US'
}

export function getLocaleData(locale) {
  let localeToUse = locale || getLocale(window.location)
  return localeData[localeToUse] || localeData['en-US']
}

function translate(key, locale) {
  let dataForLocale = getLocaleData(locale)
  if (dataForLocale && dataForLocale.messages[key]) {
    return dataForLocale.messages[key]
  }
  return key
}

export default function i18n(data) {
  localeData = data
  return translate
}
