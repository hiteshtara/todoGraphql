/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect, assert } from 'chai'
import sinon from 'sinon'
import crud from 'shared/crud-mongoose'
import mongoose from 'shared/mongoose'
import { getTestConnectionInfo } from 'shared/test-helpers'

let sandbox

let schema = mongoose.Schema({
  a: Number,
  b: Number,
  c: Number,
  snowflakeId: String
})
schema.methods = {
  toJSON() {
    let obj = this.toObject()
    obj.id = String(this._id)
    delete obj._id
    delete obj.__v
    return obj
  }
}

const { connection } = getTestConnectionInfo()

let Model = connection.model('TestCrudMongoose', schema)

describe('crud-mongoose plugin', () => {
  let si

  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await Model.collection.drop().catch((err) => {
      if (err.message !== 'ns not found') throw err
    })
    si = crud(Model)
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('queries something', async () => {
    await si.save({ c: 1 })
    let { result, count } = await si.query()
    expect(count).to.be.equal(1)
    expect(result).to.have.length(1)
    expect(result[0]).to.have.property('c', 1)
    expect(result[0]).to.have.property('id')
  })

  it('filters on less than', async () => {
    await si.save({ c: 1 })
    await si.save({ c: 5 })
    let { result, count } = await si.query({ c: 'lt(5)' })
    expect(count).to.be.equal(1)
    expect(result).to.have.length(1)
    expect(result[0]).to.have.property('c', 1)
    expect(result[0]).to.have.property('id')
  })

  it('filters on greater than', async () => {
    await si.save({ c: 1 })
    await si.save({ c: 5 })
    let { result, count } = await si.query({ c: 'gt(1)' })
    expect(count).to.be.equal(1)
    expect(result).to.have.length(1)
    expect(result[0]).to.have.property('c', 5)
    expect(result[0]).to.have.property('id')
  })

  it('filters on greater than for floats', async () => {
    await si.save({ c: 1 })
    await si.save({ c: 5 })
    let { result, count } = await si.query({ c: 'gt(1.1)' })
    expect(count).to.be.equal(1)
    expect(result).to.have.length(1)
    expect(result[0]).to.have.property('c', 5)
    expect(result[0]).to.have.property('id')
  })

  it('filters on less than or equal', async () => {
    await si.save({ c: 1 })
    await si.save({ c: 5 })
    await si.save({ c: 10 })
    let { result, count } = await si.query({ c: 'lte(5)' })
    expect(count).to.be.equal(2)
    expect(result).to.have.length(2)
    expect(result[0]).to.have.property('c', 1)
    expect(result[1]).to.have.property('c', 5)
  })

  it('filters on greater than or equal', async () => {
    await si.save({ c: 1 })
    await si.save({ c: 5 })
    await si.save({ c: 10 })
    let { result, count } = await si.query({ c: 'gte(5)' })
    expect(count).to.be.equal(2)
    expect(result).to.have.length(2)
    expect(result[0]).to.have.property('c', 5)
    expect(result[1]).to.have.property('c', 10)
  })

  it('is able to query by null', async () => {
    await si.save({ c: 1 })
    await si.save({ c: null })
    let { result, count } = await si.query({ c: 'null' })
    expect(count).to.be.equal(1)
    expect(result).to.have.length(1)
    expect(result[0]).to.have.property('c', null)
  })

  it('saves something', async () => {
    let res = await si.save({ a: 3 })
    expect(res).to.have.property('a', 3)
  })

  it('fails to save something', async () => {
    try {
      sandbox.stub(connection.Model, 'save').yields('error', null)
      await si.save({ a: 3 })
    } catch (ex) {
      assert(ex)
      return
    }
    assert.fail('Exception not thrown')
  })

  it('fails to save if id is not found', async () => {
    let item = await si.save({ b: 3 })
    await si.remove(item.id)
    try {
      await si.save({ id: item.id, b: 4 })
    } catch (ex) {
      expect(ex.message).to.match(/Could not find data with id/)
      return
    }
    assert.fail('Exception not found')
  })

  it('returns error for update', async () => {
    let error = 'error'
    sandbox.stub(Model, 'findById').yields(error, null)

    try {
      await si.save({ id: '1', b: 3 })
    } catch (ex) {
      assert(ex)
      return
    }
    assert.fail('Exception not thrown')
  })

  it('updates something', async () => {
    let item = await si.save({ b: 2, a: 1 })
    let res = await si.save({ id: item.id, b: 3 })
    expect(res.b).to.be.equal(3)
    expect(res.a).to.be.equal(1)
  })

  it('loads something', async () => {
    let item = await si.save({ b: 2 })
    let res = await si.load(item.id)
    expect(res.b).to.be.equal(2)
  })

  it('throws exception on id not found', async () => {
    try {
      await si.load('743c5be0ce1130c0c78b509f')
    } catch (ex) {
      expect(ex.message).to.match(/id not found/)
      return
    }
    assert.fail('No Exception thrown')
  })

  it('deletes something', async () => {
    let item = await si.save({ d: 1 })
    await si.remove(item.id)
    try {
      await si.load(item.id)
    } catch (ex) {
      expect(ex.message).to.match(/id not found/)
      return
    }
    assert.fail('should have thrown an error')
  })

  it('only updates own properties', async () => {
    let BaseClass = function() {}
    BaseClass.prototype.c = 5
    let item = await si.save({ b: 2, a: 1, c: 1 })
    let item2 = new BaseClass()
    item2.id = item.id
    item2.b = 3
    let res = await si.save(item2)
    assert.equal(res.b, 3)
    assert.equal(res.a, 1)
    assert.equal(res.c, 1)
  })

  it('returns error for queries', async () => {
    let error = 'error'
    sandbox.stub(Model, 'find').yields(error, null)

    try {
      await si.query({ id: '1', b: 3 })
    } catch (ex) {
      assert(ex)
      return
    }
    assert.fail('error not returned')
  })

  describe('Extra queries', async () => {

    it('can update with additional queries', async () => {
      let item = await si.save({ d: 1 })
      expect(await si.load(item.id)).to.be.eql(item)
      try {
        await si.save({ id: item.id, d: 3 }, { c: 1 })
        assert.fail('expected error to be thrown')
      } catch (ex) {
        expect(ex.message).to.match(/Could not find data with id:/)
        expect(ex.name).to.be.equal('NotFoundError')
        expect(ex.status).to.be.equal(404)
      }
    })

    it('can load with additional queries', async () => {
      let item = await si.save({ d: 1 })
      expect(await si.load(item.id)).to.be.eql(item)
      try {
        await si.load(item.id, { d: 2 })
        assert.fail('expected error to be thrown')
      } catch (ex) {
        expect(ex.message).to.match(/id not found/)
        expect(ex.name).to.be.equal('NotFoundError')
        expect(ex.status).to.be.equal(404)
      }
    })

    it('can remove with additional queries', async () => {
      let item = await si.save({ d: 1 })
      try {
        await si.remove(item.id, { d: 1 })
        assert.fail('expected error to be thrown')
      } catch (ex) {
        expect(ex.message).to.match(/Could not find data with id:/)
        expect(ex.name).to.be.equal('NotFoundError')
        expect(ex.status).to.be.equal(404)
      }
    })

  })

  describe('Snowflake backwards compatibility', () => {
    let snowflakeId = '1346972247374804096'
    let objectId

    beforeEach(async () => {
      let newObject = await si.save({ snowflakeId })
      objectId = newObject.id
    })

    describe('Load', () => {
      it('returns an item by _id', async () => {
        let item = await si.load(objectId)
        expect(item.id).to.be.eql(objectId)
      })

      it('returns an item by snowflakeId', async () => {
        let item = await si.load(snowflakeId)
        expect(item.id).to.be.eql(objectId)
      })
    })

    describe('Remove', () => {
      it('removes an item by _id', async () => {
        await si.remove(objectId)
        try {
          await si.load(objectId)
        } catch (ex) {
          expect(ex).to.be.instanceOf(Error)
          return
        }
        assert.fail('Expected exception to throw')
      })

      it('removes an item by snowflakeId', async () => {
        await si.remove(snowflakeId)
        try {
          await si.load(snowflakeId)
        } catch (ex) {
          expect(ex).to.be.instanceOf(Error)
          return
        }
        assert.fail('Expected exception to throw')
      })
    })

    describe('Save', () => {
      it('updates an item by _id', async () => {
        let item = await si.save({ id: objectId, c: 5 })
        expect(item.c).to.be.equal(5)
      })

      it('updates an item by snowflakeId', async () => {
        let item = await si.save({ id: snowflakeId, c: 5 })
        expect(item.c).to.be.equal(5)
      })
    })
  })
})
