/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import performQuery from 'shared/api-conventions/mongo'

/**
 * @param {Object} opts
 * @param {string}
 * @param {string[]} [opts.fields] - Array of fields to use for text searches
 * @param {number} [opts.defaultLimit=100] - The default limit on search queries
 * @param {number} [opts.maxLimit=100000] - The max limit on search queries
 * @param {string} [opts.idKey='_id'] - The id key to use when doing updates via
 *   the .save method
 */
export default function crud(Model, opts) {
  opts = Object.assign({}, {
    fields: [],
    defaultLimit: 100,
    maxLimit: 100000,
    idKey: 'id',
    oldIdKey: false
  }, opts)

  function createQuery(id, q) {
    return Object.assign({}, q, idCondition(id))
  }

  async function save(data, q) {
    if (!data.hasOwnProperty(opts.idKey)) {
      const model = new Model(data)
      const result = await model.save()
      return result && result.toJSON()
    }
    let id = data[opts.idKey]
    const entity = await Model.findOne(createQuery(id, q))
    if (!entity) {
      throw Object.assign(new Error(`Could not find data with id: ${id}`), {
        name: 'NotFoundError',
        status: 404
      })
    }
    delete data[opts.idKey]
    updateFields(entity, data)
    const result = await entity.save()
    return result && result.toJSON()
  }

  async function load(id, q) {
    const result = await Model.findOne(createQuery(id, q))
    if (!result) {
      throw Object.assign(new Error('id not found'), {
        name: 'NotFoundError',
        status: 404
      })
    }
    return result.toJSON()
  }

  async function query(reqQuery = {}) {
    if (reqQuery[opts.idKey]) {
      reqQuery = createQuery(reqQuery[opts.idKey], reqQuery)
    }
    if (opts.oldIdKey && reqQuery.fields) {
      reqQuery.fields = reqQuery.fields
        .split(',').concat(opts.oldIdKey).join(',')
    }
    const { res, count } = await performQuery(Model, opts, reqQuery)
    return {
      count,
      result: res.map(r => r.toJSON())
    }
  }

  async function remove(id, q) {
    let result = await Model.remove(createQuery(id, q))
    result = result && result.toJSON()
    let { n } = result
    if (n) return result
    throw Object.assign(new Error(`Could not find data with id: ${id}`), {
      name: 'NotFoundError',
      status: 404
    })
  }

  return { save, load, query, remove }
}

function idCondition(id) {
  // If id is all numbers and 19 chars long, then its a snowflakeId
  const snowflakeId = new RegExp(/^\d{19}$/)
  let idKey = snowflakeId.test(id) ? 'snowflakeId' : '_id'
  return { [idKey]: id }
}

function updateFields(updatee, updator) {
  Object.assign(updatee, updator)
}
