import { expect } from 'chai'
import cache, { isCacheableValue } from 'shared/cache'

describe('Cache', () => {
  it('retrieves from cache', async () => {
    await cache.setAsync(123, { test: 'test' }, { ttl: 10 })
    const fromCache = await cache.getAsync(123)
    expect(fromCache).to.have.property('test', 'test')
  })
  it('deletes from cache', async () => {
    await cache.setAsync(123, { test: 'test' }, { ttl: 10 })
    let fromCache = await cache.getAsync(123)
    expect(fromCache).to.have.property('test', 'test')
    await cache.delAsync(123)
    fromCache = await cache.getAsync(123)
    expect(fromCache).to.not.exist //eslint-disable-line
  })
  it('deletes all cache', async () => {
    await cache.setAsync(123, { test: 'test' }, { ttl: 10 })
    let fromCache = await cache.getAsync(123)
    expect(fromCache).to.have.property('test', 'test')
    await cache.resetAsync()
    fromCache = await cache.getAsync(123)
    expect(fromCache).to.not.exist //eslint-disable-line
  })
  it('won\'t cache null', () => {
    expect(isCacheableValue(null)).to.be.false //eslint-disable-line
  })
  it('won\'t cache undefined', () => {
    expect(isCacheableValue(undefined)).to.be.false //eslint-disable-line
  })
  it('won\'t cache false', () => {
    expect(isCacheableValue(false)).to.be.false //eslint-disable-line
  })
  it('will cache objects', () => {
    expect(isCacheableValue({})).to.be.true //eslint-disable-line
  })
})
