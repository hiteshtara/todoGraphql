import config from 'config'
import cacheManager from 'cache-manager'
import redisStore from 'cache-manager-redis'
import Promise from 'bluebird'

export const isCacheableValue = function(value) {
    return value !== null && value !== false && value !== undefined
}

const memoryCache = cacheManager.caching({
  store: 'memory',
  max: 100,
  ttl: 10,
  isCacheableValue
})

const caches = [memoryCache]
/* istanbul ignore next */ //no redis in test
if (config.redis && config.redis.uri) {
  caches.push(cacheManager.caching({
    store: redisStore,
    url: config.redis.uri,
    isCacheableValue,
    ttl: 300
  }))
}

const cache = cacheManager.multiCaching(caches)
cache.getAsync = Promise.promisify(cache.get)
cache.setAsync = Promise.promisify(cache.set)
cache.delAsync = Promise.promisify(cache.del)
cache.resetAsync = async () => {
  await Promise.all(caches.map(c => {
    return c.reset()
  }))
}
export default cache
