import url from 'url'
import { some, get } from 'lodash'

export function isValidRedirect(redirectUrl, { institution, host: inHost }) {
  const parsedUrl = url.parse(redirectUrl)
  if (!parsedUrl.host) {
    return true
  }
  if (inHost === parsedUrl.host) {
    return true
  }
  if (/\.kuali\.co$/.test(parsedUrl.host)) {
    return true
  }
  if (
    some(get(institution, 'validRedirectHosts', []), host => {
      return parsedUrl.host === host
    })
  ) {
    return true
  }
  return false
}
