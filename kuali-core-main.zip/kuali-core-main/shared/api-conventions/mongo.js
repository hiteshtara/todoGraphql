/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

// NOTE!!!
// =======
// Most of the query language that we accept here is duplicated in the
// `elasticsearch.js` file in this same folder. If you change anything here, you
// should also change it there.

import { each, isEmpty, map, omit, reduce } from 'lodash'

export default async function apiQuery(Model, opts, query) {
  const countCursor = buildCursor(Model, opts, query)
  let resCursor = buildCursor(Model, opts, query)
  resCursor = paging(resCursor, opts, query)
  const [count, res] = await Promise.all([
    countCursor.count().exec(),
    resCursor.exec()
  ])
  return { count, res }
}

function buildCursor(Model, opts, query) {
  let _query = {}
  let _projection
  if (query.$or) _query.$or = query.$or
  if (query.$and) _query.$and = query.$and
  // full text search
  if (query.q) {
    const searchStr = query.q.replace(/[#-.]|[[-^]|[?|{}]/g, '\\$&')
    const fullTextSearch = map(opts.fields, field => ({
      [field]: new RegExp(`.*${searchStr}.*`, 'i')
    }))
    if (_query.$or) {
      _query.$and = (_query.$and || [])
        .concat([{ $or: _query.$or }, { $or: fullTextSearch }])
      delete _query.$or
    } else {
      _query.$or = fullTextSearch
    }
  }
  // attribute search
  const searchFields = omit(query, ['sort', 'limit', 'skip', 'q', 'fields'])
  if (!isEmpty(searchFields)) {
    each(searchFields, (val, key) => {
      if (key[0] === '$') return
      if (val === 'null') val = null
      if (key[0] === '_') key = key.substr(1)
      if (isGreaterOrLesser(val)) {
        _query[key] = greaterOrLesserQuery(val)
      } else {
        _query[key] = val
      }
    })
  }
  // field filtering
  if (query.fields) {
    const fields = query.fields.split(',')
    _projection = reduce(
      fields,
      (memo, field) => {
        return { ...memo, [field]: 1 }
      },
      {}
    )
  }
  let cursor = Model.find(_query, _projection)
  // sorting
  if (query.sort) {
    const sorts = reduce(
      query.sort.split(','),
      (memo, field) => {
        const dir = field.indexOf('-') === 0 ? -1 : 1
        const attr = field.indexOf('-') === 0 ? field.substr(1) : field
        return { ...memo, [attr]: dir }
      },
      {}
    )
    cursor = cursor.sort(sorts)
  }
  return cursor
}

function paging(cursor, opts, query) {
  let limit = 'limit' in query ? +query.limit : opts.defaultLimit || 100
  let skip = 'skip' in query ? +query.skip : 0
  if (isNaN(skip) || skip < 0) {
    skip = 0
  }
  if (isNaN(limit) || limit < 0) {
    limit = opts.defaultLimit || 100
  }
  limit = Math.min(limit, opts.maxLimit || 100000)
  return cursor.skip(skip).limit(limit)
}

function isGreaterOrLesser(val) {
  return /^[gl]te?\(\d+(\.\d+)?\)$/.test(val)
}

function greaterOrLesserQuery(val) {
  const operator = `$${/^([gl]te?)\(/.exec(val)[1]}`
  const value = /\((\d+(\.\d+)?)\)/.exec(val)[1]
  return { [operator]: parseFloat(value) }
}
