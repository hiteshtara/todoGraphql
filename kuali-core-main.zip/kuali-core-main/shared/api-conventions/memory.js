/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* @flow */

/*
 * This is built in accordance to:
 * https://docs.google.com/document/d/1x0fQM7HIkSalw0gc_vYTFzZukmL6MW7EX_qY1x_
 *   jEqg/edit#heading=h.g8otbmvslgi2
 * (as of 11-20-15)
 *
 * This is only an in-memory version. We also need an ElasticSearch version
 */

import Fuse from 'fuse.js'
import { all, filter, isEmpty, map, omit, reduce, set, get } from 'lodash'

type Query = {
  sort?: string;
  limit?: number;
  page?: number;
  q?: string;
  fields?: string;
} & Object;

export default function apiQuery(
  items: Array<Object>,
  query: Query,
  keysToSearch: Array<string>
) {
  items = fullTextSearch(query, keysToSearch, items)
  items = sorting(query, items)
  items = attributeSearch(query, items)
  items = fieldFiltering(query, items)
  items = paging(query, items)
  return items
}

function sorting(query, items) {
  if (!query.sort) {
    return items
  }
  let sorts = map(query.sort.split(','), field => ({
    ascending: field.indexOf('-') !== 0,
    field: field.indexOf('-') === 0 ? field.substr(1) : field
  }))
  return items.sort((a, b) => {
    for (let i = 0; i < sorts.length; ++i) {
      let { field, ascending } = sorts[i]
      let num = ascending ? 1 : -1
      let first = numify(a, field)
      let second = numify(b, field)
      if (first !== second) {
        return first < second ? -num : +num
      }
    }
    return 0
  })
}

function paging(query, items) {
  let limit = 'limit' in query ? +query.limit : 100
  let skip = 'skip' in query ? +query.skip : 0
  if (isNaN(skip) || skip < 0) {
    skip = 0
  }
  if (isNaN(limit) || limit < 0) {
    limit = 100
  }
  limit = Math.min(limit, 1000)
  return items.slice(skip, skip + limit)
}

function attributeSearch(query, items) {
  let searchFields = omit(query, ['sort', 'limit', 'skip', 'q', 'fields'])
  let itemsToReturn = items
  return isEmpty(searchFields)
    ? items
    : filter(itemsToReturn, item =>
        all(searchFields, (val, key) =>
          stringify(get(item, key)) == stringify(val)
        )
      )
}

function fullTextSearch(query, keys, items) {
  if (!query.q) {
    return items
  }
  let searcher = new Fuse(items, { keys })
  return searcher.search(query.q)
}

function fieldFiltering(query, items) {
  if (!query.fields) {
    return items
  }
  let fields = query.fields.split(',')
  return map(items, item => {
    return reduce(fields, (memo, field) => {
      let val = get(item, field)
      if (val !== undefined && val !== null) {
        set(memo, field, val)
      }
      return memo
    }, {})
  })
}


function numify(item, field) {
  let val = get(item, field)
  return isNaN(+val) ? val : +val
}

function stringify(val) {
  if (val === true) {
    return 'true'
  }
  if (val === false) {
    return 'false'
  }
  return val
}
