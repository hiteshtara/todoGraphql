/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable camelcase, complexity, max-len */

import Bluebird from 'bluebird'
import { each, isEmpty, omit, reduce, set, clamp, get } from 'lodash'

export default async function apiQuery(Model, opts, query) {
  const { query: elasticsearchQuery, options } = buildQuery(Model, opts, query)
  const { hits } = await Bluebird.fromCallback(cb => {
    Model.esSearch(elasticsearchQuery, options, cb)
  })
  return {
    count: hits.total,
    res: hits.hits.map(hit => hit._source)
  }
}

function buildQuery(Model, opts, query) {
  query = Object.assign(
    {
      sort: opts.defaultSort
    },
    query
  )
  let _query = set({}, 'query.bool', {
    must: [],
    must_not: []
  })
  let _options = {}

  // full text search
  if (query.q) {
    _query.query.bool.must.push({
      query_string: {
        query: `*${query.q}*`,
        fields: opts.fields || /* istanbul ignore next */ []
      }
    })
  }

  // attribute search
  const searchFields = omit(query, ['sort', 'limit', 'skip', 'q', 'fields'])
  if (!isEmpty(searchFields)) {
    each(searchFields, (val, key) => {
      /* istanbul ignore if */ if (key[0] === '_') key = key.substr(1)
      if (hasKeywordField(Model, key)) {
        key = `${key}.keyword`
      }
      if (val === 'null') {
        _query.query.bool.must_not.push({
          exists: { field: key }
        })
      } else if (isGreaterOrLesser(val)) {
        _query.query.bool.must.push({
          range: { [key]: greaterOrLesserQuery(val) }
        })
      } else {
        _query.query.bool.must.push({
          term: { [key]: val }
        })
      }
    })
  }

  // field filtering
  // if (query.fields) {
  //   const fields = query.fields.split(',')
  //   set(_query, 'query.fields', fields)
  // }

  // sorting
  // TODO sorting not supported in mongoosastic until we can add fielddata to
  // the mappings.
  // @see https://www.elastic.co/guide/en/elasticsearch/reference/current/fielddata.html
  // @see https://github.com/mongoosastic/mongoosastic/issues/324
  if (query.sort) {
    const sorts = reduce(
      query.sort.split(','),
      (memo, field) => {
        const dir = field.indexOf('-') === 0 ? 'desc' : 'asc'
        let attr = field.replace(/^-/, '')
        if (hasKeywordField(Model, attr)) {
          attr = `${attr}.keyword`
        }
        return memo.concat({ [attr]: dir })
      },
      []
    )
    sorts.push('_score')
    set(_options, 'sort', sorts)
  }

  // paging
  const defaultLimit = opts.defaultLimit || 100
  let limit = 'limit' in query ? +query.limit : defaultLimit
  let skip = 'skip' in query ? +query.skip : 0
  limit = clamp(limit || defaultLimit, 0, opts.maxLimit || 100000)
  skip = clamp(skip || 0, 0, Infinity)
  set(_query, 'from', skip)
  set(_query, 'size', limit)

  return {
    query: _query,
    options: _options
  }
}

function hasKeywordField(Model, attr) {
  return Boolean(
    get(Model, `schema.paths[${attr}].options.es_fields.keyword`) ||
      get(Model, `_esCustomProperties.${attr}.fields.keyword`)
  )
}

function isGreaterOrLesser(val) {
  return /^[gl]te?\(\d+(\.\d+)?\)$/.test(val)
}

function greaterOrLesserQuery(val) {
  const operator = `${/^([gl]te?)\(/.exec(val)[1]}`
  const value = /\((\d+(\.\d+)?)\)/.exec(val)[1]
  return { [operator]: parseFloat(value) }
}
