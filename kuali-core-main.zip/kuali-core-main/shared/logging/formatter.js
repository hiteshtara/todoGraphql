/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/**
 * A lot of the things in here came from this project:
 * -- https://github.com/thlorenz/bunyan-format --
 */
import stringify from 'json-stable-stringify'
import { assign, omit, pick, isPlainObject } from 'lodash'
import { Writable } from 'stream'
import { inherits } from 'util'
import moment from 'moment'

const levelNames = {
  10: 'TRACE',
  20: 'DEBUG',
  30: 'INFO',
  40: 'WARN',
  50: 'ERROR',
  60: 'FATAL',
  70: 'AUDIT'
}

const rootFields = ['ts', 'level', 'message', 'data', 'service', 'priority',
  'institutionId', 'userId', 'requestId', 'sessionId', 'serverId', 'method',
  'endpoint', 'environment']
const trimmedFields = ['name', 'time', 'msg', '_audit', '_sensitive']

inherits(FormattingWritable, Writable)
function FormattingWritable (opts, delegate = process.stdout) {
  if (!(this instanceof FormattingWritable)) {
    return new FormattingWritable(opts, delegate)
  }

  Writable.call(this, opts)
  this.out = delegate
  return null
}

FormattingWritable.prototype._write = function (chunk, __, cb) {
  try {
    this.out.write(formatRecord(JSON.parse(chunk)))
  } catch (e) {
    this.out.write(`${chunk}\n`)
  }
  cb()
}

/**
 * Print out a single result, considering input options.
 */
function formatRecord(rec) {
  const record = pick(rec, rootFields)

  if (rec._audit === true) {
    record.level = 'AUDIT'
  } else if (rec._sensitive === true) {
    record.level = 'SENSITIVE'
  } else {
    record.level = levelNames[rec.level]
  }
  record.ts = moment(rec.time).valueOf()
  record.message = rec.msg

  let data = {}
  if (isPlainObject(rec.data)) {
    data = rec.data
  } else if (rec.data) {
    data = { data: rec.data }
  }
  data = assign({}, data, omit(rec, trimmedFields.concat(rootFields)))
  record.data = data

  return `${stringify(record, compareFields)}\n`
}

const priority = ['ts', 'level', 'sessionId', 'requestId', 'message']
function compareFields(left, right) {
  const leftPriority = priority.indexOf(left.key)
  const rightPriority = priority.indexOf(right.key)

  let result
  if (leftPriority === -1 && rightPriority === -1) {
    result = left.key < right.key ? -1 : 1
  } else if (leftPriority === -1) {
    result = 1
  } else if (rightPriority === -1) {
    result = -1
  } else {
    result = leftPriority < rightPriority ? -1 : 1
  }

  return result
}

export { FormattingWritable }
