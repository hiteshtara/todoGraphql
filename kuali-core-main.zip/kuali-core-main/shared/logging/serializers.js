/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { isObject, omit, pick, pickBy } from 'lodash'

const importantHeaders = ['content-type', 'content-length', 'user-agent']

export function error(err) {
  if (!isObject(err)) return err

  const result = pick(err, ['message', 'name', 'stack'])
  Object.keys(err).forEach((k) => {
    if (err[k] !== undefined) {
      result[k] = err[k]
    }
  })
  return result
}

export function request(req) {
  if (!isObject(req)) return req

  const result = pick(req, ['method', 'path', 'query', 'ip', 'originalUrl'])
  result.headers = pick(req.headers,
    Object.keys(req.headers)
      .filter(f => !/^(connection|accept|cookie|authorization).*/i.test(f)))
  // Log just json bodies for now
  if (req.body && /json/.test(req.get('content-type'))) {
    result.body = req.body
  }

  return result
}

export function response(res) {
  if (!isObject(res)) return res

  return {
    status: res.statusCode,
    headers: pickBy(res._headers, (v, k) => {
      if (typeof k !== 'string') return false
      return importantHeaders.indexOf(k) !== -1 || /^x-/.test(k)
    })
  }
}

export function user(usr) {
  return omit(usr, 'passwordDigest')
}

export function institution(org) {
  return omit(org, 'secret')
}

export default {
  request,
  response,
  error,
  user,
  institution,
  // aliases
  req: request,
  res: response,
  err: error
}
