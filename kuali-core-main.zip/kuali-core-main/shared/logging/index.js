/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import bunyan from 'bunyan'
import { isString, isObject, extend, set, omit } from 'lodash'
import { v4 as randomUUID } from 'uuid'

import { FormattingWritable } from './formatter'
import defaultSerializers from './serializers'

const validLevels = ['trace', 'verbose', 'debug', 'info', 'warn', 'error',
  'fatal', 'dev', 'none', 'audit']
const deprecatedLevels = ['tiny', 'silent']

const noop = () => {
}

let defaults = {
  level: 'info',
  serializers: defaultSerializers
}

export function __reset() {
  defaults = {
    level: 'info',
    serializers: defaultSerializers
  }
  defaultLogger = null
}

export let defaultLogger = null
export function initDefaults(config) {
  extend(defaults, config)
  if (config.name) {
    defaultLogger = createLogger(defaults)
    extendLogger(defaultLogger)
  }
}

function newLogger(name, options = {}) {
  if (isObject(name)) {
    options = omit(name)
    name = name.name || defaults.name
  }

  let {
    stream,
    streams,
    level = defaults.level,
    serializers = {},
    ...fields
    } = options

  name = name || defaults.name
  if (!name) {
    throw new Error('"name" is required to create a logger')
  }

  let deprecatedWarning
  if (validLevels.includes(level.toLowerCase()) === false) {
    if (deprecatedLevels.includes(level.toLowerCase())) {
      deprecatedWarning = {
        msg: `Use of deprecated log level: ${level}`,
        level
      }
      level = level === 'tiny' ? 'info' : level
    } else {
      const error = new Error(`invalid log level: ${level}`)
      error.level = level
      throw error
    }
  }

  serializers = extend({}, defaults.serializers, serializers)
  streams = streams || stream && [{ stream }]
  const logger = createLogger({ name, level, streams, serializers, ...fields })
  extendLogger(logger)

  if (deprecatedWarning) {
    logger.warn(deprecatedWarning)
  }
  logger.name = name
  return logger
}
export { newLogger as createLogger }

export function middleware(logger) {
  return function (req, res, next) {
    const requestId = req.requestId
      || req.headers['x-request-id']
      || randomUUID()
    const sessionId = req.sessionId || req.headers['X-Session-Id']

    let parent = req.log || logger
    req.log = parent.child({ requestId, sessionId })
    extendLogger(req.log)

    const start = process.hrtime()
    res.on('finish', () => {
      const diff = process.hrtime(start)
      req.log.info({
        req: omit(req, 'body.password'),
        res,
        duration: diff[0] * 1e3 + diff[1] * 1e-6
      }, 'request complete')
    })

    next()
  }
}

export default function (name, options) {
  const rootLogger = newLogger(name, options)
  return middleware(rootLogger)
}


/*******************************************************************************
 * Internal Functions
 ******************************************************************************/


function createLogger({ name, level, streams, serializers, ...fields }) {
  let logger
  if (level === 'silent' || level === 'none') {
    logger = validLevels.reduce((res, l) => set(res, l, noop), {})
    logger.child = () => logger
    delete logger.none
    delete logger.dev
    logger.level = () => level
  } else {
    if (!streams) {
      if (level === 'dev') {
        level = 'debug'
        streams = [{ stream: process.stdout }]
      } else {
        streams = [{ stream: new FormattingWritable() }]
      }
    }
    logger =
      bunyan.createLogger({ name, streams, level, serializers, ...fields })
  }
  return logger
}

function extendLogger(logger) {
  logger.audit = (meta, message) => {
    if (!message && isString(meta)) {
      message = meta
      meta = { _audit: true }
    } else {
      meta._audit = true
    }

    return logger.info(meta, message)
  }

  logger.sensitive = (meta, message) => {
    if (!message && isString(meta)) {
      message = meta
      meta = { _sensitive: true }
    } else {
      meta._sensitive = true
    }

    return logger.info(meta, message)
  }
}
