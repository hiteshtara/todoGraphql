/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import sinon from 'sinon'
import { isString } from 'lodash'
import moment from 'moment'
import { FormattingWritable } from '../formatter'

describe('Formatter', () => {

  let formatter, spy
  beforeEach(() => {
    spy = sinon.spy()
    formatter = new FormattingWritable({}, { write: spy })
  })

  function run(input, output) {
    formatter._write(isString(input)
      ? input
      : JSON.stringify(input), null, () => {})

    sinon.assert.calledWith(spy, `${output}\n`)
  }

  it('returns instance when used as function', () => {
    formatter = FormattingWritable()
    assert(formatter instanceof FormattingWritable)
  })

  it('writes out unparseable chunks', () => {
    const chunk = '{foo}'
    run(chunk, chunk)
  })

  it('handles an existing data object', () => {
    const ts = moment()
    run({ time: ts, data: { a: 1 } }, `{"ts":${ts.valueOf()},"data":{"a":1}}`)
  })

  it('handles an existing data value', () => {
    const ts = moment()
    run({ time: ts, data: 'hello world' }, `{"ts":${ts.valueOf()},"data":{"data":"hello world"}}`) //eslint-disable-line
  })

  it('sorts things', () => {
    const timestamp = '2016-01-29T00:00:00.000Z'
    run({
      a: 1,
      requestId: 'req',
      level: 50,
      sessionId: 'sess',
      time: timestamp,
      msg: 'message'
    }, `{"ts":${moment(timestamp).valueOf()},"level":"ERROR","sessionId":"sess","requestId":"req","message":"message","data":{"a":1}}`) //eslint-disable-line
  })
})
