/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { identity } from 'lodash'
import sinon from 'sinon'
import { expect, assert } from 'chai'
import { DEBUG } from 'bunyan'
import defaultExport, {
  createLogger,
  initDefaults,
  defaultLogger,
  __reset,
  middleware
} from '../index'

describe('Bunyan Logging', () => {

  let logger
  beforeEach(() => {
    __reset()
    logger = createLogger('test')
  })

  after(() => {
    initDefaults({ name: 'test', level: 'silent' })
  })

  it('creates both on default export', () => {
    const mw = defaultExport('test', {
      level: 'ERROR',
      serializers: { thing: identity }
    })
    expect(mw).to.be.a('function')
  })

  it('throws error if no name is given', () => {
    try {
      createLogger()
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert.ok(ex)
    }
  })

  it('takes a single alternate stream gracefully', () => {
    createLogger('test', { stream: process.stdout })
  })

  it('takes alternate output streams gracefully', () => {
    createLogger('test', { streams: [{ stream: process.stdout }] })
  })

  describe('defaults', () => {

    it('takes defaults and uses them', () => {
      const config = { level: 'debug' }
      initDefaults(config)
      logger = createLogger('test')
      expect(logger.level()).to.be.equal(DEBUG)
    })

    it('allows no name to be given if defaults are set', () => {
      initDefaults({ name: 'default-name' })
      logger = createLogger({ level: 'debug' })
      expect(logger.level()).to.be.equal(DEBUG)
      expect(logger).to.have.property('name').that.is.equal('default-name')
    })

    it('allows empty invocation when defaults are set', () => {
      initDefaults({ name: 'default-name' })
      createLogger()
    })

    it('exposes null defaultLogger if defaults not set', () => {
      expect(defaultLogger).to.not.exist // eslint-disable-line
    })

    it('exposes null defaultLogger if defaults do not include a name', () => {
      initDefaults({ level: 'debug' })
      expect(defaultLogger).to.not.exist // eslint-disable-line
    })

    it('exposes a defaultLogger if default name is set', () => {
      initDefaults({ name: 'default-name' })
      expect(defaultLogger).to.exist // eslint-disable-line
      expect(defaultLogger).to.have.property('info').that.is.a('function')
    })

  })

  describe('alternate levels', () => {

    describe('dev', () => {
      logger = createLogger({ level: 'dev' })
      expect(logger.level()).to.be.equal(DEBUG)
    })

    describe('audit', () => {

      it('simple message', () => {
        logger.audit('simple message')
      })

      it('message with metadata', () => {
        logger.audit({ requestId: 'random string here' }, 'message with meta')
      })
    })

    describe('sensitive', () => {

      it('simple message', () => {
        logger.sensitive('simple message')
      })

      it('message with metadata', () => {
        logger.sensitive({ a: 'random string here' }, 'message with meta')
      })
    })

    it('throws on invalid log level', () => {
      try {
        createLogger('test', { level: 'nonsense' })
        assert.fail('should have thrown an error')
      } catch (err) {
        assert.instanceOf(err, Error)
        expect(err).to.have.property('level', 'nonsense')
      }
    })

    it('warns on deprecated level', () => {
      createLogger('test', { level: 'tiny' })
    })

    it('creates a noop logger', () => {
      logger = createLogger('test', { level: 'silent' })
      expect(logger).to.be.an('object').that.contains.keys(['trace', 'verbose',
        'debug', 'info', 'warn', 'error', 'fatal', 'audit', 'sensitive'])
    })

    it('noop logger returns correct level', () => {
      logger = createLogger('test', { level: 'none' })
      expect(logger.level()).to.be.equal('none')
    })
  })

  describe('serializers', () => {

    describe('errors', () => {

      let err
      beforeEach(() => {
        err = new Error('test error')
      })

      it('pulls keys off the error', () => {
        err.prop = 'test property'
        err.undefinedProp = undefined
        logger.error({ err }, 'error logged')
      })

      it('skips primitive errors', () => {
        logger.error({ error: 'a thing is broken' })
      })

    })

    describe('users', () => {

      let user
      beforeEach(() => {
        user = {
          id: 'idstring',
          name: 'John',
          username: 'test',
          password: 'super secret'
        }
      })

      it('logs the user and strips the password', () => {
        logger.info({ user }, 'simple log of user object')
      })

    })

    describe('institutions', () => {

      let institution
      beforeEach(() => {
        institution = {
          id: 'idstring',
          name: 'MIT',
          secret: 'hash string'
        }
      })

      it('logs the institution and strips the secret', () => {
        logger.info({ institution })
      })

    })

    describe('req/res', () => {

      it('returns primitives as is', () => {
        logger.info({ req: null, res: 'string response thing' })
      })

      it('does headers in the response', () => {
        logger.info({ res: { _headers: 'Host: localhost:8080' } })
      })

      it('does json bodies', () => {
        const req = { body: { key: 'value' }, headers:
          { host: 'localhost:8080' } }
        req.get = sinon.stub()
          .withArgs('content-type')
          .returns('application/json')
        logger.info({ req })
        sinon.assert.calledWith(req.get, 'content-type')
      })

      it('does not json bodies', () => {
        const req = { body: { key: 'value' }, headers:
          { host: 'localhost:8080' } }
        req.get = sinon.stub()
          .withArgs('content-type')
          .returns('application/html')
        logger.info({ req })
        //I realize I'm not asserting anything here
        //this test is simply to catch that one branching logic
        //for code coverage :sad_panda:
      })

    })

    describe('middleware', () => {
      it('should remove passwords from logging', () => {
        const testReq = {
          requestId: 1234,
          sessionId: 1234,
          body: {
            password: 'password',
            username: 'testuser'
          }
        }
        const testRes = {
          on: (type, cb) => cb()
        }
        const testNext = sinon.spy()
        const testInfo = sinon.spy()
        const mockLogger = {
          child: () => ({ info: testInfo })
        }
        const mwToTest = middleware(mockLogger)
        mwToTest(testReq, testRes, testNext)

        expect(testInfo.firstCall.args[0].req.body.password)
          .to.be.an('undefined')
        sinon.assert.called(testNext)
      })
    })
  })
})
