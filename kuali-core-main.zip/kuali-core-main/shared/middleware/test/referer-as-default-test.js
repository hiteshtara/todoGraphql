/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import refererAsDefault from '../referer-as-default'

describe('referer-as-default', () => {
  it('uses the referer header when there is no return_to', () => {
    const refererHeader = 'thisisthereferrerheader'
    let redirectedUrl

    const req = {
      query: {
      },
      get() {
        return refererHeader
      }
    }
    const res = {
      redirect(newUrl) {
        redirectedUrl = newUrl
      }
    }
    refererAsDefault(req, res, () => {
      throw new Error('next should not have been called')
    })

    assert.equal(req.query.return_to, refererHeader)
    assert(redirectedUrl.indexOf(refererHeader) > 0)
  })

  it('leaves the request alone if return_to is present', () => {
    const refererHeader = 'thisisthereferrerheader'
    const returnToValue = 'returntovalue'
    let redirectedUrl

    const req = {
      query: {
        return_to: returnToValue // eslint-disable-line camelcase
      },
      get() {
        return refererHeader
      }
    }
    const res = {
      redirect(newUrl) {
        redirectedUrl = newUrl
      }
    }
    refererAsDefault(req, res, () => {
      assert.equal(req.query.return_to, returnToValue)
      assert.equal(redirectedUrl, undefined)
    })
  })
})
