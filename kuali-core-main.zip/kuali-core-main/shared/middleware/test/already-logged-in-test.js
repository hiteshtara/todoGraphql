/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import sinon from 'sinon'
import seneca from 'shared/seneca'
import alreadyLoggedIn from '../already-logged-in'

describe('already-logged-in', () => {
  let sandbox

  beforeEach( () => {
    sandbox = sinon.sandbox.create()
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('no Authorization header', async () => {
    let nextCalled = false
    const req = {
      cookies: {},
      get() {
        return ''
      }
    }

    await alreadyLoggedIn(req, {}, () => {
      nextCalled = true
    })

    assert(nextCalled)
  })

  it('token on authorization header', async () => {
    let nextCalled = false
    let redirectCalled = false
    const req = {
      cookies: {},
      get() {
        return 'Authorization 111'
      },
      institution: {
        subdomain: 'kuali'
      },
      query: {}
    }

    const res = {
      redirect() {
        redirectCalled = true
      },
      locals: {
        connectionKey: true
      }
    }

    sandbox.stub(seneca, 'actAsync', async msg => {
      if (msg.cmd === 'getSecret') {
        return { secret: 'thesecret' }
      }
      if (msg.cmd === 'verify') {
        return { id: 222 }
      }
      return null
    })

    await alreadyLoggedIn(req, res, () => {
      nextCalled = true
    })

    assert(!nextCalled)
    assert(redirectCalled)
    seneca.actAsync.restore()
  })

  it('token on cookie', async () => {
    let nextCalled = false
    let redirectCalled = false
    const req = {
      cookies: {
        authToken: '3333'
      },
      get() {
        return ''
      },
      institution: {
        subdomain: 'kuali'
      },
      query: {}
    }

    const res = {
      redirect() {
        redirectCalled = true
      },
      locals: {
        connectionKey: true
      }
    }

    sandbox.stub(seneca, 'actAsync', async msg => {
      if (msg.cmd === 'getSecret') {
        return { secret: 'thesecret' }
      }
      if (msg.cmd === 'verify') {
        return { id: 222 }
      }
      return null
    })

    await alreadyLoggedIn(req, res, () => {
      nextCalled = true
    })

    assert(!nextCalled)
    assert(redirectCalled)
    seneca.actAsync.restore()
  })

  it('decoded object without id', async () => {
    let nextCalled = false
    let redirectCalled = false
    const req = {
      cookies: {
        authToken: '3333'
      },
      get() {
        return ''
      },
      institution: {
        subdomain: 'kuali'
      },
      query: {}
    }

    const res = {
      redirect() {
        redirectCalled = true
      },
      locals: {
        connectionKey: true
      }
    }

    sandbox.stub(seneca, 'actAsync', async msg => {
      if (msg.cmd === 'getSecret') {
        return { secret: 'thesecret' }
      }
      if (msg.cmd === 'verify') {
        return { }
      }
      return null
    })

    await alreadyLoggedIn(req, res, () => {
      nextCalled = true
    })

    assert(nextCalled)
    assert(!redirectCalled)
    seneca.actAsync.restore()
  })

  it('invalid secret', async () => {
    let nextCalled = false
    let redirectCalled = false
    const req = {
      cookies: {
        authToken: '3333'
      },
      get() {
        return ''
      },
      institution: {
        subdomain: 'kuali'
      },
      query: {}
    }

    const res = {
      redirect() {
        redirectCalled = true
      },
      locals: {
        connectionKey: true
      }
    }

    sandbox.stub(seneca, 'actAsync', async msg => {
      if (msg.cmd === 'getSecret') {
        throw new Error('no secret here')
      }
      if (msg.cmd === 'verify') {
        return { id: 222 }
      }
      return null
    })

    await alreadyLoggedIn(req, res, () => {
      nextCalled = true
    })

    assert(nextCalled)
    assert(!redirectCalled)
    seneca.actAsync.restore()
  })

})
