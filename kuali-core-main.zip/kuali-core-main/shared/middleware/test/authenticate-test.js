/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'

import authenticate from '../authenticate'

describe('Authenticate Middleware', () => {

  it('throws error on request with no institution', async () => {
    let middleware = authenticate()
    let req = {
      get() {
        return ''
      }
    }
    req.cookies = {}
    let res = {
      status(code) {
        this.code = code
        return () => {}
      },
      locals: { connectionKey: 'foo' }
    }
    await middleware(req, res, (err) => {
      assert.equal(err.httpCode, 401)
    })
  })

  it('throws secret error if there is an error getting a secret', async () => {
    let middleware = authenticate()
    let req = {
      get() {
        return 'Bearer thesupersecrettoken'
      },
      cookies: {},
      institution: {
        id: 'foo',
        subdomain: 'bar',
        features: {
          apps: {}
        }
      }
    }
    let res = {
      status(code) {
        this.code = code
        return () => {}
      },
      locals: { connectionKey: 'foo' }
    }
    await middleware(req, res, (err) => {
      assert.equal(err.httpCode, 401)
    })
  })

})
