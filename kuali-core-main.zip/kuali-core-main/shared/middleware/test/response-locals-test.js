/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { expect } from 'chai'
import mongoose from 'shared/mongoose'
import sinon from 'sinon'

import { connectionMap, clear, getConnection }
  from 'shared/mongoose/pool'
import middleware from '../response-locals'

describe('Response Locals Middleware Test | ', () => {
  after(() => clear())
  it('creates a connection if none exists', async () => {
    const TEST_VAL1 = 'Conny McConnface'
    const TEST_VAL2 = 'Notty McNotface'

    let sandbox = sinon.sandbox.create()
    sandbox.stub(mongoose, 'createConnection')
      .returns(TEST_VAL1)

    // Clear the pool and make sure it is empty
    clear()
    assert.equal(Object.keys(connectionMap).length, 0)

    let req = {}
    let res = {}

    // Get a connection from the middleware
    middleware(req, res, async () => {
      assert.equal(req.locals.connection, TEST_VAL1)
      assert.notEqual(req.locals.connectionKey, undefined)
      assert.equal(res.locals.connection, TEST_VAL1)
      assert.notEqual(res.locals.connectionKey, undefined)
    })

    // Make sure the connection is cached
    assert.equal(Object.keys(connectionMap).length, 1)

    // Make mongoose.createConnection return a different value
    sandbox.restore()
    sandbox.stub(mongoose, 'createConnection')
      .returns(TEST_VAL2)

    // Get a cached connection from the middleware
    middleware(req, res, async () => {
      assert.equal(req.locals.connection, TEST_VAL1)
      assert.notEqual(req.locals.connectionKey, undefined)
      assert.equal(res.locals.connection, TEST_VAL1)
      assert.notEqual(res.locals.connectionKey, undefined)
    })
    expect(() => getConnection()).to.throw('connectionKey required')

    sandbox.restore()
    clear()
  })
})
