/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'

export default async function(req, res, next) {
  let header = req.get('Authorization') || ''
  let token = header.split(' ')[1] || null
  if (!token) {
    token = req.cookies.authToken
  }
  if (!token) {
    return next()
  }

  let secret
  try {
    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: req.institution.subdomain },
      connectionKey: res.locals.connectionKey
    })
    secret = value.secret
    let decoded = await seneca.actAsync({
      role: 'token',
      cmd: 'verify',
      token,
      secret,
      connectionKey: res.locals.connectionKey
    })
    if (decoded && decoded.id) {
      let location = req.query.return_to || '/apps'
      return res.redirect(location)
    }

    return next()
  } catch (err) {
    return next()
  }
}
