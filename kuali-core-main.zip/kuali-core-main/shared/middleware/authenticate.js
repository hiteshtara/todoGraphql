/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import ServiceAgent from 'service2service'
import config from 'config'
import cache from 'shared/cache'
import { UnauthorizedError, ForbiddenError } from 'shared/errors'
import { includes, omit, flatten } from 'lodash'

let loadingError = Symbol('loading error')
let secretError = Symbol('secret loading error')
let notFoundError = Symbol('not found error')

const serviceAgent = new ServiceAgent({
  secret: config.serviceSecret,
  expire: 60, // 1 minute
  disableSingleUse: true
})

export default function authenticate(options = { allowAnonymous: false }) {
  const roleRequired = !!options.role || !!options.roles
  const userRequired = !options.allowAnonymous ||
    roleRequired
  const roles = flatten([options.role, options.roles])
  return async (req, res, next) => {
    const header = req.get('Authorization') || ''
    const headerToken = header.split(' ')[1]
    const authToken = options.useCookie
      ? (req.cookies && req.cookies.authToken)
      : headerToken
    let user = req.user

    if (!user && authToken) {
        user = await getCachedUser(req, res, authToken)
    }

    if (userRequired && !user) {
      return next(new UnauthorizedError())
    }

    if (roleRequired && !includes(roles, user.role)) {
      return next(new ForbiddenError())
    }

    req.user = user
    return next()
  }
}

async function getCachedUser(req, res, authToken) {
  let user = await cache.getAsync(
    `authTokens:${authToken}:${res.locals.connectionKey}`)
  if (!user) {
    user = await getUser(req, res, authToken)
    if (user && !user.service) {
      await cache.setAsync(
        `authTokens:${authToken}:${res.locals.connectionKey}`, user)
    }
  }
  return user
}

async function getUser(req, res, authToken) {
  const connectionKey = res.locals.connectionKey
  let user
  try {
    user = await getInstitutionUser(req, { connectionKey }, authToken)
  } catch (error) {
    //regular auth failed, handling below
  }

  if (!user) {
    try {
      user = await getServiceUser(req, authToken)
    } catch (error) {
      //service auth failed, handling below
    }
  }

  if (user && req.institution) {
    let { apps } = req.institution.features
    if (user.role !== 'admin') {
      apps = omit(apps, ['workflow', 'groups'])
    }
    user.apps = apps
  }
  return user
}

async function getInstitutionUser(req, options, token) {
  options = Object.assign({
    institution: req.institution && req.institution.subdomain
  }, options)
  const { connectionKey } = options

  const secret = await getSecretFor(options.institution, connectionKey)
  let decoded = await seneca.actAsync({
    role: 'token',
    cmd: 'verify',
    token,
    secret,
    connectionKey
  })
  return await loadUser(decoded.id, decoded.impersonatedBy, connectionKey)
}

async function getServiceUser(req, token) {
  let { user } = await serviceAgent.verify(token)
  user = Object.assign({
      id: 'service-user'
    }, user, {
      role: 'service',
      service: true
    })
  return user
}

async function getSecretFor(subdomain, connectionKey) {
  try {
    let { secret } = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain },
      connectionKey
    })
    return secret
  } catch (secretLoadingError) {
    throw { errorType: secretError, secretLoadingError }
  }
}

async function loadUser(id, impersonatedBy, connectionKey) {
  try {
    let user = await seneca.actAsync({
      role: 'users',
      cmd: 'load',
      id,
      connectionKey
    })
    if (impersonatedBy) {
      user.impersonatedBy = impersonatedBy.id
      user.displayName =
        `${user.displayName} (impersonated by ${impersonatedBy.displayName})`
    }
    return user
  } catch (error) {
    if (/id not found/.test(error.message)) {
      throw { errorType: notFoundError, error }
    } else {
      throw { errorType: loadingError, error }
    }
  }
}
