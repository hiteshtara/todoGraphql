import config from 'config'
import RedRover from 'red-rover'
import { defaultLogger as logger } from 'shared/logging'

const MESSAGE = 'message'
const ACK = 'ack'
const redRover = new RedRover(config.cache, config.cache.silentFail)

redRover.client.on('ready', () => {
  logger.info({ 'red-rover': config.cache }, 'Red Rover connected.')
})

/* istanbul ignore else */
if (config.cache.silentFail) {
  logger.warn({ 'red-rover': config.cache }, 'Red Rover will silently fail')
}

export const subscriber = redRover.subscriber()
subscriber.on(MESSAGE, (channel, data) => {
  /* istanbul ignore else */
  if (channel === ACK) {
    logger.info(`Events ack from: ${data.msg.app}`)
  }
})

subscriber.subscribe(ACK)
  .then(() => {
    publisher.publish(ACK, { app: 'cor-main-mt' })
  })
  .catch(/* istanbul ignore next */(err) => {
    logger.error(`ERROR: flow events error: ${err}`)
    logger.error(err)
  })

export const publisher = redRover.publisher()

export default redRover
