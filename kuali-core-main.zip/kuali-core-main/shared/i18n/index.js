/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const labels = defineMessages({
  signIn: {
    id: 'label.signIn',
    description: 'Button/link text for signing in',
    defaultMessage: 'Sign In'
  },
  signOut: {
    id: 'label.signOut',
    description: 'Button/link text for signing out',
    defaultMessage: 'Sign Out'
  },
  home: {
    id: 'label.home',
    description: 'Button/link text for returning to the "home" screen',
    defaultMessage: 'Home'
  },
  cancel: {
    id: 'label.cancel',
    description: 'Button/link text for canceling',
    defaultMessage: 'Cancel'
  },
  save: {
    id: 'label.save',
    description: 'Button/link text for saving',
    defaultMessage: 'Save'
  },
  password: {
    id: 'label.password',
    description: 'Label for password fields',
    defaultMessage: 'Password'
  },
  search: {
    id: 'label.search',
    description: 'Button/link text for searching',
    defaultMessage: 'Search'
  },
  edit: {
    id: 'label.edit',
    description: 'Button/link text for editing something',
    defaultMessage: 'Edit'
  },
  editPermissions: {
    id: 'label.edit.permissions',
    description: 'Button/link text for editing permissions',
    defaultMessage: 'Edit Permissions'
  },
  done: {
    id: 'label.done',
    description: 'Button/link text for being finished with something',
    defaultMessage: 'Done'
  },
  name: {
    id: 'label.name',
    description: 'Label/header text for somethings name',
    defaultMessage: 'Name'
  },
  all: {
    id: 'label.all',
    description: 'Button/link text for the complete something',
    defaultMessage: 'All'
  },
  new: {
    id: 'label.new',
    description: 'Button/link text for a contextual creation',
    defaultMessage: 'New'
  },
  copy: {
    id: 'label.copy',
    description: 'Button/link text for copying something to the clipboard',
    defaultMessage: 'Copy'
  },
  next: {
    id: 'label.next',
    description: 'Button/link text for going to the next page of a list',
    defaultMessage: 'Next'
  },
  prev: {
    id: 'label.prev',
    description: 'Button/link text for going to the previous page of a list',
    defaultMessage: 'Prev'
  }
})

export const apps = defineMessages({
  core: {
    id: 'apps.core',
    description: 'Name of the Core product',
    defaultMessage: 'Core'
  },
  users: {
    id: 'apps.users',
    description: 'Name of Users application',
    defaultMessage: 'Users'
  },
  groups: {
    id: 'apps.groups',
    description: 'Name of Groups application',
    defaultMessage: 'Groups'
  },
  actions: {
    id: 'apps.actions',
    description: 'Name of the Actions application',
    defaultMessage: 'Actions'
  },
  workflow: {
    id: 'apps.workflow',
    description: 'Name of Workflow application',
    defaultMessage: 'Workflow'
  },
  curriculum: {
    id: 'apps.curriculum',
    description: 'Name of Curriculum application',
    defaultMessage: 'Curriculum'
  }
})

export const paging = defineMessages({
  size: {
    id: 'paging.pageSize',
    description: 'Number of records per page on paginated list',
    defaultMessage: '{count} Per Page'
  },
  current: {
    id: 'paging.current',
    description: 'Current page in total pages',
    defaultMessage: '{page} of {totalPages}'
  },
  range: {
    id: 'paging.range',
    description: 'Range of records with a total on a paginated list',
    defaultMessage: `{total, plural,
      =0 {No Results}
      one {One Result}
      other {{pageStart} - {pageEnd} of #}
    }`
  }
})

export const errors = defineMessages({
  simple: {
    id: 'errors.simple',
    description: 'Generic, simple error message with no details',
    defaultMessage: 'An error occurred'
  }
})

export default { labels, apps, paging }
