/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import stringify from 'json-stable-stringify'
import HttpError from './classes/http-error'

export default function errorHandler(err, req, res, next) { //eslint-disable-line no-unused-vars, max-len
  err = standardizeError(err)
  if (err.httpCode === 500) {
    req.log.error({ err }, 'STACK ERROR')
  }
  return res.status(err.httpCode).json({ errors: err.errors })
}

function standardizeError(err) {
  if (err instanceof HttpError) {
    return jsonify(err)
  }
  let code = err.code || err.status ||
    err.statusCode || 500
  if (isNaN(code)) {
    code = 500
  }
  err = Object.assign(new HttpError(code, err), err)
  return jsonify(err)
}

// avoiding json errors that express allows
function jsonify(item) {
  return JSON.parse(stringify(item))
}
