/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import bluebird from 'bluebird'
import Seneca from 'seneca'
import { merge } from 'lodash'
import { createLogger } from '../logging'

let logger
function getLogger() {
  if (!logger) {
    logger = createLogger(config.log).child({ source: 'seneca-shim' })
  }
  return logger
}

let seneca = getSenecaContext()
export default seneca

export function getSenecaContext() {
  let _seneca = Seneca(merge({}, config.seneca.options, {
    log: {
      level: 'info+',
      handler: senecaLoggingShim
    }
  }))
  _seneca.actAsync = bluebird.promisify(_seneca.act)
  return _seneca
}

function senecaLoggingShim() {
  const [, , level, type, plugin, _case, act, pattern, ...extras]
    = Array.prototype.slice.call(arguments)
  getLogger()[level]({ type, plugin, _case, act, pattern, extras })
}
