/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import wrapAsync from '../'

describe('wrapAsync', () => {
  it('calls next with error if one is thrown', done => {
    function nextFunction(err) {
      assert(err !== undefined)
      assert.equal(err.message, 'headed to next')
      done()
    }

    let wrappedFunction = wrapAsync(async () => {
      throw new Error('headed to next')
    })

    wrappedFunction({}, {}, nextFunction)
  })

  it('req and res are modified correctly', done => {
    const reqObj = {}
    const resObj = {}

    function nextFunction() {
      assert.equal(reqObj.dog, 'pluto')
      assert.equal(resObj.cat, 'tom')
      done()
    }

    let wrappedFunction = wrapAsync(async (req, res, next) => {
      req.dog = 'pluto'
      res.cat = 'tom'
      next()
    })

    wrappedFunction(reqObj, resObj, nextFunction)
  })

  it('should not send on res via return', done => {
    let sentValue = 'unset'
    const resObj = {
      send(toSend) {
        sentValue = toSend
      }
    }

    let wrappedFunction = wrapAsync(async () => {
      return 'was set'
    })

    wrappedFunction({}, resObj)

    process.nextTick(() => {
      assert.equal(sentValue, 'unset')
      done()
    })
  })
})
