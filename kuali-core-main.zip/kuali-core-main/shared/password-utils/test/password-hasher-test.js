/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { assert, expect } from 'chai'
import sinon from 'sinon'

import { compare, generatePassword } from '../index'

describe('Password Hasher', () => {
  it('validates password', async () => {
    let password = 'whatNownow'
    let expectedHash =
      '$2a$10$dzCPKeYon4OSZlCfs14.GefED6W5N66qL/gz/p2m35gLj1h87IL5.'
    let result = await compare(password, expectedHash)
    assert(result)
  })
  it('fails invalid password', async () => {
    let password = 'wrongpassword'
    let expectedHash =
      '$2a$10$dzCPKeYon4OSZlCfs14.GefED6W5N66qL/gz/p2m35gLj1h87IL5.'
    let result = await compare(password, expectedHash)
    assert(!result)
  })
})

describe('Password Generator', () => {
  let sandbox
  beforeEach(() => {
    sandbox = sinon.sandbox.create()
  })
  afterEach(() => {
    sandbox.restore()
  })
  it('generates 128 character password', async () => {
    const pw = await generatePassword()
    expect(pw).to.have.length(128)
  })
})
