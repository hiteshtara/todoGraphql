/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import bcrypt from 'bcrypt'
import bluebird from 'bluebird'
import crypto from 'crypto'

bcrypt.hashAsync = bluebird.promisify(bcrypt.hash)
bcrypt.compareAsync = bluebird.promisify(bcrypt.compare)

export async function hash(password) {
  return await bcrypt.hashAsync(password, 10)
}

export async function compare(password, hashedPassword) {
  return await bcrypt.compareAsync(password, hashedPassword)
}

export function generatePassword() {
  return crypto.randomBytes(96).toString('base64')
}
