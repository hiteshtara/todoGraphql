/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import express from 'express'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import request from 'supertest-as-promised'

import loadInstitution from '../'

let app = express()

let connectionKey
const responseLocals = {
  middleware(req, res, next) {
    res.locals = {
      connectionKey
    }
    next()
  }
}
app.use(responseLocals.middleware)
app.use(loadInstitution)
app.get('/', (req, res, next) => {
  res.status(200).json(req.institution)
  next()
})

app.use((err, req, res, next) => {
  if (err && err.code === 404) return res.status(404).end()
  res.end(500)
  return next()
})

describe('Institution Loader Middleware', () => {
  let sandbox

  beforeEach( () => {
    sandbox = sinon.sandbox.create()
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('populates req.institution', async () => {
    connectionKey = 'test'
    sandbox.stub(seneca, 'actAsync').returns(
      new Promise(accept => {
        return accept({ subdomain: 'kuali' })
      })
    )
    let res = await request(app)
      .get('/')
      .expect(200)
    assert.equal(res.body.subdomain, 'kuali')
  })

  it('sets req.institution to null without connectionKey', async () => {
    connectionKey = null
    let res = await request(app)
      .get('/')
      .expect(200)
    assert.equal(res.body, '')
  })

  it('returns 404 if institution not found', async () => {
    connectionKey = 'test'
    sandbox.stub(seneca, 'actAsync').throws(new Error('error'))
    await request(app)
      .get('/')
      .expect(404)
  })
})
