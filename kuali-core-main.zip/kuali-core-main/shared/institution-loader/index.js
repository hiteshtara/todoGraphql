/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import cache from 'shared/cache'

export default async function institutionLoader(req, res, next) {
  try {
    if (!res.locals.connectionKey) {
      next()
      return
    }
    let institution = await getCachedInstitution(res.locals.connectionKey,
      res.locals.subdomain)

    if (!institution) {
      throw Error('No institution returned!')
    }

    req.institution = institution
    req.institutionId = institution.id && institution.id.toString()

    next()
  } catch (e) {
    next({ code: 404, message: 'Not Found' })
  }
}

async function getCachedInstitution(connectionKey, subdomain) {
  const cacheKey = `institutions:${subdomain}`
  let institution = await cache.getAsync(cacheKey)
  if (!institution) {
    institution = await getInstitution(connectionKey, subdomain)
    await cache.set(cacheKey, institution)
  }
  return institution
}

async function getInstitution(connectionKey, subdomain) {
  return await seneca.actAsync({
      role: 'institutions',
      cmd: 'load',
      data: {
        subdomain
      },
      connectionKey
    })
}
