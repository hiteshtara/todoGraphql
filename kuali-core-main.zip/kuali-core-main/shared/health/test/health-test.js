/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import express from 'express'
import supertest from 'supertest-as-promised'
import { Schema } from 'shared/mongoose'
import { getTestConnectionInfo } from 'shared/test-helpers'
import healthRouter, { health, metric } from '../index'

const { connection } = getTestConnectionInfo()
const Model = connection.model('TestHealth', new Schema({
  a: String,
  b: Number
}))

function createApp(opts) {
  const app = express()
  app.use(healthRouter(opts))
  return supertest(app)
}

describe('Health Check', () => {

  describe('metric', () => {

    it('should normalize options', () => {
      let met = metric({
        measure: 'foo',
        metric: 'bar',
        method: () => 'hello'
      })
      expect(met.measure).to.be.equal('foo')
      expect(met.metric).to.be.equal('bar')
      expect(met.method()).to.be.equal('hello')
    })

    it('should have sensible defaults', () => {
      let met = metric()
      expect(met.measure).to.be.equal('Unspecified')
      expect(met.metric).to.be.equal('Unspecified')
      expect(met.method()).to.be.equal('Unspecified')
    })

  })

  describe('health', () => {

    it('should return status OK with no metrics passed', async () => {
      let details = await health()
      expect(details.Status).to.be.equal('OK')
    })

    it('should return status OK with all succeeding metrics', async () => {
      let details = await health([
        metric()
      ])
      expect(details.Status).to.be.equal('OK')
    })

    it('should return status FAILED when metrics fail', async () => {
      let details = await health([
        metric({
          method: () => {
            throw new Error('foo')
          }
        })
      ])
      expect(details.Status).to.be.equal('FAILED')
    })

    it('should return normalized metrics in resulte', async () => {
      let details = await health([
        metric({
          measure: 'foo',
          metric: 'bar',
          method: () => 'hello'
        }),
        metric({
          measure: 'bar',
          metric: 'foo',
          method: () => {
            throw new Error('hello')
          }
        })
      ])
      expect(details.Metrics).to.be.eql([
        {
          Measure: 'foo',
          Metric: 'bar',
          Value: 'hello'
        },
        {
          Measure: 'bar',
          Metric: 'foo',
          Value: 'FAILED'
        }
      ])
    })

    it('should work with async methods', async () => {
      let details = await health([
        metric({
          measure: 'foo',
          metric: 'bar',
          method: () => Promise.resolve('hello')
        })
      ])
      expect(details.Metrics).to.be.eql([
        {
          Measure: 'foo',
          Metric: 'bar',
          Value: 'hello'
        }
      ])
    })

    it('uses fallback if metric method fails', async () => {
      let details = await health([
        metric({
          measure: 'foo',
          metric: 'bar',
          method: () => Promise.reject('error'),
          fallback: () => 'fallback'
        })
      ])
      expect(details.Metrics).to.be.eql([
        {
          Measure: 'foo',
          Metric: 'bar',
          Value: 'fallback'
        }
      ])
    })

  })

  describe('healthRouter', () => {

    before(async () => {
      await Model.remove({})
      await Model.create({ a: 'foo', b: 2 })
    })

    it('should return 204 with no models/extras', async () => {
      let request = createApp()
      await request.get('/').expect(204)
    })

    it('should return 204 with models', async () => {
      let request = createApp({
        models: [ Model ]
      })
      await request.get('/').expect(204)
    })

    it('should return 200 with models and results', async () => {
      let request = createApp({
        models: [ Model ],
        detail: true
      })
      let { body } = await request.get('/?detail=true').expect(200)
      expect(body.Status).to.be.equal('OK')
      expect(body.Message).to.be.equal('')
      expect(body.Metrics).to.have.length(2)
      expect(body.Metrics[0].Measure).to.be.equal('DB:testhealths')
      expect(body.Metrics[0].Metric).to.be.equal('count')
      expect(body.Metrics[1].Measure).to.be.equal('DB:testhealths')
      expect(body.Metrics[1].Metric).to.be.equal('size')
    })

    it('should return 503 if it fails', async () => {
      let request = createApp({
        extra: [
          metric({
            method: () => {
              throw new Error('error')
            }
          })
        ]
      })
      await request.get('/').expect(503)
    })

    it('should not return details if detail is set to false', async () => {
      let request = createApp()
      let { text } = await request.get('/?details=true').expect(204)
      expect(text).to.be.eql('')
    })

    it('should call fallback if stats fails', async () => {
      const oldMethod = Model.collection.stats
      Model.collection.stats = () => Promise.reject('stats error')
      try {
        let request = createApp({
          models: [ Model ],
          detail: true
        })
        let { body } = await request.get('/?detail=true').expect(200)
        expect(body).to.be.eql({
          Status: 'OK',
          Message: '',
          Metrics: [
            { Measure: 'DB:testhealths', Metric: 'count', Value: 1 },
            { Measure: 'DB:testhealths', Metric: 'size', Value: 1 }
          ]
        })
      } finally {
        Model.collection.stats = oldMethod
      }
    })

  })

})
