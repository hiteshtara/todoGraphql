# shared/health

This module is an opinionated way of structuring health check endpoints. It was
built for the Kuali Core development team's needs.

There are three exports for this module:

```js
import healthMiddleware, { health, metric } from 'shared/health'
```

## `metric`

Metric is a function that helps normalize metric options for consuming them in
the `health` method. Metric takes in three options and returns a normalized
object with sensible defaults (default values shown in input):

```js
metric({
  measure: 'Unspecified',
  metric: 'Unspecified',
  method: () => 'Unspecified'
})
// returns the following object:
// {
//   measure: 'Unspecified',
//   metric: 'Unspecified',
//   method: () => 'Unspecified'
// }
```

## `health`

This function takes in an array of objects in the format that `metric()`
returns. It then proceeds to call all of the functions specified in each
metric's `method` property. This function can return a promise or be an `async`
function. It will catch any errors thrown by the method, and change the status
of the overall health check to `FAILED`. If all of the metrics check out and
don't throw errors, then the status will be `OK`. `health()` returns a promise
which resolves to an object shown in the example below:

```js
let details = await health([
  metric({
    measure: 'DB',
    metric: 'connections',
    method: () => 1
  }),
  metric({
    measure: 'Google',
    metric: 'alive',
    method: async () => {
      let { statusCode } = request.get('http://www.google.com')
      if (statusCode === 200) return true
      throw new Error('If google is not accessible, how are we?')
    }
  })
])
```

`details` contains the following object

```js
{
  Status: 'OK',
  Message: '',
  Metrics: [
    {
      Measure: 'DB',
      Metric: 'connections',
      Value: 1
    },
    {
      Measure: 'Google',
      Metric: 'alive',
      Value: true
    }
  ]
}
```

If for some reason Google was inaccessible, this is what would be returned:

```js
{
  Status: 'FAILED',
  Message: 'If google is not accessible, how are we?',
  Metrics: [
    {
      Measure: 'DB',
      Metric: 'connections',
      Value: 1
    },
    {
      Measure: 'Google',
      Metric: 'alive',
      Value: 'FAILED'
    }
  ]
}
```

## healthMiddleware

The router is just a helpful wrapper around the health method, with some Kuali
Core specific needs. It will return an empty 204 response if the `Status` is
`OK`, or 503 if the `Status` is `FAILED` (`Status` referring to the property) of
the object that is returned from `health()`. You can set an option to accept a
`?detail=true` parameter if you wish to return the object in this way. It's set
to `false` by default.

```js
import healthMiddleware, { metric } from 'shared/health'
import { Model as Jobs } from '../resources/jobs/model'

app.get('/health', healthMiddleware({
  name: 'jobs',
  models: [ Jobs ],
  extra: [
    metric({
      measure: 'Google',
      metric: 'alive',
      method: async () => {
        let { statusCode } = request.get('http://www.google.com')
        if (statusCode === 200) return true
        throw new Error('If google is not accessible, how are we?')
      }
    })
  ],
  detail: false
}))
```

### options

* `name` - Used in logs for when a health check is run. `${name} health check`.
Defaults to `'unspecified'`

* `models` - An array of raw mongoose models to check. By default it will only
run a `.stats()` method can get the count and size of the collection. This does
not have any thresholds built in, but we may want to add this later. Defaults
to `[]`

* `extra` - Any extra metrics outside of Models you wish to check. It's
recommended that you use the included `metric()` function to build these
metrics. Defaults to `[]`

* `detail` - Set to `true` if you wish to accept `?detail=true` as a query
parameter and actually display the results of the `health()` call. Note that if
you do this, you will need to make sure your error messages are cleaned up and
do not contain any information that an attacker could use to compromise the
system. Defaults to `false`
