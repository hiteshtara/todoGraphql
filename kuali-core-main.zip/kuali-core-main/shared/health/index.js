/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

const OK = 'OK'
const FAILED = 'FAILED'

export default function healthMiddleware(opts) {
  let options = Object.assign({
    name: 'unspecified',
    models: [],
    extra: [],
    detail: true,
    getModel(model) {
      return model
    }
  }, opts)

  return async (req, res) => {
    let { log } = req
    let metrics = []

    options.models.forEach((Model) => {
      Model = options.getModel(Model, req, res)
      let measure = `DB:${Model.collection.collectionName}`
      let getStats = Model.collection.stats()

      metrics.push(
        metric({
          measure,
          metric: 'count',
          method: () => getStats.then((stats) => stats.count),
          fallback: () => Model.collection.count()
        }),
        // NOTE: This is no longer the case with newer versions of mongodb
        // Previous notes:
        // Model.collection.count() is used for the fallback because
        // Model.collection.stats() will fail if there are no documents in the
        // database. If Model.collection.count() fails then something bigger
        // is wrong
        metric({
          measure,
          metric: 'size',
          method: () => getStats.then((stats) => stats.size),
          fallback: () => Model.collection.count()
        })
      )
    })
    metrics = metrics.concat(options.extra)

    let details = await health(metrics)
    let failed = details.Status === FAILED

    if (failed) {
      res.status(503)
      res.end()
    } else if (req.query.detail) {
      res.json(details)
    } else {
      res.status(204)
      res.end()
    }

    log.info(details, `${options.name} health check`)
  }
}

export async function health(metrics = []) {
  let details = {
    Status: OK,
    Message: []
  }

  details.Metrics = await Promise.all(metrics.map(async (met) => {
    let value
    try {
      value = await met.method()
    } catch (err) {
      try {
        if (met.fallback) value = await met.fallback()
        else throw err
      } catch (err2) {
        details.Status = FAILED
        details.Message.push(err.message)
        value = FAILED
      }
    }
    return {
      Measure: met.measure,
      Metric: met.metric,
      Value: value
    }
  }))

  details.Message = details.Message.join(', ')
  return details
}

export function metric(opts) {
  return Object.assign({
    measure: 'Unspecified',
    metric: 'Unspecified',
    method: () => 'Unspecified'
  }, opts)
}
