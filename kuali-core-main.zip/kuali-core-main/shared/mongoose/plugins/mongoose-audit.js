/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable camelcase */

import { defaultLogger as logger } from 'shared/logging'

export default function auditPlugin(schema) {
  const logChange = async (doc, operation, date) => {
    saveHistory(doc, operation, date)
  }
  const saveHistory = async (doc, operation, date) => {
    const collectionName = getCollectionName(doc)
    const logEntry = createLogEntry(operation, collectionName, date, doc)
    logger.audit(logEntry, `${operation} on ${collectionName}`)
  }
  const createLogEntry = function(operation, collectionName, date, doc) {
    const result = {
      ts: date,
      operation,
      collection: collectionName,
      user: doc.updatedBy,
      objectId: doc.id
    }

    return result
  }
  const getCollectionName = doc => {
    const collection =
      doc._collection || (doc.constructor && doc.constructor.collection)
    return collection && collection.name
  }
  schema.add({
    updatedBy: {
      id: {
        type: String,
        es_indexed: false
      },
      impersonatedBy: {
        type: String,
        es_indexed: false
      }
    }
  })
  schema.pre('save', function(next) {
    if (this.isModified()) {
      if (!this.updatedBy || !this.updatedBy.id) {
        return next(
          new Error(
            'user required to save ' + `${getCollectionName(this)} data`
          )
        )
      }
      const date = new Date()
      logChange(this, this.isNew ? 'create' : 'update', date)
    }
    return next()
  })
  schema.pre('remove', function(next) {
    if (!this.updatedBy || !this.updatedBy.id) {
      return next(
        new Error(
          'user required to remove ' + `${getCollectionName(this)} data`
        )
      )
    }
    saveHistory(this, 'delete', new Date())
    return next()
  })
  schema.pre('update', function(next) {
    if (!this.updatedBy || !this.updatedBy.id) {
      return next(
        new Error(
          'user required to update ' + `${getCollectionName(this)} data`
        )
      )
    }
    saveHistory(this, 'update', new Date())
    return next()
  })
}
