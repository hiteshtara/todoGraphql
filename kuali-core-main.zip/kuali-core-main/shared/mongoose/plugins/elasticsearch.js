/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import Bluebird from 'bluebird'
import mongoosastic from 'mongoosastic'
import elasticsearch from 'shared/elasticsearch'

export default function elasticsearchPlugin(schema, config) {
  /* istanbul ignore if */ if (!elasticsearch) return

  config = Object.assign(
    {
      customProperties: {},
      transform: (raw, doc) => doc.toJSON()
    },
    config
  )

  assert(
    config.index,
    'You must pass in an index option to elasticsearch mongoose plugin'
  )

  schema.plugin(mongoosastic, {
    index: config.index,
    esClient: elasticsearch,
    customProperties: config.customPropeties,
    transform: config.transform
  })

  schema.static('_esCustomProperties', config.customProperties)

  schema.static('clearIndexAsync', async function() {
    await Bluebird.fromCallback(cb => {
      this.esClient.indices.delete({ index: config.index }, cb)
    }).catch(/* istanbul ignore next */ () => {})
    await Bluebird.fromCallback(cb => {
      this.esClient.indices.create({ index: config.index }, cb)
    }).catch(/* istanbul ignore next */ () => {})
  })

  schema.static('createMappingAsync', function() {
    return Bluebird.fromCallback(cb => {
      this.createMapping({}, cb)
    })
  })

  schema.static('synchronizeAsync', function() {
    return new Bluebird((resolve, reject) => {
      // TODO look on 'data' event to get progress
      this.synchronize().on('close', resolve).on('error', reject)
    })
  })

  schema.static('reindex', async function() {
    await this.clearIndexAsync()
    await this.createMappingAsync()
    await this.synchronizeAsync()
  })
}
