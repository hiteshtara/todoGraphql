/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import mongoose from 'shared/mongoose'

const rootConnection = mongoose.createConnection(
  config.db.uri,
  config.db.options
)

export const connectionMap = {}

export function getConnection(connectionKey) {
  if (!connectionKey) throw new Error('connectionKey required')
  if (!connectionMap[connectionKey]) {
    connectionMap[connectionKey] = rootConnection
  }
  return connectionMap[connectionKey]
}

/**
 * Clears all cached connections. When connections are requested they will be
 * re-established and cached. Useful for testing.
 */
export function clear() {
  Object.keys(connectionMap).forEach(key => {
    delete connectionMap[key]
  })
}
