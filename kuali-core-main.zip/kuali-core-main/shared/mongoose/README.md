# shared/mongoose


# Plugins

## shared/mongoose/plugins/compound-sparse-index

This plugin allows you to define a compound sparse index, where the index is
only upheld when one specified field has a value, or passes a given partial
filter expression.

### Options object

- `fields` (Object) - This is a hash keyed by field paths to the fields you wish
  to include in the compound index
  - `{fieldPath}` (Object)
    - `sort` (Number) - This should be included in every field. Indicates how
      the index should be sorted
    - `sparse` (Boolean) - This should be marked as `true` for the field you
      wish to mark as sparse, which means that the compound index will only be
      upheld if a value is passed here.
    - `filter` (Object) - The partial filter expression to use when deciding
      whether a sparse field value is sparse or not. Defaults to
      `{ $exists: true }`, which means that even if someone passes `null` or
      `undefined` as the value of the field, it will be considered filled and
      will uphold the compound index. It is recommended that you filter by type,
      like `{ $type: 'string' }` so that `null`ish values don't get included
- `opts` (Object) - The options to pass into the schema index function. If you
  which for this compound index to be unique, pass `{ unique: true }` as the
  value for this property

### Example

```js
import mongoose, { Schema } from 'shared/mongoose'
import compoundSparseIndex from 'shared/mongoose/plugins/compound-sparse-index'

let mySchema = new Schema({
  appId: {
    type: String,
    required: true
  },
  typeId: {
    type: String
  }
})

mySchema.plugin(compoundSparseIndex, {
  fields: {
    appId: { sort: 1 },
    typeId: {
      sort: 1
      sparse: true,
      filter: { $type: 'string' }
    }
  },
  opts: {
    unique: true
  }
})

let Model = mongoose.model('MyModel', mySchema)

Model
  // Creates a model
  .create({
    appId: 'foo',
    typeId: 'bar'
  })
  // Creates another one, does not throw unique error
  .then(() => Model.create({
    appId: 'foo'
  }))
  // Tries to create another one, but throws unique error
  .then(() => Model.create({
    appId: 'foo',
    typeId: 'bar'
  })
  // Creates another one, but does not throw unique error because there is a
  // different appId
  .then(() => Model.create({
    appId: 'foo1',
    typeId: 'bar'
  }))
```
