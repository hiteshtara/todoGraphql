/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import mongoose from 'mongoose'
import { identity, get, set } from 'lodash'
import sparseIndex from 'shared/mongoose/plugins/compound-sparse-index'

const _create = mongoose.Schema.bind(mongoose)
mongoose.Promise = Promise

function newSchema(def, attrs) {
  const originalTransform = get(attrs, 'toJSON.transform', identity)
  const schema = _create(def, set(attrs, 'toJSON.transform', (doc, obj) => {
    Object.keys(schema.paths).forEach(path => {
      if (get(obj, path) === undefined) {
        set(obj, path, null)
      }
    })

    // For backwards compat, if snowflakeId exists then return
    // snowflakeId as id, include new ObjectId as newId attribute
    if (obj.snowflakeId) {
      obj.id = obj.snowflakeId
      obj.newId = obj._id
    } else {
      obj.id = obj._id
    }

    delete obj._id
    delete obj.__v
    delete obj.snowflakeId

    originalTransform(doc, obj)
  }))

//Custom options
  sparseUniqueStringOption(schema)

  return schema
}

//these properties need to carry over from the Schema object
//TODO: future-proof this
const props = [
  'interpretAsType',
  'indexTypes',
  'Types',
  'ObjectId'
]
props.forEach(prop => {
  newSchema[prop] = mongoose.Schema[prop]
})
mongoose.Schema = newSchema
const connect = mongoose.connect.bind(mongoose)
mongoose.connect = function() {
  if (!mongoose.connection.db) {
    return connect(...arguments)
  }
  return mongoose
}

export default mongoose
export const Schema = mongoose.Schema

function sparseUniqueStringOption(schema) {
  Object.keys(schema.paths).forEach(key => {
    if (schema.paths[key].options.sparseUniqueString === true) {
      sparseUniqueIndex(key, schema)
    }
  })

  schema.pre('validate', function (next) {
    Object.keys(schema.paths).forEach(key => {
      if (schema.paths[key].options.sparseUniqueString === true
        && typeof this[key] === 'string' && this[key].trim() === '') {
        this[key] = undefined
      }
    })
    next()
  })
}

function sparseUniqueIndex(field, schema) {
  schema.plugin(sparseIndex, {
    fields: {
      [field]: {
        sort: 1,
        sparse: true,
        filter: { $type: 'string' }
      }
    },
    opts: {
      unique: true
    }
  })
}
