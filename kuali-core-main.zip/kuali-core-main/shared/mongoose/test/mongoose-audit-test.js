/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import sinon from 'sinon'
// import { defaultLogger as logger } from 'shared/logging'
import audit from '../plugins/mongoose-audit'

describe('Mongoose Audit Plugin', () => {
  let sandbox
  const errorSchema = {
    preFunctions: {
      _collection: {
        name: 'test'
      },
      isModified() {
        return true
      }
    },
    pre(key, func) {
      this.preFunctions[key] = func
    },
    add() {}
  }
  const unmodifiedSchema = {
    preFunctions: {
      isModified() {
        return false
      }
    },
    pre(key, func) {
      this.preFunctions[key] = func
    },
    add() {}
  }
  const updateSchema = {
    preFunctions: {
      _collection: {
        name: 'test'
      },
      isModified() {
        return true
      },
      isNew: false,
      updatedBy: {
        id: 'test'
      }
    },
    pre(key, func) {
      this.preFunctions[key] = func
    },
    add() {}
  }
  beforeEach(() => {
    sandbox = sinon.sandbox.create()
  })
  afterEach(() => {
    sandbox.restore()
  })
  it('throws error on save without updatedBy', () => {
    const next = sinon.spy()
    audit(errorSchema)
    errorSchema.preFunctions.save(next)
    sinon.assert.calledWithMatch(next,
      { message: 'user required to save test data' })
  })
  it('throws error on remove without updatedBy', () => {
    const next = sinon.spy()
    audit(errorSchema)
    errorSchema.preFunctions.remove(next)
    sinon.assert.calledWithMatch(next,
      { message: 'user required to remove test data' })
  })
  it('throws error on update without updatedBy', () => {
    const next = sinon.spy()
    audit(errorSchema)
    errorSchema.preFunctions.update(next)
    sinon.assert.calledWithMatch(next,
      { message: 'user required to update test data' })
  })
  it('returns on save for unmodified item', () => {
    audit(unmodifiedSchema)
    const next = sinon.spy()
    unmodifiedSchema.preFunctions.save(next)
    sinon.assert.calledWithExactly(next)
  })
  it('logs an audit record for update', async () => {
    // const auditFunc = sandbox.spy(logger, 'audit')
    audit(updateSchema)
    const next = sinon.spy()
    updateSchema.preFunctions.update(next)
    sinon.assert.calledWithExactly(next)
    // await wait(5000)
    // sinon.assert.calledOnce(auditFunc)
  })
  it('logs an audit record for update on save', async () => {
    audit(updateSchema)
    const next = sinon.spy()
    updateSchema.preFunctions.save(next)
    sinon.assert.calledWithExactly(next)
  })
})

// function wait(time = 1000) {
//   return new Promise((accept) => {
//     setTimeout(accept, time)
//   })
// }
