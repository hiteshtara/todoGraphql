/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import { expect, assert } from 'chai'
import { Schema } from 'shared/mongoose'
import { getTestConnectionInfo } from 'shared/test-helpers'
import compoundSparseIndex from '../plugins/compound-sparse-index'

const modelName = 'compoundsparseindextest'
const { connection } = getTestConnectionInfo()

const attrs = {
  typeId: String,
  appId: {
    type: String,
    required: true
  }
}

describe('shared/mongoose/plugins/compound-sparse-index', () => {

  let Model

  afterEach(async () => {
    connection.models = {}
    connection.modelSchemas = {}
    if (!Model) return
    try {
      await Promise.delay(250)
      await Model.collection.drop()
    } catch (err) {
      if (err.message !== 'ns not found') throw err
    }
  })

  it('enforces unique index', async () => {
    const schema = new Schema(attrs)
    schema.plugin(compoundSparseIndex, {
      fields: {
        typeId: {
          sort: 1,
          sparse: true
        },
        appId: { sort: 1 }
      },
      opts: { unique: true }
    })
    Model = connection.model(modelName, schema)
    await Promise.delay(100)
    await Model.create({
      typeId: 'foo',
      appId: 'bar'
    })
    try {
      await Model.create({
        typeId: 'foo',
        appId: 'bar'
      })
      assert.fail('Should have gotten error')
    } catch (ex) {
      expect(ex.code).to.be.equal(11000)
    }
    await Model.create({
      typeId: 'foo2',
      appId: 'bar'
    })
    await Model.create({
      typeId: 'foo',
      appId: 'bar2'
    })
  })

  it('allows sparse fields', async () => {
    const schema = new Schema(attrs)
    schema.plugin(compoundSparseIndex, {
      fields: {
        typeId: {
          sort: 1,
          sparse: true
        },
        appId: { sort: 1 }
      },
      opts: { unique: true }
    })
    Model = connection.model(modelName, schema)
    await Model.create({
      typeId: 'foo',
      appId: 'bar'
    })
    await Model.create({
      appId: 'bar'
    })
  })

  it('should allow multiple required fields along with 1 sparse', async () => {
    const schema = new Schema(Object.assign(attrs, {
      otherId: {
        type: String,
        required: true
      }
    }))
    schema.plugin(compoundSparseIndex, {
      fields: {
        typeId: {
          sort: 1,
          sparse: true
        },
        appId: { sort: 1 },
        otherId: { sort: 1 }
      },
      opts: { unique: true }
    })
    Model = connection.model(modelName, schema)
    await Model.create({
      appId: 'foo',
      otherId: 'bar'
    })
    await Model.create({
      appId: 'foo',
      otherId: 'bar',
      typeId: 'hello'
    })
    try {
      await Model.create({
        appId: 'foo',
        otherId: 'bar',
        typeId: 'hello'
      })
      assert.fail('Should have gotten error')
    } catch (ex) {
      if (ex.code !== 11000) {
        ex.message = `${ex.message}
          Expected exception to have property 'code' === 11000`
        throw ex
      }
    }
  })

  it('enforces the filter option', async () => {
    const schema = new Schema(Object.assign({
      typeId: {
        type: Schema.Types.Mixed
      }
    }))
    schema.plugin(compoundSparseIndex, {
      fields: {
        typeId: {
          sort: 1,
          sparse: true,
          filter: { $type: 'string' }
        },
        appId: { sort: 1 }
      },
      opts: { unique: true }
    })
    Model = connection.model(modelName, schema)
    await Model.create({
      appId: 'foo',
      typeId: 'bar'
    })
    await Model.create({
      appId: 'foo',
      typeId: 2
    })
    await Model.create({
      appId: 'foo',
      typeId: 2
    })
    try {
      await Model.create({
        appId: 'foo',
        typeId: 'bar'
      })
      assert.fail('Should have gotten error')
    } catch (ex) {
      if (ex.code !== 11000) {
        ex.message = `${ex.message}
          Expected exception to have property 'code' === 11000`
        throw ex
      }
    }
  })

  it('should fail if a sparse index is not defined', async () => {
    const schema = new Schema(attrs)
    const failFunction = () => {
      schema.plugin(compoundSparseIndex, {
        fields: {
          typeId: { sort: 1 },
          appId: { sort: 1 }
        },
        opts: { unique: true }
      })
    }
    expect(failFunction).to.throw(/sparse field not specified/)
  })

})
