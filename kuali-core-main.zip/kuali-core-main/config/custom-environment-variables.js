/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

const parse = (name, format) => ({
  __name: name,
  __format: format || 'json'
})

module.exports = {
  port: 'PORT',
  baseUrl: 'BASE_URL',
  log: {
    level: 'LOG_LEVEL',
    name: 'LOG_NAME'
  },
  seneca: {},
  rootDomain: 'COOKIE_DOMAIN',
  cookieOpts: {
    httpOnly: parse('COOKIE_HTTP_ONLY'),
    secure: parse('COOKIE_SECURE'),
    domain: 'COOKIE_DOMAIN',
    path: 'COOKIE_PATH',
    maxAge: parse('COOKIE_MAX_AGE')
  },
  db: {
    uri: 'MONGO_URI',
    options: {
      user: 'MONGO_USER',
      pass: 'MONGO_PASS'
    }
  },
  elasticsearch: {
    host: 'ELASTICSEARCH_HOST',
    httpAuth: 'ELASTICSEARCH_AUTH',
    apiVersion: 'ELASTICSEARCH_VERSION'
  },
  cache: {
    silentFail: parse('CACHE_SILENT_FAIL'),
    host: 'REDIS_URI',
    port: 'REDIS_PORT'
  },
  auth: {
    casCallbackUrl: 'CAS_CALLBACK_URL',
    samlCallbackUrl: 'SAML_CALLBACK_URL',
    samlKeys: {
      v0: 'SAML_KEY_V0',
      v2: 'SAML_KEY_V2'
    },
    acceptedClockSkewMs: 'SAML_CLOCK_SKEW_MS'
  },
  notifications: {
    smtp: {
      host: 'SMTP_HOST',
      auth: parse('SMTP_AUTH'),
      port: parse('SMTP_PORT'),
      pool: parse('SMTP_POOL'),
      maxConnections: parse('SMTP_MAX_CONNECTIONS')
    },
    dkim: {
      domainName: 'DKIM_DOMAIN',
      keySelector: 'DKIM_KEY_SELECTOR',
      privateKey: 'DKIM_PRIVATE_KEY'
    }
  },
  jobs: {
    interval: parse('JOBS_INTERVAL'),
    statusUrl: 'JOBS_STATUS_URL',
    hostMatch: 'HOST_MATCH'
  }
}
