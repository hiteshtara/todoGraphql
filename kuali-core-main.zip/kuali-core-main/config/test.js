/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

module.exports = {
  port: process.env.PORT || 3000,
  serviceSecret: [
    process.env.SERVICE_SECRET_1 || '4439ew8uf23weausdfljho4iuweahfs7023das',
    process.env.SERVICE_SECRET_2
  ].filter(Boolean),
  baseUrl: 'https://kuali.co',
  secret: 'so secret',
  seneca: {
    options: {
      log: 'debug'
    }
  },
  redis: {
    uri: undefined
  },
  rootDomain: '.kuali.co',
  cookieOpts: {
    httpOnly: true,
    secure: true,
    domain: '.kuali.co',
    path: '/',
    maxAge: 1209600000
  },
  log: {
    level: process.env.LOG_LEVEL || 'none',
    name: 'cor-main-test',
    options: {
      skip() {
        return true
      }
    }
  },
  auth: {
    casCallbackUrl: '',
    samlMeta: './samlMeta.xml',
    samlMeta2: './samlMeta2.xml',
    samlKeys: {
      v0: process.env.SAML_KEY_V0 ||
        '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Kp+1D20R3Qs1KbuKLXZcHAoofsvMmMuO8W/g+uggPr+glId\nRKWCkjBQRfC0aP3S4HSP9MJGNilUUTUsl4PC7onIPSyKqc2X92SYYz3Im4IS301I\nUXnU1Br+beyLR3qHcy/hEnu31hvIozYK6qswUyL2CYzJabpwNBIGWOZXtpnTjSio\n95+MiUElA4wNLTJDZjvK48HeQdiUaylx3l4oUsL+a5Fk4WpTQ6JFKnM+R0hpCj+T\nEzkM066I3/KrKgJeWoaBLHSTINnXRk2nzrqsbLGy0ncyzv8w+d1X3k709W6x882Z\nMnOCA3IxktZh/LM4UAoxrrdKaYGjCyC0y3qVZwIDAQABAoIBAChJUpVNmHnXLzSb\nSg3oFiQEM4Qah+E1jt6Rbklc+68LRooIqofvYIcy9ryaHWrL3qPhPU3nGEEqt5G6\nL3LNSJxfU56j892WyQlFjbpTWmDTuysLs7OvTuzojUjRy44wVOhjTRQReMvIr3L7\nYx4tkPXsIQ509QoJqdITzM/rIPIq5S3JI4m3Etdbj8GkDikdpXGj41CWwlgyofwx\nIiEyQS7pj7oZ1tCc+OvKPMqNM2VOfV4S4aj2ZFfSeju0ceUtR4tOByl87Sm474zo\nIEuOD0VqkZbncyXkuirskV8U6XeipDiHA8jpK0ujfqHJt0t9oafEAwa10CpKr/0T\nhqwmQZkCgYEA/fM0cT/kSsjH7t3utcRE4kFpBc0aBIvRPHVPLtzmbIEvJds/z1/k\nh/6+1z1U2dS7VK+BzcStgW7dm4gvsyzibrwmDG4RuWVfVCFyNab+FKGuEkdNi2EN\n2eNJVa8+5jE3hZBOvU090h/Fm8x6Kc35xLtY5CVLALWqYptYeUti/B0CgYEA0lm1\ntp40wtiFh9x/qiLyjDFHnNYxolYBomYUPb0YRQ0lkRHGKh+pvHGO6DcB6AIaGwo7\nUWDqPvjMmKWANcQLtZSXzWQ1b5m6n4NO8sdc4I8mXa+zmOAdz0aDkum4gEyj3VEz\nYs5jd/3CBqANp9IKnukWpqVOcpw2YOoTitaGuFMCgYAB3SQYZLCnP9v/y88xtFQR\nGQvNSBkVyXTqra28GVDzoOsYqwhH3FtQCDWcXM3fn2kUkQkx2myvk4G634ACH6U1\nzNm2o6QrqSvO8UPmUuhwfFNLvQw7pqW0YK+sGlIq3Fec+lcpmoSGo0cPAqwu3F0l\n7X4UhpWLVsn+WUeH9F6wnQKBgFWhTXbtCn9zU1COc64YEfL+MK/pBkWWi43Hzl+f\ntdyOUIew26HUR+29sLZZhj4jdOsjDCjBsjo2YFuXrAy3JSkjN3TWYWZwB2feNWph\nvC5yN+UVnKAURC5X/0H0QTaBfIehAbEsYZO8SpsV1tlFiStNqfnm+3tumjhzscbo\nM+mfAoGBAKw2fxOkm1bv0urwBtbYVN8ldAyyWUj6WgXJKMxXkiJZesbaEIqAjvQb\nRx24XSwq1PhfvlVKIksK1sLFp4FkF6NoFjc99mzwE16S02AlBAPOglDj9j+6jozz\n+gC2Lnn8D8Q7EINV/+3QCjIpFwgJiA/oZNuLW0Ly0O8LiEott9UX\n-----END RSA PRIVATE KEY-----',
      v2: process.env.SAML_KEY_V2 ||
        '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Kp+1D20R3Qs1KbuKLXZcHAoofsvMmMuO8W/g+uggPr+glId\nRKWCkjBQRfC0aP3S4HSP9MJGNilUUTUsl4PC7onIPSyKqc2X92SYYz3Im4IS301I\nUXnU1Br+beyLR3qHcy/hEnu31hvIozYK6qswUyL2CYzJabpwNBIGWOZXtpnTjSio\n95+MiUElA4wNLTJDZjvK48HeQdiUaylx3l4oUsL+a5Fk4WpTQ6JFKnM+R0hpCj+T\nEzkM066I3/KrKgJeWoaBLHSTINnXRk2nzrqsbLGy0ncyzv8w+d1X3k709W6x882Z\nMnOCA3IxktZh/LM4UAoxrrdKaYGjCyC0y3qVZwIDAQABAoIBAChJUpVNmHnXLzSb\nSg3oFiQEM4Qah+E1jt6Rbklc+68LRooIqofvYIcy9ryaHWrL3qPhPU3nGEEqt5G6\nL3LNSJxfU56j892WyQlFjbpTWmDTuysLs7OvTuzojUjRy44wVOhjTRQReMvIr3L7\nYx4tkPXsIQ509QoJqdITzM/rIPIq5S3JI4m3Etdbj8GkDikdpXGj41CWwlgyofwx\nIiEyQS7pj7oZ1tCc+OvKPMqNM2VOfV4S4aj2ZFfSeju0ceUtR4tOByl87Sm474zo\nIEuOD0VqkZbncyXkuirskV8U6XeipDiHA8jpK0ujfqHJt0t9oafEAwa10CpKr/0T\nhqwmQZkCgYEA/fM0cT/kSsjH7t3utcRE4kFpBc0aBIvRPHVPLtzmbIEvJds/z1/k\nh/6+1z1U2dS7VK+BzcStgW7dm4gvsyzibrwmDG4RuWVfVCFyNab+FKGuEkdNi2EN\n2eNJVa8+5jE3hZBOvU090h/Fm8x6Kc35xLtY5CVLALWqYptYeUti/B0CgYEA0lm1\ntp40wtiFh9x/qiLyjDFHnNYxolYBomYUPb0YRQ0lkRHGKh+pvHGO6DcB6AIaGwo7\nUWDqPvjMmKWANcQLtZSXzWQ1b5m6n4NO8sdc4I8mXa+zmOAdz0aDkum4gEyj3VEz\nYs5jd/3CBqANp9IKnukWpqVOcpw2YOoTitaGuFMCgYAB3SQYZLCnP9v/y88xtFQR\nGQvNSBkVyXTqra28GVDzoOsYqwhH3FtQCDWcXM3fn2kUkQkx2myvk4G634ACH6U1\nzNm2o6QrqSvO8UPmUuhwfFNLvQw7pqW0YK+sGlIq3Fec+lcpmoSGo0cPAqwu3F0l\n7X4UhpWLVsn+WUeH9F6wnQKBgFWhTXbtCn9zU1COc64YEfL+MK/pBkWWi43Hzl+f\ntdyOUIew26HUR+29sLZZhj4jdOsjDCjBsjo2YFuXrAy3JSkjN3TWYWZwB2feNWph\nvC5yN+UVnKAURC5X/0H0QTaBfIehAbEsYZO8SpsV1tlFiStNqfnm+3tumjhzscbo\nM+mfAoGBAKw2fxOkm1bv0urwBtbYVN8ldAyyWUj6WgXJKMxXkiJZesbaEIqAjvQb\nRx24XSwq1PhfvlVKIksK1sLFp4FkF6NoFjc99mzwE16S02AlBAPOglDj9j+6jozz\n+gC2Lnn8D8Q7EINV/+3QCjIpFwgJiA/oZNuLW0Ly0O8LiEott9UX\n-----END RSA PRIVATE KEY-----'
    },
    acceptedClockSkewMs: -1
  },
  db: {
    uri: process.env.MONGO_URI || 'mongodb://localhost/core-test',
    options: null
  },
  notifications: {
    smtp: {
      host: 'mx-p1ap.private',
      port: 25,
      pool: true,
      maxConnections: 50
    },
    dkim: {
      enabled: false,
      domainName: process.env.DKIM_DOMAIN,
      keySelector: process.env.DKIM_KEY_SELECTOR,
      privateKey: process.env.DKIM_PRIVATE_KEY
    }
  },
  jobs: {
    eachInterval: 100,
    interval: 400
  },
  elasticsearch: {
    host: 'http://localhost:9200',
    httpAuth: 'elastic:changeme'
  }
}
