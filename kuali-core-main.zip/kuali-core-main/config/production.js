/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */


module.exports = {
  port: process.env.PORT || 3000,
  serviceSecret: [
    process.env.SERVICE_SECRET_1 || '4439ew8uf23weausdfljho4iuweahfs7023das',
    process.env.SERVICE_SECRET_2
  ].filter(Boolean),
  baseUrl: process.env.KUALI_BASE_URL,
  log: {
    level: 'info',
    name: 'cor-main'
  },
  redis: {
    uri: undefined
  },
  rootDomain: '.kuali.co',
  seneca: { options: {} },
  cookieOpts: {
    httpOnly: true,
    secure: true,
    domain: '',
    path: '/',
    maxAge: 1209600000
  },
  db: {
    uri: process.env.MONGO_URI,
    options: {
      user: process.env.MONGO_USER,
      pass: process.env.MONGO_PASS
    }
  },
  cache: {
    silentFail: true,
    host: process.env.REDIS_URI || 'localhost',
    port: process.env.REDIS_PORT || 6379
  },
  auth: {
    // TODO Change this process.env. to CAS_CALLBACK_URL when everyone is using
    // CAS_CALLBACK_URL. We currently support both, and CAS_CALLBACK_URL will
    // override CAS_SERVER_BASE_URL
    casCallbackUrl: process.env.CAS_SERVER_BASE_URL,
    samlCallbackUrl: 'https://saas1.kuali.co/auth/saml/consume',
    samlMeta: './samlMeta.xml',
    samlMeta2: './samlMeta2.xml',
    samlKeys: {
      v0: process.env.SAML_KEY_V0,
      v2: process.env.SAML_KEY_V2
    },
    acceptedClockSkewMs: process.env.SAML_CLOCK_SKEW_MS
  },
  notifications: {
    smtp: {
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT || 25,
      pool: process.env.SMTP_POOL || true,
      maxConnections: process.env.SMTP_MAX_CONNECTIONS || 50
    },
    dkim: {
      enabled: process.env.DKIM_ENABLED || false,
      domainName: process.env.DKIM_DOMAIN,
      keySelector: process.env.DKIM_KEY_SELECTOR,
      privateKey: process.env.DKIM_PRIVATE_KEY
    }
  },
  jobs: {
    interval: parseInt(process.env.JOBS_INTERVAL) || 1 * 60 * 1000, // 1 minute
    statusUrl: process.env.JOBS_STATUS_URL || 'http://example.com',
    hostMatch: process.env.HOST_MATCH || '^https?://'
  }
}
