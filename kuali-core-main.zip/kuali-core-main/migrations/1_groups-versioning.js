/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable import/no-commonjs */
'use strict'

const _ = require('lodash')
const Promise = require('bluebird')
const ObjectId = require('mongodb').ObjectId
const transformEach = require('./helpers/transform-each')

const GROUP_FIELDS = [
  'fields',
  'name',
  'categoryId',
  'parentId',
  'roles',
  'fieldSchemas',
  'roleSchemas',
  'startDate'
]

const CATEGORY_FIELDS = [
  'fieldSchemas',
  'name',
  'parentId',
  'roleSchemas',
  'startDate'
]

exports.migrate = (client, done) => {
  const db = client.db
  return Promise.all([
    versionsUp(db.collection('groups'), GROUP_FIELDS),
    versionsUp(db.collection('categories'), CATEGORY_FIELDS)
  ]).asCallback(done)
}

exports.rollback = (client, done) => {
  const db = client.db
  return Promise.all([
    versionsDown(db.collection('groups'), GROUP_FIELDS),
    versionsDown(db.collection('categories'), CATEGORY_FIELDS)
  ]).asCallback(done)
}

function versionsUp(col, fields) {
  return transformEach(col, (doc) => {
    if (doc.versions) return null
    doc.versions = []
    const version = _.pick(doc, fields)
    version._id = new ObjectId()
    version.startDate = new Date(0)
    doc.versions.push(version)
    doc = _.omit(doc, fields)
    return doc
  })
}

function versionsDown(col, fields) {
  return transformEach(col, (doc) => {
    if (!doc.versions) return null
    const firstVersion = doc.versions[0]
    delete firstVersion.startDate
    Object.assign(doc, _.pick(firstVersion, fields))
    delete doc.versions
    return doc
  })
}
