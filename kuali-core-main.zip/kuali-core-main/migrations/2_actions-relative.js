/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable import/no-commonjs */
'use strict'

const url = require('url')
const transformEach = require('./helpers/transform-each')

const KUALI_HOST_REGEX = /\.kuali\.co$/

exports.migrate = (client, done) => {
  const db = client.db
  const actions = db.collection('actions')
  return transformEach(actions, (doc) => {
    if (!doc.handlerUrl) return null
    const parsedUrl = url.parse(doc.handlerUrl)
    if (KUALI_HOST_REGEX.test(parsedUrl.hostname)) {
      doc.handlerPath = url.format({
        search: parsedUrl.search,
        pathname: parsedUrl.pathname,
        hash: parsedUrl.hash
      })
    } else {
      doc.handlerPath = null
    }
    return doc
  }).asCallback(done)
}

exports.rollback = (client, done) => {
  const db = client.db
  const actions = db.collection('actions')
  return transformEach(actions, (doc) => {
    delete doc.handlerPath
    return doc
  }).asCallback(done)
}
