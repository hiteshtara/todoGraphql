/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable import/no-commonjs */
'use strict'

const transformEach = require('./helpers/transform-each')

exports.migrate = (client, done) => {
  const db = client.db
  const institutions = db.collection('institutions')
  return transformEach(institutions, doc => {
    if (!doc.idp && !doc.eppn) return null
    doc.idps = []
    doc.idps.push({
      name: 'default',
      idp: doc.idp,
      eppn: doc.eppn
    })
    return doc
  }).asCallback(done)
}

exports.rollback = (client, done) => {
  const db = client.db
  const institutions = db.collection('institutions')
  return transformEach(institutions, doc => {
    if (doc.idps && doc.idps.length > 0) {
      doc.idp = doc.idps[0].idp
      doc.eppn = doc.idps[0].eppn
    }
    return doc
  }).asCallback(done)
}
