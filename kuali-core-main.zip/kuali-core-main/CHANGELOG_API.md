# core-main API changelog

This document is meant to be kept up to date as new features are added,
especially as other projects begin to depend on those new features. Although we
can't back-track and add every feature to this changelog, we will require all
future contributions to update this changelog as well as the version in the
`package.json` file. As changes get added, they should be added to the **top**
of the list. Look at the format of previous Changelog items for new items in the
list.

To update the version, run `npm version YY.MM.DD` (no leading zeros on month
and day)

# 17.8.9

- Adds 'timezone' property to the /api/v1/institution apis. Value must be a valid IANA time zone.

# 17.8.1

- Added initial version and changelog
- Adds experimental elasticsearch support for users search endpoint
  - This is under a feature flag on the institution collection. This is not
    officially supported yet. If you do not provide elasticsearch configuration,
    the app will not attempt to connect to elasticsearch.
