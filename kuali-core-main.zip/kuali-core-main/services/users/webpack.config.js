/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

var ExtractTextPlugin = require('extract-text-webpack-plugin')
var webpack = require('webpack')

module.exports = {

  plugins: [
    new webpack.optimize.OccurenceOrderPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    new ExtractTextPlugin('style.css', { allChunks: true }),
    new webpack.NoErrorsPlugin()
  ],

  entry: [
    'webpack-dev-server/client?http://localhost:8080',
    'webpack/hot/dev-server',
    './client/app/index.js'
  ],

  output: {
    path: '../../public/users/build/',
    filename: 'users.js',
    publicPath: '/build/'
  },

  resolve: {
    modulesDirectories: ['node_modules', __dirname + '/node_modules', __dirname + '/../../'],
    extensions: ['', '.js', 'index.js', '.css', 'style.css']
  },

  resolveLoader: {
    modulesDirectories: ['node_modules', __dirname + '/node_modules', __dirname + '/../../'],
  },

  module: {
    preLoaders: [
      {
        test: /\.json$/,
        loader: 'json'
      }
    ],
    loaders: [
      {
        test: /\.js$/,
        loader: 'babel',
        query: {
          presets: ['es2015', 'react', 'stage-1'],
          plugins: [
            [require.resolve('babel-plugin-react-transform'), {
              transforms: [
                {
                  transform: require.resolve('react-transform-hmr'),
                  imports: ['react'],
                  locals: ['module']
                },
                {
                  transform: require.resolve('react-transform-catch-errors'),
                  imports: ['react', require.resolve('redbox-react')]
                }
              ]
            }],
            [require.resolve('babel-plugin-react-intl'), {
              "messagesDir": '../../i18n/messages/users',
              "enforceDescriptions": true
            }]
          ]
        },
        exclude: [/node_modules/]
      },
      {
        test: /\.css$/,
        loader: ExtractTextPlugin.extract('style-loader', 'css?modules&importLoaders=1&localIdentName=[name]__[local]___[hash:base64:5]!postcss'), // eslint-disable-line
        exclude: [/node_modules/]
      }
    ]
  },

  postcss: [
    require('autoprefixer')
  ],

  devServer: {
    publicPath: '/build/',
    contentBase: './client',
    quiet: true,
    hot: true,
    proxy: {
      '/api/*': 'http://localhost:3000',
      '/css/*': 'http://localhost:3000',
      '/img/*': 'http://localhost:3000'
    }
  },

  devtool: '#eval'

}
