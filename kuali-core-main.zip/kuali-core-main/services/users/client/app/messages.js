/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const fields = defineMessages({
  display: {
    id: 'users.fields.display',
    description: 'Alternate name for display purposes',
    defaultMessage: 'Display Name'
  },
  email: {
    id: 'users.fields.email',
    description: 'User email',
    defaultMessage: 'Email'
  },
  username: {
    id: 'users.fields.username',
    description: 'Username for login',
    defaultMessage: 'Username'
  },
  first: {
    id: 'users.fields.givenName',
    description: 'Given name of the user',
    defaultMessage: 'First name'
  },
  last: {
    id: 'users.fields.familyName',
    description: 'Family name of the user',
    defaultMessage: 'Last name'
  },
  approved: {
    id: 'users.fields.approved',
    description: 'Whether the user is approved',
    defaultMessage: 'Approved'
  },
  role: {
    id: 'users.fields.role',
    description: 'Permissions role',
    defaultMessage: 'Role'
  },
  groupId: {
    id: 'users.fields.groupId',
    description: 'The Primary Group that this user belongs to',
    defaultMessage: 'Primary Group'
  }
})
export const roles = defineMessages({
  user: {
    id: 'users.roles.user',
    description: 'Normal user role',
    defaultMessage: 'User'
  },
  admin: {
    id: 'users.roles.admin',
    description: 'Adminstrative user role',
    defaultMessage: 'Admin'
  },
  service: {
    id: 'users.roles.service',
    description: 'Service (not a person) role',
    defaultMessage: 'Service'
  },
  cmadmin: {
    id: 'users.roles.cmadmin',
    description: 'CM Admin',
    defaultMessage: 'CM Admin'
  },
  external: {
    id: 'users.roles.external',
    description: 'External User',
    defaultMessage: 'External User'
  }
})

export default { fields, roles }
