/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component } from 'react'
import { IntlProvider } from 'react-intl'
import { Router, IndexRoute, Redirect, Route, hashHistory } from 'react-router'
import { NotAuthenticated, NotAuthorized, NotFound } from 'shared/kuali-common'

import './style'
import './common/fix-axios'
import Main from './pages/main'
import UserList from './pages/user-list'
import UserEdit from './pages/user-edit'
import UserView from './pages/user-view'
import UserApiKeys from './pages/user-api-keys'
import * as Users from './stores/users'
import * as Institution from './stores/institutions'

let fetchUser, fetchInstitution

async function onEnter(location, replaceWith, callback) {
  try {
    const institution = await fetchInstitution
    const user = await fetchUser
    /* istanbul ignore if */
    if (!user) {
      throw Error('No User Found')
    }
    window.kualiUser = user
    window.kualiInstitution = institution
    callback()
  } catch (e) {
    /* istanbul ignore next */
    console.error('Error Thrown:', e, e.stack)//eslint-disable-line no-console
  }
}

export default class App extends Component {

  displayName = 'App';

  componentWillMount() {
    fetchUser = Users.getUser()
    fetchInstitution = Institution.getInstitution()
  }

  render() {
    return (
      <IntlProvider locale="en" messages={{}}>
        <Router history={hashHistory}>
          <Route component={Main} onEnter={onEnter} path="/">
            <IndexRoute component={UserList}/>
            <Route component={UserEdit} path="new"/>
            <Redirect from=":userId/details" to=":userId/details/view"/>
            <Route path=":userId/details">
              <Route component={UserView} path="view"/>
              <Route component={UserEdit} path="edit"/>
            </Route>
            <Route component={UserApiKeys} path=":userId/api-keys"/>
          </Route>
          <Route component={NotFound} path="404"/>
          <Route component={NotAuthenticated} path="401"/>
          <Route component={NotAuthorized} path="403"/>
          <Redirect from="*" to="404"/>
        </Router>
      </IntlProvider>
    )
  }

}
