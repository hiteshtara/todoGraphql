/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import axios from 'axios'
import qs from 'querystring'

export function getUser() {
  return wrap(axios.get('/api/v1/users/current'))
}

export function getUserById(id) {
  return wrap(axios.get(`/api/v1/users/${id}`))
}

export function getAllUsers(params) {
  return axios.get(`/api/v1/users/?${qs.encode(params)}`)
    .then(res => ({
      count: res.headers['item-count'],
      users: res.data
    }))
    .catch(catchError)
}

/* istanbul ignore next - This function doesn't seem to be called anywere */
// TODO Remove if we don't need this anymore
export function searchUsersByName(name) {
  return wrap(axios.get(`/api/v1/users/?q=${name}`))
}

export function saveUser(id, user) {
  return wrap(axios.put(`/api/v1/users/${id}`, user))
}

export function createUser(user) {
  return wrap(axios.post('/api/v1/users', user))
}

export function deleteUser(id) {
  return wrap(axios.delete(`/api/v1/users/${id}`))
}

export function getApiKeysByUser(id) {
  return wrap(axios.get(`/api/v1/users/${id}/tokens?type=apiKey`))
}

export function createApiKeyForUser(id, name) {
 return wrap(axios.post(`/api/v1/users/${id}/tokens`, { name }))
}

export function revokeApiKeyForUser(userId, tokenId) {
  return wrap(axios.delete(`/api/v1/users/${userId}/tokens/${tokenId}`))
}

export function impersonateUser(user) {
  return wrap(axios.post('/api/v1/auth/impersonate', { user }))
}

function wrap(promise) {
  return promise
    .then(res => res.data)
    .catch(catchError)
}

function catchError(e) {
  throw (e.response && e.response.data) || e
}
