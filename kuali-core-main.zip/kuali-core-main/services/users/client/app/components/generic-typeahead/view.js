/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'

import styles from './styles'
import AsyncTemplate from '../async-template'

export default class TypeaheadView extends Component {

  static displayName = 'TypeaheadView';

  static propTypes = {
    getById: PropTypes.func.isRequired,
    noValueMsg: PropTypes.string.isRequired,
    notFoundMsg: PropTypes.string.isRequired,
    value: PropTypes.string
  };

  render() {
    const { getById, notFoundMsg, noValueMsg, value } = this.props
    const template = name => (
      <div className={styles.tag}>
        {name && <span>{name}</span>}
        {!name && <span style={{ color: '#e74c3c' }}>{notFoundMsg}</span>}
      </div>
    )
    if (value) {
      return (
        <AsyncTemplate
          default="..."
          error={template()}
          load={getById.bind(null, value)}
          tmpl={item => template(item.name || /* istanbul ignore next */ '--')}
        />
      )
    }
    return (
      <div>{noValueMsg}</div>
    )
  }

}
