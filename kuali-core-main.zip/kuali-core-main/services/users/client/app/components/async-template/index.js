/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'

export default class AsyncTemplate extends Component {

  static displayName = 'AsyncTemplate';

  static propTypes = {
    default: PropTypes.oneOfType([
      PropTypes.element,
      PropTypes.string
    ]).isRequired,
    error: PropTypes.oneOfType([
      PropTypes.element,
      PropTypes.string
    ]),
    load: PropTypes.func.isRequired,
    tmpl: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props)
    this.state = {
      value: null,
      isSet: false,
      error: false
    }
  }

  componentDidMount() {
    this.load(this.props)
  }

  componentWillReceiveProps(nextProps) {
    this.load(nextProps)
  }

  load(props) {
    props.load()
      .then(value => this.setState({ isSet: true, value }))
      .catch(() => this.setState({ error: true }))
  }

  renderItem() {
    if (this.state.error) {
      return this.props.error || /* istanbul ignore next */ 'Error!'
    }
    if (!this.state.isSet) {
      return this.props.default
    }
    return this.props.tmpl(this.state.value)
  }

  render() {
    return <span>{this.renderItem()}</span>
  }

}
