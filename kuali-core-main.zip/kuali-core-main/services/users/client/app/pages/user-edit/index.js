/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import cx from 'classnames'
import React, { Component, PropTypes } from 'react'
import { Link } from 'react-router'
import { injectIntl, intlShape, FormattedMessage } from 'react-intl'
import { labels } from 'shared/i18n'
import { get } from 'lodash'

import styles from './style'
import { fields, roles } from '../../messages'
import {
  title,
  passwordConfirmMsg,
  invalidUsernameMsg,
  invalidEmailMsg,
  duplicateFieldMsg,
  invalidPasswordMsg
} from './messages'
import { UserType } from '../../common/prop-types'
import * as Users from '../../stores/users'
import { GroupTypeahead } from '../../common/group-typeahead'

class UserEdit extends Component {
  displayName: 'UserEdit'

  static propTypes = {
    curUser: UserType.isRequired,
    intl: intlShape.isRequired,
    params: PropTypes.shape({
      userId: PropTypes.string
    }).isRequired,
    route: PropTypes.shape({
      path: PropTypes.string.isRequired
    }).isRequired,
    user: UserType
  }

  constructor(props) {
    super(props)
    if (props.curUser.role !== 'admin' && props.curUser.id !== props.user.id) {
      location.assign(`#/${props.user.id}/details`)
    }
    this.linkUser = this.linkUser.bind(this)
    this.renderField = this.renderField.bind(this)
    this.saveUser = this.saveUser.bind(this)
    this.formatMessage = this.props.intl.formatMessage
    this.state = {
      user: props.user || { approved: true },
      errors: {}
    }
  }

  async saveUser() {
    const isNew = this.props.route.path === 'new'
    let { passwordConfirm, ...user } = this.state.user
    if (passwordConfirm !== user.password) {
      this.setState({ error: 'Passwords do not match!' })
      return
    }
    try {
      if (isNew) {
        user = await Users.createUser(user)
      } else {
        await Users.saveUser(user.id, user)
      }
      window.location = `#/${user.id}/details`
    } catch (e) {
      this.handleErrors(e.cause || e)
    }
  }

  duplicateMessage(field) {
    return this.formatMessage(duplicateFieldMsg, { field })
  }

  validationMessage(field) {
    if (field === 'username') {
      return this.formatMessage(invalidUsernameMsg)
    }
    if (field === 'password') {
      return this.formatMessage(invalidPasswordMsg)
    }
    return this.formatMessage(invalidEmailMsg)
  }

  handleErrors(error) {
    if (Array.isArray(get(error, 'errors[0].fields'))) {
      error = error.errors[0]
      let errorMessage = err => err
      switch (error.name) {
        case 'DuplicateKeyError':
          errorMessage = this.duplicateMessage.bind(this)
          break
        case 'ValidationError':
          errorMessage = this.validationMessage.bind(this)
      }
      let errors = {}
      error.fields.forEach(field => {
        errors[field] = errorMessage(field)
      })
      this.setState({ errors })
      if (errors.password) {
        this.setState({ error: errors.password })
      }
    } else {
      this.setState({ error: JSON.stringify(error) })
    }
  }

  linkUser(key) {
    return {
      requestChange: val =>
        this.setState({
          user: { ...this.state.user, [key]: val }
        }),
      value: this.state.user[key]
    }
  }

  renderField({ children, id, ...props }) {
    return (
      <div className={styles.field}>
        <label htmlFor={id}>{children}</label>
        <input
          className={this.state.errors[id] && styles.error}
          id={id}
          type="text"
          valueLink={this.linkUser(id)}
          {...props}
        />
        {this.state.errors[id] &&
          <div className={styles.error} id={`${id}-error`}>
            <span className={styles.arrow} />
            {this.state.errors[id]}
          </div>}
      </div>
    )
  }

  renderPasswordField() {
    return (
      <div className={styles.field}>
        <label htmlFor="password">
          <FormattedMessage {...labels.password} />
        </label>
        <input
          className={this.state.errors.password && styles.error}
          id="password"
          type="password"
          valueLink={this.linkUser('password')}
        />
        <input
          className={this.state.errors.password && styles.error}
          id="password-confirm"
          placeholder={this.props.intl.formatMessage(passwordConfirmMsg)}
          type="password"
          valueLink={this.linkUser('passwordConfirm')}
        />
      </div>
    )
  }

  renderRoleField() {
    const isAdmin = this.props.curUser.role === 'admin'
    return (
      <div className={styles.field}>
        <label htmlFor="role"><FormattedMessage {...fields.role} /></label>
        <select
          className={cx('form-control', styles.select)}
          disabled={!isAdmin}
          id="role"
          valueLink={this.linkUser('role')}
        >
          <option value="user">{this.formatMessage(roles.user)}</option>
          <option value="admin">{this.formatMessage(roles.admin)}</option>
          <option value="cmadmin">{this.formatMessage(roles.cmadmin)}</option>
          <option value="external">{this.formatMessage(roles.external)}</option>
          <option value="service">{this.formatMessage(roles.service)}</option>
        </select>
      </div>
    )
  }

  renderGroupField() {
    const isAdmin = this.props.curUser.role === 'admin'
    const { requestChange, value } = this.linkUser('groupId')
    return (
      <div className={styles.field}>
        <label htmlFor="groupId">
          <FormattedMessage {...fields.groupId} />
        </label>
        <GroupTypeahead
          disabled={!isAdmin}
          id="groupId"
          onChange={requestChange}
          placeholder="Select Group"
          value={value}
        />
      </div>
    )
  }

  renderApprovedField() {
    const isAdmin = this.props.curUser.role === 'admin'
    return (
      <div className={styles.field}>
        <label htmlFor="approved">
          <FormattedMessage {...fields.approved} />
        </label>
        <input
          checkedLink={this.linkUser('approved')}
          className={cx('form-control', styles.select, styles.checkbox)}
          disabled={!isAdmin}
          id="approved"
          type="checkbox"
        />
      </div>
    )
  }

  render() {
    const isNew = this.props.route.path === 'new'
    const cancelPath = isNew ? '/' : `${this.props.user.id}/details`
    const Field = this.renderField
    return (
      <div className={styles.container}>
        <div>
          <div className={styles.header}>
            <img alt="" src="/img/v1/top-bar/profile.svg" />
            <h1>
              <FormattedMessage {...title} values={{ isNew }} />
            </h1>
          </div>
          {this.state.error &&
            <div data-test="user-edit-error">
              {this.state.error}
            </div>}
          <div className={styles.form}>
            <Field autoFocus id="name">
              <FormattedMessage {...fields.display} />
            </Field>
            {this.renderRoleField()}
            {this.renderGroupField()}
            {this.renderApprovedField()}
            <Field id="email">
              <FormattedMessage {...fields.email} />
            </Field>
            <Field id="username">
              <FormattedMessage {...fields.username} />
            </Field>
            <Field id="firstName">
              <FormattedMessage {...fields.first} />
            </Field>
            <Field id="lastName">
              <FormattedMessage {...fields.last} />
            </Field>
            {this.renderPasswordField()}
          </div>
          <div className={styles.buttons}>
            <button
              className="btn btn-success"
              data-test="user-edit-save-button"
              onClick={this.saveUser}
            >
              <FormattedMessage {...labels.save} />
            </button>
            <Link className="btn" to={cancelPath}>
              <FormattedMessage {...labels.cancel} />
            </Link>
          </div>
        </div>
      </div>
    )
  }
}

export default injectIntl(UserEdit)
