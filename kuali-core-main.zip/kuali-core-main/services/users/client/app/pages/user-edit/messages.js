/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

const messages = defineMessages({
  title: {
    id: 'users.edit.title',
    description: 'Title for edit page of a user',
    defaultMessage: '{isNew, select, true {New} false {Edit}} User'
  },
  passwordConfirmMsg: {
    id: 'users.edit.passwordConfirmMsg',
    description: 'Placeholder for password verification field',
    defaultMessage: 'Re-Enter Password'
  },
  invalidEmailMsg: {
    id: 'users.edit.invalidEmailMsg',
    description: 'Error message for email validation error',
    defaultMessage: 'Oops not an email'
  },
  invalidUsernameMsg: {
    id: 'users.edit.invalidUsernameMsg',
    description: 'Error message for username validation error',
    defaultMessage: 'Invalid username'
  },
  duplicateFieldMsg: {
    id: 'users.edit.duplicateFieldMsg',
    description: 'Error message for duplicate field error',
    defaultMessage: '{field} already in use'
  },
  invalidPasswordMsg: {
    id: 'users.edit.invalidPasswordMsg',
    description: 'Password validation error',
    defaultMessage: 'Password must be at least 8 characters'
  }
})
export const { title, passwordConfirmMsg, invalidPasswordMsg,
  invalidEmailMsg, invalidUsernameMsg, duplicateFieldMsg } = messages
export default messages
