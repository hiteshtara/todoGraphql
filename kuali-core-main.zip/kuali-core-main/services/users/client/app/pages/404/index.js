/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React from 'react'
import { Link } from 'react-router'
import { FormattedMessage } from 'react-intl'
import { labels } from 'shared/i18n'

import styles from './style'
import { content } from './messages'

let notFound = () => (
  <div className={styles.wrapper}>
    <div className={styles.title}>404</div>
    <div><FormattedMessage {...content}/></div>
    <Link to="/"><FormattedMessage {...labels.home}/></Link>
  </div>
)

notFound.displayName = '404notFound'

export default notFound
