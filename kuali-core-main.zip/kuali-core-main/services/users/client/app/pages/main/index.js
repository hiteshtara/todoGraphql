/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { Header } from 'shared/kuali-common'
import { injectIntl, intlShape } from 'react-intl'
import { apps } from 'shared/i18n'

import styles from './style'
import UserCard from '../user-card'

export class _Main extends Component {

  displayName: 'Main';

  static propTypes = {
    children: PropTypes.node.isRequired,
    intl: intlShape.isRequired,
    routes: PropTypes.arrayOf(
      PropTypes.shape({
        path: PropTypes.string
      }).isRequired
    ).isRequired
  };

  constructor() {
    super()
    this.state = {
      user: window.kualiUser
    }
  }

  render() {
    const { children, routes } = this.props
    const { user } = this.state
    let content = React.cloneElement(children, { curUser: user })
    if ('path' in routes[1]) {
      content = <UserCard {...this.props} curUser={user}>{content}</UserCard>
    }
    return (
      <div className={styles.container}>
        <Header logo="/img/v1/kualistudentlogo.svg"
          title={this.props.intl.formatMessage(apps.users)} user={user}/>
        {content}
      </div>
    )
  }

}

export default injectIntl(_Main)
