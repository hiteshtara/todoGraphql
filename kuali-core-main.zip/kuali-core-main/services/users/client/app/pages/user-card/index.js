/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { Link } from 'react-router'
import { FormattedMessage } from 'react-intl'
import { Preloader } from 'shared/kuali-common'

import styles from './style'
import messages from './messages'
import { UserType } from '../../common/prop-types'
import * as Users from '../../stores/users'

export default class UserCard extends Component {

  displayName: 'UserCard';

  static propTypes = {
    children: PropTypes.node.isRequired,
    curUser: UserType.isRequired,
    params: PropTypes.shape({
      userId: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props)
    this.state = { user: null }
    if (props.params.userId) {
      this.fetchUser(props.params.userId)
    }
  }

  componentWillReceiveProps(props) {
    this.setState({ user: null })
    if (props.params.userId) {
      this.fetchUser(props.params.userId)
    }
  }

  async fetchUser(id) {
    try {
      const user = await Users.getUserById(id)
      this.setState({ user })
    } catch (e) {/* istanbul ignore next */
      window.location = '#/404'
    }
  }

  render() {
    const { userId } = this.props.params
    const { user } = this.state
    const canEdit = this.props.curUser.role === 'admin' ||
      this.props.curUser.id === userId
    if (userId && !user) {
      return <Preloader/>
    }
    return (
      <div className={styles.wrapper}>
        <Link className={styles.back} to="/">
          <FormattedMessage {...messages.userList}/>
        </Link>
        <div className={styles.container}>
          {userId && (
            <div className={styles.nav}>
              <Link activeClassName={styles.active} to={`${userId}/details`}>
                <FormattedMessage {...messages.account}/>
              </Link>
              {canEdit && (<Link activeClassName={styles.active}
                to={`${userId}/api-keys`}>
                <FormattedMessage {...messages.apiKeys}/>
              </Link>)}
            </div>
          )}
          <div className={styles.content}>
            {React.cloneElement(this.props.children, { user })}
          </div>
        </div>
      </div>
    )
  }

}
