/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

const messages = defineMessages({
  userList: {
    id: 'users.links.userList',
    description: 'Return to the full list of users',
    defaultMessage: ' < Back to User List'
  },
  account: {
    id: 'users.links.accountInfo',
    description: 'User Account Information',
    defaultMessage: 'Account Information'
  },
  apiKeys: {
    id: 'users.links.apiKeys',
    description: 'User API Key Management',
    defaultMessage: 'API Keys'
  }
})

export const { userList, account, apiKeys } = messages
export default messages
