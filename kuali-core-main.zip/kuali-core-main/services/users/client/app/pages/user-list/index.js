/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import cx from 'classnames'
import { map } from 'lodash'
import React, { Component } from 'react'
import { injectIntl, intlShape, FormattedMessage } from 'react-intl'
import { Preloader } from 'shared/kuali-common'
import { labels } from 'shared/i18n'

import Pagination from './pagination'
import styles from './style'
import { search, addUser } from './messages'
import { fields } from '../../messages'
import { UserType } from '../../common/prop-types'
import * as Users from '../../stores/users'

class UserList extends Component {

  displayName: 'UserList';

  static propTypes = {
    curUser: UserType.isRequired,
    intl: intlShape.isRequired
  };

  constructor(props) {
    super(props)
    this.state = {
      users: null,
      count: 0,
      pagination: {
        page: 1,
        limit: '25',
        query: ''
      }
    }
    this.updateQuery = this.updateQuery.bind(this)
    this.updateSearch = this.updateSearch.bind(this)
    this.fetchAllUsers(this.state.pagination)
  }

  async fetchAllUsers(pagination) {
    const { page, limit, query } = pagination
    const params = {
      limit,
      skip: (page - 1) * limit,
      q: query
    }
    const { users, count } = await Users.getAllUsers(params)
    this.setState({ users, count })
  }

  updateQuery(newStuff) {
    let { pagination } = this.state
    pagination = {
      ...pagination,
      ...newStuff
    }
    this.setState({ pagination })
    this.fetchAllUsers(pagination)
  }

  updateSearch(e) {
    this.updateQuery({
      page: 1,
      query: e.target.value
    })
  }

  render() {
    const { count, users, pagination } = this.state
    const { curUser } = this.props
    const isAdmin = curUser.role === 'admin'
    if (!users) {
      return <Preloader/>
    }

    const fmt = this.props.intl.formatMessage
    return (
      <div className={styles.container}>
        <div className={styles.topContainer}>
          <div className={styles.search}>
            <input
              className="form-control"
              data-test="user-list-search-input"
              onChange={this.updateSearch}
              placeholder={fmt(search)}
              type="text"
              value={pagination.query}
            />
            <button className="btn btn-info">
              <FormattedMessage {...labels.search}/>
            </button>
          </div>
          {isAdmin && (
            <a className="btn btn-success" href="#/new" id="add-user">
              <FormattedMessage {...addUser}/>
            </a>
          )}
        </div>
        <table className={cx('table', styles.table)}>
          <thead>
            <tr>
              <th><FormattedMessage {...fields.display}/></th>
              <th><FormattedMessage {...fields.email}/></th>
              <th><FormattedMessage {...fields.username}/></th>
              <th><FormattedMessage {...fields.role}/></th>
            </tr>
          </thead>
          <tbody>
            {map(users, user => (
              <tr key={user.id}>
                <td><a href={`#/${user.id}/details`}>
                  <img
                    alt=""
                    className={styles.profile}
                    src="/img/v1/top-bar/profile.svg"
                  /> {user.displayName}
                </a></td>
                <td><a href={`#/${user.id}/details`}>{user.email}</a></td>
                <td><a href={`#/${user.id}/details`}>{user.username}</a></td>
                <td className={styles.role}>
                  <a href={`#/${user.id}/details`}>{user.role}</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <Pagination count={count} update={this.updateQuery} {...pagination}/>
      </div>
    )
  }

}

export default injectIntl(UserList)
