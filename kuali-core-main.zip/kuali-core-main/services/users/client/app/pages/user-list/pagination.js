/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape, FormattedMessage } from 'react-intl'
import { paging } from 'shared/i18n'

import styles from './style'
import { userCount } from './messages'
import Icon from '../../components/icon'

class Pagination extends Component {

  displayName: 'Pagination';

  static propTypes = {
    count: PropTypes.string.isRequired,
    intl: intlShape.isRequired,
    limit: PropTypes.string.isRequired,
    page: PropTypes.number.isRequired,
    update: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props)
    this.updateLimit = this.updateLimit.bind(this)
    this.back = this.back.bind(this)
    this.next = this.next.bind(this)
  }

  updateLimit(e) {
    this.props.update({
      page: 1,
      limit: e.target.value
    })
  }

  updatePage(newPage) {
    const { count, limit, update } = this.props
    const totalPages = Math.ceil(count / limit)
    /* istanbul ignore if - couldn't get this branch, other places check this */
    if (newPage < 1) {
      newPage = 1
    }
    /* istanbul ignore if - couldn't get this branch, other places check this */
    if (newPage > totalPages) {
      newPage = totalPages
    }
    update({ page: newPage })
  }

  back() {
    this.updatePage(this.props.page - 1)
  }

  next() {
    this.updatePage(this.props.page + 1)
  }

  render() {
    const { count, limit, page } = this.props
    const totalPages = Math.ceil(count / limit)
    const fmt = this.props.intl.formatMessage
    return (
      <div className={styles.pagination}>
        <div><FormattedMessage {...userCount} values={{ count }}/></div>
        <div>
          <button data-test="pagination-prev-button"
            disabled={page <= 1} onClick={this.back}>
            <Icon name="chevron-left"/>
          </button>
          <span data-test="pagination-text">
            <FormattedMessage {...paging.current}
              values={{ page, totalPages }}/>
          </span>
          <button data-test="pagination-next-button"
            disabled={page >= totalPages} onClick={this.next}>
            <Icon name="chevron-right"/>
          </button>
        </div>
        <div>
          <select
            className="form-control"
            data-test="pagination-limit-select"
            onChange={this.updateLimit} value={limit}
          >
            <option value="25">{fmt(paging.size, { count: 25 })}</option>
            <option value="50">{fmt(paging.size, { count: 50 })}</option>
            <option value="100">{fmt(paging.size, { count: 100 })}</option>
          </select>
        </div>
      </div>
    )
  }

}

export default injectIntl(Pagination)
