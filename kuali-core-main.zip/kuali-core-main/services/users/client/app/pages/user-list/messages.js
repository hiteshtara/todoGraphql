/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

const messages = defineMessages({
  userCount: {
    id: 'users.list.count',
    description: 'Number of users in list',
    defaultMessage: '{count, plural, one {# User} other {# Users}}' //eslint-disable-line max-len
  },
  search: {
    id: 'users.list.search',
    description: 'Placeholder for search box in user list',
    defaultMessage: 'Search Users'
  },
  addUser: {
    id: 'users.list.add',
    description: 'Link text to add a new user',
    defaultMessage: '+ Add User'
  }
})
export const { userCount } = messages
export const { search } = messages
export const { addUser } = messages
export default messages
