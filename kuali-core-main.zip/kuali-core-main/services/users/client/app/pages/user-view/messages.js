/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

const messages = defineMessages({
  deleteUser: {
    id: 'user.view.delete',
    description: 'Delete the currently viewed user',
    defaultMessage: 'Delete User'
  },
  approveUser: {
    id: 'user.view.approve',
    description: 'Approve the currently viewed user',
    defaultMessage: 'Approve User'
  },
  deleteConfirmation: {
    id: 'user.view.confirmDelete',
    description: 'Ask the user to confirm deletion',
    defaultMessage: 'Are you sure you want to delete this user?'
  },
  impersonate: {
    id: 'user.view.impersonate',
    description: 'Impersonate the user',
    defaultMessage: 'Impersonate'
  }
})
export const { deleteUser } = messages
export const { approveUser } = messages
export const { deleteConfirmation } = messages
export const { impersonate } = messages
export default messages
