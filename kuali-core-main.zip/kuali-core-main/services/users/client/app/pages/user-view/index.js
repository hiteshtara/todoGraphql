/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint no-alert: 0 */

import React, { Component } from 'react'
import { Link } from 'react-router'
import { injectIntl, intlShape, FormattedMessage } from 'react-intl'
import { labels } from 'shared/i18n'
import { get } from 'lodash'

import styles from './style'
import {
  deleteUser,
  deleteConfirmation,
  impersonate,
  approveUser
} from './messages'
import { fields } from '../../messages'
import { UserType } from '../../common/prop-types'
import * as Users from '../../stores/users'
import { GroupTypeaheadView } from '../../common/group-typeahead'

class UserView extends Component {
  displayName: 'UserView'

  static propTypes = {
    curUser: UserType.isRequired,
    intl: intlShape.isRequired,
    user: UserType
  }

  constructor(props) {
    super(props)
    this.renderField = this.renderField.bind(this)
    this.deleteUser = this.deleteUser.bind(this)
    this.approveUser = this.approveUser.bind(this)
    this.impersonateUser = this.impersonateUser.bind(this)
    this.state = { user: props.user }
  }

  async deleteUser() {
    if (confirm(this.props.intl.formatMessage(deleteConfirmation))) {
      try {
        await Users.deleteUser(this.props.user.id)
        window.location = '#/'
      } catch (e) {
        /* istanbul ignore next */
        this.setState({ error: JSON.stringify(e) })
      }
    }
  }

  async approveUser() {
    try {
      const user = Object.assign({}, this.props.user, { approved: true })
      await Users.saveUser(user.id, user)
      window.location.reload()
    } catch (e) {
      /* istanbul ignore next */
      this.setState({ error: JSON.stringify(e) })
    }
  }

  async impersonateUser() {
    try {
      await Users.impersonateUser(this.state.user)
      window.location = '/apps'
    } catch (ex) {
      /* istanbul ignore next */
      this.setState({ error: JSON.stringify(ex) })
    }
  }

  renderField({ children, id, val }) {
    let value = val || this.props.user[id]
    if (typeof value === 'boolean') {
      value = value.toString()
    }
    return (
      <div className={styles.field}>
        <label>{children}</label>
        <div>{value}</div>
      </div>
    )
  }

  render() {
    const { user } = this.props
    const isAdmin = this.props.curUser.role === 'admin'
    const canEdit = isAdmin || this.props.curUser.id === user.id
    const Field = this.renderField
    const primaryGroup = <GroupTypeaheadView value={this.props.user.groupId} />
    return (
      <div className={styles.container}>
        <div>
          <div className={styles.header}>
            <img alt="" src="/img/v1/top-bar/profile.svg" />
            <h1>{user.displayName}</h1>
          </div>
          {this.state.error && <div>{this.state.error}</div>}
          <div className={styles.form}>
            <Field id="name"><FormattedMessage {...fields.display} /></Field>
            <Field id="role"><FormattedMessage {...fields.role} /></Field>
            <Field id="groupId" val={primaryGroup}>
              <FormattedMessage {...fields.groupId} />
            </Field>
            <Field id="approved">
              <FormattedMessage {...fields.approved} />
            </Field>
            <Field id="email"><FormattedMessage {...fields.email} /></Field>
            <Field id="username">
              <FormattedMessage {...fields.username} />
            </Field>
            <Field id="firstName">
              <FormattedMessage {...fields.first} />
            </Field>
            <Field id="lastName"><FormattedMessage {...fields.last} /></Field>
            <Field val="•••••••">
              <FormattedMessage {...labels.password} />
            </Field>
          </div>
          {canEdit &&
            <div className={styles.buttons}>
              <Link className="btn btn-success" to={`${user.id}/details/edit`}>
                <FormattedMessage {...labels.edit} />
              </Link>
              {isAdmin &&
                <button
                  className="btn btn-danger"
                  data-test="user-view-delete-btn"
                  onClick={this.deleteUser}
                >
                  <FormattedMessage {...deleteUser} />
                </button>}
              {isAdmin &&
                !user.approved &&
                <button
                  className="btn btn-success"
                  data-test="user-view-approve-btn"
                  onClick={this.approveUser}
                >
                  <FormattedMessage {...approveUser} />
                </button>}
              {isAdmin &&
                this.props.curUser.id !== user.id &&
                user.approved &&
                !this.props.curUser.impersonatedBy &&
                get(window, 'kualiInstitution.features.impersonation') &&
                <button
                  className="btn btn-success"
                  data-test="user-view-impersonate-btn"
                  onClick={this.impersonateUser}
                >
                  <FormattedMessage {...impersonate} />
                </button>}
            </div>}
        </div>
      </div>
    )
  }
}

export default injectIntl(UserView)
