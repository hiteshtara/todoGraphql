/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import { labels as sharedLabels } from 'shared/i18n'
import { assign } from 'lodash'

import { labels as localLabels, placeholders, errors } from './messages'

import styles from './styles'

const labels = assign({}, sharedLabels, localLabels)

export class _NewKeyForm extends Component {

  constructor(props) {
    super(props)
    this.callDelegate = this.callDelegate.bind(this)
    this.checkSubmit = this.checkSubmit.bind(this)
    this.state = {}
  }

  callDelegate() {
    const name = this.refs.newKeyName.value
    const state = this.state
    if (!name) {
      state.error = this.props.intl.formatMessage(errors.noName)
    } else {
      delete state.error
      this.props.success(name)
    }
    this.setState(state)
  }

  checkSubmit(event) {
    if (event.key === 'Enter') {
      this.callDelegate()
    }
  }

  render() {
    const format = this.props.intl.formatMessage
    return (<div className={styles.creator}>
      <div>*{format(labels.name)}:</div>
      <input autoFocus data-test="new-key-form-input"
        onKeyPress={this.checkSubmit}
        placeholder={format(placeholders.keyName)} ref="newKeyName"
        type="text"/>
      <div>
        <div className="btn btn-success" data-test="new-key-form-create"
          onClick={this.callDelegate}>
          {format(labels.createKey)}
        </div>
        <div className="btn btn-cancel" data-test="new-key-form-cancel"
          onClick={this.props.cancel}>
          {format(labels.cancel)}
        </div>
      </div>
      <div className={styles.errorMsg}>{this.state.error}</div>
    </div>)
  }
}

_NewKeyForm.displayName = 'NewKeyForm'
_NewKeyForm.propTypes = {
  cancel: PropTypes.func.isRequired,
  intl: intlShape.isRequired,
  success: PropTypes.func.isRequired
}

export default injectIntl(_NewKeyForm)
