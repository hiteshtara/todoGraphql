/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'

import { UserType } from '../../common/prop-types'

import { labels, titles } from './messages'
import small from './small'
import normal from './normal'

export function _Header({ intl, mode, user, mq, onClick }) {
  const name = user.displayName || user.username
  const styles = mq === 'small' ? small : normal

  return (<div className={styles.header}>
    <h2>{name} &mdash; {intl.formatMessage(titles.apiKeys, { name })}</h2>
    {mode !== 'create'
      ? <div
        className="btn btn-primary"
        data-test="user-api-keys-header-button"
        onClick={onClick}>
          {intl.formatMessage(labels.newKey, { size: mq })}
        </div>
      : null}
  </div>)
}

_Header.displayName = 'ApiKeysHeader'
_Header.propTypes = {
  intl: intlShape.isRequired,
  mode: PropTypes.string.isRequired,
  mq: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  user: UserType.isRequired
}

export default injectIntl(_Header)
