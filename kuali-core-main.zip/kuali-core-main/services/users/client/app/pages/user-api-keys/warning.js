/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React from 'react'
import { injectIntl, intlShape, FormattedHTMLMessage } from 'react-intl'

import styles from './styles'
import { warning } from './messages' //eslint-disable-line max-len

export function _Warning({ intl }) {
  return (<div className={styles.warningContainer}>
    <div><i className="fa fa-exclamation-triangle fa-3x"/></div>
    <div className={styles.warningMessage}>
      <div>{intl.formatMessage(warning.title)}</div>
      <div><FormattedHTMLMessage {...warning.content}/></div>
    </div>
  </div>)
}

_Warning.displayName = 'ApiKeyWarning'

_Warning.propTypes = {
  intl: intlShape.isRequired
}

export default injectIntl(_Warning)
