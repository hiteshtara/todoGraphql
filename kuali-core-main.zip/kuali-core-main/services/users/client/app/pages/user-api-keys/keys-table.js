/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'
import cx from 'classnames'
import { injectIntl, intlShape } from 'react-intl'
import { labels as sharedLabels } from 'shared/i18n'
import { assign, sortBy } from 'lodash'

import { labels as localLabels, headers } from './messages'
import styles from './styles'
import normal from './normal'
import small from './small'

const dateFormat = { month: 'short', day: 'numeric', year: 'numeric' }
const labels = assign({}, sharedLabels, localLabels)

export function _ApiKeysTable({ intl, keys, mq, revoke }) {
  const format = intl.formatMessage
  const isSmall = mq === 'small'

  const tableBody = sortBy(keys, 'expiresAt').map(value => {
    return (<tr data-test="api-keys-row" key={value.id}>
      <td><span>{value.name}</span></td>
      {isSmall
        ? null
        : (<td><span>
            {intl.formatDate(value.createdAt, dateFormat)}
          </span></td>)}
      <td><span>
          {intl.formatDate(value.expiresAt, dateFormat)}
        </span></td>
      <td>
          <span>
          <div className={cx('btn btn-danger', styles.revoke)}
            data-test="api-keys-revoke-btn"
            onClick={() => revoke(value.id)}>
            {isSmall
              ? <i className="fa fa-trash-o fa-2x"/>
              : format(labels.revoke)}
          </div>
          </span>
      </td>
    </tr>)
  })

  const tableStyle = (isSmall ? small : normal).table
  return (<table className={cx('table', tableStyle)}>
    <thead>
    <tr>
      <th>{format(labels.name)}</th>
      {isSmall ? null : <th>{format(headers.creation)}</th>}
      <th>{format(headers.expiration)}</th>
      <th/>
    </tr>
    </thead>
    <tbody>
    {tableBody}
    </tbody>
  </table>)
}

_ApiKeysTable.displayName = 'ApiKeysTable'
_ApiKeysTable.propTypes = {
  intl: intlShape.isRequired,
  keys: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    createdAt: PropTypes.string.isRequired,
    expiresAt: PropTypes.string.isRequired
  })).isRequired,
  mq: PropTypes.string.isRequired,
  revoke: PropTypes.func.isRequired
}

export default injectIntl(_ApiKeysTable)
