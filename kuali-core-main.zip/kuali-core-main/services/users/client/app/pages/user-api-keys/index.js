/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import { labels as sharedLabels } from 'shared/i18n'
import { Preloader, MediaQueryify } from 'shared/kuali-common'
import { assign, has, isEmpty, omit } from 'lodash'

import {
  getApiKeysByUser as loadKeys,
  createApiKeyForUser as createKey,
  revokeApiKeyForUser as revokeKey
} from '../../stores/users'
import { UserType } from '../../common/prop-types'

import Header from './header'
import NewKeyForm from './form'
import ApiKeysTable from './keys-table'

import Warning from './warning'
import styles from './styles'
import small from './small'
import normal from './normal'
import { labels as localLabels } from './messages' //eslint-disable-line max-len

const labels = assign({}, sharedLabels, localLabels)

export class _UserApiKeys extends Component {
  displayName: 'UserApiKeys'

  static propTypes = {
    curUser: UserType.isRequired,
    intl: intlShape.isRequired,
    mq: PropTypes.oneOf(['small', 'medium', 'large', 'huge']).isRequired,
    user: UserType.isRequired
  }

  constructor(props) {
    super(props)
    if (props.curUser.role !== 'admin' && props.curUser.id !== props.user.id) {
      location.assign(`#/${props.user.id}/details`)
    }
    this.newKey = this.newKey.bind(this)
    this.fetchKeys = this.fetchKeys.bind(this)
    this.revoke = this.revoke.bind(this)
    this.cancelCreate = this.cancelCreate.bind(this)
    this.createNewKey = this.createNewKey.bind(this)
    this.styles = this.styles.bind(this)
    this.showForm = this.showForm.bind(this)

    this.state = { mode: 'view', errors: {} }
    this.fetchKeys()
  }

  /* istanbul ignore next - Not sure where this gets called*/
  styles() {
    if (this.props.mq === 'small') {
      return assign({}, styles, small)
    }
    return assign({}, styles, normal)
  }

  async fetchKeys() {
    const keys = await loadKeys(this.props.user.id)
    const state = this.state
    state.keys = keys
    this.setState(state)
  }

  async revoke(id) {
    await revokeKey(this.props.user.id, id)
    const state = this.state
    state.keys = state.keys.filter(k => k.id !== id)
    this.setState(state)
  }

  async createNewKey(name) {
    const key = await createKey(this.props.user.id, name)
    const state = this.state
    const keys = (state.keys || /* istanbul ignore next */ []).concat(key.token)
    this.setState({
      brandNewKey: key.value,
      keys,
      mode: 'view'
    })
  }

  newKey(name) {
    this.setState({ mode: 'creating' })
    this.createNewKey(name)
  }

  cancelCreate() {
    const state = this.state
    state.mode = 'view'
    this.setState(state)
  }

  showForm() {
    const state = omit(this.state, 'brandNewKey')
    state.mode = 'create'
    this.setState(state)
  }

  render() {
    if (has(this.state, 'keys') === false) {
      return <div className={styles.container}><Preloader /></div>
    }

    const format = this.props.intl.formatMessage

    let body
    if (this.state.mode === 'create') {
      body = (
        <NewKeyForm
          cancel={this.cancelCreate}
          data-test="uper-api-keys-new-key-form"
          success={this.newKey}
        />
      )
    } else if (this.state.brandNewKey || !isEmpty(this.state.keys)) {
      const currentKeys = (
        <ApiKeysTable
          keys={this.state.keys}
          mq={this.props.mq}
          revoke={this.revoke}
        />
      )

      if (this.state.brandNewKey) {
        body = (
          <div>
            <Warning />
            <div className={styles.brandNewKey}>
              <div>{this.state.brandNewKey}</div>
            </div>
            {currentKeys}
          </div>
        )
      } else {
        body = currentKeys
      }
    } else {
      body = <div className={styles.noKeys}>{format(labels.noKeys)}</div>
    }

    return (
      <div className={styles.container}>
        <Header
          mode={this.state.mode}
          mq={this.props.mq}
          onClick={this.showForm}
          user={this.props.user}
        />
        {body}
      </div>
    )
  }
}
export default MediaQueryify(injectIntl(_UserApiKeys))
