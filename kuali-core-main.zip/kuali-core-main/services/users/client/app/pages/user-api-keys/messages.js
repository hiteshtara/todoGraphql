/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const headers = defineMessages({
  creation: {
    id: 'users.headers.created',
    description: 'Column header for the creation dates of API keys',
    defaultMessage: 'Created'
  },
  expiration: {
    id: 'users.headers.expires',
    description: 'Column header for the expiration dates of API keys',
    defaultMessage: 'Expires'
  }
})

export const labels = defineMessages({
  revoke: {
    id: 'users.labels.revoke',
    description: 'Button text for revoking API keys',
    defaultMessage: 'Revoke'
  },
  noKeys: {
    id: 'users.labels.noKeys',
    description: 'Message for empty table if no API keys exist',
    defaultMessage: 'This account has no API Keys.'
  },
  newKey: {
    id: 'users.labels.newKey',
    description: 'Button text for showing form to create new API keys',
    defaultMessage: '{ size, select, small {+} other {Create KEY}}'
  },
  createKey: {
    id: 'users.labels.createKey',
    description: 'Button text to actually create an API key with a name',
    defaultMessage: 'Create Key'
  }
})

export const placeholders = defineMessages({
  keyName: {
    id: 'users.placeholders.apiKeyName',
    description: 'Placeholder text of input field for API key name',
    defaultMessage: 'Enter API Key Name'
  }
})

export const errors = defineMessages({
  failedToCreate: {
    id: 'users.errors.failedToCreate',
    description: 'Error message if API key creation failed',
    defaultMessage: 'Unable to create API key'
  },
  noName: {
    id: 'users.errors.noKeyName',
    description: 'Error message if API key creation is attempted without a name', //eslint-disable-line
    defaultMessage: '"Name" is required'
  }
})

export const titles = defineMessages({
  apiKeys: {
    id: 'users.titles.apiKeys',
    description: 'Partial section title for API keys',
    defaultMessage: 'API Keys'
  }
})

export const warning = defineMessages({
  title: {
    id: 'users.apiKeys.warningTitle',
    description: 'Title for the warning when new api keys are created',
    defaultMessage: 'Warning - READ ME!'
  },
  content: {
    id: 'users.apiKeys.warningContent',
    description: 'HTML content for warning when new api keys are created',
    defaultMessage: '<span style="font-weight:600;">Copy</span> and <span style="font-weight:600;">Save</span> this API key now, it cannot be displayed again!' //eslint-disable-line max-len
  }
})

export default { headers, labels, placeholders, errors, titles }
