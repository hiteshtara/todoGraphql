/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import axios from 'axios'
import { get } from 'lodash'

axios.interceptors.request.use(config => {
  /* istanbul ignore else - We don't ever make non json requests */
  if (!config.headers['Content-Type']) {
    config.headers['Content-Type'] = 'application/json'
  }
  const token = /authToken=(.+?)(;|$)/.exec(document.cookie) &&
    /authToken=(.+?)(;|$)/.exec(document.cookie)[1]
  if (!config.headers.Authorization && token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  config.withCredentials = true
  return config
}, /* istanbul ignore next */ error => {
  console.log(error)//eslint-disable-line no-console
})

axios.interceptors.response.use(response => {
  return response
}, error => {
  if (get(error, 'response.status') === 401) {
    let query = `return_to=${encodeURIComponent(window.location.href)}`
    window.location = `${error.response.headers.location || '/auth'}/?${query}`
    return Promise.reject(Object.assign(
      Error('User not logged in, redirecting'),
      error
    ))
  }
  return Promise.reject(error)
})
