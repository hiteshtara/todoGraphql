/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint react/prop-types: 0, react/no-multi-comp: 0 */

import React from 'react'
import axios from 'axios'

import Typeahead from '../components/generic-typeahead'
import TypeaheadView from '../components/generic-typeahead/view'

function getById(id) {
  return axios.get(`/api/v1/groups/${id}`)
    .then((response) => response.data)
}

function getAll() {
  return axios.get('/api/v1/groups/')
    .then((response) => response.data)
}

function searchByName(name) {
  return axios.get(`/api/v1/groups/?q=${name}`)
    .then((response) => response.data)
}

export const GroupTypeahead = ({
  onChange, placeholder, value, disabled, id
}) => (
  <Typeahead
    ariaLabel="Select Group"
    disabled={disabled}
    getAll={getAll}
    getById={getById}
    id={id}
    notFoundMsg="Group Deleted"
    onChange={onChange}
    placeholder={placeholder}
    searchByName={searchByName}
    value={value}
  />
)

export const GroupTypeaheadView = ({ value, link }) => (
  <TypeaheadView
    getById={getById}
    link={link}
    noValueMsg="No Group Selected"
    notFoundMsg="Group Deleted"
    value={value}
  />
)
