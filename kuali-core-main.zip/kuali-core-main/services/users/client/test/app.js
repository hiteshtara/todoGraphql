/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import assert from 'assert'
import { mount } from 'enzyme'
import React from 'react'
import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import App from '../app/app'
import { _Main } from '../app/pages/main'

const repeatObj = (times, obj) =>
  new Array(times).fill(null).map((_, i) => {
    const id = `id${i}`
    return {
      ...JSON.parse(JSON.stringify(obj)),
      id,
      newId: id
    }
  })

describe('Actions - <App />', () => {
  let origWidth, origHeight, mock

  before(() => {
    mock = new MockAdapter(axios)
    origWidth = window.innerWidth
    origHeight = window.innerHeight
  })

  beforeEach(() => {
    mock.reset()
    window.innerWidth = origWidth
    window.innerHeight = origHeight
  })

  after(() => {
    window.innerWidth = origWidth
    window.innerHeight = origHeight
    mock.restore()
  })

  it('renders', async () => {
    mock.onGet('/api/v1/users/current').reply(200, {
      id: 'test',
      displayName: 'test',
      role: 'admin',
      apps: {}
    })
    mock.onGet('/api/v1/institution').reply(200, {
      name: 'Monsters University',
      id: '1207296187375989873',
      newId: '56ee8f33ff97516706c37b50'
    })
    mock.onGet('/api/v1/users/1210810306089735501').reply(200, {
      name: 'Dallin rocks',
      username: 'dallin',
      email: 'dallin@kuali.co',
      createdAt: 1438219436000,
      updatedAt: 1463416025358,
      firstName: 'Dallin',
      lastName: 'Osmun',
      scopesCm: "'[\\'OVERLORD\\',\\'EDIT_CONFIG\\']'",
      schoolId: null,
      phone: null,
      approved: true,
      role: 'admin',
      id: '1210810306089735501',
      newId: '56ee8fb2ff97516706c37c17',
      displayName: 'Dallin rocks',
      ssoId: null
    })
    mock.onGet(/\/api\/v1\/users\/(.*)/).reply(200, [
      {
        name: 'Mike',
        username: 'mike',
        email: 'mikec@kuali.co',
        createdAt: 1438204770000,
        updatedAt: 1441935777000,
        firstName: 'Mike',
        lastName: 'Collier',
        scopesCm: "'[\\'OVERLORD\\',\\'EDIT_CONFIG\\']'",
        schoolId: null,
        approved: true,
        role: 'admin',
        phone: null,
        id: '1210687281006471963',
        newId: '56ee8fb2ff97516706c37bfd',
        displayName: 'Mike',
        ssoId: null
      },
      {
        name: 'Dallin rocks',
        username: 'dallin',
        email: 'dallin@kuali.co',
        createdAt: 1438219436000,
        updatedAt: 1463416025358,
        firstName: 'Dallin',
        lastName: 'Osmun',
        scopesCm: "'[\\'OVERLORD\\',\\'EDIT_CONFIG\\']'",
        schoolId: null,
        phone: null,
        approved: true,
        role: 'admin',
        id: '1210810306089735501',
        newId: '56ee8fb2ff97516706c37c17',
        displayName: 'Dallin rocks',
        ssoId: null
      }
    ], {
      'item-count': '2'
    })
    const test = mount(<App />)
    await Promise.delay(50)
    const main = test.find(_Main)
    main.node.props.router.push('/1210810306089735501/details')
    await Promise.delay(50)
    main.node.props.router.push('/1210810306089735501/details/edit')
    await Promise.delay(50)
    main.node.props.router.push('/')
    assert(test.html())
  })

  it('works with pagination', async () => {
    const dallin = {
      name: 'Dallin rocks',
      username: 'dallin',
      email: 'dallin@kuali.co',
      createdAt: 1438219436000,
      updatedAt: 1463416025358,
      firstName: 'Dallin',
      lastName: 'Osmun',
      scopesCm: "'[\\'OVERLORD\\',\\'EDIT_CONFIG\\']'",
      schoolId: null,
      phone: null,
      approved: true,
      role: 'admin',
      id: '1210810306089735501',
      newId: '56ee8fb2ff97516706c37c17',
      displayName: 'Dallin rocks',
      ssoId: null
    }
    const users = repeatObj(25, dallin)
    const fiftyUsers = repeatObj(50, dallin)
    mock.onGet('/api/v1/users/current').reply(200, {
      id: 'test',
      displayName: 'test',
      role: 'admin',
      apps: {}
    })
    mock.onGet('/api/v1/users/1210810306089735501').reply(200, {
      id: 'test',
      displayName: 'test',
      role: 'admin',
      apps: {}
    })
    mock.onGet('/api/v1/institution').reply(200, {
      name: 'Monsters University',
      id: '1207296187375989873',
      newId: '56ee8f33ff97516706c37b50'
    })
    mock.onGet(/\/api\/v1\/users\/\?limit=25&skip=(\d*)&q=/).reply(200, users, {
      'item-count': '100'
    })
    mock
      .onGet(/\/api\/v1\/users\/\?limit=50&skip=(\d*)&q=/)
      .reply(200, fiftyUsers, {
        'item-count': '100'
      })
    const el = mount(<App />)
    await Promise.delay(100)
    const prevButton = el.find('[data-test="pagination-prev-button"]')
    const nextButton = el.find('[data-test="pagination-next-button"]')
    const limitSelect = el.find('[data-test="pagination-limit-select"]')
    const paginationText = el.find('[data-test="pagination-text"]')
    assert(paginationText.text() === '1 of 4')
    nextButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '2 of 4')
    nextButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '3 of 4')
    nextButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '4 of 4')
    nextButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '4 of 4')
    prevButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '3 of 4')
    prevButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '2 of 4')
    prevButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '1 of 4')
    prevButton.simulate('click')
    await Promise.delay(10)
    assert(paginationText.text() === '1 of 4')
    limitSelect.simulate('change', {
      target: { value: '50' }
    })
    await Promise.delay(10)
    assert(paginationText.text() === '1 of 2')
  })

  it('works with searching', async () => {
    const dallin = {
      name: 'Dallin rocks',
      username: 'dallin',
      email: 'dallin@kuali.co',
      createdAt: 1438219436000,
      updatedAt: 1463416025358,
      firstName: 'Dallin',
      lastName: 'Osmun',
      scopesCm: "'[\\'OVERLORD\\',\\'EDIT_CONFIG\\']'",
      schoolId: null,
      phone: null,
      approved: true,
      role: 'admin',
      id: '1210810306089735501',
      newId: '56ee8fb2ff97516706c37c17',
      displayName: 'Dallin rocks',
      ssoId: null
    }
    const users = repeatObj(25, dallin)
    mock.onGet('/api/v1/users/current').reply(200, {
      id: 'test',
      displayName: 'test',
      role: 'admin',
      apps: {}
    })
    mock.onGet('/api/v1/users/1210810306089735501').reply(200, {
      id: 'test',
      displayName: 'test',
      role: 'admin',
      apps: {}
    })
    mock.onGet('/api/v1/institution').reply(200, {
      name: 'Monsters University',
      id: '1207296187375989873',
      newId: '56ee8f33ff97516706c37b50'
    })
    mock.onGet(/\/api\/v1\/users\/\?limit=25&skip=(\d*)&q=/).reply(200, users, {
      'item-count': '100'
    })
    const el = mount(<App />)
    await Promise.delay(100)
    const search = el.find('[data-test="user-list-search-input"]')
    search.simulate('change', {
      target: { value: 'dall' }
    })
    await Promise.delay(100)
  })

  it('throws redirect error if error code is 401', async () => {
    const error = Symbol('unique error')
    mock.onGet('/api/v1/users/current').reply(
      401,
      {},
      {
        location: ''
      }
    )
    const val = await axios.get('/api/v1/users/current').catch(err => {
      assert(err.message === 'User not logged in, redirecting')
      return error
    })
    assert(val === error)
  })

  describe('authenticated api requests', () => {
    it('sends authToken cookie as Authorization header', async () => {
      const url = '/api/v1/users/current'
      mock.onGet(url).reply(200)

      document.cookie = 'authToken=test'
      const response = await axios.get(url)
      assert(response.config.headers.Authorization === 'Bearer test')
    })
  })
})
