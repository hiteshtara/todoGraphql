/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import { expect } from 'chai'
import { mount, shallow, render } from 'enzyme'
import React from 'react'
import sinon from 'sinon'
import { identity } from 'lodash'
import { IntlProvider } from 'react-intl'
import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import UserApiKeys from '../../app/pages/user-api-keys'
import { _Header as Header } from '../../app/pages/user-api-keys/header'
import { _NewKeyForm as NewKeyForm } from '../../app/pages/user-api-keys/form'
import {
  _ApiKeysTable as ApiKeysTable
} from '../../app/pages/user-api-keys/keys-table' //eslint-disable-line
import messages from '../../app/pages/user-api-keys/messages'

const useDefault = msg => msg.defaultMessage

const intl = elem => (
  <IntlProvider locale="en" messages={messages}>
    {elem}
  </IntlProvider>
)

/* eslint-disable no-unused-expressions */
describe('API Key Management', () => {
  let sandbox, ctx, mock

  before(() => {
    mock = new MockAdapter(axios)
  })

  beforeEach(() => {
    sandbox = sinon.sandbox.create()
    ctx = {
      intl: {
        formatMessage: useDefault,
        formatDate: identity
      },
      user: {
        id: '12345',
        username: 'testuser',
        role: 'admin',
        displayName: 'testuser'
      },
      curUser: {
        id: '12345',
        username: 'testuser',
        role: 'admin',
        displayName: 'testuser'
      },
      mq: 'large'
    }
  })

  afterEach(() => {
    mock.reset()
    sandbox.restore()
  })

  after(() => mock.restore())

  it('renders', () => {
    shallow(<UserApiKeys {...ctx} />)
  })

  describe('Authorization', () => {
    let stub
    beforeEach(() => {
      stub = sandbox.stub(location, 'assign')
    })
    afterEach(() => {
      stub.resetBehavior()
    })

    it('redirects to user details if not admin and not same user', () => {
      ctx.curUser.role = 'user'
      ctx.curUser.id = '54321'
      ctx.user.id = '12345'

      mount(intl(<UserApiKeys {...ctx} />))
      sinon.assert.calledWith(stub, '#/12345/details')
    })

    it('does not redirect if admin', () => {
      ctx.curUser.role = 'admin'
      ctx.curUser.id = '54321'
      ctx.user.id = '12345'

      mount(intl(<UserApiKeys {...ctx} />))
      sinon.assert.notCalled(stub)
    })

    it('does not redirect if same user as current user', () => {
      ctx.curUser.role = 'user'
      ctx.curUser.id = '12345'
      ctx.user.id = '12345'

      mount(intl(<UserApiKeys {...ctx} />))
      sinon.assert.notCalled(stub)
    })
  })

  describe('Header', () => {
    it('renders with normal button', () => {
      ctx.user.displayName = null
      const el = shallow(<Header mode="view" {...ctx} />)

      expect(el.children()).to.have.length(2)

      expect(el.children().first().text()).to.contain(ctx.user.username)

      expect(el.find('.btn-primary')).to.have.length(1)
      expect(el.find('.btn-primary').text()).to.be.equal(
        messages.labels.newKey.defaultMessage
      )
    })

    it('renders display name with normal button', () => {
      ctx.user.displayName = 'display'
      const el = shallow(<Header mode="view" {...ctx} />)

      expect(el.children()).to.have.length(2)

      expect(el.children().first().text()).to.contain(ctx.user.displayName)

      expect(el.find('.btn-primary')).to.have.length(1)
      expect(el.find('.btn-primary').text()).to.be.equal(
        messages.labels.newKey.defaultMessage
      )
    })

    it('renders with small button', () => {
      ctx.mq = 'small'
      const el = shallow(<Header mode="view" {...ctx} />)

      expect(el.children()).to.have.length(2)

      expect(el.children().first().text()).to.contain(ctx.user.username)

      expect(el.find('.btn-primary')).to.have.length(1)
      expect(el.find('.btn-primary').text()).to.be.equal(
        messages.labels.newKey.defaultMessage
      )
    })

    it('renders without the button', () => {
      const el = shallow(<Header mode="create" {...ctx} />)

      expect(el.children()).to.have.length(1)

      expect(el.children().first().text()).to.contain(ctx.user.username)

      expect(el.find('.btn-primary')).to.have.length(0)
    })
  })

  describe('Form', () => {
    it('renders', () => {
      const el = shallow(
        <NewKeyForm {...ctx} cancel={identity} success={identity} />
      )
      expect(el.children().last().text()).to.be.empty
    })

    it('displays error on empty name', () => {
      const spy = sandbox.spy()
      const el = mount(<NewKeyForm {...ctx} cancel={identity} success={spy} />)
      el.find('.btn-success').simulate('click')
      expect(el.children().last().text()).to.not.be.empty
    })

    it('invokes success callback with key name', () => {
      const spy = sandbox.spy()
      const el = mount(<NewKeyForm {...ctx} cancel={identity} success={spy} />)
      const name = 'test-name'
      el.find('input[type="text"]').get(0).value = name
      el.find('.btn-success').simulate('click')
      expect(el.children().last().text()).to.be.empty
      sinon.assert.calledWith(spy, name)
    })

    it('invokes cancel callback', () => {
      const spy = sandbox.spy()
      const el = mount(<NewKeyForm {...ctx} cancel={spy} success={identity} />)
      el.find('.btn-cancel').simulate('click')
      expect(el.children().last().text()).to.be.empty
      sinon.assert.calledOnce(spy)
    })

    it('runs delegate with enter keypress', () => {
      const spy = sandbox.spy()
      const el = mount(<NewKeyForm {...ctx} cancel={identity} success={spy} />)
      const name = 'test-name'
      el.find('input[type="text"]').get(0).value = name
      el.find('input[type="text"]').simulate('keypress', { key: 'foo' })
      el.find('input[type="text"]').simulate('keypress', { key: 'Enter' })
      expect(el.children().last().text()).to.be.empty
      sinon.assert.calledWith(spy, name)
    })
  })

  describe('Key List', () => {
    beforeEach(() => {
      mock.onGet('/api/v1/users/12345/tokens?type=apiKey').reply(200, [
        {
          updatedAt: '2016-11-10T22:09:43.365Z',
          createdAt: '2016-11-10T22:09:43.365Z',
          userId: '182349erwfj321uedcj8312981je',
          expiresAt: '2017-11-10T22:09:43.359Z',
          name: 'asdf',
          type: 'apiKey',
          impersonatedBy: null,
          id: '58w4ty09fq349reh049138qrhe094hqre9'
        }
      ])
    })

    const key = {
      id: '1234',
      name: 'test',
      createdAt: new Date().toISOString(),
      expiresAt: new Date().toISOString()
    }

    it('renders UserApiKeys', async () => {
      const el = shallow(intl(<UserApiKeys {...ctx} mq="medium" />))
      await Promise.delay(50)
      el.setState({ mode: 'create' })
      el.setState({ mode: 'view', keys: [] })
      el.setState({ brandNewKey: true })
    })

    it('calls various methods', async () => {
      const el = mount(intl(<UserApiKeys {...ctx} mq="large" />))
      await Promise.delay(50)
      const headerBtn = el.find('[data-test="user-api-keys-header-button"]')
      headerBtn.simulate('click')
      await Promise.delay(50)
      const cancelBtn = el.find('[data-test="new-key-form-cancel"]')
      cancelBtn.simulate('click')
    })

    it('revokes key', async () => {
      let uri = '/api/v1/users/12345/tokens/58w4ty09fq349reh049138qrhe094hqre9'
      mock.onDelete(uri).reply(204)
      const el = mount(intl(<UserApiKeys {...ctx} />))
      await Promise.delay(50)
      const rowsBefore = el.find('[data-test="api-keys-row"]')
      expect(rowsBefore).to.have.length(1)
      const revokeBtn = el.find('[data-test="api-keys-revoke-btn"]')
      revokeBtn.simulate('click')
      await Promise.delay(50)
      const rowsAfter = el.find('[data-test="api-keys-row"]')
      expect(rowsAfter).to.have.length(0)
    })

    it('creates a key', async () => {
      let uri = '/api/v1/users/12345/tokens'
      mock.onPost(uri).reply(201, {
        token: {
          ...key,
          id: '1235'
        },
        value: '322132123124kj1l2k4j1lkj2;23lkj1;l32kj1'
      })
      const el = mount(intl(<UserApiKeys {...ctx} />))
      await Promise.delay(50)
      expect(el.find('[data-test="api-keys-row"]')).to.have.length(1)
      el.find('[data-test="user-api-keys-header-button"]').simulate('click')
      const createInput = el.find('[data-test="new-key-form-input"]')
      createInput.simulate('keyPress', { key: 'Tab' })
      createInput.simulate('keyPress', { key: 'Enter' })
      createInput.get(0).value = 'new token'
      createInput.simulate('keyPress', { key: 'Enter' })
      await Promise.delay(50)
    })

    it("creates a key and doesn't fail if no keys are present", async () => {
      let uri = '/api/v1/users/12345/tokens'
      mock.onPost(uri).reply(201, {
        token: {
          ...key,
          id: '1235'
        },
        value: '322132123124kj1l2k4j1lkj2;23lkj1;l32kj1'
      })
      const el = mount(intl(<UserApiKeys {...ctx} />))
      await Promise.delay(50)
      el.setState({ keys: null })
      el.find('[data-test="user-api-keys-header-button"]').simulate('click')
      const createInput = el.find('[data-test="new-key-form-input"]')
      createInput.get(0).value = 'new token'
      createInput.simulate('keyPress', { key: 'Enter' })
      await Promise.delay(50)
    })

    it('renders full size', () => {
      const testKey = key
      const el = shallow(
        <ApiKeysTable {...ctx} keys={[testKey]} revoke={identity} />
      )
      expect(el.find('th')).to.have.length(4)
      expect(el.find('.fa-trash-o')).to.have.length(0)
    })

    it('renders small', () => {
      ctx.mq = 'small'
      const testKey = key
      const el = shallow(
        <ApiKeysTable {...ctx} keys={[testKey]} revoke={identity} />
      )
      expect(el.find('th')).to.have.length(3)
      expect(el.find('.fa-trash-o')).to.have.length(1)
    })
  })
})
/*eslint-enable*/
