/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import { spy } from 'sinon'
import { expect } from 'chai'
import { mount } from 'enzyme'
import React from 'react'
import { IntlProvider } from 'react-intl'
import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import UserView from '../../app/pages/user-view'

const intl = (elem) => (<IntlProvider locale="en" messages={{}}>
  {elem}
</IntlProvider>)

describe('User Edit', () => {

  let mock
  let oldConfirm = global.confirm
  let oldKualiInstitution = window.kualiInstitution

  before(() => {
    mock = new MockAdapter(axios)
    window.kualiInstitution = {
      features: {
        impersonation: true
      }
    }
  })

  afterEach(() => {
    mock.reset()
    global.confirm = oldConfirm
  })

  after(() => {
    mock.restore()
    window.kualiInstitution = oldKualiInstitution
  })

  it('renders', async () => {
    mock.onDelete('/api/v1/users/foo2').reply(204)
    mock.onPut('/api/v1/users/foo2').reply(200)
    global.confirm = spy(() => true)
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserView {...props} />))
    const deleteButton = el.find('[data-test="user-view-delete-btn"]')
    const approveButton = el.find('[data-test="user-view-approve-btn"]')
    deleteButton.simulate('click')
    approveButton.simulate('click')
    await Promise.delay(100)
    expect(global.confirm.callCount).to.be.equal(1)
    global.confirm = spy(() => false)
    deleteButton.simulate('click')
    expect(global.confirm.callCount).to.be.equal(1)
  })

  it('renders errors', async () => {
    mock.onDelete('/api/v1/users/foo2').reply(422)
    mock.onPut('/api/v1/users/foo2').reply(422)
    global.confirm = spy(() => true)
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserView {...props} />))
    const deleteButton = el.find('[data-test="user-view-delete-btn"]')
    const approveButton = el.find('[data-test="user-view-approve-btn"]')
    deleteButton.simulate('click')
    approveButton.simulate('click')
    await Promise.delay(100)
    expect(global.confirm.callCount).to.be.equal(1)
    global.confirm = spy(() => false)
    deleteButton.simulate('click')
    expect(global.confirm.callCount).to.be.equal(1)
  })

  it('impersonates the user', async () => {
    mock.onPost('/api/v1/auth/impersonate').reply(200)
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser',
        approved: true
      }
    }
    const el = mount(intl(<UserView {...props} />))
    const impersonateButton = el.find('[data-test="user-view-impersonate-btn"]')
    impersonateButton.simulate('click')
    await Promise.delay(100)
  })

  it('renders with non-admin', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser'
      },
      user: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser',
        approved: true
      }
    }
    mount(intl(<UserView {...props} />))
  })

  it('renders with group', async () => {
    mock.onGet('/api/v1/groups/123').reply(200, {
      id: '123',
      name: 'My Group'
    })
    const props = {
      curUser: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser'
      },
      user: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser',
        approved: true,
        groupId: '123'
      }
    }
    mount(intl(<UserView {...props} />))
  })

  it('renders with error', async () => {
    mock.onGet('/api/v1/groups/123').reply(404)
    mock.onGet('/api/v1/groups/124').reply(200, {
      id: '123',
      name: 'My Group'
    })
     mock.onGet('/api/v1/groups/124').reply(200, {
      id: '125'
    })
    const props = {
      curUser: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser'
      },
      user: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser',
        approved: true,
        groupId: '123'
      }
    }
    const el = mount(intl(<UserView {...props} />))
    el.setProps({
      user: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser',
        approved: true,
        groupId: '124'
      }
    })
  })

})
