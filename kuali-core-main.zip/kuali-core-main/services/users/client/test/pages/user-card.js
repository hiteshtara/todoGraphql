/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable react/no-multi-comp */

import Promise from 'bluebird'
import { mount } from 'enzyme'
import React from 'react'
import { IntlProvider } from 'react-intl'
import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import UserCard from '../../app/pages/user-card'

const Child = () => <div />

const intl = (elem) => (<IntlProvider locale="en" messages={{}}>
  {elem}
</IntlProvider>)

describe('User Card', () => {

  let mock

  before(() => {
    mock = new MockAdapter(axios)
  })

  afterEach(() => mock.reset())

  after(() => mock.restore())

  it('renders', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'user',
        displayName: 'testuser'
      },
      params: {},
      children: <Child />
    }
    const el = mount(intl(<UserCard {...props} />))
    await Promise.delay(50)
    el.setProps({ params: {} })
  })

})
