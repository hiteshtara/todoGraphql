/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import { expect } from 'chai'
import sinon from 'sinon'
import { mount } from 'enzyme'
import React from 'react'
import { IntlProvider } from 'react-intl'
import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import UserEdit from '../../app/pages/user-edit'

// const useDefault = msg => msg.defaultMessage
const intl = elem => (
  <IntlProvider locale="en" messages={{}}>
    {elem}
  </IntlProvider>
)

const getSaveButton = el => el.find('[data-test="user-edit-save-button"]')
const getError = el => el.find('[data-test="user-edit-error"]')
const getField = (el, id) => el.find(`#${id}`)

describe('User Edit', () => {
  let sandbox, ctx, mock

  before(() => {
    mock = new MockAdapter(axios)
  })

  beforeEach(() => {
    sandbox = sinon.sandbox.create()
    ctx = {
      user: {
        id: '12345',
        username: 'testuser',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: ''
      },
      curUser: {
        id: '12345',
        username: 'testuser',
        role: 'admin',
        displayName: 'testuser'
      },
      mq: 'large'
    }
  })

  afterEach(() => {
    mock.reset()
    sandbox.restore()
  })

  after(() => mock.restore())

  it('renders', async () => {
    mock.onPut('/api/v1/users/foo2').reply(200)
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: ''
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserEdit {...props} />))
    const saveButton = getSaveButton(el)
    saveButton.simulate('click')
  })

  describe('Authorization', () => {
    let stub
    beforeEach(() => {
      stub = sandbox.stub(location, 'assign')
    })
    afterEach(() => {
      stub.resetBehavior()
    })

    it('redirects to user details if not admin and not same user', () => {
      ctx.curUser.role = 'user'
      ctx.curUser.id = '54321'
      ctx.user.id = '12345'

      mount(intl(<UserEdit {...ctx} />))
      sinon.assert.calledWith(stub, '#/12345/details')
    })

    it('does not redirect if admin', () => {
      ctx.curUser.role = 'admin'
      ctx.curUser.id = '54321'
      ctx.user.id = '12345'

      mount(intl(<UserEdit {...ctx} />))
      sinon.assert.notCalled(stub)
    })

    it('does not redirect if same user as current user', () => {
      ctx.curUser.role = 'user'
      ctx.curUser.id = '12345'
      ctx.user.id = '12345'

      mount(intl(<UserEdit {...ctx} />))
      sinon.assert.notCalled(stub)
    })
  })

  it('catches password errors', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: ''
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserEdit {...props} />))
    const saveButton = getSaveButton(el)
    const password = getField(el, 'password')
    const confirm = getField(el, 'password-confirm')
    password.simulate('change', {
      target: { value: 'testabcd' }
    })
    saveButton.simulate('click')
    expect(getError(el).text()).to.be.equal('Passwords do not match!')
    confirm.simulate('change', {
      target: { value: 'testabcd' }
    })
    mock.onPut('/api/v1/users/foo2').reply(422, {
      errors: [
        {
          name: 'ValidationError',
          fields: ['password', 'username', 'someOtherField']
        }
      ]
    })
    saveButton.simulate('click')
    await Promise.delay(50)
    expect(getError(el).text()).to.be.equal(
      'Password must be at least 8 characters'
    )
  })

  it('catches username errors', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: ''
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserEdit {...props} />))
    const saveButton = getSaveButton(el)
    const username = getField(el, 'username')
    username.simulate('change', {
      target: { value: 'test' }
    })
    mock.onPut('/api/v1/users/foo2').reply(422, {
      errors: [
        {
          name: 'DuplicateKeyError',
          fields: ['username']
        }
      ]
    })
    saveButton.simulate('click')
    await Promise.delay(50)
  })

  it('catches generic errors', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: ''
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserEdit {...props} />))
    const saveButton = getSaveButton(el)
    const username = getField(el, 'username')
    username.simulate('change', {
      target: { value: 'test' }
    })
    mock.onPut('/api/v1/users/foo2').reply(422, {
      errors: [
        {
          name: 'SomeOtherError',
          fields: ['username']
        }
      ]
    })
    saveButton.simulate('click')
    await Promise.delay(50)
  })

  it('catches unknown errors', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: ''
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      }
    }
    const el = mount(intl(<UserEdit {...props} />))
    const saveButton = getSaveButton(el)
    const username = getField(el, 'username')
    username.simulate('change', {
      target: { value: 'test' }
    })
    mock.onPut('/api/v1/users/foo2').reply(422, {
      foo: 'bar'
    })
    saveButton.simulate('click')
    await Promise.delay(50)
  })

  it('follows new path', async () => {
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      params: {},
      route: {
        path: 'new'
      }
    }
    const el = mount(intl(<UserEdit {...props} />))
    const saveButton = getSaveButton(el)
    const username = getField(el, 'username')
    username.simulate('change', {
      target: { value: 'test' }
    })
    mock.onPut('/api/v1/users/foo2').reply(422, {
      foo: 'bar'
    })
    saveButton.simulate('click')
    await Promise.delay(50)
  })

  it('gets groups', async () => {
    mock.onGet('/api/v1/groups/').reply(200, [
      {
        id: '123',
        name: 'foo'
      },
      {
        id: '456'
      }
    ])
    mock.onGet('/api/v1/groups/?q=a').reply(200, [
      {
        id: '456'
      }
    ])
    mock.onGet('/api/v1/groups/456').reply(200, {
      id: '456'
    })
    const props = {
      curUser: {
        id: 'foo',
        role: 'admin',
        displayName: 'testuser'
      },
      user: {
        id: 'foo2',
        role: 'user',
        displayName: 'testuser'
      },
      route: {
        path: 'edit'
      },
      params: {}
    }
    const el = mount(intl(<UserEdit {...props} />))
    await Promise.delay(50)
    const groupId = getField(el, 'groupId')
    groupId.simulate('focus')
    groupId.simulate('change', {
      target: { value: 'a' }
    })
    await Promise.delay(50)
    const typeaheadItems = el.find('[data-test="typeahead-item"]')
    typeaheadItems.find('button').simulate('click')
    groupId.simulate('blur')
    await Promise.delay(50)
    const removeButton = el.find('[data-test="remove-button"]')
    removeButton.simulate('click')
  })
})
