/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect, assert } from 'chai'
import sinon from 'sinon'
import { defaultLogger } from 'shared/logging'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'

import { getUserModel } from '../server/resources/users/model'
import users from '../server/resources/users/plugin'

const { connectionKey, connection } = getTestConnectionInfo()
let User = getUserModel(connection)

describe('user model', () => {
  let si
  let sandbox

  before(async () => {
    await User.ensureIndexes()
  })

  beforeEach(async () => {
    si = seneca
    si.use(users)
    sandbox = sinon.sandbox.create()
    await User.remove({})
  })

  afterEach( () => {
    sandbox.restore()
  })

  it('saves a user', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: { username: 'test', email: 'test@domain.org', password: 'password',
        role: 'user' },
      connectionKey
    })
    assert.equal(user.username, 'test')
  })

  it('allows emails as username', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test+foo@domain.org',
        email: 'test@domain.org',
        password: 'password',
        role: 'user'
      },
      connectionKey
    })
    assert.equal(user.username, 'test+foo@domain.org')
  })

  it('saves a user with plus sign', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: { username: 'test+test', email: 'test+test@domain.org',
      password: 'password',
        role: 'user' },
      connectionKey
    })
    assert.equal(user.username, 'test+test')
  })

  it('retains other fields', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: { username: 'test', password: 'password',
        role: 'user' },
      connectionKey
    })
    expect(user).to.have.property('email')
  })

  it('saves email as name if no other fallbacks are provided', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        role: 'user',
        password: 'password',
        email: 'test@testerson.com'
      },
      connectionKey
    })
    expect(user).to.have.property('displayName', 'test@testerson.com')
  })

  it('fails with short password', async () => {
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', role: 'user', email: 'test@domain.org',
          password: 'short' },
        connectionKey
      })
    } catch (err) {
      assert.equal(err.name, 'ValidationError')
        return
    }
    throw new Error('save unsuccessfully succeeded')
  })

  it('succeeds with null email', async () => {
    let user = await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', email: null, role: 'user' },
        connectionKey
      })
    assert.equal(user.username, 'test')
  })

  it('fails with bad email', async () => {
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', email: 'bad email', role: 'user' },
        connectionKey
      })
    } catch (err) {
      assert.equal(err.name, 'ValidationError')
      return
    }
    throw new Error('save unsuccessfully succeeded')
  })

  it('fails without email or username', async () => {
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { role: 'user' },
        connectionKey
      })
    } catch (err) {
      assert.equal(err.name, 'ValidationError')
      return
    }
    throw new Error('save unsuccessfully succeeded')
  })

  it('fails to update with bad email', async () => {
    try {
      let user = await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })
      user.email = 'bad email'
      await si.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: user,
        connectionKey })
    } catch (err) {
      assert.equal(err.name, 'ValidationError')
      return
    }
    throw new Error('save unsuccessfully succeeded')
  })

  it('fails with unsupported role', async () => {
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', email: 'test@domain.org',
          role: 'unsupported' },
        connectionKey
      })
    } catch (err) {
      assert.equal(err.name, 'ValidationError')
      return
    }
    throw new Error('save unsuccessfully succeeded')
  })

  it('fails with bad username', async () => {
    try {
      await new User({
        username: '!!(@#$test@',
        email: 'test@domain.com',
        role: 'user'
      }).save()
      assert.fail('save succeeded')
    } catch (err) {
      expect(err).to.have.property('name', 'ValidationError')
      expect(err).to.have.deep.property('errors.username')
    }
  })

  it('fails with duplicate username', async () => {
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test2@domain.org', role: 'user' },
        connectionKey
      })
    } catch (err) {
      assert(/duplicate key error/.test(err))
      return
    }
    throw new Error('duplicate key error not thrown')
  })

  it('fails to update with duplicate username', async () => {
    let result
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'test',
          email: 'test@domain.org',
          role: 'user',
          uid: '1'
        },
        connectionKey
      })
      let user = await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'test2',
          email: 'test2@domain.org',
          role: 'user',
          uid: '2'
        },
        connectionKey
      })
      user.username = 'Test'
      await si.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: user,
        connectionKey })
      result = await si.actAsync({ role: 'users', cmd: 'list' })
    } catch (err) {
      assert(/duplicate key error/.test(err))
      return
    }
    throw result
  })

  it('fails with duplicate email', async () => {
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'test2', email: 'test@domain.org', role: 'user' },
        connectionKey
      })
    } catch (err) {
      assert(/duplicate key error/.test(err))
      return
    }
    throw new Error('duplicate key error not thrown')
  })

  it('updates an existing user', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test',
        email: 'test@domain.org',
        firstName: 'Tester',
        role: 'user'
      },
      connectionKey
    })
    assert.equal(user.firstName, 'Tester')
    let id = user.id
    user.firstName = 'Tested'
    let updatedUser = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: user,
      connectionKey
    })
    assert.equal(updatedUser.firstName, 'Tested')
    assert.equal(id.toString(), updatedUser.id.toString())
  })

  it('doesn\'t pollute user password', async () => {
    let user1 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test',
        email: 'test@domain.org',
        firstName: 'Tester',
        role: 'user',
        password: 'password1'
      },
      connectionKey
    })
    await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test2',
        email: 'test2@domain.org',
        firstName: 'Tester2',
        role: 'user',
        password: 'password2'
      },
      connectionKey
    })
    user1.lastName = 'McTesty'
    user1 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: user1,
      connectionKey
    })
    let authUser = await si.actAsync({
      role: 'users',
      cmd: 'authenticate',
      data: {
        username: 'test',
        password: 'password1'
      },
      connectionKey
    })
    expect(user1).to.deep.equal(authUser)
  })

  it('uses numeric timestamps', async () => {
    let user = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test',
        email: 'test@domain.org',
        firstName: 'Tester',
        role: 'user'
      },
      connectionKey
    })
    expect(user.createdAt).to.be.a('Number')
    expect(user.updatedAt).to.be.a('Number')
  })

  it('logs a fatal error on index error', done => {
    const spy = sandbox.spy(defaultLogger, 'fatal')
    User.emit('index', new Error('test'))
    sinon.assert.calledOnce(spy)
    done()
  })

  it('can save two users with empty email', async () => {
    let user1 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test',
        email: '  ',
        firstName: 'Tester',
        role: 'user'
      },
      connectionKey
    })
    let user2 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test2',
        email: '  ',
        firstName: 'Tester2',
        role: 'user'
      },
      connectionKey
    })

    expect(user1.email).to.be.equal(null)
    expect(user2.email).to.be.equal(null)
  })

  it('can save two users with null email', async () => {
    let user1 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test',
        email: null,
        firstName: 'Tester',
        role: 'user'
      },
      connectionKey
    })
    let user2 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test2',
        email: null,
        firstName: 'Tester2',
        role: 'user'
      },
      connectionKey
    })

    expect(user1.email).to.be.equal(null)
    expect(user2.email).to.be.equal(null)
  })

  it('can save two users without email', async () => {
    let user1 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test',
        firstName: 'Tester',
        role: 'user'
      },
      connectionKey
    })
    let user2 = await si.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        username: 'test2',
        firstName: 'Tester2',
        role: 'user'
      },
      connectionKey
    })

    expect(user1.email).to.be.equal(null)
    expect(user2.email).to.be.equal(null)
  })

  it('returns unhandled mongo error', async () => {
    class MongoError extends Error {
      constructor() {
        super()
        this.name = 'MongoError'
      }
    }
    const error = new MongoError()
    sandbox.stub(User, 'find').yields(error)
    try {
      await si.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'test',
          firstName: 'Tester',
          role: 'user',
          id: '1346972247374804096'
        },
        connectionKey
      })
    } catch (ex) {
      expect(ex.name).to.equal('MongoError')
      return
    }
    throw new Error('Exception expected')
  })

  describe('SnowflakeId backwards compatibility', () => {
    it('returns _id as id when snowflakeId is not present', async () => {
      let user = await User.create({ username: 'test',
        updatedBy: { id: 'test' } })
      let json = user.toJSON()
      assert(json.id, user._id)
      assert.equal(json.hasOwnProperty('snowflakeId'), false)
    })

    it('returns snowflakeId as id and _id as newId correctly', async () => {
      let snowflakeId = '1346972247374804096'
      let user = await User.create({ snowflakeId, username: 'test',
        updatedBy: { id: 'test' } })
      let json = user.toJSON()
      expect(json).to.contain.keys({
        id: snowflakeId,
        newId: user._id
      })
      expect(json).to.not.have.property('snowflakeId')
    })
  })
})
