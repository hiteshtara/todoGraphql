/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import express from 'express'
import seed from 'services/users/server/resources/users/seed'
import request from 'supertest-as-promised'
import { getTestConnectionInfo } from 'shared/test-helpers'

import userApp from '..'
import { getUserModel } from '../server/resources/users/model'

const { connection } = getTestConnectionInfo()
let User = getUserModel(connection)
let app = express()
app.use(userApp)

describe('Admin User Seed', () => {
  beforeEach(async () => {
    await User.remove({})
  })

  afterEach(async () => {
    await User.remove({})
  })

  describe('No Users', () => {
    it('creates admin user ', async () => {
      expect(await User.count({})).to.equal(0)
      await seed(connection)
      expect(await User.count({})).to.equal(1)
    })

    it('can seed the user through api', async () => {
      expect(await User.count({})).to.equal(0)
      await request(app).post('/api/v1/users/seed')
        .expect(200)
      expect(await User.count({})).to.equal(1)
    })
  })

  describe('Users already exist', () => {
    it('does not create admin user ', async () => {
      await User.create({
        username: 'what',
        password: 'whatwhat',
        updatedBy: { id: 'test' }
      })
      expect(await User.count({})).to.equal(1)
      await seed(connection)
      expect(await User.count({})).to.equal(1)
    })
  })
})
