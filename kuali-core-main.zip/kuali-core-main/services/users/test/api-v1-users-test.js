/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/*eslint-disable no-unused-expressions*/

import { expect, assert } from 'chai'
import config from 'config'
import express from 'express'
import jwt from 'jsonwebtoken'
import { each, find, includes, map, pick } from 'lodash'
import moment from 'moment'
import ServiceAgent from 'service2service'
import request from 'supertest-as-promised'
import institutionLoader from 'shared/institution-loader'
import logging from 'shared/logging'
import responseLocals from 'shared/middleware/response-locals'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import sinon from 'sinon'

import usersApp from '..'
import { getUserModel } from '../server/resources/users/model'
import * as tokenService from '../../auth/server/resources/tokens/utils'

let sandbox
let app
const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)

let validObjectId = '743c5be0ce1130c0c78b509f'

async function getSecretFor(subdomain) {
  let value = await seneca.actAsync({
    role: 'institutions',
    cmd: 'getSecret',
    data: { subdomain },
    connectionKey
  })
  return value.secret
}

async function getAuthHeader(userId) {
  let secret = await getSecretFor('kuali')

  let token = await seneca.actAsync({
    role: 'token',
    cmd: 'sign',
    id: userId,
    secret,
    connectionKey
  })

  return `Bearer ${token.token}`
}

async function createUser(data) {
  return await seneca.actAsync({
    role: 'users',
    cmd: 'save',
    currentUser: { id: 'test' },
    data,
    connectionKey
  })
}

describe('API V1 Users', () => {
  before(async () => {
    app = express()
    app.use(logging({ test: 'users-api-v1' }))
    app.use(responseLocals)
    app.use(institutionLoader)
    app.use(usersApp)

    await seneca.actAsync({
      role: 'institutions',
      cmd: 'load',
      data: { subdomain: 'kuali', name: 'Kuali' },
      connectionKey
    })
  })
  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await User.remove({})
    assert.equal(await User.count(), 0)
  })

  afterEach(async () => {
    sandbox.restore()
    await User.remove({})
    assert.equal(await User.count(), 0)
  })

  describe('health route |', () => {
    it('returns a health status code', async () => {
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'user'
      })
      let { text } = await request(app)
        .get('/users/health')
        .set('Authorization', await getAuthHeader(user.id))
        .expect(204)
      assert.equal(text, '')
    })

    it('returns health status detail', async () => {
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'user'
      })
      let { text } = await request(app)
        .get('/users/health?detail=true')
        .set('Authorization', await getAuthHeader(user.id))
        .expect(200)
      assert.notEqual(text, '')
    })
  })

  describe('/api/v1/users/current', () => {
    it('decodes token', async () => {
      let res

      res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        connectionKey,
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'user',
          password: 'password',
          approved: true
        }
      })
      let authHeader = await getAuthHeader(res.id)
      let resp = await request(app)
        .get('/api/v1/users/current')
        .set('Authorization', authHeader)
        .expect(200)

      expect(resp.body).to.have.property('username', 'Test')
      expect(resp.body).to.not.have.property('passwordDigest')
    })
    it('decodes token for service user', async () => {
      const user = {
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        password: 'password',
        approved: true
      }

      const agent = new ServiceAgent({
        secret: config.serviceSecret,
        expire: 60 // 1 minute
      })
      const token = await agent.generate(null, { user })

      let resp = await request(app)
        .get('/api/v1/users/current')
        .set('Authorization', `Bearer ${token}`)
        .expect(200)

      expect(resp.body).to.have.property('username', 'Test')
      expect(resp.body).to.not.have.property('passwordDigest')
    })

    it("doesn't return the password digest", async () => {
      let user = await createUser({
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        password: 'testpass',
        connectionKey
      })

      let authHeader = await getAuthHeader(user.id)

      let resp = await request(app)
        .get('/api/v1/users/current')
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(resp.body.passwordDigest, undefined)
    })

    it('does not find missing user', async () => {
      const user = await createUser({
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        password: 'password',
        connectionKey
      })
      const authHeader = await getAuthHeader(user.id)
      await seneca.actAsync({
        role: 'users',
        currentUser: { id: 'test' },
        cmd: 'remove',
        id: user.id,
        connectionKey
      })

      await request(app)
        .get('/api/v1/users/current')
        .set('Authorization', authHeader)
        .expect(401)
    })

    it('fails get when errors occur', async () => {
      let res

      res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'user',
          password: 'password'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)
      sandbox.stub(User, 'find').yields({ error: true }, null)

      await request(app)
        .get('/api/v1/users/current')
        .set('Authorization', authHeader)
        .expect(401)
    })

    it('fails without token', async () => {
      await request(app).get('/api/v1/users/current').expect(401)
    })

    it('fails without `Bearer`', async () => {
      await request(app)
        .get('/api/v1/users/current')
        .set('Authorization', 'somefaketokenwithoutbearer')
        .expect(401)
    })
  })

  describe('/api/v1/users#put', () => {
    it('allows a user to update their own info', async () => {
      const user = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'user',
          uid: '2',
          password: 'password'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(user.id)

      await request(app)
        .put(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .send({
          firstName: 'Firster',
          id: user.id
        })
        .expect(200)

      let updated = await request(app)
        .get(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .expect(200)

      expect(updated.body).to.have.property('firstName', 'Firster')
    })

    it('gets proper error if there is a duplicate key error', async () => {
      let requestingUser = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'admin',
          uid: '2',
          password: 'password'
        },
        connectionKey
      })
      let otherUser = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          firstName: 'Ot',
          username: 'Other',
          email: 'test2@domain.org',
          role: 'user',
          uid: '1',
          password: 'password'
        },
        connectionKey
      })
      let authHeader = await getAuthHeader(requestingUser.id)
      await request(app)
        .put(`/api/v1/users/${otherUser.id}`)
        .set('Authorization', authHeader)
        .send({
          email: requestingUser.email,
          id: otherUser.id
        })
        .expect(422)
    })

    it('does not allow a user to update other user info', async () => {
      let requestingUser = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'user',
          uid: '2',
          password: 'password'
        },
        connectionKey
      })

      let otherUser = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          firstName: 'Ot',
          username: 'Other',
          email: 'test2@domain.org',
          role: 'user',
          uid: '1',
          password: 'password'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(requestingUser.id)

      await request(app)
        .put(`/api/v1/users/${otherUser.id}`)
        .set('Authorization', authHeader)
        .send({
          firstName: 'Firster',
          id: otherUser.id
        })
        .expect(403)
    })

    it('allows an admin to update others info', async () => {
      let requestingUser = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'admin' },
        connectionKey
      })

      let otherUser = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          firstName: 'Ot',
          username: 'Other',
          email: 'other@domain.org',
          role: 'user'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(requestingUser.id)

      let resp = await request(app)
        .put(`/api/v1/users/${otherUser.id}`)
        .set('Authorization', authHeader)
        .send({
          firstName: 'Firster',
          id: otherUser.id,
          username: 'Other',
          email: 'other2@domain.org',
          role: 'admin'
        })
      assert.equal(resp.status, 200)
      let updatedOther = await request(app)
        .get(`/api/v1/users/${otherUser.id}`)
        .set('Authorization', authHeader)

      assert.equal(updatedOther.status, 200)
      assert.equal(updatedOther.body.firstName, 'Firster')
      assert.equal(updatedOther.body.role, 'admin')
    })

    it('only saves user allowed properties', async () => {
      let user = await createUser({
        username: 'Test',
        email: 'firsttest@domain.org',
        role: 'user'
      })

      let authHeader = await getAuthHeader(user.id)

      const sentObject = {
        id: user.id,
        nonexistantproperty: 'Utah',
        username: 'Test',
        email: 'secondtest@domain.org',
        role: 'admin',
        scopesCm: 'somescopes',
        passwordDigest: 'newDigest',
        schoolId: 'newSchool'
      }

      let putResp = await request(app)
        .put(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .send(sentObject)

      assert.equal(putResp.status, 200)

      let getResp = await request(app)
        .get(`/api/v1/users/${putResp.body.id}`)
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(getResp.status, 200)
      assert.equal(getResp.body.id, sentObject.id)
      assert.equal(getResp.body.nonexistantproperty, undefined)
      assert.equal(getResp.body.role, 'user')
      assert.equal(getResp.body.scopesCm, undefined)
      assert.equal(getResp.body.passwordDigest, undefined)
      assert.equal(getResp.body.email, 'secondtest@domain.org')
    })

    it('returns 404 is user not found', async () => {
      let data = {
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        id: '567c5be0ce1130c0c78b509f'
      }

      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'admin' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .put('/api/v1/users/567c5be0ce1130c0c78b509f')
        .set('Authorization', authHeader)
        .send(data)

      assert.equal(resp.status, 404)
      assert.notEqual(resp.body.errors, undefined)
    })

    it('returns 404 if invalid user id', async () => {
      let data = {
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        id: '567c5be0ce1130c0c78b509f'
      }

      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .put('/api/v1/users/billy')
        .set('Authorization', authHeader)
        .send(data)

      assert.equal(resp.status, 404)
      assert.notEqual(resp.body.errors, undefined)
    })

    it('user with snowflakeId', async () => {
      let data = {
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        snowflakeId: '1275927545074800728'
      }

      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data,
        connectionKey
      })
      let authHeader = await getAuthHeader(res.newId)

      let resp = await request(app)
        .put('/api/v1/users/1275927545074800728')
        .set('Authorization', authHeader)
        .send(data)

      expect(resp.status).to.equal(200)
      expect(resp.body.id).to.equal(res.id)
    })

    it('fails put when loading errors occur', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      res.toJSON = function() {
        return this
      }

      sandbox
        .stub(User, 'find')
        .onCall(0)
        .yields(null, [res])
        .onCall(1)
        .yields({ error: true }, null)

      let resp = await request(app)
        .put(`/api/v1/users/${res.id}`)
        .set('Authorization', authHeader)
        .send(res)

      assert.equal(resp.status, 500)
      assert(resp.body.errors)
    })

    it('updates on put', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      res.firstName = 'Tester'

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .put(`/api/v1/users/${res.id}`)
        .set('Authorization', authHeader)
        .send(res)

      assert.equal(resp.status, 200)
      assert.equal(resp.body.firstName, 'Tester')
    })

    it('fails put when saving errors occur', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let originalAct = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'users' && pattern.cmd === 'save') {
          return Promise.reject(new Error('error from stub'))
        }
        return originalAct(pattern)
      })

      await request(app)
        .put(`/api/v1/users/${res.id}`)
        .set('Authorization', authHeader)
        .send(res)
        .expect(500)
    })

    it('skips updating read only fields', async () => {
      const admin = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'tAdmin', email: 'admin@domain.org', role: 'admin' },
        connectionKey
      })
      let user = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'TestUser', email: 'user@domain.org', role: 'user' },
        connectionKey
      })

      const originalId = user.id.toString()
      user.id = validObjectId
      user.ssoId = 'DO NOT SAVE ME'

      let authHeader = await getAuthHeader(admin.id)

      let { body } = await request(app)
        .put(`/api/v1/users/${originalId}`)
        .set('Authorization', authHeader)
        .send(user)
        .expect(200)

      expect(body).to.have.property('ssoId').that.is.null
      expect(body.id).to.be.equal(originalId)
    })
  })

  describe('/api/v1/users#post', () => {
    it('updates on post', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'admin',
          uid: 'admin'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .post('/api/v1/users')
        .set('Authorization', authHeader)
        .send({
          username: 'Test1',
          email: 'test1@domain.org',
          role: 'user',
          uid: 'user'
        })
        .expect(201)

      assert.equal(resp.body.username, 'Test1')
    })

    it('only saves valid properties', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'admin',
          uid: 'admin'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let postResp = await request(app)
        .post('/api/v1/users')
        .set('Authorization', authHeader)
        .send({
          username: 'Test1',
          email: 'test1@domain.org',
          role: 'user',
          nonexistantproperty: 'Utah',
          uid: 'user'
        })
        .expect(201)

      let getResp = await request(app)
        .get(`/api/v1/users/${postResp.body.id}`)
        .set('Authorization', authHeader)
        .expect(200)

      expect(getResp.body).to.not.have.property('nonexistantproperty')
    })

    it('only saves user allowed properties', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'admin' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      const sentObject = {
        updatedAt: '2013-01-07T22:01:23.000Z',
        createdAt: '2012-01-07T22:04:56.000Z',
        name: 'The full name',
        firstName: 'Firster',
        lastName: 'Laster',
        username: 'TWIiii',
        email: 'test@kuali.com',
        role: 'admin',
        password: 'password1',
        uid: '354e533',
        ssoId: 'whatwhat',
        scopesCm: 'some stuff',
        nonexistantproperty: 'Utah',
        schoolId: 'theschoolid'
      }

      let postResp = await request(app)
        .post('/api/v1/users')
        .set('Authorization', authHeader)
        .send(sentObject)
        .expect(201)

      let getResp = await request(app)
        .get(`/api/v1/users/${postResp.body.id}`)
        .set('Authorization', authHeader)
        .expect(200)

      expect(getResp.body).to.have
        .property('updatedAt')
        .that.is.not.equal(sentObject.updatedAt)
      expect(getResp.body).to.have
        .property('createdAt')
        .that.is.not.equal(sentObject.createdAt)
      expect(getResp.body).to.contain.keys(
        pick(sentObject, [
          'name',
          'firstName',
          'lastName',
          'username',
          'scopesCm',
          'schoolId',
          'email'
        ])
      )
      expect(getResp.body).to.not.have.keys([
        'password',
        'uid',
        'nonexistantproperty'
      ])
      expect(getResp.body).to.have.property('ssoId', null)
    })

    it('only allows admins to create new users', async () => {
      let adminUser = await createUser({
        username: 'Admintocreateuser',
        email: 'admin@domain.org',
        role: 'admin'
      })
      let adminHeader = await getAuthHeader(adminUser.id)

      let adminResult = await request(app)
        .post('/api/v1/users')
        .set('Authorization', adminHeader)
        .send({
          updatedAt: '2013-01-07T22:01:23.000Z',
          createdAt: '2012-01-07T22:04:56.000Z',
          name: 'The full name',
          firstName: 'Firster',
          lastName: 'Laster',
          username: 'madebyadmin',
          email: 'madebyadmin@kuali.com',
          role: 'admin',
          password: 'password1',
          scopesCm: 'some stuff',
          nonexistantproperty: 'Utah',
          schoolId: 'theschoolid',
          uid: 'uid1'
        })
        .expect(201)

      let getResp = await request(app)
        .get(`/api/v1/users/${adminResult.body.id}`)
        .set('Authorization', adminHeader)
        .expect(200)

      assert.equal(getResp.body.email, 'madebyadmin@kuali.com')

      let normalUser = await createUser({
        username: 'Normal',
        email: 'normal@domain.org',
        role: 'user',
        uid: 'uid2'
      })
      let normalHeader = await getAuthHeader(normalUser.id)

      let normalResult = await request(app)
        .post('/api/v1/users')
        .set('Authorization', normalHeader)
        .send({
          updatedAt: '2013-01-07T22:01:23.000Z',
          createdAt: '2012-01-07T22:04:56.000Z',
          name: 'The full name',
          firstName: 'Firster',
          lastName: 'Laster',
          username: 'madebynormal',
          email: 'madebynormal@kuali.com',
          role: 'admin',
          password: 'password1',
          scopesCm: 'some stuff',
          nonexistantproperty: 'Utah',
          schoolId: 'theschoolid',
          uid: 'uid3'
        })
        .expect(403)

      await request(app)
        .get(`/api/v1/users/${normalResult.body.id}`)
        .set('Authorization', adminHeader)
        .expect(404)
    })

    it('fails post when saving errors occur', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'admin' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      sandbox.stub(User.prototype, 'save').yields({ error: true }, null)

      let resp = await request(app)
        .post('/api/v1/users')
        .set('Authorization', authHeader)
        .send({ username: 'Test', email: 'test@domain.org', role: 'user' })
        .expect(500)

      expect(resp.body.errors).to.exist
      assert(resp.body.errors)
    })

    it('returns 422 with useful errors', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'admin',
          uid: 'admin'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      await request(app)
        .post('/api/v1/users')
        .set('Authorization', authHeader)
        .send({
          username: 'Test1',
          email: 'testdomain.org',
          role: 'user',
          uid: 'user'
        })
        .expect(422)
    })

    it('plain errors throw 500', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'admin' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let originalAct = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'users' && pattern.cmd === 'save') {
          return Promise.reject(new Error('error from stub'))
        }
        return originalAct(pattern)
      })

      let resp = await request(app)
        .post('/api/v1/users')
        .set('Authorization', authHeader)
        .send({ username: 'Test', email: 'test@domain.org', role: 'user' })
        .expect(500)

      expect(resp.body.errors).to.exist
      assert(resp.body.errors)
    })
  })

  describe('/api/v1/users#get', () => {
    it('returns 404 when user not found', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .get(`/api/v1/users/${validObjectId}`)
        .set('Authorization', authHeader)
        .expect(404)

      assert(resp.body.errors)
    })

    it('returns 404 when invalid user id', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .get(`/api/v1/users/${undefined}`)
        .set('Authorization', authHeader)
        .expect(404)

      assert(resp.body.errors)
    })

    it('fails get when loading errors occur', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      const actAsync = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', pattern => {
        const { role, cmd, id } = pattern
        if (role == 'users' && cmd == 'load' && id == validObjectId) {
          return Promise.reject(new Error('error from stub'))
        }
        return actAsync(pattern)
      })

      await request(app)
        .get(`/api/v1/users/${validObjectId}`)
        .set('Authorization', authHeader)
        .expect(500)
    })

    it('returns requested object with snowflakeId', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'Test',
          email: 'test@domain.org',
          role: 'user',
          snowflakeId: '1275927545074800728'
        },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.newId)

      let resp = await request(app)
        .get('/api/v1/users/1275927545074800728')
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(resp.body.username, 'Test')
    })

    it('returns requested object', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .get(`/api/v1/users/${res.id}`)
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(resp.body.username, 'Test')
    })

    it('doesnt return the passwordDigest', async () => {
      let user = await createUser({
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        password: 'testpass'
      })

      let authHeader = await getAuthHeader(user.id)

      let resp = await request(app)
        .get(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(resp.body.passwordDigest, undefined)
    })
  })

  describe('/api/v1/users#getAll', () => {
    describe('elasticsearch queries', function() {
      this.timeout(5000)

      const testUsers = [
        { username: 'fred', email: 'shmitty@wut.co', role: 'admin' },
        { username: 'Bubba', email: 'bubba@kuali.co', role: 'user' },
        { username: 'Herbert', email: 'herb@kuali.co', role: 'user' },
        { username: 'Trixie', email: 't@kuali.co', role: 'user' },
        { username: 'MYRMAL', email: 'Sk8rGirl@kuali.co', role: 'user' },
        { username: 'Lucy', email: 'lol@wut.co', role: 'admin' }
      ]

      async function prep() {
        const _users = await Promise.all(testUsers.map(createUser))
        _users.map(u => {
          u.id = u.id.toString()
          delete u.passwordDigest
        })
        const authHeader = await getAuthHeader(_users[0].id)
        await User.reindex()
        await new Promise(resolve => setTimeout(resolve, 300))
        return { _users, authHeader }
      }

      let app // eslint-disable-line no-shadow
      before(async () => {
        app = express()
        app.use(logging({ test: 'users-api-v1' }))
        app.use(responseLocals)
        app.use(institutionLoader)
        app.use((req, res, next) => {
          req.institution.features.useElasticsearch = true
          next()
        })
        app.use(usersApp)

        await seneca.actAsync({
          role: 'institutions',
          cmd: 'load',
          data: { subdomain: 'kuali', name: 'Kuali' },
          connectionKey
        })
      })
      beforeEach(() => User.remove({}))
      after(() => User.remove({}))

      it('full text search', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?q=trixie')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 1)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Trixie' }))

        const resp2 = await request(app)
          .get('/api/v1/users?q=RMAL')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 1)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'MYRMAL' }))

        const resp3 = await request(app)
          .get('/api/v1/users?q=y&sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 3)
        assert.deepEqual(resp3.body[0], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp3.body[1], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp3.body[2], find(_users, { username: 'fred' }))

        const resp4 = await request(app)
          .get('/api/v1/users?q=kuali.co&sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp4.body.length, 4)
        assert.deepEqual(resp4.body[0], find(_users, { username: 'Bubba' }))
        assert.deepEqual(resp4.body[1], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp4.body[2], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp4.body[3], find(_users, { username: 'Trixie' }))
      })

      it('sorting', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 6)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Bubba' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp1.body[2], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp1.body[3], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp1.body[4], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp1.body[5], find(_users, { username: 'fred' }))

        const resp2 = await request(app)
          .get('/api/v1/users?sort=-username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 6)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'fred' }))
        assert.deepEqual(resp2.body[1], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp2.body[2], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp2.body[3], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp2.body[4], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp2.body[5], find(_users, { username: 'Bubba' }))

        const resp3 = await request(app)
          .get('/api/v1/users?sort=role,-email')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        assert.deepEqual(resp3.body[0], find(_users, { username: 'fred' }))
        assert.deepEqual(resp3.body[1], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp3.body[2], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp3.body[3], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp3.body[4], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp3.body[5], find(_users, { username: 'Bubba' }))
      })

      it('field limiting', async () => {
        const { authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?fields=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 6)
        each(resp1.body, user => {
          each(user, (val, key) => {
            assert.equal(key, 'username')
          })
        })

        const resp2 = await request(app)
          .get('/api/v1/users?fields=username,email,role,id')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 6)
        each(resp2.body, user => {
          each(user, (val, key) => {
            assert(includes(['username', 'email', 'role', 'id'], key))
          })
        })

        const resp3 = await request(app)
          .get('/api/v1/users?fields=username,passwordDigest')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        each(resp3.body, user => {
          each(user, (val, key) => {
            assert.equal(key, 'username')
          })
        })
      })

      it('field limiting for displayName', async () => {
        const validNames = map(testUsers, 'username')
        const { authHeader } = await prep()
        const resp = await request(app)
          .get('/api/v1/users?fields=displayName')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp.body.length, 6)
        each(resp.body, user => {
          each(user, (val, key) => {
            assert.equal(key, 'displayName')
            assert(includes(validNames, val))
          })
        })
      })

      it('attribute search', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=username&role=admin')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 2)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'fred' }))

        const resp2 = await request(app)
          .get('/api/v1/users?role=user&username=Trixie')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 1)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'Trixie' }))

        const resp3 = await request(app)
          .get('/api/v1/users?role=admin&username=Trixie')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 0)

        const resp4 = await request(app)
          .get('/api/v1/users?username=Trixie&locale=en-us')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp4.body.length, 1)
        assert.deepEqual(resp4.body[0], find(_users, { username: 'Trixie' }))
      })

      it('limit, skip, count', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=username&limit=2')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 2)
        assert.equal(resp1.headers['item-count'], 6)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Bubba' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'Herbert' }))

        const resp2 = await request(app)
          .get('/api/v1/users?sort=username&limit=2&skip=3')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 2)
        assert.equal(resp2.headers['item-count'], 6)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp2.body[1], find(_users, { username: 'Trixie' }))

        const resp3 = await request(app)
          .get('/api/v1/users?limit=bubba&skip=foo')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        assert.equal(resp3.headers['item-count'], 6)
      })

      it('complex search', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=-username&limit=2&role=user')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 2)
        assert.equal(resp1.headers['item-count'], 4)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'MYRMAL' }))

        const resp2 = await request(app)
          .get('/api/v1/users?q=kuali.co&fields=username&skip=2&sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 2)
        assert.deepEqual(resp2.body[0], { username: 'MYRMAL' })
        assert.deepEqual(resp2.body[1], { username: 'Trixie' })

        const resp3 = await request(app)
          .get(
            '/api/v1/users'
            + '?groupId=null'
            + '&createdAt=gte(0)'
            + '&fields=username,email&sort='
          )
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        resp3.body.forEach(user => {
          assert.equal(user.phone, null)
          assert.equal(Object.keys(user).length, 2)
          assert(Object.keys(user).includes('username'))
          assert(Object.keys(user).includes('email'))
        })
      })

      it('resyncs data', async () => {
        const { authHeader } = await prep()
        const resp1 = await request(app)
          .post('/api/v1/users/search/sync')
          .set('Authorization', authHeader)
          .expect(200)
        assert.deepEqual(Object.keys(resp1.body), ['dateStarted'])
        const dateStarted = resp1.body.dateStarted

        const resp2 = await request(app)
          .post('/api/v1/users/search/sync')
          .set('Authorization', authHeader)
          .expect(200)
        assert.deepEqual(resp2.body, {
          dateStarted
        })
      })
    })

    describe('advanced queries', () => {
      const testUsers = [
        { username: 'fred', email: 'shmitty@wut.co', role: 'admin' },
        { username: 'Bubba', email: 'bubba@kuali.co', role: 'user' },
        { username: 'Herbert', email: 'herb@kuali.co', role: 'user' },
        { username: 'Trixie', email: 't@kuali.co', role: 'user' },
        { username: 'MYRMAL', email: 'Sk8rGirl@kuali.co', role: 'user' },
        { username: 'Lucy', email: 'lol@wut.co', role: 'admin' }
      ]

      async function prep() {
        const _users = await Promise.all(testUsers.map(createUser))
        _users.map(u => {
          u.id = u.id.toString()
          delete u.passwordDigest
        })
        const authHeader = await getAuthHeader(_users[0].id)
        return { _users, authHeader }
      }

      it('full text search', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?q=trixie')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 1)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Trixie' }))

        const resp2 = await request(app)
          .get('/api/v1/users?q=RMAL')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 1)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'MYRMAL' }))

        const resp3 = await request(app)
          .get('/api/v1/users?q=y&sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 3)
        assert.deepEqual(resp3.body[0], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp3.body[1], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp3.body[2], find(_users, { username: 'fred' }))

        const resp4 = await request(app)
          .get('/api/v1/users?q=kuali.co&sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp4.body.length, 4)
        assert.deepEqual(resp4.body[0], find(_users, { username: 'Bubba' }))
        assert.deepEqual(resp4.body[1], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp4.body[2], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp4.body[3], find(_users, { username: 'Trixie' }))
      })

      it('sorting', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 6)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Bubba' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp1.body[2], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp1.body[3], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp1.body[4], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp1.body[5], find(_users, { username: 'fred' }))

        const resp2 = await request(app)
          .get('/api/v1/users?sort=-username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 6)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'fred' }))
        assert.deepEqual(resp2.body[1], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp2.body[2], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp2.body[3], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp2.body[4], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp2.body[5], find(_users, { username: 'Bubba' }))

        const resp3 = await request(app)
          .get('/api/v1/users?sort=role,-email')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        assert.deepEqual(resp3.body[0], find(_users, { username: 'fred' }))
        assert.deepEqual(resp3.body[1], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp3.body[2], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp3.body[3], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp3.body[4], find(_users, { username: 'Herbert' }))
        assert.deepEqual(resp3.body[5], find(_users, { username: 'Bubba' }))
      })

      it('field limiting', async () => {
        const { authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?fields=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 6)
        each(resp1.body, user => {
          each(user, (val, key) => {
            assert.equal(key, 'username')
          })
        })

        const resp2 = await request(app)
          .get('/api/v1/users?fields=username,email,role,id')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 6)
        each(resp2.body, user => {
          each(user, (val, key) => {
            assert(includes(['username', 'email', 'role', 'id'], key))
          })
        })

        const resp3 = await request(app)
          .get('/api/v1/users?fields=username,passwordDigest')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        each(resp3.body, user => {
          each(user, (val, key) => {
            assert.equal(key, 'username')
          })
        })
      })

      it('field limiting for displayName', async () => {
        const validNames = map(testUsers, 'username')
        const { authHeader } = await prep()
        const resp = await request(app)
          .get('/api/v1/users?fields=displayName')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp.body.length, 6)
        each(resp.body, user => {
          each(user, (val, key) => {
            assert.equal(key, 'displayName')
            assert(includes(validNames, val))
          })
        })
      })

      it('attribute search', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=username&role=admin')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 2)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Lucy' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'fred' }))

        const resp2 = await request(app)
          .get('/api/v1/users?role=user&username=Trixie')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 1)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'Trixie' }))

        const resp3 = await request(app)
          .get('/api/v1/users?role=admin&username=Trixie')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 0)

        const resp4 = await request(app)
          .get('/api/v1/users?username=Trixie&locale=en-us')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp4.body.length, 1)
        assert.deepEqual(resp4.body[0], find(_users, { username: 'Trixie' }))
      })

      it('limit, skip, count', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=username&limit=2')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 2)
        assert.equal(resp1.headers['item-count'], 6)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Bubba' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'Herbert' }))

        const resp2 = await request(app)
          .get('/api/v1/users?sort=username&limit=2&skip=3')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 2)
        assert.equal(resp2.headers['item-count'], 6)
        assert.deepEqual(resp2.body[0], find(_users, { username: 'MYRMAL' }))
        assert.deepEqual(resp2.body[1], find(_users, { username: 'Trixie' }))

        const resp3 = await request(app)
          .get('/api/v1/users?limit=bubba&skip=foo')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp3.body.length, 6)
        assert.equal(resp3.headers['item-count'], 6)
      })

      it('complex search', async () => {
        const { _users, authHeader } = await prep()
        const resp1 = await request(app)
          .get('/api/v1/users?sort=-username&limit=2&role=user')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp1.body.length, 2)
        assert.equal(resp1.headers['item-count'], 4)
        assert.deepEqual(resp1.body[0], find(_users, { username: 'Trixie' }))
        assert.deepEqual(resp1.body[1], find(_users, { username: 'MYRMAL' }))

        const resp2 = await request(app)
          .get('/api/v1/users?q=kuali.co&fields=username&skip=2&sort=username')
          .set('Authorization', authHeader)
          .expect(200)
        assert.equal(resp2.body.length, 2)
        assert.deepEqual(resp2.body[0], { username: 'MYRMAL' })
        assert.deepEqual(resp2.body[1], { username: 'Trixie' })
      })
    })

    it('fails get when loading errors occur', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      const act = seneca.act.bind(seneca)
      sandbox.stub(seneca, 'act', (pattern, callback) => {
        if (pattern.role === 'users' && pattern.cmd === 'query') {
          return callback(new Error('stub error'), null)
        }
        return act(pattern, callback)
      })

      await request(app)
        .get('/api/v1/users')
        .set('Authorization', authHeader)
        .expect(500)
    })

    it('returns requested object', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      let resp = await request(app)
        .get('/api/v1/users')
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(resp.body[0].username, 'Test')
    })

    it('returns requested object for service user', async () => {
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      const agent = new ServiceAgent({
        secret: config.serviceSecret,
        expire: 60 // 1 minute
      })
      const token = await agent.generate(null, { user: res })

      let resp = await request(app)
        .get('/api/v1/users')
        .set('Authorization', `Bearer ${token}`)
        .expect(200)

      assert.equal(resp.body[0].username, 'Test')
    })

    it('doesnt return the passwordDigest', async () => {
      let user = await createUser({
        username: 'Test',
        email: 'test@domain.org',
        role: 'user',
        password: 'testpass'
      })

      let authHeader = await getAuthHeader(user.id)

      let resp = await request(app)
        .get('/api/v1/users')
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(resp.body[0].passwordDigest, undefined)
    })
  })

  describe('/api/v1/users#delete', () => {
    let admin, user, authHeader
    beforeEach(async () => {
      admin = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'TestAdmin',
          email: 'admin@domain.org',
          role: 'admin'
        },
        connectionKey
      })
      authHeader = await getAuthHeader(admin.id)
      user = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'TestUser', email: 'user@domain.org', role: 'user' },
        connectionKey
      })
    })

    it('returns 404 when user not found', async () => {
      let resp = await request(app)
        .delete(`/api/v1/users/${validObjectId}`)
        .set('Authorization', authHeader)
        .expect(404)

      assert(resp.body.errors)
    })

    it('returns 404 when invalid user id', async () => {
      let resp = await request(app)
        .delete('/api/v1/users/1234')
        .set('Authorization', authHeader)
        .expect(404)

      assert(resp.body.errors)
    })

    it('removes requested object on snowflakeId', async () => {
      user = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: {
          username: 'TestUser2',
          email: 'user2@domain.org',
          role: 'user',
          snowflakeId: '1275927545074800728'
        },
        connectionKey
      })
      await request(app)
        .delete('/api/v1/users/1275927545074800728')
        .set('Authorization', authHeader)
        .expect(204)
    })

    it('fails delete when errors occur', async () => {
      sandbox.stub(User, 'find').yields({ error: true }, null)

      await request(app)
        .delete('/api/v1/users/567c5be0ce1130c0c78b509f')
        .set('Authorization', authHeader)
        .expect(401)
    })

    it('rejects with 403 is role is "user"', async () => {
      authHeader = await getAuthHeader(user.id)

      await request(app)
        .delete(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .expect(403)
    })

    it('rejects with 403 is role is "service"', async () => {
      const service = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'TestSvc', email: 'svc@domain.org', role: 'service' },
        connectionKey
      })
      authHeader = await getAuthHeader(service.id)

      await request(app)
        .delete(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .expect(403)
    })

    it('removes requested object', async () => {
      await request(app)
        .delete(`/api/v1/users/${user.id}`)
        .set('Authorization', authHeader)
        .expect(204)
    })
  })

  describe('/api/v1/users/:id/tokens', () => {
    let user, auth, secret
    beforeEach(async () => {
      secret = await getSecretFor('kuali')
      user = await createUser({
        username: 'Test',
        email: 'test@domain.org',
        role: 'user'
      })
      auth = await getAuthHeader(user.id)
    })

    describe('#get', () => {
      it('returns 404 when user not found', async () => {
        let resp = await request(app)
          .get(`/api/v1/users/${validObjectId}/tokens`)
          .set('Authorization', auth)
          .expect(404)

        assert(resp.body.errors)
      })

      it('returns 404 when invalid user id', async () => {
        let resp = await request(app)
          .get('/api/v1/users/1234/tokens')
          .set('Authorization', auth)
          .expect(404)

        assert(resp.body.errors)
      })

      it('fails get when loading errors occur', async () => {
        const actAsync = seneca.actAsync.bind(seneca)
        sandbox.stub(seneca, 'actAsync', pattern => {
          const { role, cmd, id } = pattern
          if (role == 'users' && cmd == 'load' && id == validObjectId) {
            return Promise.reject(new Error('error from stub'))
          }
          return actAsync(pattern)
        })

        let resp = await request(app)
          .get(`/api/v1/users/${validObjectId}/tokens`)
          .set('Authorization', auth)
          .expect(500)

        assert(resp.body.errors)
      })

      it('fails more differenter', async () => {
        sandbox.stub(tokenService, 'fetch').throws()

        let resp = await request(app)
          .get(`/api/v1/users/${user.id}/tokens`)
          .set('Authorization', auth)
          .expect(500)

        assert(resp.body.errors)
      })

      it('returns all tokens', async () => {
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          id: user.id,
          secret,
          options: {
            type: 'apiKey',
            name: 'test key'
          },
          connectionKey
        })

        let resp = await request(app)
          .get(`/api/v1/users/${user.id}/tokens`)
          .set('Authorization', auth)
          .expect(200)

        assert.ok(resp.body.length >= 2, 'should be at least 2 tokens')
      })

      it('returns only tokens with requested type', async () => {
        const { token } = await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          id: user.id,
          secret,
          options: {
            type: 'apiKey',
            name: 'test key'
          },
          connectionKey
        })
        const decoded = jwt.decode(token)

        let resp = await request(app)
          .get(`/api/v1/users/${user.id}/tokens?type=apiKey`)
          .set('Authorization', auth)
          .expect(200)

        const returnedToken = resp.body[0]
        assert.equal(returnedToken.userId, user.id)
        assert.equal(returnedToken.type, 'apiKey')
        const lowerBound = moment(returnedToken.expiresAt).subtract(1, 'minute')
        const upperBound = moment(returnedToken.expiresAt).add(1, 'minute')
        assert.ok(moment.unix(decoded.exp).isBetween(lowerBound, upperBound))
      })

      it('returns empty array if no tokens are found', async () => {
        await request(app)
          .get(`/api/v1/users/${user.id}/tokens?type=apiKey`)
          .set('Authorization', auth)
          .expect(200, [])
      })
    })

    describe('#post', () => {
      it('returns 404 when user not found', async () => {
        await request(app)
          .post(`/api/v1/users/${validObjectId}/tokens`)
          .set('Authorization', auth)
          .expect(404, { errors: ['Not Found'] })
      })

      it('returns 404 when invalid user id', async () => {
        let resp = await request(app)
          .post('/api/v1/users/1234/tokens')
          .set('Authorization', auth)
          .expect(404)

        assert(resp.body.errors)
      })

      it('fails when loading errors occur', async () => {
        sandbox.stub(User, 'find').yields({ error: true }, null)

        await request(app)
          .post(`/api/v1/users/${validObjectId}/tokens`)
          .set('Authorization', auth)
          .expect(401)
      })

      it('fails when save error occurs', async () => {
        sandbox.stub(tokenService, 'create').throws()

        let resp = await request(app)
          .post(`/api/v1/users/${user.id}/tokens`)
          .set('Authorization', auth)
          .expect(500)

        assert(resp.body.errors)
      })

      it('creates and returns a token', async () => {
        let resp = await request(app)
          .post(`/api/v1/users/${user.id}/tokens`)
          .set('Authorization', auth)
          .expect(201)

        const token = resp.body.value
        const decoded = jwt.decode(token)
        const tokenUser = await seneca.actAsync({
          role: 'token',
          cmd: 'verify',
          token,
          secret,
          connectionKey
        })

        assert.equal(tokenUser.id, user.id.toString())
        assert.ok(
          moment.unix(decoded.exp).isSame(moment().add(1, 'year'), 'day')
        )
      })

      it('creates and returns a named token', async () => {
        let resp = await request(app)
          .post(`/api/v1/users/${user.id}/tokens`)
          .set('Authorization', auth)
          .send({ name: 'unique-ness' })
          .expect(201)

        const token = resp.body.value
        const decoded = jwt.decode(token)
        const tokenUser = await seneca.actAsync({
          role: 'token',
          cmd: 'verify',
          token,
          secret,
          connectionKey
        })

        assert.equal(tokenUser.id, user.id.toString())
        assert.ok(
          moment.unix(decoded.exp).isSame(moment().add(1, 'year'), 'day')
        )
      })
    })

    describe('#delete', () => {
      it('returns 404 when user not found', async () => {
        let resp = await request(app)
          .delete(`/api/v1/users/${validObjectId}/tokens/${validObjectId}`)
          .set('Authorization', auth)
          .expect(404)

        assert(resp.body.errors)
      })

      it('returns 404 when invalid user id', async () => {
        let resp = await request(app)
          .delete('/api/v1/users/1234/tokens/4321')
          .set('Authorization', auth)
          .expect(404)

        assert(resp.body.errors)
      })

      it('returns 404 when invalid token id', async () => {
        let resp = await request(app)
          .delete(`/api/v1/users/${user.id}/tokens/1234`)
          .set('Authorization', auth)
          .expect(404)

        assert(resp.body.errors)
      })

      it('fails get when loading errors occur', async () => {
        sandbox.stub(User, 'find').yields({ error: true }, null)

        await request(app)
          .delete(`/api/v1/users/${validObjectId}/tokens/${validObjectId}`)
          .set('Authorization', auth)
          .expect(401)
      })

      it('also fails more differenter', async () => {
        sandbox.stub(tokenService, 'revoke').throws()

        let resp = await request(app)
          .delete(`/api/v1/users/${user.id}/tokens/${validObjectId}`)
          .set('Authorization', auth)
          .expect(500)

        assert(resp.body.errors)
      })

      it('revokes specified token', async () => {
        const { token: encoded } = await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          id: user.id,
          secret,
          opts: {
            name: 'test',
            type: 'apiKey'
          },
          connectionKey
        })

        const { id: token } = jwt.decode(encoded)
        await request(app)
          .delete(`/api/v1/users/${user.id}/tokens/${token}`)
          .set('Authorization', auth)
          .expect(204)
      })
    })
  })
})
/*eslint-enable*/
