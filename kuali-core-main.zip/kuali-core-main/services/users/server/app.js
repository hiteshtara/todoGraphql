/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import bodyParser from 'body-parser'
import cookieParser from 'cookie-parser'
import express from 'express'
import { errorHandler } from 'shared/errors'
import responseLocals from 'shared/middleware/response-locals'
import secure from 'shared/secure'
import seneca from 'shared/seneca'

import beforeUserUpdate
  from 'services/users/server/middleware/before-user-update'
import usersPlugin from './resources/users/plugin'
import userRoutes from './resources/users/routes'
import healthRoutes from './resources/health/routes'
import tokenRoutes from './resources/tokens/routes'

seneca.use(usersPlugin)

const app = express()
app.use(secure)
app.use(cookieParser())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(responseLocals)
app.use(beforeUserUpdate)
userRoutes(app)
tokenRoutes(app)
healthRoutes(app)
app.use(errorHandler)

export default app
