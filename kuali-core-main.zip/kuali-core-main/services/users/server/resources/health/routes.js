/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import healthMiddleware from 'shared/health'

import { getUserModel } from '../users/model'

const health = healthMiddleware({
  name: 'users',
  models: [getUserModel],
  getModel: (getModel, req, res) => getModel(res.locals.connection)
})

export default function (app) {
  app.get('/api/v1/users/health', health)
  app.get('/users/health', health)
}
