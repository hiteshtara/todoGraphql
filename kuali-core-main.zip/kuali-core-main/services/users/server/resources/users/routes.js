/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { assign, omit, pick, isEmpty, get } from 'lodash'
import params from 'params'
import policy from 'services/users/server/resources/users/policy'
import seed from 'services/users/server/resources/users/seed'
import { NotFoundError, ForbiddenError } from 'shared/errors'
import authenticate from 'shared/middleware/authenticate'
import seneca from 'shared/seneca'
import wrapAsync from 'shared/wrap-async'

const queryOpts = {
  fields: [
    'username',
    'email',
    'name',
    'firstName',
    'lastName',
    // These last two shouldn't be here, but research needs them for the time
    // being
    'schoolId',
    'groupId'
  ],
  defaultSort: 'displayName' // Only used by elasticsearch
}

const validQueryFields = [
  'q',
  'sort',
  'limit',
  'skip',
  // the following list needs to be kept up to date with the user model
  'createdAt',
  'updatedAt',
  'snowflakeId',
  'name',
  'firstName',
  'lastName',
  'username',
  'lowerUsername',
  'email',
  'role',
  'approved',
  'uid',
  'groupId',
  'schoolId',
  'scopesCm'
]

const readOnlyFields = ['id', 'ssoId', 'uid']

export default function(app) {
  app.post('/api/v1/users/seed', seedUsers)
  app.get('/api/v1/users/current', authenticate(), getCurrentUser)
  app.post(
    '/api/v1/users/search/sync',
    authenticate({ role: 'admin' }),
    syncUsers
  )
  app.get('/api/v1/users/:id', authenticate(), getUser)
  app.get('/api/v1/users', authenticate(), listUsers)
  app.delete('/api/v1/users/:id', authenticate(), wrapAsync(deleteUser))
  app.put('/api/v1/users/:id', authenticate(), wrapAsync(updateUser))
  app.post(
    '/api/v1/users',
    authenticate({ role: 'admin' }),
    wrapAsync(postUser)
  )
}

async function seedUsers(req, res) {
  await seed(res.locals.connection)
  res.sendStatus(200)
}

function getCurrentUser(req, res) {
  res.json(params(req.user).except(['passwordDigest']))
}

async function getUser(req, res, next) {
  let id = req.params.id
  if (!isValidId(id)) {
    return next(new NotFoundError())
  }
  try {
    let result = await seneca.actAsync({
      role: 'users',
      cmd: 'load',
      id,
      connectionKey: res.locals.connectionKey
    })
    return res.json(clean(result))
  } catch (err) {
    if (/id not found/.test(err.message)) {
      return next(new NotFoundError())
    }
    err.errors = []
    return next(err)
  }
}

function syncUsers(req, res, next) {
  const msg = {
    role: 'users',
    cmd: 'resync',
    connectionKey: res.locals.connectionKey
  }
  seneca.act(msg, (err, response) => {
    /* istanbul ignore if */
    if (err) {
      err.errors = []
      return next(err)
    }
    return res.json(response)
  })
}

function listUsers(req, res, next) {
  const msg = {
    role: 'users',
    cmd: 'query',
    query: params(req.query).only(validQueryFields),
    opts: {
      ...queryOpts,
      elasticsearch: get(req, 'institution.features.useElasticsearch', false)
    },
    connectionKey: res.locals.connectionKey
  }
  seneca.act(msg, (err, response) => {
    if (err) {
      err.errors = []
      return next(err)
    }
    let { count, result } = response
    let requestedFields = req.query.fields ? req.query.fields.split(',') : []
    result = result.map(user => clean(user, requestedFields))
    res.set('Item-Count', count)
    return res.json(result)
  })
}

async function updateUser(req, res) {
  let updatedItem = req.body
  let id = req.params.id
  if (!isValidId(id)) {
    throw new NotFoundError()
  }

  // Because req.user.id is an ObjectId from mongo, we can't use !==
  if (req.user.role !== 'admin' && req.user.id != id) {
    throw new ForbiddenError()
  }

  updatedItem = policy(req.user, updatedItem)
  let user
  try {
    user = await seneca.actAsync({
      role: 'users',
      cmd: 'load',
      id,
      connectionKey: res.locals.connectionKey
    })
    let data = assign({}, user, omit(updatedItem, readOnlyFields))
    const result = await seneca.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: req.user,
      data,
      connectionKey: res.locals.connectionKey
    })
    req.log.debug({ updated: result }, 'Updated User')
    return res.json(clean(result))
  } catch (err) {
    let error = err
    if (/id not found/.test(error.message)) {
      throw new NotFoundError()
    }
    req.log.error({ error, user, update: updatedItem }, 'Failed to update user')
    if (error.orig) {
      const { orig } = error
      const { name, fields, errors } = orig
      error = new Error()
      assign(error, { name, errors: [{ name, fields, errors }] })
    }
    if (error.name === 'DuplicateKeyError') {
      error.statusCode = 422
    }
    error.errors = error.errors || []
    throw error
  }
}

export async function postUser(req, res) {
  try {
    const data = Object.assign({ approved: true }, policy(req.user, req.body))
    const result = await seneca.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: req.user,
      data,
      connectionKey: res.locals.connectionKey
    })
    return res.status(201).json(result)
  } catch (err) {
    let error = err
    req.log.error(
      { error, user: req.user, institution: req.institution },
      'Failed to create new user.'
    )
    req.log.debug(`error && error.orig is
      ${JSON.stringify(error && error.orig)}`)
    if (error.orig) {
      const { orig } = error
      const { name, fields, errors } = orig
      error = new Error()
      assign(error, { name, errors: [{ name, fields, errors }] })
    }
    error.errors = error.errors || []
    let status = 500
    if (
      error.name === 'ValidationError' ||
      error.name === 'DuplicateKeyError'
    ) {
      status = 422
    }
    error.status = status
    throw error
  }
}

export async function deleteUser(req, res) {
  let id = req.params.id
  if (!isValidId(id)) {
    throw new NotFoundError()
  }

  if (req.user.role !== 'admin') {
    throw new ForbiddenError()
  }
  let result = await seneca.actAsync({
    role: 'users',
    cmd: 'remove',
    connectionKey: res.locals.connectionKey,
    currentUser: req.user,
    id
  })
  if (result.n < 1) {
    throw new NotFoundError()
  }
  return res.status(204).json(result)
}

function clean(user, requestedFields) {
  let filtered = omit(user, ['passwordDigest'])
  if (isEmpty(requestedFields) === false) {
    return pick(filtered, requestedFields)
  }
  return filtered
}

function isValidId(id) {
  const isObjectId = new RegExp(/^[0-9a-fA-F]{24}$/)
  const isSnowflakeId = new RegExp(/^\d{19}$/)
  return isObjectId.test(id) || isSnowflakeId.test(id)
}
