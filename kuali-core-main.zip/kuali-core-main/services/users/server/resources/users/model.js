/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
/* eslint-disable camelcase */

import { defaultLogger } from 'shared/logging'
import mongoose from 'shared/mongoose'
import audit from 'shared/mongoose/plugins/mongoose-audit'
import elasticsearch from 'shared/mongoose/plugins/elasticsearch'
import { hash, compare, generatePassword } from 'shared/password-utils'

const getSchema = connectionKey => {
  let schema = mongoose.Schema(
    {
      // mysql primary key
      snowflakeId: {
        type: String,
        unique: true,
        sparse: true,
        index: true,
        es_indexed: true,
        es_type: 'keyword'
      },
      name: {
        type: String,
        trim: true,
        es_indexed: true,
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      firstName: {
        type: String,
        trim: true,
        es_indexed: true,
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      lastName: {
        type: String,
        trim: true,
        es_indexed: true,
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      username: {
        type: String,
        trim: true,
        validate: {
          validator: /^[a-zA-Z0-9!#$%&'*+-/=?^_`{|}~@\.]+$/,
          message:
            '{PATH} is not valid - only letters, numbers, hyphens and underscores are allowed' //eslint-disable-line max-len
        },
        es_indexed: true,
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      lowerUsername: {
        type: String,
        lowercase: true,
        sparseUniqueString: true,
        trim: true
      },
      email: {
        type: String,
        lowercase: true,
        sparseUniqueString: true,
        trim: true,
        es_indexed: true,
        es_analyzer: 'whitespace',
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      role: {
        type: String,
        required: true,
        enum: ['user', 'admin', 'service', 'cmadmin', 'external'],
        default: 'user',
        es_indexed: true,
        es_type: 'keyword'
      },
      approved: {
        type: Boolean,
        default: true,
        es_indexed: true
      },
      passwordDigest: {
        type: String,
        required: true
      },
      uid: {
        type: String,
        sparseUniqueString: true,
        es_indexed: true,
        es_type: 'keyword'
      },
      groupId: {
        type: String,
        es_indexed: true,
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      schoolId: {
        type: String,
        es_indexed: true,
        es_type: 'text',
        es_fields: {
          keyword: { type: 'keyword' }
        }
      },
      phone: String,
      scopesCm: String
    },
    {
      schemaName: 'User',
      minimize: false,
      timestamps: true,
      versionKey: false,
      strict: true,
      toJSON: {
        transform: (doc, obj) => {
          delete obj.lowerUsername
          delete obj.passwordDigest
          obj.displayName =
            obj.name ||
            `${obj.firstName || ''} ${obj.lastName || ''}`.trim() ||
            obj.username ||
            obj.email
          obj.createdAt = obj.createdAt && obj.createdAt.getTime()
          obj.updatedAt = obj.updatedAt && obj.updatedAt.getTime()
          obj.ssoId = obj.uid
          delete obj.uid
        }
      }
    }
  )
  /* istanbul ignore else */
  schema.plugin(elasticsearch, {
    index: `${connectionKey}-users`,
    customProperties: {
      displayName: {
        type: 'text',
        fields: {
          keyword: { type: 'keyword' }
        }
      },
      createdAt: {
        type: 'date'
      },
      updatedAt: {
        type: 'date'
      }
    }
  })
  schema.plugin(audit)
  schema.path('email').validate(email => {
    if (!email) {
      return true
    }
    var re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i // eslint-disable-line
    return re.test(email)
  })

  // This virtual attribute allows for a new password to be accessible
  // in the model instance
  schema.virtual('password').set(function(newPassword) {
    this.newPassword = newPassword
  })

  schema.methods.validatePassword = function(inputPassword) {
    return compare(inputPassword, this.passwordDigest)
  }

  schema.pre('validate', async function(next) {
    this.lowerUsername = this.username && this.username.toLowerCase()
    if (!validUsernameEmail(this)) {
      let error = new Error('Must have either username or email')
      error.name = 'ValidationError'
      error.errors = {
        username: {
          path: 'username'
        },
        email: {
          path: 'email'
        }
      }
      return next(error)
    }
    // If there is a new password, hash it
    if (this.newPassword) {
      this.passwordDigest = await hash(this.newPassword)
    }
    // If passwordDigest is still not set, then auto generate it
    if (!this.passwordDigest) {
      this.passwordDigest = await hash(generatePassword())
    }
    return next()
  })

  return schema
}

const modelMap = {}

export function getUserModel(connection) {
  if (modelMap[connection]) {
    return modelMap[connection]
  }
  let schema = getSchema(connection.name)
  let User = connection.model('User', schema)
  /* istanbul ignore else */
  if (User.createMappingAsync) {
    User.createMappingAsync().catch(
      /* istanbul ignore next */ err => {
        defaultLogger.fatal("Couldn't create all ES indexes on User", err)
      }
    )
  }
  User.on('index', err => {
    if (err) {
      defaultLogger.fatal("Couldn't create all indexes on User", err)
    }
  })
  modelMap[connection] = User
  return User
}

function validUsernameEmail(obj) {
  let isValid = !!obj.lowerUsername || !!obj.email
  return isValid
}

export const UserModel = {
  getUserModel
}
