/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import params from 'params'

export default function policy(currentUser, input) {
  if (currentUser.role === 'admin') {
    return params(input).only(adminUserParams)
  }
  return params(input).only(baseUserParams)
}

let baseUserParams =
  [
    'name',
    'firstName',
    'lastName',
    'email',
    'password',
    'schoolId',
    'username',
    'phone'
  ]

let adminUserParams = baseUserParams.concat(['role', 'approved', 'groupId'])
