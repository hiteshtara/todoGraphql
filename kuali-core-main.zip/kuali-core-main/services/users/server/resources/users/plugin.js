/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { get } from 'lodash'
import crud from 'shared/crud'
import { defaultLogger as logger } from 'shared/logging'
import { getConnection } from 'shared/mongoose/pool'

import { getUserModel } from './model'

let role = 'users'

export default function users() {
  this.use(crud, { role, getModel: getUserModel })

  this.add({ role, cmd: 'save' }, async function saveUser(msg, respond) {
    let { data, currentUser } = msg
    if (data.password && data.password.length < 8) {
      return respond(errorCleanup(new ValidationError('password')))
    }
    return this.prior(
      {
        role,
        cmd: 'save',
        data,
        currentUser,
        connectionKey: msg.connectionKey
      },
      (err, result) => {
        logger.debug(`user:save prior err is ${JSON.stringify(err)}`, err)
        respond(errorCleanup(err), result)
      }
    )
  })

  this.add({ role, cmd: 'authenticate' }, async (msg, respond) => {
    let orCondition = [
      { lowerUsername: msg.data.username.toLowerCase().trim() },
      { email: msg.data.username.toLowerCase().trim() }
    ]
    const User = getUserModel(getConnection(msg.connectionKey))
    User.findOne({ $or: orCondition }, async (err, user) => {
      if (err) return respond(err)
      if (!user) {
        logger.debug('Basic Auth Failed', msg.data.username, 'User not found')
        return respond(null, null)
      }

      let valid = await user.validatePassword(msg.data.password)
      if (!valid) {
        logger.debug(
          'Basic Auth Failed',
          msg.data.username,
          'Password did not match'
        )
        return respond(null)
      }

      logger.debug('Basic Auth Succeeded', msg.data.username)
      return respond(null, user.toJSON())
    })
  })

  this.add({ role, cmd: 'resync' }, async (msg, respond) => {
    const User = getUserModel(getConnection(msg.connectionKey))
    /* istanbul ignore if */
    if (!User.synchronizeAsync) return respond(null, {})
    if (!User._isSyncing) {
      User._isSyncing = new Date()
      User.synchronizeAsync()
        .then(() => {
          logger.info(`Done syncing index for ${msg.connectionKey} users`, {
            timeMs: Date.now() - User._isSyncing.getTime()
          })
          User._isSyncing = null
        })
        .catch(
          /* istanbul ignore next */ err => {
            logger.info(`Error syncing index for ${msg.connectionKey} users`, {
              timeMs: Date.now() - User._isSyncing.getTime(),
              err
            })
            User._isSyncing = null
          }
        )
    }
    return respond(null, { dateStarted: User._isSyncing.getTime() })
  })
}

const messages = {
  username:
    'Username is not valid - only letters, numbers, hyphens and underscores are allowed', //eslint-disable-line max-len
  email: 'Email is not a valid email address'
}

function errorCleanup(err) {
  if (!err) return err
  logger.debug(`errorCleanup err.name is ${JSON.stringify(err.name)}`)

  switch (err.name) {
    case 'ValidationError':
      return validationError(err)
    case 'MongoError':
      return mongoError(err)
    default:
      return err
  }
}

function validationError(err) {
  const clean = new Error(err)
  clean.name = 'ValidationError'
  clean.errors = []
  clean.fields = []
  const genericFields = []
  Object.keys(err.errors).map(k => err.errors[k]).forEach(e => {
    if (messages[e.path]) {
      clean.errors.push(messages[e.path])
    } else {
      genericFields.push(e.path)
    }
    clean.fields.push(e.path)
  })
  if (genericFields.length > 0) {
    clean.errors.push(`Unable to validate fields: ${genericFields.join(', ')}`)
  }
  return clean
}

function mongoError(errorIn) {
  logger.debug(`errorIn is ${JSON.stringify(errorIn)}`)
  //the actual exception is nested pretty deep
  let error = get(errorIn, 'orig.orig')
  switch (error && error.code) {
    case 11000:
      return duplicateError(error)

    default:
      return error
  }
}

function duplicateError(error) {
  const clean = new Error(error)
  clean.name = 'DuplicateKeyError'
  clean.fields = []
  const keyRegex = /([a-zA-Z0-9]+?)_\d/g
  let match = keyRegex.exec(error.message)
  while (match) {
    let key = match[1]
    if (key === 'lowerUsername') {
      key = 'username'
    }
    clean.fields.push(key)
    match = keyRegex.exec(error.message)
  }
  return clean
}

class ValidationError extends Error {
  constructor(field) {
    super()
    this.name = 'ValidationError'
    this.errors = { field: { path: field } }
  }
}
