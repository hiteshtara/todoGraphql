/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { assign } from 'lodash'
import moment from 'moment'
import { NotFoundError, InternalServerError } from 'shared/errors'
import authenticate from 'shared/middleware/authenticate'
import seneca from 'shared/seneca'
import wrapAsync from 'shared/wrap-async'

export default function (app) {
  app.get('/api/v1/users/:id/tokens', authenticate(),
    wrapAsync(checkUser), listTokens)
  app.post('/api/v1/users/:id/tokens', authenticate(),
    wrapAsync(checkUser), createToken)
  app.delete('/api/v1/users/:id/tokens/:tokenId', authenticate(),
    wrapAsync(checkUser), deleteToken)
}

async function checkUser(req, res, next) {
  if (isValidId(req.params.id)) {

    try {
      let user = await seneca.actAsync({
        role: 'users',
        cmd: 'load',
        id: req.params.id,
        connectionKey: res.locals.connectionKey
      })

      // I'm not sure this will ever be used, but why load it twice?
      req.tokenOwner = user
      next()
    } catch (e) {
      if (/id not found/.test(e)) {
        throw new NotFoundError()
      } else {
        e.errors = []
        throw new InternalServerError(e)
      }
    }
  } else {
    throw new NotFoundError()
  }
}

async function listTokens(req, res) {
  try {
    const tokens = await seneca.actAsync(assign({
      role: 'token',
      cmd: 'fetch',
      user: req.params.id,
      connectionKey: res.locals.connectionKey
    }, req.query))

    res.json(tokens)
  } catch (err) {
    err.errors = []
    res.status(500).json(err)
  }
}

async function createToken(req, res) {
  try {
    const { secret } = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: req.institution.subdomain },
      connectionKey: res.locals.connectionKey
    })

    const options = { expiresAt: moment().add(1, 'year') }
    options.name = req.body.name || 'None'

    const result = await seneca.actAsync({
      role: 'token',
      cmd: 'sign',
      type: 'apiKey',
      id: req.params.id,
      currentUser: req.user,
      secret,
      options,
      connectionKey: res.locals.connectionKey
    })

    res.status(201).json(result)

  } catch (err) {
    err.errors = []
    res.status(500).json(err)
  }
}

async function deleteToken(req, res) {
  if (!isValidId(req.params.tokenId)) {
    return res.status(404).json({ errors: ['Not found'] })
  }

  try {

    await seneca.actAsync({
      role: 'token',
      cmd: 'revoke',
      currentUser: req.user,
      id: req.params.tokenId,
      connectionKey: res.locals.connectionKey
    })

    return res.status(204).end()

  } catch (err) {
    err.errors = []
    return res.status(500).json(err)
  }
}

function isValidId(id) {
  const isObjectId = new RegExp(/^[0-9a-fA-F]{24}$/)
  const isSnowflakeId = new RegExp(/^\d{19}$/)
  return isObjectId.test(id) || isSnowflakeId.test(id)
}
