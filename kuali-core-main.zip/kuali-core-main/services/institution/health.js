/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import healthMiddleware from 'shared/health'
import { getInstitutionModel } from './model'

const health = healthMiddleware({
  name: 'institution',
  models: [
    getInstitutionModel
  ],
  getModel(getModel, req, res) {
    return getModel(res.locals.connection)
  }
})

export default function (app) {
  app.get('/api/v1/institution/health', health)
  app.get('/institution/health', health)

  app.get('/cor/settings/api/v1/settings/health', health)
  app.get('/cor/settings/health', health)
}
