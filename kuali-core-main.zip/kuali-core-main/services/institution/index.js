/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import bodyParser from 'body-parser'
import cookieParser from 'cookie-parser'
import express from 'express'
import seneca from 'shared/seneca'
import secure from 'shared/secure'
import responseLocalsMW from 'shared/middleware/response-locals'
import plugin from 'services/institution/plugin'
import { errorHandler } from 'shared/errors'
import health from './health'

import apiV1 from './api-v1'

const app = express()
app.use(secure)

seneca.use(plugin)

app.use(cookieParser())
app.use(bodyParser.json())
app.use(responseLocalsMW)

// Deprecated path
app.use('/api/v1/institution', apiV1)
// New path
app.use('/cor/settings/api/v1/settings', apiV1)
health(app)
app.use(errorHandler)

export default app
