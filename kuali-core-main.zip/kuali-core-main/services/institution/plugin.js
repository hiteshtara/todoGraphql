/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import crud from 'shared/crud'
import { defaultLogger as logger } from 'shared/logging'
import { getConnection } from 'shared/mongoose/pool'
import events from 'shared/events'
import seed from 'services/users/server/resources/users/seed'
import seedApp from 'seed/app'
import { getInstitutionModel } from './model'

function getSubdomain(data) {
  let subdomain = 'kuali'
  if (data.subdomain) {
    subdomain = data.subdomain.toLowerCase().trim()
  }
  return subdomain
}

export default function institutions() {
  const role = 'institutions'

  this.use(crud, { role, getModel: getInstitutionModel })

  this.add('role:institutions, cmd:save', function (msg, respond) {
    this.prior(msg, (err, result) => {
      if (result) {
        events.emit('institution:save', result)
      }
      return respond(err, result)
    })
  })

  this.add('role:institutions, cmd:load', (msg, respond) => {
    logger.debug(`enter institutions load msg is ${JSON.stringify(msg)}`)
    if (!msg.connectionKey) {
      throw Error('msg does not contain connectionKey')
    }

    const autoCreate = msg.autoCreate === undefined ? true : msg.autoCreate
    logger.debug(`institutions load autoCreate is
      ${JSON.stringify(autoCreate)}`)

    let data = msg.data || {}
    let subdomain = getSubdomain(data)
    logger.debug(`institutions load subdomain is ${JSON.stringify(subdomain)}`)

    let conn = getConnection(msg.connectionKey)
    const Institution = getInstitutionModel(conn)
    Institution.findOne({ subdomain })
      .then(existingInstitution => {
        logger.debug(`institution found: existingInstitution is
          ${JSON.stringify(existingInstitution)}`)
        if (existingInstitution) {
          return existingInstitution.toJSON()
        }

        if (autoCreate) {
          logger.debug('autoCreating institution')
          return new Institution({
            subdomain,
            name: data.name || 'Kuali',
            updatedBy: { id: 'kuali-system' },
            features: {
              apps: {
                users: true,
                cm: true,
                workflow: true,
                groups: true
              }
            }
          }).save().then(result => {
            setImmediate(() => seed(conn))
            setImmediate(() => {
              seedApp(conn, { institution: result.toJSON() })
            })
            events.emit('institution:save', result.toJSON())
            return result.toJSON()
          })
        }
        logger.error(`Institution not found: subdomain is
          ${JSON.stringify(subdomain)}`)
        throw new Error('id not found')
      })
      .then(institution => {
        return respond(null, institution)
      })
      .catch(exception => {
        logger.error(`Institution.findOne exception is
          ${JSON.stringify(exception)}`)
        respond(exception)
      })
  })

  this.add('role:institutions, cmd:getSecret', (msg, respond) => {
    let data = msg.data || {}
    let subdomain = getSubdomain(data)

    let conn = getConnection(msg.connectionKey)
    const Institution = getInstitutionModel(conn)

    Institution.findOne({ subdomain })
      .then(institution => {
        if (institution) {
          return respond(null, {
            secret: institution.secret,
            id: institution.id
          })
        }

        return respond(new Error('No institution found'))
      })
  })
}
