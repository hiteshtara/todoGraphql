/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import mongoose from 'shared/mongoose'
import { defaultLogger as logger } from 'shared/logging'
import crypto from 'crypto'
import audit from 'shared/mongoose/plugins/mongoose-audit'
import moment from 'moment-timezone'

const institutionSchemaDef = {
  // mysql primary key
  snowflakeId: {
    type: String,
    unique: true,
    sparse: true,
    index: true
  },
  subdomain: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    maxlength: 60,
    minlength: 2,
    validate: {
      validator(v) {
        return /^\w[\w.-]+\w?$/.test(v)
      }
    }
  },
  name: {
    type: String,
    required: true
  },
  secret: {
    type: String,
    required: true
  },
  provider: {
    type: String,
    required: true,
    enum: ['kuali', 'saml', 'cas', 'ldap'],
    default: 'kuali'
  },
  validRedirectHosts: {
    type: Array,
    default: []
  },
  ldapConfig: {
    url: String,
    bindDn: String,
    bindCredentials: String,
    searchBase: String,
    searchFilter: String,
    searchAttributes: Array,
    tlsOptions: {
      rejectUnauthorized: Boolean
    }
  },
  featureFlagsCm: {
    type: String
  },
  idp: {
    type: String
  },
  eppn: {
    type: String
  },
  ldapUserIdentifier: {
    type: String
  },
  idps: [
    {
      name: String,
      eppn: String,
      idp: String,
      schoolIdAttr: String
    }
  ],
  casVersion: {
    type: String,
    enum: ['CAS1.0', 'CAS2.0', 'CAS3.0'],
    default: 'CAS1.0'
  },
  signInExpiresIn: {
    type: Number,
    default: 1209600000 // two weeks
  },
  signInExpiresWithSession: {
    type: Boolean,
    required: true,
    default: true
  },
  forceAuthn: {
    type: Boolean,
    required: true,
    default: false
  },
  casServiceUrl: {
    type: String
  },
  casForceLogout: {
    type: Boolean,
    required: true,
    default: false
  },
  timezone: {
    type: String,
    default: 'America/Denver',
    validate: [
      {
        validator: value => {
          if (value == null) return true
          return Boolean(moment.tz.zone(value))
        },
        message:
        '"{VALUE}" is not a supported time zone. ' +
        'See IANA Time Zone Database'
      }
    ]
  },
  features: {
    impersonation: {
      type: Boolean,
      default: false
    },
    ssoDisableStripDomain: {
      type: Boolean,
      default: false
    },
    formsUsesPermissions: {
      type: Boolean,
      default: false
    },
    disableNotifications: {
      type: Boolean,
      default: false
    },
    apps: {
      users: Boolean,
      cm: Boolean,
      workflow: Boolean,
      groups: Boolean,
      appBuilder: Boolean
    },
    useElasticsearch: {
      type: Boolean,
      default: false
    }
  },
  approval: {
    type: String,
    enum: ['auto', 'scopedAuto', 'manual'],
    default: 'auto'
  },
  approvalScope: {
    type: Object,
    default: {}
  }
}

const institutionSchemaAttrs = {
  schemaName: 'Institution',
  timestamps: true,
  versionKey: false,
  toJSON: {
    transform(doc, ret) {
      delete ret.secret

      ret.createdAt = doc.createdAt && doc.createdAt.getTime()
      ret.updatedAt = doc.updatedAt && doc.updatedAt.getTime()

      ret.featureFlagsCm = doc.featureFlagsCm || null
      ret.idp = doc.idp || null
      ret.eppn = doc.eppn || null
    }
  }
}

function getSchema() {
  let schema = mongoose.Schema(institutionSchemaDef, institutionSchemaAttrs)

  schema.plugin(audit)
  schema.pre('validate', function(next) {
    if (!this.isNew) return next()
    this.secret = crypto.randomBytes(128).toString('base64')
    return next()
  })

  return schema
}

let schema = getSchema()
const modelMap = {}

export function getInstitutionModel(conn) {
  if (!conn) {
    throw Error('Cannot get Institution Model without a connection')
  }

  if (modelMap[conn]) {
    return modelMap[conn]
  }
  let Institution = conn.model('Institution', schema)
  Institution.on('index', err => {
    /* istanbul ignore else */
    if (err) {
      logger.fatal("Couldn't create all indexes on Institution", err)
    }
  })

  modelMap[conn] = Institution
  return Institution
}
