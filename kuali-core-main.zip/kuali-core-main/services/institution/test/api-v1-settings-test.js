/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

// Tests for change from institution to settings name
// Until we separate into standalone service,
// we're just making top-level changes

import assert from 'assert'
import { expect } from 'chai'
import seneca from 'shared/seneca'
import express from 'express'
import mongoose from 'shared/mongoose'
import responseLocalsMW from 'shared/middleware/response-locals'
import institutionLoader from 'shared/institution-loader'
import sinon from 'sinon'
import request from 'supertest-as-promised'
import institution from 'services/institution'
import usersPlugin from 'services/users/server/resources/users/plugin'
import { getUserModel } from 'services/users/server/resources/users/model'
import { getTestConnectionInfo } from 'shared/test-helpers'

let app = express()
app.use(responseLocalsMW)
app.use(institutionLoader)
app.use(institution)

let sandbox

const { connection, connectionKey } = getTestConnectionInfo()
const User = getUserModel(connection)

async function getSecretFor(subdomain) {
  let value = await seneca.actAsync({
    role: 'institutions',
    cmd: 'getSecret',
    data: { subdomain },
    connectionKey
  })

  return value.secret
}

async function getAuthHeader(userId) {
  let secret = await getSecretFor('kuali')

  let token = await seneca.actAsync({
    role: 'token',
    cmd: 'sign',
    id: userId,
    secret,
    connectionKey
  })

  return `Bearer ${token.token}`
}

async function createUser(data) {
  return await seneca.actAsync({
    role: 'users',
    cmd: 'save',
    currentUser: { id: 'test' },
    data,
    connectionKey
  })
}

describe('Settings API V1', () => {

  before( async () => {
    seneca.use(usersPlugin)

    await seneca.actAsync({
      role: 'institutions',
      cmd: 'load',
      data: { subdomain: 'kuali', name: 'Kuali' },
      connectionKey
    })
  })

  beforeEach( done => {
    sandbox = sinon.sandbox.create()
    User.collection.remove({}, done)
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('settings health route', () => {
    it('returns a health status code', async () => {
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'user'
      })
      let { text } =
        await request(app).get('/cor/settings/api/v1/settings/health')
        .set('Authorization', await getAuthHeader(user.id))
        .expect(204)
      assert.equal(text, '')
    })

    it('returns health status detail', async () => {
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'user'
      })
      let { text } = await request(app)
        .get('/cor/settings/api/v1/settings/health?detail=true')
        .set('Authorization', await getAuthHeader(user.id))
        .expect(200)
      assert.notEqual(text, '')
    })
  })

  describe('/cor/settings/api/v1/settings#get', async () => {
    it('returns settings', async () => {
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'user'
      })
      const authHeader = await getAuthHeader(user.id)
      const res = await request(app)
        .get('/cor/settings/api/v1/settings')
        .set('Authorization', authHeader)
        .expect('Content-Type', /json/)
        .expect(200)
      assert.equal(res.body.subdomain, 'kuali')
    })

    it('returns just name and id without authToken', async () => {
      const result = await request(app)
        .get('/cor/settings/api/v1/settings')
        .expect(200)
      expect(result.body).to.have.property('name')
      expect(result.body).to.have.property('id')
      expect(result.body).to.not.have.property('provider')
      expect(result.body).to.not.have.property('subdomain')
    })

    it('returns error correctly', async () => {
      sandbox.stub(mongoose.Model, 'findOne').throws('error')

      let res = await request(app).get('/cor/settings/api/v1/settings')
      assert.equal(res.status, 500)
    })
  })

  describe('/cor/settings/api/v1/settings#put', async () => {
    it('updates settings', async () => {
      let newName = 'New Name'
      let data = { name: newName }
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'admin'
      })
      const authHeader = await getAuthHeader(user.id)

      let res = await request(app)
        .put('/cor/settings/api/v1/settings')
        .set('Authorization', authHeader)
        .send(data)
        .expect('Content-Type', /json/)
        .expect(200)

      assert.equal(res.body.name, newName)

      let updatedInstitution = await request(app)
        .get('/cor/settings/api/v1/settings')
        .set('Authorization', authHeader)
        .expect(200)

      assert.equal(updatedInstitution.body.name, newName)
    })

    it('fails to update without admin', async () => {
      let newName = 'New Name'
      let data = { name: newName }
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'user'
      })
      const authHeader = await getAuthHeader(user.id)

      await request(app)
        .put('/cor/settings/api/v1/settings')
        .set('Authorization', authHeader)
        .send(data)
        .expect(403)
    })

    it('throw error on findOne', async () => {
      let newName = 'New Name'
      let data = { name: newName }
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'admin'
      })
      const authHeader = await getAuthHeader(user.id)

      sandbox.stub(
        mongoose.Model,
        'findOne',
        (criteria, update, options, callback) => {
          callback(new Error('stubbed'))
        }
      )

      await request(app)
        .put('/cor/settings/api/v1/settings')
        .set('Authorization', authHeader)
        .send(data)
        .expect(500)
    })

    it('only allows updating certain fields', async () => {
      let updated = {
        name: 'name2',
        provider: 'saml',
        idp: 'idp2',
        eppn: 'eppn2',
        featureFlagsCm: 'flags2',
        casServiceUrl: 'url2',
        signInExpiresIn: 999,
        signInExpiresWithSession: false,
        forceAuthn: true,
        secret: 'secret2',
        subdomain: 'subdomaintwo',
        nonExistantField: 'shouldntsave'
      }
      const user = await createUser({
        username: 'test',
        email: 'test@domain.org',
        role: 'admin'
      })
      const authHeader = await getAuthHeader(user.id)

      let res = await request(app)
        .put('/cor/settings/api/v1/settings')
        .set('Authorization', authHeader)
        .send(updated)
        .expect('Content-Type', /json/)
        .expect(200)

      assert.equal(res.body.name, updated.name)
      assert.equal(res.body.provider, updated.provider)
      assert.equal(res.body.idp, updated.idp)
      assert.equal(res.body.eppn, updated.eppn)
      assert.equal(res.body.featureFlagsCm, updated.featureFlagsCm)
      assert.equal(res.body.casServiceUrl, updated.casServiceUrl)
      assert.equal(res.body.signInExpiresIn, updated.signInExpiresIn)
      assert.equal(
        res.body.signInExpiresWithSession,
        updated.signInExpiresWithSession
      )
      assert.equal(res.body.forceAuthn, updated.forceAuthn)
      assert.notEqual(res.body.secret, updated.secret)
      assert.notEqual(res.body.subdomain, updated.subdomain)
      assert.notEqual(res.body.nonExistantField, updated.subdomain)
    })
  })
})
