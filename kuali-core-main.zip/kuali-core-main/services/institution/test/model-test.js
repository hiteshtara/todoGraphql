/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect, assert } from 'chai'
import crypto from 'crypto'
import sinon from 'sinon'
import { defaultLogger } from 'shared/logging'
import { getTestConnectionInfo } from 'shared/test-helpers'

import db from './db'
import { getInstitutionModel } from '../model'

const { connection } = getTestConnectionInfo()
const Institution = getInstitutionModel(connection)

const validInstitution = {
  subdomain: 'acme',
  name: 'Acme University',
  updatedBy: { id: 'test' }
}

let lastInstitution

describe('Institution Model', () => {
  db()
  let sandbox

  beforeEach(async () => {
    let institution = new Institution(validInstitution)
    let result = await institution.save()
    lastInstitution = result
    sandbox = sinon.sandbox.create()
  })

  afterEach( () => {
    sandbox.restore()
  })

  it('fails to get model if connection is not passed', () => {
    expect(() => getInstitutionModel())
      .to.throw('Cannot get Institution Model without a connection')
  })

  describe('Defaults', () => {
    it('sets id', () => {
      assert.notEqual(lastInstitution.id, null)
    })

    it('sets secret', () => {
      assert.notEqual(lastInstitution.secret, null)
    })

    it('provider is kuali', () => {
      assert.equal(lastInstitution.provider, 'kuali')
    })

    it('signInExpiresIn is 1209600000', () => {
      assert.equal(lastInstitution.signInExpiresIn, 1209600000)
    })

    it('signInExpiresWithSession is true', () => {
      assert.equal(lastInstitution.signInExpiresWithSession, true)
    })

    it('forceAuthn is false', () => {
      assert.equal(lastInstitution.forceAuthn, false)
    })

    it('timezone defaults to Mountain Time', () => {
      assert.equal(lastInstitution.timezone, 'America/Denver')
    })
  })

  it('logs a fatal error on index error', done => {
    const spy = sandbox.spy(defaultLogger, 'fatal')
    Institution.emit('index', new Error('test'))
    sinon.assert.calledOnce(spy)
    done()
  })

  describe('Validations', () => {
    describe('name', () => {
      it('is required', async () => {
        let institution = new Institution()
        try {
          await institution.validate()
        } catch (e) {
          assert.notEqual(e.errors.name, undefined)
        }
      })
    })

    describe('subdomain', () => {
      it('is required', async () => {
        let institution = new Institution()
        try {
          await institution.validate()
        } catch (e) {
          assert.notEqual(e.errors.subdomain, undefined)
        }
      })

      it('is less than 60 characters long', async () => {
        let institution = new Institution()
        institution.subdomain = crypto.randomBytes(96).toString('hex')
        try {
          await institution.validate()
        } catch (e) {
          assert.notEqual(e.errors.subdomain, undefined)
        }
      })

      it('does not start with hypen', async () => {
        let institution = new Institution()
        institution.subdomain = '-subdomain'
        try {
          await institution.validate()
        } catch (e) {
          assert.notEqual(e.errors.subdomain, undefined)
        }
      })

      it('allows for hyphen', async () => {
        let institution = new Institution()
        institution.subdomain = 'subdomain-tst'
        try {
          await institution.validate()
        } catch (e) {
          assert.equal(e.errors.subdomain, undefined)
        }
      })

      it('lowercases subdomain', async () => {
        let data = (JSON.parse(JSON.stringify(validInstitution)))
        data.subdomain = 'UPPERCASE'
        let institution = new Institution(data)
        let result = await institution.save()
        assert.equal(result.subdomain, 'uppercase')
      })

      it('runs validations on update', async () => {
        lastInstitution.name = ''
        try {
          await lastInstitution.save()
        } catch (e) {
          assert.notEqual(e.errors.name, undefined)
        }
      })
    })
  })

  describe('toJSON', () => {
    let json

    beforeEach( () => {
      json = lastInstitution.toJSON()
    })

    it('includes correct attributes', () => {
      let attributes = [
        'id',
        'subdomain',
        'name',
        'provider',
        'featureFlagsCm',
        'idp',
        'eppn',
        'signInExpiresIn',
        'signInExpiresWithSession',
        'forceAuthn',
        'timezone'
      ]
      attributes.forEach(a => expect(json).to.have.ownProperty(a))
    })

    it('excludes correct attributes', () => {
      let attributes = [
        '_id',
        'secret'
      ]
      attributes.forEach(a => expect(json).to.not.have.ownProperty(a))
    })

    it('returns _id as id when snowflakeId is not present', async () => {
      expect(json).to.have.property('id').that.deep.equals(lastInstitution._id)
    })

    it('returns snowflakeId as id and _id as newId correctly', async () => {
      let snowflakeId = '1346972247374804096'
      validInstitution.snowflakeId = snowflakeId
      validInstitution.subdomain = 'whatwhat'

      let institution = new Institution(validInstitution)
      let newInstitution = await institution.save()
      json = newInstitution.toJSON()
      assert.equal(json.id, validInstitution.snowflakeId)
      assert.equal(json.newId, newInstitution.id)
      expect(json).to.not.have.ownProperty('snowflakeId')
    })
  })

  describe('timezone', () => {
    it('is not required', async () => {
      let institution = new Institution()
      try {
        await institution.validate()
      } catch (e) {
        assert.equal(e.errors.timezone, undefined)
      }
    })

    it('rejects invalid timezones', async () => {
      let institution = new Institution()
      institution.timezone = 'Not A Real TimeZone'
      try {
        await institution.validate()
      } catch (e) {
        assert.notEqual(e.errors.timezone, undefined)
      }
    })

    it('accepts a valid timezone', async () => {
      let institution = new Institution()
      institution.timezone = 'America/Denver'
      try {
        await institution.validate()
      } catch (e) {
        assert.equal(e.errors.timezone, undefined)
      }
    })

    it('accepts null', async () => {
      let institution = new Institution()
      institution.timezone = null
      try {
        await institution.validate()
      } catch (e) {
        assert.equal(e.errors.timezone, undefined)
      }
    })

    it('runs validations on update', async () => {
      lastInstitution.timezone = 'America/Lehi'
      try {
        await lastInstitution.save()
      } catch (e) {
        assert.notEqual(e.errors.timezone, undefined)
      }
    })
  })
})
