/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import express from 'express'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import { assert, expect } from 'chai'
import mongoose from 'shared/mongoose'
import InstitutionApp from 'services/institution'
import { defaultLogger } from 'shared/logging'
import { getTestConnectionInfo } from 'shared/test-helpers'

import db from './db'
import { getInstitutionModel } from '../model'

let app = express()

app.use(InstitutionApp)

const subdomain = 'subdomain'
const { connection, connectionKey } = getTestConnectionInfo()
const Institution = getInstitutionModel(connection)

let sandbox

describe('Institution Plugin', () => {
  db()

  beforeEach( async () => {
    sandbox = sinon.sandbox.create()
    await Institution.create({ name: 'test', subdomain,
      updatedBy: { id: 'test' } })
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('fails if connection key is not passed', async () => {
    try {
      await seneca.actAsync({
        role: 'institutions',
        cmd: 'load'
      })
      assert.fail()
    } catch (err) {
      expect(err.message).to.contain('msg does not contain connectionKey')
    }
  })

  it('save fails if connection key is not passed', async () => {
    try {
      await seneca.actAsync({
        role: 'institutions',
        cmd: 'save'
      })
      assert.fail()
    } catch (err) {
      expect(err.message).to.contain('connectionKey needed')
    }
  })

  describe('load command', () => {
    it('returns default if no domain submitted', async () => {
      let institution = await seneca.actAsync({
        role: 'institutions',
        cmd: 'load',
        connectionKey
      })
      assert(institution.subdomain, 'kuali')
    })

    it('returns institution if found', async () => {
      let institution = await seneca.actAsync({
        role: 'institutions',
        cmd: 'load',
        data: { subdomain },
        connectionKey
      })
      assert.equal(institution.subdomain, subdomain)
    })

    it('returns institution if not lowercase', async () => {
      let institution = await seneca.actAsync({
        role: 'institutions',
        cmd: 'load',
        data: { subdomain: subdomain.toUpperCase() },
        connectionKey
      })
      assert.equal(institution.subdomain, subdomain)
    })

    it('returns error if not found', async () => {
      try {
        await seneca.actAsync({
          role: 'institutions',
          cmd: 'load',
          data: { subdomain: 'missingsubdomain' },
          autoCreate: false,
          connectionKey
        })
        throw new Error('this line should not execute')
      } catch (e) {
        assert.notEqual(e.cause, undefined)
      }
    })

    it('returns error if invalid subdomain', async () => {
      try {
        await seneca.actAsync({
          role: 'institutions',
          cmd: 'load',
          data: { subdomain: 'missing subdomain' },
          connectionKey
        })
        throw new Error('this line should not execute')
      } catch (e) {
        assert.notEqual(e.cause, undefined)
      }
    })

    it('returns error if findOne throws error', async () => {
      sandbox.stub(mongoose.Model, 'findOne')
        .returns(new Promise((resolve, reject) => {
          return reject(new Error())
      }))
      const spy = sandbox.spy(defaultLogger, 'error')
      try {
        await seneca.actAsync({
          role: 'institutions',
          cmd: 'load',
          data: { subdomain },
          connectionKey
        })
        throw new Error('this line should not execute')
      } catch (e) {
        assert.notEqual(e.cause, undefined)
        sinon.assert.calledOnce(spy)
      }
    })
  })

  describe('getSecret command', () => {
    it('returns error if findOne throws error', async () => {
      sandbox.stub(mongoose.Model, 'findOne').throws('error')

      try {
        await seneca.actAsync({
          role: 'institutions',
          cmd: 'getSecret',
          data: { subdomain },
          connectionKey
        })
        throw new Error('this line should not execute')
      } catch (e) {
        assert.notEqual(e.cause, undefined)
      }
    })

    it('returns secret if found', async () => {
      let value = await seneca.actAsync({
        role: 'institutions',
        cmd: 'getSecret',
        data: { subdomain },
        connectionKey
      })
      assert.notEqual(value, undefined)
      assert.notEqual(value.secret, undefined)
      assert(value.secret.length > 10)
    })

    it('returns secret if not lowercase', async () => {
      let value = await seneca.actAsync({
        role: 'institutions',
        cmd: 'getSecret',
        data: { subdomain: subdomain.toUpperCase() },
        connectionKey
      })
      assert.notEqual(value, undefined)
      assert.notEqual(value.secret, undefined)
      assert(value.secret.length > 10)
    })

    it('returns error if not found', async () => {
      try {
        await seneca.actAsync({
          role: 'institutions',
          cmd: 'getSecret',
          data: { subdomain: 'missing subdomain' },
          connectionKey
        })
        throw new Error('this line should not execute')
      } catch (e) {
        assert.notEqual(e.cause, undefined)
      }
    })

    it('defaults to kuali when no data', async () => {
      await Institution.create({ name: 'Kuali', subdomain: 'kuali',
        updatedBy: { id: 'test' } })

      let value = await seneca.actAsync({
        role: 'institutions',
        cmd: 'getSecret',
        connectionKey
      })
      assert.notEqual(value, undefined)
      assert.notEqual(value.secret, undefined)
      assert(value.secret.length > 10)
    })
  })
})
