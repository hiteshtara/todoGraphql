/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { Router } from 'express'
import params from 'params'
import { pick } from 'lodash'
import authenticate from 'shared/middleware/authenticate'
import wrapAsync from 'shared/wrap-async'
import { getConnection } from 'shared/mongoose/pool'
import events from 'shared/events'
import cache from 'shared/cache'
import policy from 'services/institution/policy'
import { getInstitutionModel } from './model'

let router = Router()

router.use(authenticate({ allowAnonymous: true }))

router.get('/', ({ user, institution }, res) => {
  if (!user) {
    const unauthedKeys = [
      'name',
      'id',
      'newId',
      'redirect',
      'validRedirectHosts',
      'idps',
      'timezone'
    ]
    return res.status(200).json(pick(institution, unauthedKeys))
  }
  const allowedKeys = [
    'name',
    'id',
    'newId',
    'redirect',
    'features',
    'subdomain',
    'validRedirectHosts',
    'idps',
    'timezone'
  ]
  return res.status(200).json(pick(institution, allowedKeys))
})

router.put(
  '/',
  authenticate({ roles: ['admin', 'service'] }),
  wrapAsync(async (req, res) => {
    let allowedProperties = params(req.body).only(policy())
    allowedProperties.updatedBy = req.user
    const conn = getConnection(res.locals.connectionKey)
    const Institution = getInstitutionModel(conn)
    let institution = await Institution.findOne({
      subdomain: req.institution.subdomain
    })
    Object.assign(institution, allowedProperties)
    institution = await institution.save()
    events.emit('institution:save', institution)
    await clearCache(institution)
    res.status(200).json(institution)
  })
)

async function clearCache(institution) {
  const { subdomain } = institution
  const cacheKey = `institutions:${subdomain}`
  await cache.delAsync(cacheKey)
}

export default router
