# Institution Service

## Seneca Messages

The Institution service provides the following seneca messages:

### Find institution by subdomain

#### Pattern
```
role:institution,cmd:load,subdomain:<insert subdomain>
```

#### Example
```js
import seneca from 'shared/seneca'

async function getInstitution() {
  return await seneca.actAsync('role:institution,cmd:load,subdomain:monsters')
}
```
