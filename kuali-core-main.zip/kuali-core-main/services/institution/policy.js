export default function policy() {
  return [
    'name',
    'provider',
    'idp',
    'idps',
    'eppn',
    'ldapUserIdentifier',
    'featureFlagsCm',
    'casServiceUrl',
    'casForceLogout',
    'signInExpiresIn',
    'signInExpiresWithSession',
    'forceAuthn',
    'features',
    'approval',
    'ldapConfig',
    'timezone'
  ]
}
