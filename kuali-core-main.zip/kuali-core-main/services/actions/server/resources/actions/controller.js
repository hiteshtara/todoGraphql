/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { pick } from 'lodash'
import config from 'config'
import seneca from 'shared/seneca'
import { ForbiddenError, BadRequestError } from 'shared/errors'
import select from 'shared/api-conventions/select'
import { getConnection } from 'shared/mongoose/pool'
import { publisher } from 'shared/events/publisher'
import { getCollection } from './model'

const CREATE_FIELDS = [
  'userId',
  'userIds',
  'roleIds',
  'type',
  'handlerUrl',
  'handlerPath',
  'display',
  'details'
]

const UPDATE_FIELDS = ['status', 'comment', 'completedBy', 'details']

async function query(q, connectionKey) {
  if (!connectionKey) {
    throw new Error('connectionKey is required')
  }
  if (q.userId) {
    const userId = q.userId
    delete q.userId
    const roleIds = await seneca.actAsync({
      role: 'groups',
      cmd: 'getRolesByUser',
      connectionKey,
      userId
    })
    q.$or = [
      {
        roleIds: {
          $in: roleIds
        }
      },
      {
        userIds: {
          $in: [userId]
        }
      },
      { userId }
    ]
  }
  const { result, count } = await getActions(connectionKey).query(q)
  return {
    count,
    result: select(q && q.fields, result)
  }
}

async function load(id, connectionKey) {
  if (!connectionKey) {
    throw new Error('connectionKey is required')
  }
  return await getActions(connectionKey).load(id)
}

async function create(data, connectionKey, currentUser) {
  if (!connectionKey) {
    throw new Error('connectionKey is required')
  }
  data = pick(data, CREATE_FIELDS)
  data.updatedBy = currentUser
  const newAction = await getActions(connectionKey).save(data)

  const channel = `${config.events.actions.v1}create`
  const meta = { tenant: connectionKey }
  publisher.publish(channel, newAction, meta)

  return newAction
}

async function update(id, data, connectionKey, currentUser) {
  data = data || {}
  if (!connectionKey) {
    throw new Error('connectionKey is required')
  }
  const action = await load(id, connectionKey)
  if (action.completed) {
    throw new ForbiddenError('That action has already been completed')
  }
  if (!data.status) {
    throw new BadRequestError('You must send a status')
  }
  data = pick(data, UPDATE_FIELDS)
  Object.assign(data, {
    completedDate: new Date(),
    completed: true,
    id,
    updatedBy: currentUser
  })
  const newAction = await getActions(connectionKey).save(data)

  const channel = `${config.events.actions.v1}update`
  const meta = { tenant: connectionKey }
  publisher.publish(channel, newAction, meta)

  return newAction
}

function getActions(connectionKey) {
  return getCollection(getConnection(connectionKey))
}

export { query, load, create, update }
