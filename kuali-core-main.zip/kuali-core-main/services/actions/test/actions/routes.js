/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import express from 'express'
import mongoose from 'shared/mongoose'
import supertest from 'supertest-as-promised'
import { getTestConnectionInfo } from 'shared/test-helpers'
import responseLocals from 'shared/middleware/response-locals'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import healthRoutes from '../../server/resources/actions/health'
import testAction from '../helpers/test-action'
import rootApp from '../../index'
import * as actions from '../../server/resources/actions/controller'
import { getModel } from '../../server/resources/actions/model'

const userId = mongoose.Types.ObjectId()
const { connectionKey, connection } = getTestConnectionInfo()
const Action = getModel(connection)

const defaultMiddleware = (req, res, next) => {
  req.user = { id: userId, role: 'admin' }
  next()
}

function createApp (mw = defaultMiddleware, router = rootApp) {
  let subApp = express()
  subApp.use(responseLocals)
  subApp.use(mw)
  healthRoutes(subApp)
  subApp.use(router)
  let subRequest = supertest(subApp)

  return subRequest
}

const request = createApp()

describe('Actions Routes', () => {
  let sandbox
  beforeEach(async () => {
    await Action.remove({})
    sandbox = sinon.sandbox.create()
  })
  afterEach(() => {
    sandbox.restore()
  })

  describe('health', () => {
    it('gets health', async () => {
      await request.get('/api/v1/actions/health').expect(204)
      await request.get('/actions/health').expect(204)
    })
  })

  describe('query', () => {
    it('queries actions', async () => {
      await actions.create(testAction({ userId }), connectionKey, {
        id: 'test'
      })
      let response = await request
        .get('/api/v1/actions')
        .expect(200)
        .expect('Item-Count', '1')
      expect(response.body).to.have.length(1)
    })

    it('is able to select fields', async () => {
      await actions.create(testAction({ userId }), connectionKey, {
        id: 'test'
      })
      let { body } = await request
        .get('/api/v1/actions?fields=type,display')
        .expect(200)
      expect(body).to.have.length(1)
      expect(body[0]).to.have.keys('type', 'display')
    })

    it('returns old id as id', async () => {
      await Action.create(testAction({ userId, oldId: 'foobar' }))
      let response = await request.get('/api/v1/actions').expect(200)
      expect(response.body).to.have.deep.property('0.id', 'foobar')
    })

    it('returns old id along with other field selections', async () => {
      await Action.create(testAction({ userId, oldId: 'foobar2' }))
      let { body } = await request
        .get('/api/v1/actions?fields=id,newId,display')
        .expect(200)
      expect(body[0]).to.have.keys('id', 'newId', 'display')
      expect(body[0]).to.have.property('id', 'foobar2')
    })

    it('queries actions and filters user', async () => {
      let originalAct = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'groups' && pattern.cmd === 'getRolesByUser') {
          return Promise.resolve([])
        }
        return originalAct(pattern)
      })
      await actions.create(testAction({ userId }), connectionKey, {
        id: 'test'
      })
      let response = await request
        .get(`/api/v1/actions?userId=${userId}`)
        .expect(200)
        .expect('Item-Count', '1')
      expect(response.body).to.have.length(1)
    })
  })

  describe('get', () => {
    it('gets an action', async () => {
      let action = await actions.create(testAction({ userId }), connectionKey, {
        id: 'test'
      })
      let { body } = await request.get(`/api/v1/actions/${action.id}`)
      expect(body).to.be.eql(action)
    })

    it('returns 404 if action is not found', async () => {
      await request.get('/api/v1/actions/helloworld').expect(404)
    })

    it('accepts oldId as id parameter', async () => {
      let action = await Action.create(testAction({ oldId: 'foobar' }))
      action = await actions.load(action._id, connectionKey)
      let { body } = await request.get('/api/v1/actions/foobar').expect(200)
      expect(body).to.be.eql(action)
    })
  })

  describe('create', () => {
    it('creates an action', async () => {
      let action = testAction({
        userId,
        handlerPath: 'https://google.com/foo/bar'
      })
      let { body } = await request
        .post('/api/v1/actions')
        .send(action)
        .expect(201)
      expect(body.userId).to.be.eql(String(userId))
      expect(body.handlerPath).to.be.equal('/foo/bar')
    })

    it('replaces ID in action handlerPath', async () => {
      let action = testAction({
        userId,
        handlerPath: 'https://test.kuali.co/actions/{{ID}}',
        handlerUrl: 'https://test.kuali.co/actions/{{ID}}'
      })
      let { body } = await request
        .post('/api/v1/actions')
        .send(action)
        .expect(201)
      expect(body.handlerPath).to.be.equal(`/actions/${body.id}`)
      expect(body.handlerUrl).to.be.equal(
        `https://test.kuali.co/actions/${body.id}`
      )
    })

    it('creates an action', async () => {
      let action = testAction({
        userId,
        handlerPath: 'https://google.com/foo/bar',
        handlerUrl: null
      })
      let { body } = await request
        .post('/api/v1/actions')
        .send(action)
        .expect(201)
      expect(body.handlerUrl).to.be.equal(null)
    })
  })

  describe('update', () => {
    it('updates an action', async () => {
      let action = await actions.create(testAction({ userId }), connectionKey, {
        id: 'test'
      })
      let { body } = await request
        .put(`/api/v1/actions/${action.id}`)
        .send({ status: 'approved' })
      expect(body).to.have.property('completed', true)
    })
  })
})
