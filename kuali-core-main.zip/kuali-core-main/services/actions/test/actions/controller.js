/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect, assert } from 'chai'
import { getTestConnectionInfo } from 'shared/test-helpers'
import testAction from '../helpers/test-action'
import * as actions from '../../server/resources/actions/controller'
import { getModel } from '../../server/resources/actions/model'

const FIELDS = [
  'comment',
  'completed',
  'completedBy',
  'completedDate',
  'createdAt',
  'details',
  'display',
  'handlerUrl',
  'handlerPath',
  'id',
  'newId',
  'status',
  'type',
  'updatedAt',
  'updatedBy',
  'userId',
  'userIds',
  'roleIds'
]
const { connectionKey, connection } = getTestConnectionInfo()
const Action = getModel(connection)

describe('Actions Controller', () => {
  beforeEach(async () => {
    await Action.remove({})
  })

  it('fails if connection key is not present', async () => {
    const methods = [
      actions.query,
      actions.load,
      actions.create,
      actions.update
    ]
    methods.forEach(async method => {
      try {
        await method()
        assert.fail()
      } catch (err) {
        expect(err.message).to.contain('connectionKey is required')
      }
    })
  })

  describe('query', () => {
    it('able to query', async () => {
      await Action.create(testAction())
      const { result, count } = await actions.query({}, connectionKey)
      expect(count).to.be.equal(1)
      expect(result).to.have.length(1)
    })

    it('selects fields', async () => {
      await Action.create(testAction())
      const { result } = await actions.query(
        { fields: 'id,type' },
        connectionKey
      )
      expect(result).to.have.length(1)
      result.forEach(action => {
        expect(action).to.have.keys('id', 'type')
      })
    })

    it('pulls id as old id if present', async () => {
      const action = await Action.create(testAction({ oldId: 'foobar' }))
      const { result } = await actions.query(
        { fields: 'id,newId' },
        connectionKey
      )
      expect(result).to.have.deep.property('0.id', 'foobar')
      expect(result).to.have.deep.property('0.newId', action._id.toString())
    })

    it('fails without connection key', async () => {
      try {
        await actions.query({})
      } catch (err) {
        expect(err.message).to.contain('connectionKey is required')
        return
      }
      assert.fail()
    })

    it('works with querying by userId', async () => {
      await Promise.all([
        Action.create(testAction({ userId: 'user1' })),
        Action.create(testAction({ userId: 'user2' }))
      ])
      const { result } = await actions.query(
        {
          userId: 'user1',
          q: 'Display'
        },
        connectionKey
      )
      expect(result).to.have.length(1)
      expect(result).to.have.deep.property('0.userId', 'user1')
    })
  })

  describe('load', () => {
    it('loads a single action', async () => {
      let { _id: id } = await Action.create(testAction())
      const action = await actions.load(id, connectionKey)
      expect(action).to.have.keys(FIELDS)
    })
  })

  describe('create', () => {
    it('strips out status and completed fields upon create', async () => {
      let action = await actions.create(
        testAction({ status: 'foo', comment: 'bar' }),
        connectionKey,
        { id: 'test' }
      )
      expect(action.status).to.be.equal(null)
      expect(action.comment).to.be.equal(null)
    })

    it('replaces {{ID}} with id', async () => {
      let action = await actions.create(
        testAction({ handlerUrl: 'https://google.com/foo/bar/{{ID}}' }),
        connectionKey,
        { id: 'test' }
      )
      expect(action).to.have.property(
        'handlerUrl',
        `https://google.com/foo/bar/${action.id}`
      )
    })

    it('turns handler path to absolute path with host stripped', async () => {
      let action = await actions.create(
        testAction({ handlerPath: 'https://google.com/foo/bar' }),
        connectionKey,
        { id: 'test' }
      )
      expect(action.handlerPath).to.be.equal('/foo/bar')
    })

    it('keeps handler path null if set to null', async () => {
      let action = await actions.create(
        testAction({ handlerPath: null }),
        connectionKey,
        { id: 'test' }
      )
      expect(action.handlerPath).to.be.equal(null)
    })

    it('will not create actions without userids and roleids', async () => {
      try {
        await actions.create(
          testAction({ userId: null, userIds: [] }),
          connectionKey,
          { id: 'test' }
        )
        throw Error('expected an exception')
      } catch (ex) {
        assert.equal(ex.message, 'Must have either userId, userIds, or roleIds')
      }
    })
  })

  describe('update', () => {
    it('only updates status and comment, sets completed to true', async () => {
      let action = await Action.create(testAction())
      const updatedAction = await actions.update(
        action._id,
        {
          status: 'approved',
          comment: 'foobar',
          handlerUrl: 'http://foobar.com'
        },
        connectionKey,
        { id: 'test' }
      )
      expect(updatedAction.status).to.be.equal('approved')
      expect(updatedAction.comment).to.be.equal('foobar')
      expect(updatedAction.handlerUrl).to.not.be.equal('http://foobar.com')
      expect(updatedAction.completed).to.be.equal(true)
      expect(updatedAction).to.have.property('completedDate')
    })

    it('throws error if action has been completed', async () => {
      let action = await Action.create(testAction({ completed: true }))
      try {
        await actions.update(action._id, null, connectionKey, { id: 'test' })
      } catch (err) {
        expect(err.message).to.match(/Forbidden/)
        return
      }
      assert.fail('expected error to happen')
    })

    it('throws error if status is not sent', async () => {
      let action = await Action.create(testAction())
      try {
        await actions.update(action._id, null, connectionKey, { id: 'test' })
      } catch (err) {
        expect(err.message).to.match(/Bad Request/)
        return
      }
      assert.fail('expected error to happen')
    })
  })
})
