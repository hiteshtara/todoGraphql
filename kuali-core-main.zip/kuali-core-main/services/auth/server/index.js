/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import bodyParser from 'body-parser'
import config from 'config'
import cookieParser from 'cookie-parser'
import express from 'express'
import seneca from 'shared/seneca'
import secure from 'shared/secure'
import { readFile } from 'fs-promise'
import responseLocals from 'shared/middleware/response-locals'
import path from 'path'

import tokenService from './resources/tokens/service'
import inCommonService from './resources/in-common/service'
import loginRoutes from './resources/login/routes'
import tokenRoutes from './resources/tokens/routes'
import errorHandler from './utils/error-handler'
import passports from './utils/passports'
import healthRoute from './utils/health'
import idpHandler from './utils/idp-handler'

const samlMeta = readFile(
  path.resolve(__dirname, config.auth.samlMeta),
  'utf-8'
)
const samlMeta2 = readFile(
  path.resolve(__dirname, config.auth.samlMeta2),
  'utf-8'
)

seneca.use(inCommonService)
seneca.use(tokenService)

const app = express()
app.use(responseLocals)
healthRoute(app)

app.use(secure)

const router = express.Router()

app.use(cookieParser())
app.use(bodyParser.json())
app.use(idpHandler)
app.use(passports.attach())
app.use(passports.middleware('initialize'))
app.use(passports.middleware('session'))

tokenRoutes(router)
loginRoutes(passports, router, samlMeta, samlMeta2)
app.use(router)
app.use(errorHandler)

export default app
