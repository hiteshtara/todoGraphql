/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map, some } from 'lodash'
import { defaultLogger as logger } from 'shared/logging'

export default function (err, req, res, next) { // eslint-disable-line
  if (err.httpCode) {
    res.status(err.httpCode).send(err)
  }
  if (err.name === 'SamlConfigError') {
    logger.error('SAML ERROR CONFIG', err.message, err.items, err.stack)
    res.status(401).send(samlError(err.message, err.items))
  } else if (err.message == 'Invalid signature') {
    // TODO:: There is more info to be had if this is the error. To get it,
    // we'll need to log out sig.validationErrors on line 502 from
    // node_modules/passport-saml/lib/passport-saml/saml.js
    logger.error('SAML ERROR INVALID SIGNATURE', err.message, err.stack)
    res.status(401).send(samlError('Invalid Signature: the public key we got' +
      ' from incommon wasn\'t able to verify the signed response.', [
        'Did you save the Kuali Metadata with windows line endings' +
          ' (\\r\\n)? We require the data to be saved with mac/unix' +
          ' endings (\\n).',
        'Are you using the correct private key to sign?',
        'Have you given us the correct public key?'
      ]))
  } else if (err.name === 'Unapproved') {
    if (some(['saml', 'cas'], p => p === req.institution.provider)) {
      res.redirect('/auth/kuali/#/needsApproval')
    } else {
      res.status(401).send({ redirect: '/auth/kuali/#/needsApproval' })
    }
  } else {
    logger.error('SAML ERROR UNEXPECTED', err.message, err.stack)
    res.status(401).send(samlError(err.message, []))
  }
}

const samlError = (msg, items) => errorTmpl(
  'SAML Error',
  'We hit an issue attempting to sign you in.',
  `
<div>${msg}</div>
<ul>${map(items, item => `<li>${item}</li>`).join('')}</ul>
`
)

const errorTmpl = (title, subtitle, error) => `
<!doctype html>
<html>
  <head>
    <title>${title}</title>
    <style>
      html {
        background: #E0E0E0;
        padding-top: 50px;
        display: flex;
        justify-content: center;
      }
      h1 {
        text-align: center;
      }
      .error {
        background-color: #F0F0F0;
        padding: 40px;
        box-shadow: 0 0 8px 1px rgba(0, 0, 0, 0.2) inset;
        border-radius: 15px;
      }
    </style>
  </head>
  <body>
    <div>
      <h1>You've encountered an error</h1>
      <h2>${subtitle}</h2>
      <div class="error">
        ${error}
      </div>
    </div>
  </body>
</html>
`
