/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { Passport } from 'passport'
import Passports from 'passports'
import seneca from 'shared/seneca'
import config from 'config'
import { defaultLogger as logger } from 'shared/logging'

import basicStrategy from '../strategies/basic'
import {
  getSamlStrategy,
  getSamlOptions,
  tryConfigurations
} from '../strategies/saml'
import getCasStrategy from '../strategies/cas'
import { getLdapStrategy } from '../strategies/ldap'

import { ensure } from '../strategies/utils/saml-helpers'

import { checkConfig } from './shibboleth'

async function getConfig(req, cb) {
  let institution = req.institution || {}
  let providerKey = `${institution.provider}`
  let samlKey
  if (institution.provider === 'saml') {
    checkConfig(req, this); // BU CUSTOMIZATION: See function below.
    samlKey = await tryConfigurations(req, institution)
    providerKey = `${institution.provider}:${req.locals.idp.idp}:${samlKey}`
  }
  let configKey = `${providerKey}:${req.institutionId}` //eslint-disable-line max-len
  cb(null, configKey, {
    realm: req.institutionId,
    institution: req.institution,
    samlKey,
    locals: req.locals
  })
}

async function createInstance({ institution, samlKey, locals }, cb) {
  institution = institution || {}
  const instance = new Passport()
  instance.use('basic', basicStrategy)
  if (institution.provider == 'saml') {
    const incommonMeta = await seneca.actAsync({
      role: 'incommon',
      cmd: 'load',
      idp: locals.idp.idp,
      connectionKey: locals.connectionKey
    })
    try {
      ensure(
        incommonMeta,
        `Unable to find configuration meta data for
        ${institution.name} (${institution.subdomain}): ${locals.idp.idp}.`
      )
      const privateKey = config.auth.samlKeys[samlKey]
      let samlOptions = getSamlOptions(institution, incommonMeta, privateKey)
      instance.use('saml', getSamlStrategy(samlOptions, institution))
    } catch (ex) {
      logger.fatal(ex)
    }
  }
  if (institution.provider == 'cas') {
    instance.use('cas', getCasStrategy(institution))
  }
  if (institution.provider == 'ldap') {
    instance.use('ldap', getLdapStrategy(institution))
  }
  return cb(null, instance)
}

export default new Passports({
  getConfig,
  createInstance
})
