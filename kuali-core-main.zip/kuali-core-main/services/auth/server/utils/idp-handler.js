/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
import { assign } from 'lodash'
import config from 'config'
import qs from 'querystring'

export default function(req, res, next) {
  const institution = req.institution || {}

  if (
    !req.cookies.idp &&
    !req.query.idp &&
    institution.idps &&
    institution.idps.length > 1 &&
    req.path.indexOf('signout') < 0 &&
    req.path.indexOf('/api/') < 0
  ) {
    return res.redirect(`/auth/kuali/?${qs.encode(req.query)}#/idpselection`)
  }

  if (
    (institution.idps &&
      institution.idps.length === 1 &&
      !req.query.idp &&
      !req.cookies.idp) ||
    req.path.indexOf('signout') >= 0
  ) {
    req.locals.idp = institution.idps[0]
  }

  if (req.query.idp) {
    req.locals.idp = findIdpByname(institution, req.query.idp)
  }

  if (req.cookies.idp) {
    req.locals.idp = findIdpByname(institution, req.cookies.idp)
    const cookieOpts = assign({}, config.cookieOpts)
    cookieOpts.maxAge = 0
    res.cookie('idp', '', cookieOpts)
  }

  if (!req.locals.idp && institution.provider === 'saml') {
    req.locals.idp = institution.idps[0]
  }

  return next()
}

function findIdpByname(institution, name) {
  return institution.idps.find(idpInfo => idpInfo.name === name)
}
