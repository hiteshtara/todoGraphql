/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import url from 'url'
import { isValidRedirect } from 'shared/url-helpers'
import * as analytics from 'shared/analytics'

export function postAuthRedirect(req, res) {
  analytics.identify(req.user, req.institution)
  analytics.track(
    req.user,
    'Signin success',
    {
      provider: req.institution.provider,
      subdomain: req.institution.subdomain,
      institution: req.institution.name
    }
  )
  let redirectUrl = req.query.redirect_to || req.query.return_to || '/apps/'
  if (!isValidRedirect(redirectUrl, req)) {
    redirectUrl = '/apps/'
  }
  res.redirect(redirectUrl)
}

export function postLogoutRedirect(req, res) {
  const { institution } = req
  analytics.identify(req.user, institution)
  analytics.track(
    req.user,
    'Signout success',
    {
      provider: institution.provider,
      subdomain: institution.subdomain,
      institution: institution.name
    }
  )
  let redirectUrl = req.query.redirect_to || req.query.return_to || '/apps/'

  // Force CAS logout on forceAuthn
  if (shouldLogoutCas(institution)) {
    const { casServiceUrl } = institution
    const redirectIsAbsolute = Boolean(url.parse(redirectUrl).host)
    let referrer = req.get('referrer')
    let casRedirect = ''
    if (!referrer && redirectIsAbsolute) referrer = '/'
    if (referrer) {
      const root = url.resolve(referrer, '/')
      casRedirect = encodeURIComponent(url.resolve(root, redirectUrl))
    }
    redirectUrl = `${casServiceUrl}/logout?service=${casRedirect}`
  }
  res.redirect(redirectUrl)
}

function shouldLogoutCas(institution) {
  return (
    institution
    && institution.provider === 'cas'
    && institution.casForceLogout
  )
}
