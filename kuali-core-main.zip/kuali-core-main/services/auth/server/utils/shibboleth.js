import config from 'config'
import { defaultLogger as logger } from 'shared/logging'
import { Strategy, SAML } from 'passport-saml'

SAML.prototype.getCallbackUrl = function (req) {
  return req.headers.callbackUrl;
};

/**
 * BU CUSTOMIZATION: If coi requests authentication from core and core determines that the IDP (shibboleth)
 * session has not expired, the redirect_to query parameter sent by coi is used to redirect directly back to
 * coi. However, if authentication requires authentication with the shibboleth IDP, then the callback parameter
 * needs to be passed to shibboleth in order to get it back again from shibboleth. Currently this saml
 * callback parameter can only have one value set in local.js, but we need it to be dynamic. This is because
 * if one is logging in from the core login page, the callback needs to be /auth/saml/consume, but if one is 
 * logging in from coi, it needs to be /auth/saml/consume?return_to=[coi home page]. This runtime resetting
 * of the saml callback value is done here.
 */
export function checkConfig(req, config) {
  for (var key in config._instances) {
    if (/shib/.test(key)) {

      var coreCallback = new CallbackUrl(req);
      if(!coreCallback.url.getValue() || !coreCallback.redirect.getValue()) {
        return; // We have to take the saml redirect as it's the only thing we have.
      }

      var samlCallback = new CallbackUrl(config._instances[key]);
      if(!samlCallback.url.getValue()) {
        // Something is wrong. There should at least be a url (with or without a query string).
        return;
      }
      
      var url = samlCallback.url.getValue();
      if(coreCallback.redirect.isToCore()) {
        // SCENARIO 1
        // The Shibboleth IDP is configured to recognize a core callback that redirects to itself as not 
        // having a redirect_to parameter at all. We favor invoking only the default core redirection to '/apps/'.
        // Therefore we need to trim off the redirect querystring parameter if we find one (it would cause 
        // shibboleth to respond with a claim that the sender of the authentication request is unrecognized).
        var qs = samlCallback.queryString.removeRedirectParameter();
        if(qs) {
          url += ('?' + qs);
        }
      }
      else {
        // SCENARIO 2
        // Core is being accessed via coi or some other client application and redirection needs to indicate
        // returning to that application. The shibboleth IDP should have been configured with SP metadata
        // that includes the core 'consume' endpoint as a callback with a redirect that includes the application url.
        url += ('?' + samlCallback.queryString.setParameter(coreCallback.redirect));
      }
      // config._instances[key]._strategies.saml._saml.options.callbackUrl = url;
      req.headers.callbackUrl = url;
    }
  }
};

function CallbackUrl(_data) {
  var regex = /((redirect)|(return))_to=([^&]+)/;
  var data = _data;
  var corehost = process.env.CORE_VIRTUAL_HOST;

  if (!/^https?:\/\//.test(corehost)) {
    corehost = 'https://' + corehost;
  }

  // THIS IS THE URL PORTION OF THE CALLBACK (DOES NOT INCLUDE QUERYSTRING).
  this.url = {
    _url: '',
    getValue: function() {
      if (!this._url) {
          var fullurl = data.url || data.originalUrl;
          if (!fullurl && data._strategies) {
            fullurl = data._strategies.saml._saml.options.callbackUrl;
          }
          if (fullurl) {
            var parts = fullurl.split('?');
            this._url = parts[0];
          }
        }
        return this._url;
      }
    };

  // THIS IS THE QUERYSTRING PORTION OF THE CALLBACK.
  this.queryString = {
    _querystring: '',
    getValue: function() {
      var fullurl = data.url || data.originalUrl;
      if (!fullurl && data._strategies) {
        fullurl = data._strategies.saml._saml.options.callbackUrl;
      }
      if (fullurl) {
        var parts = fullurl.split('?');
        if (parts.length == 2) {
          this._querystring = parts[1];
        }
      }
      return this._querystring;
    },
    setParameter: function(redir) {
      var qs = this.getValue();
      if(regex.test(qs)) {
        return qs.replace(regex, '$1_to='+redir.getValue());
      }
      else {
        // The SP metadata provided to the Shibboleth IDP specified 'redirect_to'
        // instead of 'return_to' as the redirect parameter name. It must be set to match here.
        return qs + (/\?/.test(qs) ? '&' : '') + 'redirect_to=' + redir.getValue();
      }
    },
    removeRedirectParameter: function() {
      var qs = this.getValue();
      qs = qs.replace(regex, '');
      qs = qs.replace('&&', '&');
      if(/^\?/.test(qs)) {
        qs = qs.substring(1);
      }
      if(/^\?/.test(qs)) {
        qs = qs.substring(0, qs.length-1);
      }
      return qs;
    }
  };
  
  // THIS IS THE PARAMETER WITHIN THE QUERYSTRING OF THE CALLBACK THAT SPECIFIES REDIRECTION.
  this.redirect = {
    key: '',
    val: '',
    parent: '',
    init: function(_parent) {
      this.parent = _parent;
      if (!this.key || !this.val) {
        if (data.query) {
          if (data.query.redirect_to) {
            this.key = 'redirect_to';
            this.val = data.query.redirect_to;
          } 
          else if (data.query.return_to) {
            this.key = 'return_to';
            this.val = data.query.return_to;
          }
        } 
        else {
          var qs = this.parent.queryString.getValue();
          if (qs) {
            var matches = qs.match(regex);
            if (matches.length > 0) {
              this.key = matches[0].split('=')[0];
              this.val = matches[0].split('=')[1];
            }
          }
        }
      }
    },
    getValue() {
      if(this.isToKc() && process.env.KC_IDP_CALLBACK_OVERRIDE) {
        return process.env.KC_IDP_CALLBACK_OVERRIDE;
      }
      return this.val;
    },
    toString: function toString() {
      return this.key + '=' + this.getValue();
    },
    isToCore: function() {
      return /^(https?:\/\/)?[^\/]+?(\/?|(\/apps\/?))?$/.test(this.val);
    },
    isToKc: function() {
      return /^(https?:\/\/)?[^\/]+?(\/?|(\/kc(\/?|(\/.*))))?$/.test(this.val);
    }
  };

  this.redirect.init(this);
};
