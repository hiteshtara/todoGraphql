/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { Schema } from 'shared/mongoose'
import { defaultLogger } from 'shared/logging'

const inCommonSchema = new Schema({
  idp: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  cert: {
    type: String
  },
  entryPoint: {
    type: String
  }
},
{
  schemaName: 'InCommon',
  timestamps: true,
  versionKey: false
})

const modelMap = {}
function getInCommonModel(connection) {
  let InCommon = modelMap[connection]
  if (!InCommon) {
    InCommon = connection.model('InCommon', inCommonSchema)
    InCommon.on('index', err => {
      /* istanbul ignore else */
      if (err) {
        defaultLogger.fatal('Couldn\'t create all indexes on InCommon', err)
      }
    })
    modelMap[connection] = InCommon
  }
  return InCommon
}

export { getInCommonModel }
