/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { getConnection } from 'shared/mongoose/pool'
import { getInCommonModel } from
  'services/auth/server/resources/in-common/model'

export default function incommon() {
  this.add('role:incommon,cmd:load', ({ idp, connectionKey }, respond) => {
    let Model = getInCommonModel(getConnection(connectionKey))
    Model.find({ idp }, (err, result) => {
      respond(err, result[0] && result[0].toJSON())
    })
  })
}
