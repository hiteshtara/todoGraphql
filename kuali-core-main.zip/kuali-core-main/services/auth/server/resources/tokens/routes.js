/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import seneca from 'shared/seneca'
import { map, first, groupBy, union, isEmpty } from 'lodash'
import moment from 'moment'
import getBaseUrl from 'shared/base-url'
import wrapAsync from 'shared/wrap-async'
import service2service from 'service2service/express'
import { userExpiredTokenHTML, userExpiredTokensHTML,
  userExpiringTokensHTML, userExpiringTokenHTML,
  adminEmailUserHTML, adminUserExpiredTokensHTML,
  adminUserExpiringTokensHTML } from './html'

const tokenMW = service2service({
  secret: config.get('serviceSecret')
})

export default function (router) {
  router.post('/api/v1/tokens/notifyUsers', tokenMW, wrapAsync(notifyUsers))
  router.post('/api/v1/tokens/notifyAdmins', tokenMW, wrapAsync(notifyAdmins))
  return router
}

async function notifyUsers(req, res) {
  const baseUrl = getBaseUrl(req)
  let expiringKeys = []
  const { daysAhead } = req.body
  if (typeof daysAhead !== 'undefined') {
    const { startDate, endDate } = extractDates(daysAhead)
    expiringKeys = await seneca.actAsync({
      role: 'token',
      cmd: 'fetch',
      expired: 'expired',
      type: 'apiKey',
      startDate: moment.max(moment(startDate), moment()),
      endDate,
      connectionKey: res.locals.connectionKey
    })
  }
  const expiringKeysByUser = groupBy(expiringKeys, 'userId')
  const expiredKeys = await seneca.actAsync({
    role: 'token',
    cmd: 'fetch',
    expired: 'expired',
    type: 'apiKey',
    connectionKey: res.locals.connectionKey
  })
  const templates = await seneca.actAsync({
    role: 'notification-templates',
    cmd: 'list',
    query: {
      displayName: 'user-expiring-keys'
    },
    connectionKey: res.locals.connectionKey
  })
  const template = first(templates)
  const expiredKeysByUser = groupBy(expiredKeys, 'userId')
  const users = union(Object.keys(expiredKeysByUser),
    Object.keys(expiringKeysByUser))
  await Promise.all(map(users, async userId => {
    const user = await seneca.actAsync({
      role: 'users',
      cmd: 'load',
      id: userId,
      connectionKey: res.locals.connectionKey
    })
    await notifyUser(user, expiredKeysByUser[userId],
      expiringKeysByUser[userId], baseUrl, template,
      req.user, res.locals.connectionKey, res.locals.subdomain)
  }))
  res.sendStatus(200)
}

async function notifyUser(user, expiredKeysIn,
  expiringKeysIn, baseUrl, template, currentUser, connectionKey, subdomain) {
  const expiredKeys = getUserExpiredKeysHTML(expiredKeysIn)
  const expiringKeys = getUserExpiringKeysHTML(expiringKeysIn)
  if (user.email) {
    await seneca.actAsync({
      role: 'notifications',
      cmd: 'create',
      notification: {
        templateId: template.id,
        addresses: [user.email],
        variables: {
          firstName: user.displayName,
          expiredKeys,
          expiringKeys,
          APIKeysUrl: `${baseUrl}/users/#/${user.id}/api-keys`
        }
      },
      connectionKey,
      subdomain,
      currentUser
    })
  }
}

function getUserExpiredKeysHTML(expiredKeys) {
  if (isEmpty(expiredKeys)) {
    return ''
  }
  const tokens = map(expiredKeys, key => {
    return userExpiredTokenHTML
      .replace(/\$keyName/g, key.name)
      .replace(/\$expiredDate/g, moment(key.expiresAt).format('MMMM D, YYYY'))
  }).join('')
  return userExpiredTokensHTML.replace(/\$tokens/g, tokens)
}

function getUserExpiringKeysHTML(expiringKeys) {
  if (isEmpty(expiringKeys)) {
    return ''
  }
  const tokens = map(expiringKeys, key => {
    return userExpiringTokenHTML
      .replace(/\$keyName/g, key.name)
      .replace(/\$expiringDate/g, moment(key.expiresAt).format('MMMM D, YYYY'))
  }).join('')
  return userExpiringTokensHTML.replace(/\$tokens/g, tokens)
}

function extractDates(daysAhead) {
  const day = moment().add(daysAhead, 'days')
  const startDate = moment(day).startOf('day').toDate()
  const endDate = moment(day).endOf('day').toDate()
  return {
    startDate,
    endDate
  }
}

async function notifyAdmins(req, res) {
  const baseUrl = getBaseUrl(req)
  const expiredKeys = await seneca.actAsync({
    role: 'token',
    cmd: 'fetch',
    expired: 'expired',
    type: 'apiKey',
    connectionKey: res.locals.connectionKey
  })
  const expiringKeys = await seneca.actAsync({
    role: 'token',
    cmd: 'fetch',
    expired: 'expired',
    type: 'apiKey',
    startDate: moment().toDate(),
    endDate: moment().add(30, 'days').endOf('day').toDate(),
    connectionKey: res.locals.connectionKey
  })
  if (isEmpty(union(expiredKeys, expiringKeys))) {
    return res.sendStatus(200)
  }
  const adminResult = await seneca.actAsync({
    role: 'users',
    cmd: 'query',
    query: {
      role: 'admin',
      email: /@/
    },
    connectionKey: res.locals.connectionKey
  })
  const admins = adminResult.result
  const templates = await seneca.actAsync({
    role: 'notification-templates',
    cmd: 'list',
    query: {
      displayName: 'admin-expiring-keys'
    },
    connectionKey: res.locals.connectionKey
  })
  const template = first(templates)
  const expiredKeysByUser = groupBy(expiredKeys, 'userId')
  const expiringKeysByUser = groupBy(expiringKeys, 'userId')
  const userIds = union(
    Object.keys(expiredKeysByUser), Object.keys(expiringKeysByUser)
  )
  const users = []
  await Promise.all(map(userIds, async userId => {
    const user = await seneca.actAsync({
      role: 'users',
      cmd: 'load',
      id: userId,
      connectionKey: res.locals.connectionKey
    })
    users.push(user)
  }))
  const usersTemplate = map(users, user => {
    const userId = user && (user.newId || user.id)
    const expiredTokens = expiredKeysByUser[userId] ?
      adminUserExpiredTokensHTML
        .replace(/\$expiredTokens/g,
          getUserExpiredKeysHTML(expiredKeysByUser[userId])) : ''
    const expiringTokens = expiringKeysByUser[userId] ?
      adminUserExpiringTokensHTML
        .replace(/\$expiringTokens/g,
          getUserExpiringKeysHTML(expiringKeysByUser[userId])) : ''
    return adminEmailUserHTML
      .replace(/\$expiredTokens/g, expiredTokens)
      .replace(/\$expiringTokens/g, expiringTokens)
      .replace(/\$username/g, user.username || user.email)
      .replace(/\$apiKeysUrl/g, `${baseUrl}/users/#/${user.id}/api-keys`)
  }).join('')
  await Promise.all(map(admins, async admin => {
    await notifyAdmin(admin, usersTemplate, template, req.user,
      res.locals.connectionKey, res.locals.subdomain)
  }))
  return res.sendStatus(200)
}

async function notifyAdmin(admin, users, template,
  currentUser, connectionKey, subdomain) {
  await seneca.actAsync({
    role: 'notifications',
    cmd: 'create',
    notification: {
      templateId: template.id,
      addresses: [admin.email],
      variables: {
        firstName: admin.displayName,
        users
      }
    },
    connectionKey,
    subdomain,
    currentUser
  })
}
