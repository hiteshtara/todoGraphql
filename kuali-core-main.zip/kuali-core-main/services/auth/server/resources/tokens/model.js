/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import mongoose from 'shared/mongoose'
import { defaultLogger } from 'shared/logging'

let tokenSchema = mongoose.Schema(
  {
    // mysql primary key
    snowflakeId: {
      type: String,
      unique: true,
      sparse: true,
      index: true
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    impersonatedBy: {
      type: {
        displayName: String,
        id: String
      }
    },
    expiresAt: {
      type: Date,
      required: true
    },
    type: {
      type: String,
      required: true,
      enum: ['user', 'apiKey'],
      default: 'user'
    },
    name: {
      type: String,
      trim: true
    }
  },
  {
    schemaName: 'Token',
    timestamps: true,
    versionKey: false
  }
)

const modelMap = {}
function getTokenModel(connection) {
  let Token = modelMap[connection]
  if (!Token) {
    Token = connection.model('Token', tokenSchema)
    Token.on('index', err => {
      /* istanbul ignore else */
      if (err) {
        defaultLogger.fatal('Couldn\'t create all indexes on Token', err)
      }
    })
    modelMap[connection] = Token
  }
  return Token
}

export { getTokenModel }
