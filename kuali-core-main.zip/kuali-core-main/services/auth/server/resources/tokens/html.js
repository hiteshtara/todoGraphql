/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint-disable max-len */
export const userExpiredTokensHTML = `
<br>
Expired API Key(s):
<br>
<ul>
  $tokens
</ul> `

export const userExpiredTokenHTML = `
<li style="-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">
  <strong>$keyName</strong> (expired since $expiredDate)
</li>`

export const userExpiringTokensHTML = `
<br>
API Key(s) Expiring Soon:
<br>
<ul>
  $tokens
</ul>`

export const userExpiringTokenHTML = `
<li style="-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">
  <strong>$keyName</strong> (expiring $expiringDate)
</li>`

export const adminUserExpiredTokensHTML = `
<br>
<strong>$username</strong> has the following API keys that are expired:
<br>
<ul>
  $expiredTokens
</ul>`

export const adminUserExpiringTokensHTML = `
<br>
<strong>$username</strong> has the following API keys that are expiring soon:
<br>
<ul>
  $expiringTokens
</ul>`

export const adminEmailUserHTML = `
<tr>
  <td align="left" valign="top" class="eventBlockHeading" style="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-bottom: 5px;">
    <h2 style="font-size: 14px !important;padding-top: 5px;line-height: 22px !important;font-weight: 300;margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;color: #606060;text-align: left;">
      $expiredTokens
      $expiringTokens
    </h2><br>
  </td>
</tr>
<tr style="text-align:center;">
  <td style="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">
    <a style="background-color: #558DD8;color: white;text-decoration: none;padding: 10px 30px;border-radius: 2px;box-shadow: 0px 2px 0px #3F73B9;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;" href="$apiKeysUrl">
      Go To $username's API Keys
    </a>
  </td>
</tr>`
