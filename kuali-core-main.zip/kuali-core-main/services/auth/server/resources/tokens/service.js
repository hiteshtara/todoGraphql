/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import { UnauthorizedError } from 'shared/errors'
import { create, validate, fetch, revoke, fetchExpired } from './utils'

export default function tokens() {
  this.add('role:token,cmd:verify', (msg, respond) => {
    (async function() {
      try {
        let { userId, impersonatedBy } = await validate(
          msg.token,
          msg.secret,
          msg.query,
          msg.connectionKey
        )
        respond(null, { id: userId, impersonatedBy })
      } catch (ex) {
        respond(ex)
      }
    })()
  })

  this.add('role:token,cmd:sign', (msg, respond) => {
    (async function() {
      try {
        let user = await seneca.actAsync({
          role: 'users',
          cmd: 'load',
          id: msg.id,
          connectionKey: msg.connectionKey
        })

        let userId = user && (user.newId || user.id)

        msg.options = { ...msg.options, connectionKey: msg.connectionKey }
        let token = await create(userId, msg.secret, msg.options)
        respond(null, { token })
      } catch (ex) {
        respond(ex)
      }
    })()
  })

  this.add('role:token,cmd:sign', function(msg, respond) {
    if (!msg.id) return respond(new Error('id is required'))
    if (!msg.secret) return respond(new Error('secret is required'))
    return this.prior(msg, respond)
  })

  this.add('role:token,cmd:sign,type:apiKey', (msg, respond) => {
    (async function() {
      try {
        let user = await seneca.actAsync({
          role: 'users',
          cmd: 'load',
          id: msg.id,
          connectionKey: msg.connectionKey
        })

        let userId = user && (user.newId || user.id)

        if (
          msg.currentUser.id.toString() !== user.id.toString() &&
          msg.currentUser.role !== 'admin'
        ) {
          throw new UnauthorizedError()
        }

        msg.options = { ...msg.options, connectionKey: msg.connectionKey }
        let token = await create(userId, msg.secret, {
          full: true,
          type: 'apiKey',
          ...msg.options
        })
        respond(null, token)
      } catch (ex) {
        respond(ex)
      }
    })()
  })

  this.add('role:token,cmd:sign,type:apiKey', function(msg, respond) {
    if (!msg.id) return respond(new Error('id is required'))
    if (!msg.secret) return respond(new Error('secret is required'))
    return this.prior(msg, respond)
  })

  this.add('role:token,cmd:fetch', (msg, respond) => {
    (async function() {
      try {
        let user = await seneca.actAsync({
          role: 'users',
          cmd: 'load',
          id: msg.user,
          connectionKey: msg.connectionKey
        })

        let userId = user && (user.newId || user.id)

        const userTokens = await fetch(userId, msg.type, msg.connectionKey)
        respond(null, userTokens)
      } catch (ex) {
        respond(ex)
      }
    })()
  })

  this.add('role:token,cmd:fetch', function(msg, respond) {
    if (!msg.user) return respond(new Error('user is required'))
    return this.prior(msg, respond)
  })

  this.add(
    'role:token,cmd:fetch,expired:expired,type:apiKey',
    (msg, respond) => {
      (async function() {
        try {
          const userTokens = await fetchExpired(
            msg.type,
            msg.startDate,
            msg.endDate,
            msg.connectionKey
          )
          respond(null, userTokens)
        } catch (ex) {
          respond(ex)
        }
      })()
    }
  )

  this.add('role:token,cmd:revoke', (msg, respond) => {
    (async function() {
      try {
        const result = await revoke(msg.id, msg.currentUser, msg.connectionKey)
        respond(null, { success: result })
      } catch (ex) {
        respond(ex)
      }
    })()
  })

  this.add('role:token,cmd:revoke', function(msg, respond) {
    if (!msg.id) return respond(new Error('id is required'))
    return this.prior(msg, respond)
  })
}
