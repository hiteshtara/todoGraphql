/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import jwt from 'jsonwebtoken'
import moment from 'moment'
import seneca from 'shared/seneca'
import { getConnection } from 'shared/mongoose/pool'
import { assign } from 'lodash'
import { UnauthorizedError } from 'shared/errors'

import { getTokenModel } from './model'

const issuer = 'kuali.co'
const defaultExpiresIn = moment.duration(2, 'weeks')

const isObjectId = new RegExp('^[0-9a-fA-F]{24}$')

export async function create(userId, secret, opts = {}) {
  if (!userId) throw new Error('userId is required')
  if (!isObjectId.test(userId)) throw new Error('valid userId is required')
  if (!secret) throw new Error('secret is required')
  const { connectionKey } = opts
  if (!connectionKey) throw new Error('connectionKey is required')
  const Token = getTokenModel(getConnection(connectionKey))

  let { type, name, impersonatedBy } = opts
  let expiresAt = opts.expiresAt
    ? moment(opts.expiresAt)
    : moment().add(defaultExpiresIn)

  let data = {
    userId,
    expiresAt: expiresAt.toDate()
  }
  if (type) data.type = type
  if (name) data.name = name
  if (impersonatedBy) data.impersonatedBy = impersonatedBy

  let token = new Token(data)
  await token.save()

  let payload = {
    id: token.id,
    iss: issuer,
    exp: expiresAt.unix(),
    iat: moment().unix()
  }

  const signedToken = jwt.sign(payload, secret)
  if (opts.full === true) {
    return { token, value: signedToken }
  }
  return signedToken
}

export async function validate(token, secret, query, connectionKey) {
  if (!connectionKey) throw new Error('connectionKey is required')
  const Token = getTokenModel(getConnection(connectionKey))
  let opts = {
    issuer
  }

  let payload = jwt.verify(token, secret, opts)
  query = Object.assign({}, query, idCondition(payload.id))
  let result = await Token.findOne(query)
  if (result) {
    return {
      userId: result.userId,
      impersonatedBy: result.impersonatedBy
    }
  }
  throw { name: 'JsonWebTokenError', message: 'invalid token' }
}

function idCondition(id) {
  // If id is all numbers and 19 chars long, then its a snowflakeId
  const snowflakeId = new RegExp(/^\d{19}$/)
  if (snowflakeId.test(id)) {
    return { snowflakeId: id }
  }
  return { _id: id }
}

export async function revoke(tokenId, currentUser, connectionKey) {
  if (!connectionKey) throw new Error('connectionKey is required')
  const Token = getTokenModel(getConnection(connectionKey))
  try {
    const token = await Token.findOne(idCondition(tokenId))
    if (
      token !== null &&
      token.userId.toString() !== currentUser.id.toString() &&
      currentUser.role !== 'admin'
    ) {
      throw new UnauthorizedError()
    }
    await Token.findOneAndRemove(idCondition(tokenId))
    return true
  } catch (e) {
    if (e.name === 'CastError') return true
    throw e
  }
}

export async function revokeUser(userId, connectionKey) {
  if (!connectionKey) throw new Error('connectionKey is required')
  const Token = getTokenModel(getConnection(connectionKey))
  let tokens
  try {
    tokens = await Token.find({ userId, type: 'user' })
  } catch (err) {
    return err
  }

  let success = true

  tokens.forEach(async token => {
    try {
      await Token.findOneAndRemove({ _id: token.id })
    } catch (err) {
      success = err
      return false
    }
    return null
  })
  return success
}

export async function fetch(userId, type, connectionKey) {
  if (!userId) throw new Error('userId is required')
  if (!isObjectId.test(userId)) throw new Error('valid userId is required')
  if (!connectionKey) throw new Error('connectionKey is required')
  const Token = getTokenModel(getConnection(connectionKey))
  const query = { userId }
  if (type) query.type = type

  return await Token.find(query)
}

export async function fetchExpired(type, startDate, endDate, connectionKey) {
  if (!connectionKey) throw new Error('connectionKey is required')
  const Token = getTokenModel(getConnection(connectionKey))
  startDate = startDate || moment().subtract(60, 'days')
  endDate = endDate || new Date()
  const query = {
    $and: [{ expiresAt: { $gt: startDate } }, { expiresAt: { $lt: endDate } }]
  }
  query.type = type

  return await Token.find(query)
}

export function tokenize(provider) {
  return async (req, res, next) => {
    const { connectionKey } = res.locals
    try {
      if (!connectionKey) throw new Error('connectionKey is required')
      if (!req.user.approved) {
        const error = new Error()
        error.name = 'Unapproved'
        throw error
      }
      let value = await seneca.actAsync({
        role: 'institutions',
        cmd: 'getSecret',
        data: { subdomain: req.institution.subdomain },
        connectionKey
      })

      // if newId is present, then id is a snowflakeId
      // and needs to be replaced with the ObjectId in newId
      let id = req.user && (req.user.newId || req.user.id)

      const options = { connectionKey }
      if (req.impersonatedBy) {
        options.impersonatedBy = req.impersonatedBy
      }
      const cookieOpts = assign({}, config.cookieOpts)

      if (req.institution.signInExpiresWithSession) {
        delete cookieOpts.maxAge
      } else {
        const life = req.institution.signInExpiresIn
          ? moment.duration(req.institution.signInExpiresIn, 'seconds')
          : defaultExpiresIn
        options.expiresAt = moment().add(life)
        cookieOpts.maxAge = life.asSeconds()
      }
      let token = await create(id, value.secret, options)
      req.user.token = token
      res.cookie('authToken', token, cookieOpts)
      req.log.audit(
        {
          userId: id,
          provider,
          options,
          institution: {
            id: req.institution.id,
            subdomain: req.institution.subdomain
          }
        },
        'Successful Login'
      )
      next()
    } catch (err) {
      next(err)
    }
  }
}
