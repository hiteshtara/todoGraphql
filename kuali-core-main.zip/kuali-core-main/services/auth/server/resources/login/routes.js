/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import authenticate from 'shared/middleware/authenticate'
import institutionHasFeature from 'shared/middleware/institution-has-feature'
import {
  postAuthRedirect,
  postLogoutRedirect
} from 'services/auth/server/utils/redirect'
import { BadRequestError, InternalServerError } from 'shared/errors'
import { defaultLogger as logger } from 'shared/logging'
import qs from 'querystring'
import { assign } from 'lodash'
import {
  revokeUser,
  tokenize
} from 'services/auth/server/resources/tokens/utils'
import * as analytics from 'shared/analytics'

export default function(passports, router, samlMeta, samlMeta2) {
  const passportAuth = passports.middleware.bind(passports, 'authenticate')
  router.get('/auth', authRedirect)
  router.get(
    '/auth/signout',
    authenticate({ allowAnonymous: true, useCookie: true }),
    signout,
    revokeCurrentUser,
    postLogoutRedirect
  )
  router.post('/api/v1/auth/authenticate', basicLogin(passportAuth))
  router.post(
    '/api/v1/auth/impersonate',
    institutionHasFeature('impersonation'),
    authenticate({ role: 'admin' }),
    revokeCurrentUser,
    impersonate
  )
  router.post(
    '/auth/saml/consume',
    decrlfSAMLResponse,
    passportAuth('saml', { session: false }),
    tokenize('saml'),
    postAuthRedirect
  )
  router.get(
    '/auth/saml',
    prepareRequest,
    passportAuth('saml', { session: false })
  )
  router.get('/auth/saml/meta', async (req, res) =>
    res.status(200).type('xml').send(await samlMeta)
  )
  router.get('/auth/saml/meta2', async (req, res) =>
    res.status(200).type('xml').send(await samlMeta2)
  )
  router.get(
    '/auth/cas',
    passportAuth('cas', { session: false }),
    tokenize('cas'),
    postAuthRedirect
  )
  router.post(
    '/api/v1/auth/ldap',
    passportAuth('ldap', { session: false }),
    tokenize('ldap'),
    (req, res) => {
      res.send({ token: req.user.token })
    }
  )
  return router
}

// Some IDPs return SAMLResponse xml with CRLFs in it which can
// break signature validation. This function decodes the SAMLResponse
// replaces all CRLFs in the response with LFs, reencodes the result
// and puts the deCRLFed response back into the request body
// for processing by the Passport Saml strategy
function decrlfSAMLResponse(req, res, next) {
  let response = req.body.SAMLResponse
  if (!response) {
    return next()
  }
  req.log.debug('RAW SAML RESPONSE', response)
  let decodedResponse = new Buffer(response, 'base64').toString('utf8')
  // BU-CUSTOMIZATION: Removing newline characters from the saml response has the opposite
  // effect as intended when it comes to our shibboleth IDP saml response. This is because
  // It comes with a newline character already encrypted in the signature value, so you 
  // cannot remove it else the xml-crypto.js comparison functionality will fail.
  if(/shib(\-test)?\.bu\.edu/.test(decodedResponse)) {
    return next(); 
  }
  let decrlfedResponse = decodedResponse.replace(/\r\n/g, '\n')
  let reencodedResponse = new Buffer(decrlfedResponse).toString('base64')
  req.body.SAMLResponse = reencodedResponse
  return next()
}

function authRedirect({ institution, query }, res) {
  clearCookies(res)
  analytics.track({ id: 'anonymous' }, 'Signin start', {
    provider: institution.provider,
    subdomain: institution.subdomain,
    institution: institution.name
  })
  const _query = qs.encode(query) && `?${qs.encode(query)}`
  if (institution && institution.provider === 'saml') {
    res.redirect(`/auth/saml${_query}`)
  } else if (institution && institution.provider === 'cas') {
    res.redirect(`/auth/cas${_query}`)
  } else if (institution && institution.provider === 'ldap') {
    const ldapParam = _query ? '&provider=ldap' : '?provider=ldap'
    res.redirect(`/auth/kuali${_query}${ldapParam}`)
  } else {
    res.redirect(`/auth/kuali${_query}`)
  }
}

async function signout(req, res, next) {
  clearCookies(res)
  analytics.track(req.user, 'Signout')
  next()
}

async function revokeCurrentUser(req, res, next) {
  if (req.user) {
    await revokeUser(req.user.newId || req.user.id, res.locals.connectionKey)
  }
  next()
}

function clearCookies(res) {
  // clearCookie doesn't actually remove the cookie
  // this sets the cookie to empty string and expires it immediately
  const cookieOpts = assign({}, config.cookieOpts)
  cookieOpts.maxAge = 0
  res.cookie('authToken', '', cookieOpts)
  res.cookie('samlSubdomain', '', cookieOpts)
  res.cookie('samlReturnTo', '', cookieOpts)
  res.cookie('idp', '', cookieOpts)
}

function basicLogin(passportAuth) {
  return function _basicLogin(req, res, next) {
    passportAuth('basic', { session: false }, (err, user) => {
      if (err) {
        res.sendStatus(500)
      } else if (user) {
        req.user = user
        tokenize('kuali')(req, res, error => {
          if (error) {
            if (req.log) {
              req.log.error(error)
            }
            if (error.name === 'Unapproved') {
              return res
                .status(401)
                .send({ redirect: '/auth/kuali/#/needsApproval' })
            }
            return res.status(500).send(error)
          }
          analytics.identify(user, req.institution)
          analytics.track(user, 'Signin success', {
            provider: req.institution.provider,
            subdomain: req.institution.subdomain,
            institution: req.institution.name
          })
          return res.send({ token: req.user.token })
        })
      } else {
        res.sendStatus(401)
      }
    })(req, res, next)
  }
}

function prepareRequest(req, res, next) {
  logger.debug(
    `
    prepareRequest has req.institution = ${JSON.stringify(req.institution)}
  `
  )
  const subdomain = req.institution.subdomain

  const cookieOpts = assign({}, config.cookieOpts)
  cookieOpts.maxAge = 1000 * 60 * 2 // 2 minutes
  res.cookie('samlSubdomain', subdomain, cookieOpts)
  logger.debug(`Saved ${subdomain} to the samlSubdomain cookie`)
  res.cookie('idp', req.locals.idp.name, cookieOpts)
  logger.debug(`Saved ${req.locals.idp.name} to the idp cookie`)

  const returnTo = req.query.return_to
  if (returnTo) {
    res.cookie('samlReturnTo', returnTo, cookieOpts)
    logger.debug(`Saved ${returnTo} to the samlReturnTo cookie`)
  }

  next()
}

function impersonate(req, res, next) {
  let { body } = req, realUser = req.user
  if (realUser.impersonatedBy) {
    next(new BadRequestError('Already impersonating'))
  } else if (!body.user) {
    next(new BadRequestError('User required to impersonate'))
  } else {
    req.user = body.user
    req.impersonatedBy = {
      id: realUser.newId || realUser.id,
      displayName: realUser.displayName
    }
    tokenize('impersonating')(req, res, error => {
      if (error) {
        req.log.error(error)
        return next(new InternalServerError(error))
      }
      return res.send({ token: req.user.token })
    })
  }
}
