/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { BasicStrategy } from 'passport-http'
import seneca from 'shared/seneca'


export default new BasicStrategy({
  passReqToCallback: true
  }, (req, username, password, done) => {
  (async function() {
    try {
      password = decodeURIComponent(password)
      let user = await seneca.actAsync(
        { role: 'users', cmd: 'authenticate', data: { username, password },
          connectionKey: req.locals.connectionKey }
      )
      if (!user) {
        return done(null, null, { message: 'Authentication failed' })
      }
      return done(null, user)
    } catch (ex) {
      return done(ex)
    }
  }())
})
