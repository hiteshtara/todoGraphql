/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import { Strategy } from 'passport-cas'

import { fetchUser, saveUser, maybeUpdateUser,
  isApproved, notifyNeedsApproval } from './utils/saml-helpers'

export default function getCasStrategy(institution) {
  const version = institution.casVersion
  return new Strategy({
    version: version === 'CAS2.0' ? 'CAS3.0' : version,
    ssoBaseURL: institution.casServiceUrl,
    serverBaseURL: config.auth.casCallbackUrl ||
      `https://${institution.subdomain}${config.rootDomain}`,
    validateURL: version === 'CAS2.0' ? '/serviceValidate' : null,
    passReqToCallback: true
  }, async (req, data, done) => {
    try {
      const { connectionKey } = req.locals
      if (version === 'CAS3.0') {
        // figure out how to handle this response
        return done(new Error('Not Implemented'))
      } else if (version === 'CAS2.0') {
        if (!data || !data.user) {
          return new done(new Error('Error authenticating'))
        }
        data = data.user
      } else {
        // no-op keep data as a string
      }
      let user = await fetchUser({ uid: data }, connectionKey)
          || await fetchUser({ lowerUsername: data.toLowerCase() },
            connectionKey)
          || await fetchUser({ username: data }, connectionKey)
      if (!user) {
        let approved = isApproved({ institution }, data)
        user = await saveUser({ uid: data, username: data, approved },
          connectionKey)
        if (!approved) {
          await notifyNeedsApproval(req, user)
        }
      }
      user = await maybeUpdateUser(user, data, { uid: data }, connectionKey)
      return done(null, user)
    } catch (ex) {
      return done(ex)
    }
  })
}
