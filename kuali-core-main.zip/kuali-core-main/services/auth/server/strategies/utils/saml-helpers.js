/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import { every, some, map, first, get } from 'lodash'
import getBaseUrl from 'shared/base-url'

export async function fetchUser(options, connectionKey) {
  if (!connectionKey) {
    throw new Error('connectionKey required')
  }
  const users = await seneca.actAsync({
    role: 'users',
    cmd: 'list',
    options,
    connectionKey
  })
  return users[0]
}

export async function saveUser(data, connectionKey) {
  if (!connectionKey) {
    throw new Error('connectionKey required')
  }
  return seneca.actAsync({
    role: 'users',
    currentUser: { id: 'kuali-system' },
    cmd: 'save',
    data,
    connectionKey
  })
}

// Would have loved to do this:
// export async function maybeUpdateUser(user, { username, ...attrs }) {
// What do you guys think? Should we turn on support for the spread and
// rest (...) operators?
export async function maybeUpdateUser(user, username, attrs, connectionKey) {
  if (!connectionKey) {
    throw new Error('connectionKey required')
  }
  let shouldUpdate = false
  if (
    typeof user.username !== 'string' ||
    user.username.toLowerCase() !== username.toLowerCase()
  ) {
    user.username = username
    shouldUpdate = true
  }
  for (let key in attrs) {
    if (!user[key] && attrs[key]) {
      user[key] = attrs[key]
      shouldUpdate = true
    }
  }
  if (shouldUpdate) {
    await saveUser(user, connectionKey)
  }
  return user
}

export function getAttrs(eppn, attributes, institution) {
  const uid = attributes[eppn]
  const stripDomain = get(institution, 'features.ssoDisableStripDomain')
  return {
    uid,
    email: (attributes.mail ||
      attributes.officialMail ||
      attributes.email ||
      attributes['E-Mail-Address'] ||
      attributes.mail ||
      uid)
      .toLowerCase(),
    username: stripDomain ? uid : uid.split('@')[0],
    firstName: attributes.givenName || attributes['Given Name'],
    lastName: attributes.sn || attributes.surname || attributes.Surname,
    name: attributes.displayName
  }
}

export function ensure(statement, msg, items) {
  if (!statement) {
    throw new SamlConfigError(msg, items)
  }
}

export class SamlConfigError extends Error {
  constructor(message, items) {
    super(message)
    this.name = 'SamlConfigError'
    this.message = message
    this.items = items
  }
}

export function isApproved({ institution }, attributes) {
  if (institution.approval === 'auto') {
    return true
  }
  if (institution.approval === 'scopedAuto') {
    const { approvalScope } = institution
    let approved = every(
      map(Object.keys(approvalScope), attr => {
        return some(approvalScope[attr], val => {
          return attributes[attr] === val
        })
      })
    )
    return approved
  }
  //institution.approval === 'manual'
  return false
}

export async function notifyNeedsApproval(req, user) {
  const { connectionKey, subdomain } = req.locals
  const baseUrl = getBaseUrl(req)
  const adminResult = await seneca.actAsync({
    role: 'users',
    cmd: 'query',
    query: {
      role: 'admin',
      email: /@/
    },
    connectionKey
  })
  const admins = adminResult.result
  const templates = await seneca.actAsync({
    role: 'notification-templates',
    cmd: 'list',
    query: {
      displayName: 'user-approval-notify-admin'
    },
    connectionKey
  })
  const template = first(templates)
  await Promise.all(
    map(admins, async admin => {
      await seneca.actAsync({
        role: 'notifications',
        cmd: 'create',
        notification: {
          templateId: template.id,
          addresses: [admin.email],
          variables: {
            firstName: admin.displayName,
            displayName: user.displayName,
            userUrl: `${baseUrl}/users/#/${user.id}/details/view`
          }
        },
        connectionKey,
        subdomain
      })
    })
  )
}
