/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import LdapStrategy from 'passport-ldapauth'
import { assign } from 'lodash'
import {
  fetchUser,
  saveUser,
  ensure,
  getAttrs,
  maybeUpdateUser,
  isApproved,
  notifyNeedsApproval
} from 'services/auth/server/strategies/utils/saml-helpers'
import { defaultLogger as logger } from 'shared/logging'

export function getLdapStrategy(institution) {
  return new LdapStrategy(
    {
      server: institution.ldapConfig,
      passReqToCallback: true,
      handleErrorsAsFailures: true,
      failureErrorCallback: /* istanbul ignore next */ e => logger.error(e)
    },
    async (req, ldapUser, done) => {
      try {
        const user = await getUser(institution, ldapUser, req)
        done(null, user)
      } catch (ex) {
        req.log.error(ex)
        done(ex)
      }
    }
  )
}

async function getUser(institution, attributes, req) {
  const { connectionKey } = req.locals
  const eppn = institution.ldapUserIdentifier
  const u = getAttrs(eppn, attributes)
  const { firstName, lastName, uid, username, name, email } = u
  ensure(uid, 'The returned LDAP user had no uid')
  ensure(username, 'The returned LDAP user had no username')
  ensure(email, 'The returned LDAP user had no email')
  const user =
    (await fetchUser({ uid }, connectionKey)) ||
    (await fetchUser(
      { lowerUsername: username.toLowerCase() },
      connectionKey
    )) ||
    (await fetchUser({ email }, connectionKey))
  if (!user) {
    const approved = isApproved({ institution }, attributes)
    const savedUser = await saveUser(assign(u, { approved }), connectionKey)
    if (!approved) {
      await notifyNeedsApproval(req, savedUser, connectionKey)
    }
    return savedUser
  }
  return await maybeUpdateUser(
    user,
    username,
    {
      firstName,
      lastName,
      email,
      name
    },
    connectionKey
  )
}
