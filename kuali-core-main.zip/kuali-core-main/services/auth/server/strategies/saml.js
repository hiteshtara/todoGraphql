/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import { assign, last } from 'lodash'
import { Strategy, SAML } from 'passport-saml'
import seneca from 'shared/seneca'
import config from 'config'
import xml2js from 'xml2js'
import { defaultLogger as logger } from 'shared/logging'

import {
  fetchUser,
  saveUser,
  maybeUpdateUser,
  ensure,
  getAttrs,
  isApproved,
  notifyNeedsApproval
} from './utils/saml-helpers'

Promise.promisifyAll(xml2js)

export function getSamlStrategy(strategy, institution) {
  return new Strategy(strategy, async (req, attributes, done) => {
    try {
      const assertion = await parseAssertionXml(req, attributes)

      req.log.debug('SAML PARSED ATTRIBUTES', assertion)
      req.log.debug('SAML INSTITUTION', institution)

      const user = await getUser(req, assertion)
      return done(null, user)
    } catch (err) {
      return done(err)
    }
  })
}

// BU-CUSTOMIZATION: Replacing hard-coded issuer with mongodb field stored in bu institution document
export function getSamlOptions(institution, incommonMeta, privateKey) {
  let strategy = {
    callbackUrl: config.auth.samlCallbackUrl,
    privateCert: privateKey,
    decryptionPvk: privateKey,
    disableRequestedAuthnContext: true,
    identifierFormat: null,
    issuer: institution.issuer,
    cert: incommonMeta.cert,
    entryPoint: incommonMeta.entryPoint,
    forceAuthn: institution.forceAuthn,
    authnRequestBinding: 'HTTP-Artifact',
    acceptedClockSkewMs: config.auth.acceptedClockSkewMs,
    signatureAlgorithm: 'sha512',
    passReqToCallback: true
  }
  let cleanStrategy = assign({}, strategy)
  delete cleanStrategy.privateCert
  delete cleanStrategy.decryptionPvk

  logger.debug('SAML STRATEGY', cleanStrategy)
  return strategy
}

export async function tryConfigurations(req, institution) {
  let samlKeys = config.get('auth.samlKeys')
  if (!req.body || !req.body.SAMLResponse) {
    return last(Object.keys(samlKeys))
  }
  let incommonMeta
  try {
    incommonMeta = await seneca.actAsync({
      role: 'incommon',
      cmd: 'load',
      idp: req.locals.idp.idp,
      connectionKey: req.locals.connectionKey
    })
    if (!incommonMeta) {
      throw new Error('no incommon')
    }
  } catch (ex) {
    return null //other paths handle a missing incommon
  }
  let samlKey
  await Promise.all(
    Object.keys(samlKeys).map(async key => {
      let success = await testConfiguration(
        req,
        institution,
        incommonMeta,
        samlKeys[key],
        key
      )
      if (success) {
        samlKey = key
      }
    })
  )
  return samlKey
}

async function testConfiguration(
  req,
  institution,
  incommonMeta,
  samlKey,
  version
) {
  let samlOptions = getSamlOptions(institution, incommonMeta, samlKey)
  let saml = new SAML(samlOptions)
  try {
    let profile = await validatePostResponse(saml, req)
    req.log.debug(`profile is ${JSON.stringify(profile)}`)
  } catch (ex) {
    req.log.error(
      ex,
      `auth failed for ${institution.subdomain} ${institution.provider} ${version}` //eslint-disable-line max-len
    )
    return false
  }
  return true
}

function validatePostResponse(saml, req) {
  return new Promise((resolve, reject) => {
    saml.validatePostResponse(req.body, (err, profile) => {
      if (err) {
        return reject(err)
      }
      return resolve(profile)
    })
  })
}

async function getUser(req, attributes) {
  const eppn = req.locals.idp.eppn
  const { connectionKey } = req.locals
  const msg =
    `The eppn you specified (${eppn}) was not found in the ` +
    `provided SAML attributes:`
  ensure(eppn in attributes, msg, Object.keys(attributes))
  const u = getAttrs(eppn, attributes, req.institution)
  const { firstName, lastName, uid, username, name, email } = u
  ensure(uid, 'The returned SAML user had no uid')
  ensure(username, 'The returned SAML user had no username')
  ensure(email, 'The returned SAML user had no email')
  const user =
    (await fetchUser({ uid }, connectionKey)) ||
    (await fetchUser(
      { lowerUsername: username.toLowerCase() },
      connectionKey
    )) ||
    (await fetchUser({ email }, connectionKey))
  if (!user) {
    const approved = isApproved(req, attributes)
    const savedUser = await saveUser(assign(u, { approved }), connectionKey)
    if (!approved) {
      await notifyNeedsApproval(req, savedUser)
    }
    return savedUser
  }
  if (user.ssoId) {
    req.log.debug('SAML USER LOOKUP', uid, user)
    /* eslint quotes: 0, max-lengh: 0 */
    ensure(
      user.ssoId == uid,
      `A user was found that matched your username ` +
        `and/or email but the ${eppn} field did not match`
    )
  }
  return await maybeUpdateUser(
    user,
    username,
    {
      firstName,
      lastName,
      email,
      name
    },
    connectionKey
  )
}

export async function parseAssertionXml(req, attributes) {
  const assertionXml = attributes.getAssertionXml()
  req.log.debug('SAML ATTRIBUTES', attributes)
  req.log.debug('SAML ASSERTION XML', assertionXml)

  const assertion = await xml2js.parseStringAsync(assertionXml, {
    // Strips the xml tag prefixes such as 'saml2:Assertion'
    tagNameProcessors: [
      name => {
        if (name.indexOf(':') < 0) {
          return name
        }
        return name.split(':').slice(1).join(':')
      }
    ]
  })
  req.log.debug('SAML ASSERTION', assertion)
  const assertionAttrs = assertion.Assertion.AttributeStatement[0].Attribute

  // Keys all of the attributes by friendlyName instead of name
  return assertionAttrs.reduce((attrs, { $, AttributeValue }) => {
    attrs[$.FriendlyName] = typeof AttributeValue[0] === 'string'
      ? AttributeValue[0]
      : AttributeValue[0]._
    return attrs
  }, Object.assign(attributes))
}
