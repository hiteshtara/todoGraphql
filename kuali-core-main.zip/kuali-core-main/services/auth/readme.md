# Core Auth

Auth is responsible for authentication to Kuali apps that are integration with
Kuali Core.

We intergrate with several different SSO implementations and authentication
protocols.

* SAML
* Shibboleth
* ADFS
* CAS
* LDAP
* Basic Authentication
