/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import { mount } from 'enzyme'
import React from 'react'
import { IntlProvider } from 'react-intl'
import { errors } from '../app/messages'

import NeedsApproval from '../app/needs-approval'

const getHeader = (elem) => elem.find('[data-test="alert-header"]')
const getDescription = (elem) => elem.find('[data-test="alert-desc"]')

describe('Auth - <NeedsApproval />', () => {

  it('renders with text', () => {
    const test = mount(
      <IntlProvider locale="en" messages={{}}>
        <NeedsApproval />
      </IntlProvider>
    )
    const header = getHeader(test)
    const description = getDescription(test)
    expect(header).to.have.length(1)
    expect(description).to.have.length(1)
    expect(header.text()).to.be.equal(errors.unapprovedTitle.defaultMessage)
    expect(description.text()).to.have.equal(errors.unapproved.defaultMessage)
  })

})
