/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { delay as sleep } from 'bluebird'
import { expect } from 'chai'
import { mount } from 'enzyme'
import nock from 'nock'
import React from 'react'
import { IntlProvider } from 'react-intl'

import SelectIdp from '../app/select-idp'

describe('Auth - <SelectIdp />', () => {
  beforeEach(async () => {
    nock.cleanAll()
    nock('http://localhost')
      .get('/api/v1/institution')
      .times(Infinity)
      .reply(200, {
        name: 'Fooniversity',
        idps: [{ name: 'Idp One' }, { name: 'Idp Two' }]
      })
  })

  it('renders with text', async () => {
    const test = mount(
      <IntlProvider locale="en" messages={{}}>
        <SelectIdp />
      </IntlProvider>
    )

    await sleep(10)
    expect(test.text()).to.have.match(/Idp One/)
  })
})
