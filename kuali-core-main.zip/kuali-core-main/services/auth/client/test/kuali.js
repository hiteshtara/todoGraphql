/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { expect } from 'chai'
import { shallow } from 'enzyme'
import nock from 'nock'
import React from 'react'
import sinon from 'sinon'
import jsdom from 'jsdom'
import { delay as sleep } from 'bluebird'

import { _Main as Kuali } from '../app/kuali'

const ctx = { intl: { formatMessage: msg => msg.defaultMessage } }

function style(name) {
  return `_services_auth_client_app_style__${name}`
}

function write(el, sel, value) {
  el.find(sel).simulate('change', { target: { value } })
}

describe('Auth - <Kuali/>', () => {
  beforeEach(async () => {
    nock.cleanAll()
    nock('http://localhost')
      .get('/api/v1/institution')
      .times(Infinity)
      .reply(200, {
        name: 'Fooniversity',
        validRedirectHosts: ['http://fooniversity.kuali.co']
      })
  })

  after(() => {
    nock.cleanAll()
  })

  it('can input username and password', () => {
    const wrapper = shallow(<Kuali {...ctx} />)
    write(wrapper, '[data-test="username"]', 'Bubba')
    write(wrapper, '[data-test="password"]', 'Jones')
    assert.equal(wrapper.state('username'), 'Bubba')
    assert.equal(wrapper.state('password'), 'Jones')
  })

  it('Pressing Signin submits a login', () => {
    const oldLogin = Kuali.prototype.login
    Kuali.prototype.login = sinon.spy()
    const wrapper = shallow(<Kuali {...ctx} />)
    write(wrapper, '[data-test="username"]', 'Bubba')
    write(wrapper, '[data-test="password"]', 'Jones')
    wrapper.find('[data-test="login"]').simulate('click')
    assert(Kuali.prototype.login.calledOnce)
    Kuali.prototype.login = oldLogin
  })

  it('Pressing Enter when in the password submits a login', () => {
    const oldLogin = Kuali.prototype.login
    Kuali.prototype.login = sinon.spy()
    const wrapper = shallow(<Kuali {...ctx} />)
    write(wrapper, '[data-test="username"]', 'Bubba')
    write(wrapper, '[data-test="password"]', 'Jones')
    wrapper.find('[data-test="password"]').simulate('keydown', { keyCode: 13 })
    assert(Kuali.prototype.login.calledOnce)
    Kuali.prototype.login = oldLogin
  })

  it('Pressing something else in the password does not submit login', () => {
    const oldLogin = Kuali.prototype.login
    Kuali.prototype.login = sinon.spy()
    const wrapper = shallow(<Kuali {...ctx} />)
    write(wrapper, '[data-test="username"]', 'Bubba')
    write(wrapper, '[data-test="password"]', 'Jones')
    wrapper.find('[data-test="password"]').simulate('keydown', { keyCode: 65 })
    assert(!Kuali.prototype.login.called)
    Kuali.prototype.login = oldLogin
  })

  it("shows no error when it doesn't exist", () => {
    const wrapper = shallow(<Kuali {...ctx} />)
    assert(
      !wrapper.contains(
        <i className={`fa fa-exclamation-circle ${style('errorIcon')}`} />
      )
    )
  })

  it('shows an error when one exists', () => {
    const wrapper = shallow(<Kuali {...ctx} />)
    wrapper.setState({ errorMessage: 'oh noes!!' })
    assert(
      wrapper.contains(
        <i className={`fa fa-exclamation-circle ${style('errorIcon')}`} />
      )
    )
    assert(wrapper.contains(<span>oh noes!!</span>))
  })

  it('logs in correctly', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(200, {})
    jsdom.changeURL(window, 'http://localhost/foo')
    const component = new Kuali(ctx)
    component.state = {}
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, '/apps/')
  })

  it('logs in via ldap correctly', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/ldap')
      .reply(200, {})
    jsdom.changeURL(window, 'http://localhost/auth/?provider=ldap')
    const component = new Kuali(ctx)
    component.state = {}
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, '/apps/')
  })

  it('correctly parses returnTo and sets it', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(200, {})
    const returnTo = 'http://test.kuali.co/wutup'
    jsdom.changeURL(
      window,
      `http://localhost/auth/?return_to=${encodeURIComponent(returnTo)}`
    )
    const component = new Kuali(ctx)
    component.state = {}
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, returnTo)
    assert(!component.setState.called)
  })

  it('correctly override bad returnTo', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(200, {})
    const returnTo = 'http://yahoo.com'
    jsdom.changeURL(
      window,
      `http://localhost/auth/?return_to=${encodeURIComponent(returnTo)}`
    )
    const component = new Kuali(ctx)
    component.state = {
      institution: { validRedirectHosts: ['google.com'] }
    }
    await sleep(100)
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, returnTo)
    assert(!component.setState.called)
  })

  it('correctly tests validRedirectHosts', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(200, {})
    const returnTo = 'http://yahoo.com'
    jsdom.changeURL(
      window,
      `http://localhost/auth/?return_to=${encodeURIComponent(returnTo)}`
    )
    const component = new Kuali(ctx)
    component.state = {
      institution: { validRedirectHosts: ['yahoo.com'] }
    }
    await sleep(100)
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, returnTo)
    assert(!component.setState.called)
  })

  it('correctly allows hosts from current domain', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(200, {})
    const returnTo = 'http://localhost/test'
    jsdom.changeURL(
      window,
      `http://localhost/auth/?return_to=${encodeURIComponent(returnTo)}`
    )
    const component = new Kuali(ctx)
    component.state = {
      institution: { validRedirectHosts: ['yahoo.com'] }
    }
    await sleep(100)
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, returnTo)
    assert(!component.setState.called)
  })

  it('sets the right error on 401', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(401, {})
    jsdom.changeURL(window, 'http://localhost/foo')
    const component = new Kuali(ctx)
    component.state = {}
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, 'foo')
    assert(component.setState.called)
    assert.equal(
      component.setState.args[0][0].errorMessage,
      'Invalid username/password'
    )
  })

  it('sets the right error on unapproved', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(401, { redirect: '/foo/' })
    jsdom.changeURL(window, 'http://localhost/foo')
    const component = new Kuali(ctx)
    component.state = {}
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // assert.equal(global.window.location, '/foo/')
  })

  it('sets the right error on 500', async () => {
    const loginCall = nock('http://localhost')
      .post('/api/v1/auth/authenticate')
      .reply(500, {})
    jsdom.changeURL(window, 'http://localhost/foo')
    const component = new Kuali(ctx)
    component.state = {}
    component.setState = sinon.spy()
    await component.login()
    loginCall.done()
    // jsdom doesn't like window.location setters
    // expect(global).to.have.deep.property('window.location', 'foo')
    expect(component).to.have.deep.property('setState.calledOnce')
    expect(component).to.have.deep.property(
      'setState.args[0][0].errorMessage',
      'An error occurred'
    )
  })

  it('contains data-test attributes needed for CM smoke tests', async () => {
    const wrapper = shallow(<Kuali {...ctx} />)
    const dataTestAttributes = ['username', 'password', 'login']
    dataTestAttributes.forEach(test => {
      const element = wrapper.find(`[data-test="${test}"]`)
      assert(element.length === 1)
    })
  })
})
