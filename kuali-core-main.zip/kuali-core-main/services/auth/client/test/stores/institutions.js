/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import nock from 'nock'

import { getInstitution } from '../../app/stores/institutions'

describe('Auth - Institutions Store', () => {

  beforeEach(async () => {
    nock.cleanAll()
  })

  it('requests an institution and returns res.data', async () => {
    const instCall = nock('http://localhost')
      .get('/api/v1/institution')
      .reply(200, { name: 'Foo University' })
    const inst = await getInstitution()
    instCall.done()
    assert.equal(inst.name, 'Foo University')
  })

  it('returns a default institution on error', async () => {
    const instCall = nock('http://localhost')
      .get('/api/v1/institution')
      .reply(500, 'OH NOES')
    const inst = await getInstitution()
    instCall.done()
    assert.equal(inst.name, 'Kuali')
  })

})
