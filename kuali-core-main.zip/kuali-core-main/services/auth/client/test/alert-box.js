/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import { shallow } from 'enzyme'
import React from 'react'

import { _AlertBox as AlertBox } from '../app/alert-box'

const intlMock = {
  formatDate() { /* no-op */ },
  formatMessage() { /* no-op */ },
  formatTime() { /* no-op */ },
  formatRelative() { /* no-op */ },
  formatNumber() { /* no-op */ },
  formatPlural() { /* no-op */ },
  formatHTMLMessage() { /* no-op */ },
  now() { /* no-op */ }
}

const getHeader = (elem) => elem.find('[data-test="alert-header"]')
const getDescription = (elem) => elem.find('[data-test="alert-desc"]')

describe('Auth - <AlertBox />', () => {

  it('renders with text', () => {
    const test = shallow(
      <AlertBox
        description="This is my description"
        intl={intlMock}
        title="My Alert"
        type="info"
      />
    )
    const header = getHeader(test)
    const description = getDescription(test)
    expect(header).to.have.length(1)
    expect(description).to.have.length(1)
    expect(header.text()).to.be.equal('My Alert')
    expect(description.text()).to.have.equal('This is my description')
  })

})
