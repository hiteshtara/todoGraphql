/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
import 'kuali-ui/lib/kuali-ui.min.css'
import React, { Component } from 'react'
import { Router, Route, hashHistory } from 'react-router'
import { IntlProvider } from 'react-intl'

import Kuali from './kuali'
import NeedsApproval from './needs-approval'
import SelectIdp from './select-idp'

export default class App extends Component {
  displayName = 'App'

  constructor() {
    super()
  }

  render() {
    return (
      <IntlProvider locale="en" messages={{}}>
        <Router history={hashHistory}>
          <Route component={Kuali} path="/" />
          <Route component={NeedsApproval} path="/needsApproval" />
          <Route component={SelectIdp} path="/idpselection" />
        </Router>
      </IntlProvider>
    )
  }
}
