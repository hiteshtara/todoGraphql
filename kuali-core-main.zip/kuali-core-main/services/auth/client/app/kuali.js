/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { post } from 'axios'
import { assign, get } from 'lodash'
import React, { Component } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import { labels as sharedLabels, errors as sharedErrors } from 'shared/i18n'
import { isValidRedirect } from 'shared/url-helpers'

import styles from './style'
import { placeholders, errors as localErrors } from './messages'
import { getInstitution } from './stores/institutions'

const labels = assign({}, sharedLabels)
const errors = assign({}, sharedErrors, localErrors)

export class _Main extends Component {
  displayName: 'Kuali'

  static propTypes = {
    intl: intlShape.isRequired
  }

  constructor(props) {
    super(props)
    this.state = { institution: {} }
    this.updateUsername = this.updateUsername.bind(this)
    this.updatePassword = this.updatePassword.bind(this)
    this.checkEnter = this.checkEnter.bind(this)
    this.login = this.login.bind(this)
    this.fetchInstitution()
  }

  async fetchInstitution() {
    const institution = await getInstitution()
    this.setState({ institution })
  }

  async login() {
    try {
      if (/provider=ldap/.test(window.location.search)) {
        await post('/api/v1/auth/ldap', {
          username: this.state.username,
          password: this.state.password
        })
      } else {
        await post(
          '/api/v1/auth/authenticate',
          {},
          {
            auth: {
              username: this.state.username,
              password: encodeURIComponent(this.state.password)
            }
          }
        )
      }

      let search = window.location.search
      let match = /return_to=(.*?)($|&)/.exec(search)
      let returnTo = (match && match[1]) || '/apps/'
      returnTo = decodeURIComponent(returnTo)

      if (
        !isValidRedirect(returnTo, {
          institution: this.state.institution,
          host: window.location.host
        })
      ) {
        returnTo = '/apps/'
      }
      window.location = returnTo
    } catch (error) {
      if (get(error, 'response.status') === 401) {
        let redirect = get(error, 'response.data.redirect')
        if (redirect) {
          window.location = redirect
          return
        }
        this.setState({
          errorMessage: this.props.intl.formatMessage(errors.invalidCredentials)
        })
        return
      }
      this.setState({
        errorMessage: this.props.intl.formatMessage(errors.simple)
      })
    }
    return
  }

  updateUsername(e) {
    this.setState({ username: e.target.value })
  }

  updatePassword(e) {
    this.setState({ password: e.target.value })
  }

  checkEnter(e) {
    if (e.keyCode === 13) {
      this.login()
    }
  }

  render() {
    const format = this.props.intl.formatMessage
    let error
    if (this.state.errorMessage) {
      error = (
        <div className={styles.error} id="error">
          <span>
            <i className={`fa fa-exclamation-circle ${styles.errorIcon}`} />
          </span>
          <span>
            {this.state.errorMessage}
          </span>
        </div>
      )
    }
    return (
      <div className={styles.container}>
        <div className={styles.schoolName}>
          {this.state.institution.name}
        </div>

        <div className={styles.controls}>
          {error}

          <div className={styles.username}>
            <i className={`fa fa-user ${styles.userIcon}`} />
            <input
              autoFocus
              className={styles.usernameTextbox}
              data-test="username"
              id="username"
              onChange={this.updateUsername}
              onKeyDown={this.checkEnter}
              placeholder={format(placeholders.usernameEmail)}
              type="text"
            />
          </div>
          <div className={styles.password}>
            <i className={`fa fa-lock ${styles.passwordIcon}`} />
            <input
              className={styles.passwordTextbox}
              data-test="password"
              id="password"
              onChange={this.updatePassword}
              onKeyDown={this.checkEnter}
              placeholder={format(labels.password)}
              type="password"
            />
          </div>

          <div className={`${styles.loginButton}`}>
            <button
              className={'btn btn-primary'}
              data-test="login"
              id="login"
              onClick={this.login}
              value={format(labels.signIn)}
            >
              Sign In
            </button>
          </div>
        </div>
      </div>
    )
  }
}
export default injectIntl(_Main)
