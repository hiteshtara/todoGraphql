/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */
import React, { Component } from 'react'
import { injectIntl, intlShape } from 'react-intl'
// import classnames from 'classnames'

import { Header, TitleBar } from 'kuali-ui'

import { idps } from './messages'
import { getInstitution } from './stores/institutions'

import styles from './style'

export class _Main extends Component {
  displayName: 'SelectIdp'

  static propTypes = {
    intl: intlShape.isRequiredn
  }

  constructor(props) {
    super(props)
    this.state = {}
    this.fetchInstitution()
  }

  async fetchInstitution() {
    const institution = await getInstitution()
    this.setState({ institution })
  }

  render() {
    const format = this.props.intl.formatMessage
    return (
      <div>
        <Header
          module={{ name: '' }}
          onBrandSelected={/* istanbul ignore next */() => {}}
          user={{ name: '' }}
        />
        <TitleBar>{format(idps.selectIdp)}</TitleBar>
        <div>
          {this.state.institution &&
            this.state.institution.idps.map((idp, i, arr) => {
              return (
                <div className={styles.idpList}>
                  <a href={`/auth/saml?idp=${idp.name}`}>{idp.name}</a>
                  {arr.length - 1 !== i && <hr />}
                </div>
              )
            })}
        </div>
      </div>
    )
  }
}
export default injectIntl(_Main)
