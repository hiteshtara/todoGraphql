/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import classnames from 'classnames'
import AlertBox from './alert-box'
import { errors } from './messages'

import styles from './style'

export class _Main extends Component {

  displayName: 'NeedsApproval';

  static propTypes = {
    intl: intlShape.isRequired
  };

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    const format = this.props.intl.formatMessage
    return (
      <div className={classnames(styles.container, styles.centerChildren)}>
        <AlertBox
          description={format(errors.unapproved)}
          title={format(errors.unapprovedTitle)}
          type="info"
        />
      </div>
    )
  }

}
export default injectIntl(_Main)
