/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import classnames from 'classnames'

import styles from './alert-box.css'

const ICON_CLASSES = {
  'info': 'fa fa-info-circle',
  'warning': 'fa fa-exclamation-circle',
  'error': 'fa fa-times-circle'
}

export class _AlertBox extends Component {

  displayName: 'AlertBox';

  static propTypes = {
    description: PropTypes.string,
    intl: intlShape.isRequired,
    title: PropTypes.string.isRequired,
    type: PropTypes.oneOf([
      'info',
      'warning',
      'error'
    ])
  }

  render() {
    const { title, description, type } = this.props
    const iconClass = ICON_CLASSES[type]
    return (
      <div className={classnames(styles.box, styles[`type-${type}`])}>
        <h3 className={styles.title} data-test="alert-header">
          <i
            aria-hidden="true"
            className={classnames(iconClass, styles.icon)}
          />
          {title}
        </h3>
        <p className={styles.description} data-test="alert-desc">
          {description}
        </p>
      </div>
    )
  }

}
export default injectIntl(_AlertBox)
