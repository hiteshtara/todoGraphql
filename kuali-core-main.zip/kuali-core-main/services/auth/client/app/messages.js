/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const placeholders = defineMessages({
  usernameEmail: {
    id: 'auth.placeholders.usernameOrEmail',
    description: 'Placeholder for text field for logging in with username/email', //eslint-disable-line max-len
    defaultMessage: 'Username / Email'
  }
})

export const errors = defineMessages({
  invalidCredentials: {
    id: 'auth.errors.invalid',
    description: 'Error message display on invalid username/password',
    defaultMessage: 'Invalid username/password'
  },
  unapproved: {
    id: 'auth.errors.unapproved',
    description: 'Error message display on unapproved user',
    defaultMessage: 'A request to approve your account has been sent to your ' +
      'admin. If approved you will be able to log in. Thank you for your ' +
      'patience.'
  },
  unapprovedTitle: {
    id: 'auth.errors.unapprovedTitle',
    description: 'Error message title to show that admin approval is in ' +
      'progress',
    defaultMessage: 'Admin approval in progress'
  }
})

export const idps = defineMessages({
  selectIdp: {
    id: 'auth.idp.select',
    description: 'Title message for ipd selection page',
    defaultMessage: 'Select Campus'
  }
})

export default { placeholders }
