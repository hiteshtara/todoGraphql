/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { expect } from 'chai'
import config from 'config'
import { includes, get } from 'lodash'
import auth from 'services/auth'
import express from 'express'
import request from 'supertest-as-promised'
import institutionLoader from 'shared/institution-loader'
import institutionPlugin from 'services/institution/plugin'
import responseLocals from 'shared/middleware/response-locals'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getInstitutionModel } from 'services/institution/model'
import { getUserModel } from 'services/users/server/resources/users/model'
import { getModel as getApplicationModel } from 'services/apps/server/model'
import { getRawTemplateModel } from 'services/notifications/server/models/template'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import { SAML } from 'passport-saml'
import { defaultLogger } from 'shared/logging'
import { getInCommonModel } from '../server/resources/in-common/model'

const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)
let Institution = getInstitutionModel(connection)
let Application = getApplicationModel(connection)
let InCommon = getInCommonModel(connection)
let Template = getRawTemplateModel(connection)

let app
let samlResponse = `PHNhbWwycDpSZXNwb25zZSB4bWxuczpzYW1sMnA9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpwcm90b2NvbCIgRGVzdGluYXRpb249Imh0dHBzOi8vc2FtbDEtdHN0Lmt1YWxpLmNvL2F1dGgvc2FtbC9jb25zdW1lIiBJRD0iXzE3MzczOTIzNzhiNWJiYzYyN2JlYTdiMTQyYWYwYmZmIiBJblJlc3BvbnNlVG89Il9iZjVkNjMyZTEyMjE0MTRiMmM4NyIgSXNzdWVJbnN0YW50PSIyMDE2LTAxLTIwVDIyOjIyOjQyLjU3NloiIFZlcnNpb249IjIuMCI+PHNhbWwyOklzc3VlciB4bWxuczpzYW1sMj0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiIgRm9ybWF0PSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6bmFtZWlkLWZvcm1hdDplbnRpdHkiPmh0dHBzOi8vaWRwLXRlc3QuaXRzLmhhd2FpaS5lZHUvaWRwL3NoaWJib2xldGg8L3NhbWwyOklzc3Vlcj48ZHM6U2lnbmF0dXJlIHhtbG5zOmRzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjIj48ZHM6U2lnbmVkSW5mbz48ZHM6Q2Fub25pY2FsaXphdGlvbk1ldGhvZCBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMTAveG1sLWV4Yy1jMTRuIyIvPjxkczpTaWduYXR1cmVNZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjcnNhLXNoYTEiLz48ZHM6UmVmZXJlbmNlIFVSST0iI18xNzM3MzkyMzc4YjViYmM2MjdiZWE3YjE0MmFmMGJmZiI+PGRzOlRyYW5zZm9ybXM+PGRzOlRyYW5zZm9ybSBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyNlbnZlbG9wZWQtc2lnbmF0dXJlIi8+PGRzOlRyYW5zZm9ybSBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMTAveG1sLWV4Yy1jMTRuIyIvPjwvZHM6VHJhbnNmb3Jtcz48ZHM6RGlnZXN0TWV0aG9kIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMC8wOS94bWxkc2lnI3NoYTEiLz48ZHM6RGlnZXN0VmFsdWU+WjRRQ3E2VXl1emxTWm14b0RmcnFtendDOHRVPTwvZHM6RGlnZXN0VmFsdWU+PC9kczpSZWZlcmVuY2U+PC9kczpTaWduZWRJbmZvPjxkczpTaWduYXR1cmVWYWx1ZT5ZTThrWHdzS2xyR3Nha01OREpRM29RS081bXRMcG5yQW5EN1p2RTJjSGpWNmZleXlQMFNUQVIrL3NyeWpqOXo2VnQrMXAvNXBpWElvNHF6aGs0aHNqdHhaVVJLM24wSnEyMkJJMHIyZHZvbXUxdW9sZjdtd1JWS21YaGhmcGdDUmsveWNIdEl4ZjMxcHpxV2ZxMEg0elVDbXNmdnJnMmdQbGhDazk4WXRobjdPNG42aVQyV2loMjJvQ2x2MnB2Yy8zNnlrR3BHckVaUWVuaW5pd3VFb3N1MkJVOTE4aXQ5UWt4RjUwbFZPTWUzY2FTbHUreEtWYWdpYlBUTzg4TzRVTUxkaFJSSGdjNnJwUkh4NS8rSDVSbXA0WW5HNXcwUThJa01TR2s5Tm55SHhhTlRYcll5eThnWVJqZUV3ZFNsZ3cxR0l5N3VKVEY0SlBpanFiaWxiVUE9PTwvZHM6U2lnbmF0dXJlVmFsdWU+PGRzOktleUluZm8+PGRzOlg1MDlEYXRhPjxkczpYNTA5Q2VydGlmaWNhdGU+TUlJRFNEQ0NBakNnQXdJQkFnSVZBSWM0QkV3UDE1SmN3VDYrMjN3Q3kwTExvZTN4TUEwR0NTcUdTSWIzRFFFQkJRVUFNQ0l4SURBZQ0KQmdOVkJBTVRGMmxrY0MxMFpYTjBMbWwwY3k1b1lYZGhhV2t1WldSMU1CNFhEVEV3TURReE1EQXdNamt5TmxvWERUTXdNRFF4TURBdw0KTWpreU5sb3dJakVnTUI0R0ExVUVBeE1YYVdSd0xYUmxjM1F1YVhSekxtaGhkMkZwYVM1bFpIVXdnZ0VpTUEwR0NTcUdTSWIzRFFFQg0KQVFVQUE0SUJEd0F3Z2dFS0FvSUJBUURsQXJSVVFuYUI1ZFRlaWZpQnJYNDlLWWhHbUdaeUxwQ1d1ekN6UVArV1gva2d1MVlUL0NoLw0KVzhRRGdVdWhMOXR3ano4bEZOK3A0NmQreHBjOHdyTzFsUFBiL0JsZ2hOK3VRMDhxSkt2ZE1rd1V0RmMzaUJRQWRhSUZSY0ZCVVZaSg0Kbml1WFp1czltUm9UZ0ErMlhWOTROWkNjVFQ3Y0QxTW15MDlUTTJ6SGU0dGthUWczd3R4ZlFtTkYvM0lpMExTVzJmek05NXc3azlkRQ0KQTBOK0F0NDl1NTdnekk4dnl5ajFMK2lTSjh1YnBER1pjcGFhVC9PcE1Wb1dQaGFoVERhaHpBUHlqK2hNR0I2MXRtRUI3RVBEYlhwSw0KRHdoZ3VFSWtMaGVoaDgvZjE5cmcwNVpCKzBNWlJRT0h4WEhDYnUzODFwTVh0V2F1RHhYL1cvc05JODRWQWdNQkFBR2pkVEJ6TUZJRw0KQTFVZEVRUkxNRW1DRjJsa2NDMTBaWE4wTG1sMGN5NW9ZWGRoYVdrdVpXUjFoaTVvZEhSd2N6b3ZMMmxrY0MxMFpYTjBMbWwwY3k1bw0KWVhkaGFXa3VaV1IxTDJsa2NDOXphR2xpWW05c1pYUm9NQjBHQTFVZERnUVdCQlRRWUxCL3hwQmREUkR1R1NmdnBBSlN4SUJOZkRBTg0KQmdrcWhraUc5dzBCQVFVRkFBT0NBUUVBa1ljQW9NaXA0OXhxTXhjUmxaRkRlWnRRT1AzSHdhTE9Qem9EWEZUNURvd1QzdEdwMmUvZw0KV2lnU0J1cmJwNHdXcnJpZll5bC9SWjFVajhYUmlmbEZOZFJuWmVmNGxTNHpYOUs1NlZCZlRVcllLU2JTS1cvOUlhZnU3YlZJZXI3Yw0Kckt1NWxRWERtaG5WNXVncHUyOHFtWWFJbHYvWjlzQkRVc0VZRjhnc0tWWDdhS1h0Z3Vjb0NETWFZU1lrZDlPb0ZsYWN6QTR1VUlhQg0KdDdqSXp2VHFFaGdoSU52MlZyOTV0K0NkaWZqU0hBUjljOURCcGJnS1JYRE9BTUxzU3VVSWJUdTBzTWc4WkJ0Nmd2SHFIMkxvdGpBNg0KU2J1aDJHbGoyaVBYQzByQjRpUDRTbno2anBzWWdiUWxvNGtTOE1Wb0M0aEE5TlFmcFRLOGEzY0hqYmkzL0E9PTwvZHM6WDUwOUNlcnRpZmljYXRlPjwvZHM6WDUwOURhdGE+PC9kczpLZXlJbmZvPjwvZHM6U2lnbmF0dXJlPjxzYW1sMnA6U3RhdHVzPjxzYW1sMnA6U3RhdHVzQ29kZSBWYWx1ZT0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnN0YXR1czpTdWNjZXNzIi8+PC9zYW1sMnA6U3RhdHVzPjxzYW1sMjpBc3NlcnRpb24geG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iIHhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiIElEPSJfNWZhZDM5NTViYmZjYTg2OWVmMTM0NTFjZDg3NjFhMmUiIElzc3VlSW5zdGFudD0iMjAxNi0wMS0yMFQyMjoyMjo0Mi41NzZaIiBWZXJzaW9uPSIyLjAiPjxzYW1sMjpJc3N1ZXIgRm9ybWF0PSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6bmFtZWlkLWZvcm1hdDplbnRpdHkiPmh0dHBzOi8vaWRwLXRlc3QuaXRzLmhhd2FpaS5lZHUvaWRwL3NoaWJib2xldGg8L3NhbWwyOklzc3Vlcj48c2FtbDI6U3ViamVjdD48c2FtbDI6TmFtZUlEIEZvcm1hdD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOm5hbWVpZC1mb3JtYXQ6dHJhbnNpZW50IiBOYW1lUXVhbGlmaWVyPSJodHRwczovL2lkcC10ZXN0Lml0cy5oYXdhaWkuZWR1L2lkcC9zaGliYm9sZXRoIj5fMmE0YzhkYTMyZDFiMThjNzE2ZTgwMjBhOWRlM2QzYmM8L3NhbWwyOk5hbWVJRD48c2FtbDI6U3ViamVjdENvbmZpcm1hdGlvbiBNZXRob2Q9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpjbTpiZWFyZXIiPjxzYW1sMjpTdWJqZWN0Q29uZmlybWF0aW9uRGF0YSBBZGRyZXNzPSI1MC4yNDMuNC4xNDkiIEluUmVzcG9uc2VUbz0iX2JmNWQ2MzJlMTIyMTQxNGIyYzg3IiBOb3RPbk9yQWZ0ZXI9IjIxMTYtMDEtMjBUMjI6Mjc6NDIuNTc2WiIgUmVjaXBpZW50PSJodHRwczovL3NhbWwxLXRzdC5rdWFsaS5jby9hdXRoL3NhbWwvY29uc3VtZSIvPjwvc2FtbDI6U3ViamVjdENvbmZpcm1hdGlvbj48L3NhbWwyOlN1YmplY3Q+PHNhbWwyOkNvbmRpdGlvbnMgTm90QmVmb3JlPSIxOTE2LTAxLTIwVDIyOjIyOjQyLjU3NloiIE5vdE9uT3JBZnRlcj0iMjExNi0wMS0yMFQyMjoyNzo0Mi41NzZaIj48c2FtbDI6QXVkaWVuY2VSZXN0cmljdGlvbj48c2FtbDI6QXVkaWVuY2U+aHR0cHM6Ly9zYWFzMS5rdWFsaS5jby9hdXRoPC9zYW1sMjpBdWRpZW5jZT48L3NhbWwyOkF1ZGllbmNlUmVzdHJpY3Rpb24+PC9zYW1sMjpDb25kaXRpb25zPjxzYW1sMjpBdXRoblN0YXRlbWVudCBBdXRobkluc3RhbnQ9IjIwMTYtMDEtMjBUMjI6MTc6MDYuMTc1WiIgU2Vzc2lvbkluZGV4PSJfMTFlOWUwNWFiODYxNTZlMTQ0MGFmNWFkNWZlZjZhODYiPjxzYW1sMjpTdWJqZWN0TG9jYWxpdHkgQWRkcmVzcz0iNTAuMjQzLjQuMTQ5Ii8+PHNhbWwyOkF1dGhuQ29udGV4dD48c2FtbDI6QXV0aG5Db250ZXh0Q2xhc3NSZWY+dXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmNsYXNzZXM6dW5zcGVjaWZpZWQ8L3NhbWwyOkF1dGhuQ29udGV4dENsYXNzUmVmPjwvc2FtbDI6QXV0aG5Db250ZXh0Pjwvc2FtbDI6QXV0aG5TdGF0ZW1lbnQ+PHNhbWwyOkF0dHJpYnV0ZVN0YXRlbWVudD48c2FtbDI6QXR0cmlidXRlIEZyaWVuZGx5TmFtZT0idWhfYWZmaWxpYXRpb24iIE5hbWU9InVybjpvaWQ6MS4zLjYuMS40LjEuNTkyMy4xLjEuMS4xIiBOYW1lRm9ybWF0PSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YXR0cm5hbWUtZm9ybWF0OnVyaSI+PHNhbWwyOkF0dHJpYnV0ZVZhbHVlIHhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIgeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSIgeHNpOnR5cGU9InhzOnN0cmluZyI+bWVtYmVyPC9zYW1sMjpBdHRyaWJ1dGVWYWx1ZT48L3NhbWwyOkF0dHJpYnV0ZT48c2FtbDI6QXR0cmlidXRlIEZyaWVuZGx5TmFtZT0ic24iIE5hbWU9InVybjpvaWQ6Mi41LjQuNCIgTmFtZUZvcm1hdD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmF0dHJuYW1lLWZvcm1hdDp1cmkiPjxzYW1sMjpBdHRyaWJ1dGVWYWx1ZSB4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiIHhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiIHhzaTp0eXBlPSJ4czpzdHJpbmciPlRlc3RJQU0tS3VhbGlDbzwvc2FtbDI6QXR0cmlidXRlVmFsdWU+PC9zYW1sMjpBdHRyaWJ1dGU+PHNhbWwyOkF0dHJpYnV0ZSBGcmllbmRseU5hbWU9ImVQUE4iIE5hbWU9InVybjpvaWQ6MS4zLjYuMS40LjEuNTkyMy4xLjEuMS42IiBOYW1lRm9ybWF0PSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YXR0cm5hbWUtZm9ybWF0OnVyaSI+PHNhbWwyOkF0dHJpYnV0ZVZhbHVlIHhtbG5zOnhzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSIgeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSIgeHNpOnR5cGU9InhzOnN0cmluZyI+aWFtXzAxMDdAaGF3YWlpLmVkdTwvc2FtbDI6QXR0cmlidXRlVmFsdWU+PC9zYW1sMjpBdHRyaWJ1dGU+PHNhbWwyOkF0dHJpYnV0ZSBGcmllbmRseU5hbWU9Im1haWwiIE5hbWU9InVybjpvaWQ6MC45LjIzNDIuMTkyMDAzMDAuMTAwLjEuMyIgTmFtZUZvcm1hdD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmF0dHJuYW1lLWZvcm1hdDp1cmkiPjxzYW1sMjpBdHRyaWJ1dGVWYWx1ZSB4bWxuczp4cz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEiIHhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiIHhzaTp0eXBlPSJ4czpzdHJpbmciPmlhbV8wMTA3QGhhd2FpaS5lZHU8L3NhbWwyOkF0dHJpYnV0ZVZhbHVlPjwvc2FtbDI6QXR0cmlidXRlPjxzYW1sMjpBdHRyaWJ1dGUgRnJpZW5kbHlOYW1lPSJnaXZlbk5hbWUiIE5hbWU9InVybjpvaWQ6Mi41LjQuNDIiIE5hbWVGb3JtYXQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphdHRybmFtZS1mb3JtYXQ6dXJpIj48c2FtbDI6QXR0cmlidXRlVmFsdWUgeG1sbnM6eHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hIiB4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIiB4c2k6dHlwZT0ieHM6c3RyaW5nIj5UZXN0Zi1TdHVkZW50PC9zYW1sMjpBdHRyaWJ1dGVWYWx1ZT48L3NhbWwyOkF0dHJpYnV0ZT48L3NhbWwyOkF0dHJpYnV0ZVN0YXRlbWVudD48L3NhbWwyOkFzc2VydGlvbj48L3NhbWwycDpSZXNwb25zZT4=` // eslint-disable-line

// TODO:: We need to figure out how to set up some kind of test where we can
// spin up our own SAML server with it's own public/private keys and actually
// test that encrypted login is working correctly.

describe('Unencrypted SAML Login', () => {
  let sandbox

  before(async () => {
    seneca.use(institutionPlugin)
    app = express()
    app.use((req, res, next) => {
      req.log = {
        audit() {},
        error() {},
        debug() {}
      }
      next()
    })
    app.use(responseLocals)
    app.use(institutionLoader)
    app.use(auth)
    try {
      await InCommon.create({
        idp: 'https://idp-test.its.hawaii.edu/idp/shibboleth',
        entryPoint:
          'https://idp-test.its.hawaii.edu/idp/profile/SAML2/Redirect/SSO', // eslint-disable-line
        cert: undefined
      })
    } catch (err) {
      if (err.code !== 11000) throw err
    }
    try {
      await InCommon.create({
        idp: 'http://adfsproxy1.snhu.edu/adfs/services/trust',
        entryPoint: 'https://adfsproxy1.snhu.edu/adfs/ls/',
        cert: undefined
      })
    } catch (err) {
      if (err.code !== 11000) throw err
    }
  })

  beforeEach(async () => {
    await Institution.remove({})
    sandbox = sinon.sandbox.create()
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('SAML Strategy', () => {
    it('handles exception in GetUser function', async () => {
      sandbox.stub(Object, 'assign').throws(new Error('error'))

      await saveValidInstitution()
      let req = request(app)
        .post('/auth/saml/consume')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(401)
      expect(res.text).to.match(/SAML Error/)
    })
  })

  it('redirects to appropriate host', async () => {
    await saveValidInstitution()
    let res = await request(app).get('/auth').expect(302)
    assert.equal(res.header.location, '/auth/saml')
  })

  it('prepares saml auth', async () => {
    await saveValidInstitution()
    let res = await request(app).get('/auth/saml').expect(302)
    assert(
      res.header.location.indexOf(
        'https://idp-test.its.hawaii.edu/idp/profile/SAML2/Redirect/SSO'
      ) === 0
    )
  })

  it('prepares saml auth with idp query param', async () => {
    await saveMultipleIdpInstitution()
    let res = await request(app).get('/auth/saml?idp=idpTwo').expect(302)
    assert(
      res.header.location.indexOf('https://adfsproxy1.snhu.edu/adfs/ls/') === 0
    )
  })

  it('sign outs removes cookies', async () => {
    await saveMultipleIdpInstitution()
    let res = await request(app)
      .get('/auth/signout')
      .set('Cookie', ['idp=idpTwo'])
      .expect(302)
    assert(res.header.location.indexOf('apps') >= 0)
  })

  it('login with multiple idps redirects', async () => {
    await saveMultipleIdpInstitution()
    let res = await request(app).get('/auth').expect(302)
    assert(res.header.location.indexOf('idpselection') >= 0)
  })

  it('is able to login with basic auth credentials', async () => {
    await saveMultipleIdpInstitution()
    await request(app)
      .post('/api/v1/auth/authenticate')
      .send({
        username: 'foo',
        password: 'bar'
      })
      .expect(401)
  })

  it('prepares snhu saml auth', async () => {
    await saveSNHU()
    let res = await request(app).get('/auth/saml').expect(302)
    assert(
      res.header.location.indexOf('https://adfsproxy1.snhu.edu/adfs/ls/') === 0
    )
  })
  it('prepares saml auth and sets samlReturnTo', async () => {
    await saveValidInstitution()
    let res = await request(app)
      .get('/auth/saml?return_to=https://www.google.com')
      .expect(302)
      .expect('set-cookie', /samlReturnTo=https%3A%2F%2Fwww.google.com;/)
    assert(
      res.header.location.indexOf(
        'https://idp-test.its.hawaii.edu/idp/profile/SAML2/Redirect/SSO'
      ) === 0
    )
  })
  it('forwards consume post', async () => {
    await saveValidInstitution()
    let req = request(app)
      .post('/auth/saml/consume')
      .send({ SAMLResponse: samlResponse })
    let res = await req.expect(302)
    assert.equal(res.headers.location, '/apps/')
  })
  describe('manual approval', () => {
    beforeEach(async () => {
      await User.remove({})
      await Application.remove({})
      await Template.remove({})
    })
    it('forwards to error page', async () => {
      await saveManualApprovalInstitution()
      let application = await seneca.actAsync({
        role: 'apps',
        cmd: 'create',
        application: { displayName: 'tokens test app' },
        user: { id: 'test' },
        connectionKey
      })
      await seneca.actAsync({
        role: 'notification-templates',
        cmd: 'create',
        template: {
          displayName: 'user-approval-notify-admin',
          applicationId: application.id,
          subject: 'User Approval Required',
          templates: {
            email: {
              html: '',
              text:
                'displayName is waiting to be approved ' +
                'for access to Kuali. userUrl'
            }
          }
        },
        connectionKey,
        currentUser: { id: 'test' }
      })
      await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        data: {
          email: 'testadminmanual@kuali.co',
          role: 'admin'
        },
        currentUser: { id: 'test' },
        connectionKey
      })
      let originalAct = seneca.actAsync.bind(seneca)
      let sentNotifications = []
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'notifications' && pattern.cmd === 'create') {
          sentNotifications.push(pattern.notification)
          return {}
        }
        return originalAct(pattern)
      })
      let req = request(app)
        .post('/auth/saml/consume')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      expect(res).to.have.deep.property(
        'header.location',
        '/auth/kuali/#/needsApproval'
      )
      expect(sentNotifications).to.have.deep.property(
        '[0].addresses[0]',
        'testadminmanual@kuali.co'
      )
    })
  })
  describe('scoped auto approval', () => {
    beforeEach(async () => {
      await User.remove({})
    })
    it('forwards to error page', async () => {
      await saveScopedApprovalInstitution({
        uh_affiliation: ['staff', 'member'],
        bogus: ['totally']
      })
      let req = request(app)
        .post('/auth/saml/consume')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      expect(res).to.have.deep.property(
        'header.location',
        '/auth/kuali/#/needsApproval'
      )
    })
    it('forwards to apps', async () => {
      await saveScopedApprovalInstitution({
        uh_affiliation: ['staff', 'member']
      })
      let req = request(app)
        .post('/auth/saml/consume')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      assert.equal(res.headers.location, '/apps/')
    })
    it('forwards to apps when redirect is invalid', async () => {
      await saveScopedApprovalInstitution({
        uh_affiliation: ['staff', 'member']
      })
      let req = request(app)
        .post('/auth/saml/consume?redirect_to=http://google.com')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      assert.equal(res.headers.location, '/apps/')
    })
    it('forwards to the same host', async () => {
      await saveScopedApprovalInstitution({
        uh_affiliation: ['staff', 'member']
      })
      let req = request(app)
        .post('/auth/saml/consume?redirect_to=http://127.0.0.1/dude/')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      assert.equal(res.headers.location, 'http://127.0.0.1/dude/')
    })
    it('forwards to any .kuali.co', async () => {
      await saveScopedApprovalInstitution({
        uh_affiliation: ['staff', 'member']
      })
      let req = request(app)
        .post('/auth/saml/consume?redirect_to=http://things.kuali.co/dude/')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      assert.equal(res.headers.location, 'http://things.kuali.co/dude/')
    })
    it('forwards to white-listed host', async () => {
      await saveScopedApprovalInstitution({
        uh_affiliation: ['staff', 'member']
      })
      let req = request(app)
        .post('/auth/saml/consume?redirect_to=http://apple.com/dude/')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      assert.equal(res.headers.location, 'http://apple.com/dude/')
    })
  })
  it('redirects with request when no SAMLResponse param', async () => {
    await saveValidInstitution()
    let req = request(app).post('/auth/saml/consume')
    let res = await req.expect(302)
    expect(res.headers.location).to.match(/SAMLRequest/)
  })

  it('validates twice consecutively', async () => {
    await saveValidInstitution()
    let req = request(app)
      .post('/auth/saml/consume')
      .send({ SAMLResponse: samlResponse })
    let res = await req.expect(302)
    assert.equal(res.headers.location, '/apps/')
    req = request(app)
      .post('/auth/saml/consume')
      .send({ SAMLResponse: samlResponse })
    res = await req.expect(302)
    assert.equal(res.headers.location, '/apps/')
  })
  describe('saml fallback', () => {
    it('falls back to correct key', async () => {
      sandbox.stub(config, 'get', name => {
        if (name !== 'auth.samlKeys') return get(config, 'name')
        return Object.assign({}, config.auth.samlKeys, {
          v0: 'v0',
          v1: 'v1',
          v4: 'v4'
        })
      })
      await saveValidInstitution()
      let validatePostResponse = SAML.prototype.validatePostResponse
      sandbox.stub(SAML.prototype, 'validatePostResponse', function(
        body,
        callback
      ) {
        if (includes(['v0', 'v1', 'v4'], this.options.decryptionPvk)) {
          return callback(new Error('from stub'))
        }
        return validatePostResponse.apply(this, [body, callback])
      })
      let req = request(app)
        .post('/auth/saml/consume')
        .send({ SAMLResponse: samlResponse })
      let res = await req.expect(302)
      assert.equal(res.headers.location, '/apps/')
    })
  })
  it('tries and fails to add user when existing user missing uid', async () => {
    await saveValidInstitution()
    let req = request(app)
      .post('/auth/saml/consume')
      .send({ SAMLResponse: samlResponse })
    let res = await req.expect(302)
    assert.equal(res.headers.location, '/apps/')
    let users = await seneca.actAsync({
      role: 'users',
      cmd: 'list',
      options: { email: 'iam_0107@hawaii.edu' },
      connectionKey
    })
    let user = users[0]
    user.uid = ''
    await seneca.actAsync({
      role: 'users',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: user,
      connectionKey
    })
    req = request(app)
      .post('/auth/saml/consume')
      .send({ SAMLResponse: samlResponse })
    res = await req.expect(302)
    assert.equal(res.headers.location, '/apps/')
  })

  it('fails correctly if cannot find idp', async () => {
    await seneca.actAsync({
      role: 'institutions',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        secret:
          'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767', // eslint-disable-line
        subdomain: 'kuali',
        name: 'Kuali',
        forceAuthn: false,
        signInExpiresWithSession: true,
        signInExpiresIn: 1209600000,
        provider: 'saml',
        idps: [
          {
            idp: 'CANNOT FIND ME IDP',
            eppn: 'email'
          }
        ]
      },
      connectionKey
    })
    let req = request(app)
      .post('/auth/saml/consume')
      .send({ SAMLResponse: samlResponse })
    let res = await req.expect(401)
    expect(res.text).to.have.string('SAML Error')
  })

  describe('InCommon', () => {
    it('logs a fatal error on index error', done => {
      const spy = sandbox.spy(defaultLogger, 'fatal')
      InCommon.emit('index', new Error('test'))
      sinon.assert.calledOnce(spy)
      done()
    })
  })
})

async function saveValidInstitution() {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: {
      secret:
        'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767', // eslint-disable-line
      subdomain: 'kuali',
      name: 'Kuali',
      forceAuthn: false,
      signInExpiresWithSession: true,
      signInExpiresIn: 1209600000,
      provider: 'saml',
      idps: [
        {
          idp: 'https://idp-test.its.hawaii.edu/idp/shibboleth',
          eppn: 'email'
        }
      ]
    },
    connectionKey
  })
}

async function saveManualApprovalInstitution() {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: {
      secret:
        'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767', // eslint-disable-line
      subdomain: 'kuali',
      name: 'Kuali',
      forceAuthn: false,
      signInExpiresWithSession: true,
      signInExpiresIn: 1209600000,
      provider: 'saml',
      approval: 'manual',
      idps: [
        {
          name: 'idpOne',
          idp: 'https://idp-test.its.hawaii.edu/idp/shibboleth',
          eppn: 'email'
        }
      ]
    },
    connectionKey
  })
}

async function saveMultipleIdpInstitution() {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: {
      secret:
        'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767', // eslint-disable-line
      subdomain: 'kuali',
      name: 'Kuali',
      forceAuthn: false,
      signInExpiresWithSession: true,
      signInExpiresIn: 1209600000,
      provider: 'saml',
      approval: 'manual',
      idps: [
        {
          name: 'idpOne',
          idp: 'https://idp-test.its.hawaii.edu/idp/shibboleth',
          eppn: 'email'
        },
        {
          name: 'idpTwo',
          idp: 'http://adfsproxy1.snhu.edu/adfs/services/trust',
          eppn: 'email'
        }
      ]
    },
    connectionKey
  })
}

async function saveScopedApprovalInstitution(approvalScope) {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: {
      secret:
        'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767', // eslint-disable-line
      subdomain: 'kuali',
      name: 'Kuali',
      forceAuthn: false,
      signInExpiresWithSession: true,
      signInExpiresIn: 1209600000,
      provider: 'saml',
      approval: 'scopedAuto',
      approvalScope,
      idps: [
        {
          idp: 'https://idp-test.its.hawaii.edu/idp/shibboleth',
          eppn: 'email'
        }
      ],
      validRedirectHosts: ['apple.com']
    },
    connectionKey
  })
}

async function saveSNHU() {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: {
      secret:
        'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767', // eslint-disable-line
      subdomain: 'kuali',
      name: 'Kuali',
      forceAuthn: false,
      signInExpiresWithSession: true,
      signInExpiresIn: 1209600000,
      provider: 'saml',
      idps: [
        {
          idp: 'http://adfsproxy1.snhu.edu/adfs/services/trust',
          eppn: 'email'
        }
      ]
    },
    connectionKey
  })
}
