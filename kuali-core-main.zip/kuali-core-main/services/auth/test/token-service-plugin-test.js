/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { assert, expect } from 'chai'
import mongoose from 'shared/mongoose'
import sinon from 'sinon'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import * as utils from 'services/auth/server/resources/tokens/utils'

let sandbox


const { connectionKey } = getTestConnectionInfo()
describe('Token Service Plugin', () => {

  beforeEach(() => {
    sandbox = sinon.sandbox.create()
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('fails if connection key is not passed', async () => {
    const methods = [
      {
        method: utils.create,
        args: [new mongoose.Types.ObjectId(), 'secret secret']
      },
      { method: utils.validate },
      { method: utils.revoke },
      { method: utils.revokeUser },
      {
        method: utils.fetch,
        args: [new mongoose.Types.ObjectId(), 'secret secret']
      },
      { method: utils.fetchExpired }
    ]

    methods.forEach(async (method) => {
      const args = method.args || []
      try {
        await method.method(...args)
        assert.fail()
      } catch (err) {
        expect(err.message).to.contain('connectionKey is required')
      }
    })

    let error
    await utils.tokenize()({}, { locals: {} }, (err) => {
      error = err
    })
    expect(error.message).to.contain('connectionKey is required')
  })

  describe('fetch', () => {

    it('requires user before fetching', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'fetch',
          connectionKey
        })
      } catch (ex) {
        assert(/user is required/.test(ex.message))
      }
    })

    it('throws on error', async () => {
      let exception
      sandbox.stub(utils, 'fetchExpired').throws(new Error())
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'fetch',
          expired: 'expired',
          type: 'apiKey',
          connectionKey
        })
      } catch (ex) {
        exception = ex
      }
      assert(exception)
    })
  })

  describe('revoke', () => {
    it('requires token id', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'revoke',
          connectionKey
        })
      } catch (ex) {
        assert(/id is required/.test(ex.message))
      }
    })
  })

  describe('sign', () => {

    it('returns error on user lookup fail', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          id: '743c5be0ce1130c0c78b509f',
          secret: 'secret',
          connectionKey
        })
      } catch (ex) {
        assert(/id not found/.test(ex.message))
      }
    })

  })

  describe('sign API key', () => {

    it('returns error on no message id', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          type: 'apiKey',
          connectionKey
        })
      } catch (err) {
        expect(err.message).to.match(/id is required/)
      }
    })

    it('returns error on no secret', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          type: 'apiKey',
          id: 'some-object-id',
          connectionKey
        })
      } catch (err) {
        expect(err.message).to.match(/secret is required/)
      }
    })

    it('fails to create for other users', async () => {
      try {
        let originalAct = seneca.actAsync.bind(seneca)
        sandbox.stub(seneca, 'actAsync', (pattern) => {
          if (pattern.role === 'users' && pattern.cmd === 'load') {
            return Promise.resolve({ id: 'some-object-id' })
          }
          return originalAct(pattern)
        })
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          type: 'apiKey',
          id: 'some-object-id',
          secret: 'secret',
          currentUser: { id: 'userPerson', role: 'user' },
          connectionKey
        })
      } catch (err) {
        expect(err.message).to.match(/Unauthorized/)
      }
    })
  })

})
