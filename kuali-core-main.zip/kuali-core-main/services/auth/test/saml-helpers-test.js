/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { expect } from 'chai'
import sinon from 'sinon'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { maybeUpdateUser, getAttrs, fetchUser, saveUser } from
  '../server/strategies/utils/saml-helpers'

let sandbox
const { connectionKey } = getTestConnectionInfo()

describe('Saml Helpers', () => {

  beforeEach( () => {
    sandbox = sinon.sandbox.create()
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('should fail if connectionKey is not passed', async () => {
    const methods = [
      fetchUser,
      saveUser,
      maybeUpdateUser
    ]

    methods.forEach(async (method) => {
      try {
        await method()
        assert.fail()
      } catch (err) {
        expect(err.message).to.contain('connectionKey required')
      }
    })
  })

  describe('maybeUpdateUser', () => {
    it('updates on different username', async () => {
      let actStub = sandbox.stub(seneca, 'actAsync')
      let user = {
        username: 'steve',
        email: 'steve@steve.com'
      }
      let username = 'bob'
      let attrs = {
        email: 'bob@bob.com'
      }
      await maybeUpdateUser(user, username, attrs, connectionKey)
      assert(actStub.called)
    })

    it('updates on new attributes', async () => {
      let actStub = sandbox.stub(seneca, 'actAsync')
      let username = 'bob'
      let user = {
        username
      }
      let attrs = {
        email: 'bob@bob.com'
      }
      await maybeUpdateUser(user, username, attrs, connectionKey)
      assert(actStub.called)
    })
  })

  describe('getAttrs', () => {
    it('resolves email addresses', () => {
      let attributes = {
        uid: 'uid@test.com'
      }
      let eppn = 'uid'
      let result = getAttrs(eppn, attributes)
      assert.equal(result.email, attributes.uid)

      attributes['E-Mail-Address'] = 'hyphenated'
      result = getAttrs(eppn, attributes)
      assert.equal(result.email, attributes['E-Mail-Address'])

      attributes.email = 'email'
      result = getAttrs(eppn, attributes)
      assert.equal(result.email, attributes.email)

      attributes.officialMail = 'officialmail'
      result = getAttrs(eppn, attributes)
      assert.equal(result.email, attributes.officialMail)

      attributes.mail = 'mail'
      result = getAttrs(eppn, attributes)
      assert.equal(result.email, attributes.mail)
    })

    it('does not strip domain if insitution settings allow it', () => {
      const attributes = {
        uid: 'uid@test.com'
      }
      const eppn = 'uid'
      const result = getAttrs(eppn, attributes, {
        features: {
          ssoDisableStripDomain: true
        }
      })
      assert.equal(result.username, attributes.uid)
    })
  })
})
