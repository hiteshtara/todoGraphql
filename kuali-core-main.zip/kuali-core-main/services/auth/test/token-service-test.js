/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* global mstub munstub  */
import 'mongoose-mstub' // exposes mstub and munstub for Mongoose instances
import assert from 'assert'
import sinon from 'sinon'
import moment from 'moment'
import jwt from 'jsonwebtoken'
import Bluebird from 'bluebird'
import { getTestConnectionInfo } from 'shared/test-helpers'
import * as tokenService from '../server/resources/tokens/utils'
import { getTokenModel } from '../server/resources/tokens/model'

const userId = '567c5b981caf93fec66457ea'
const secret = 'secret'

const { connectionKey, connection } = getTestConnectionInfo()
let Token = getTokenModel(connection)
let sandbox

describe('Token Service', () => {
  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await Token.remove({})
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('create', () => {
    it('succeeds with valid payload', async () => {
      let token = await tokenService.create(userId, secret, { connectionKey })
      let validatedUser = await tokenService.validate(
        token,
        'secret',
        {},
        connectionKey
      )
      assert.equal(validatedUser.userId, userId)
    })

    it('succeeds with name for token', async () => {
      let opts = {
        name: 'hey there',
        connectionKey
      }
      let token = await tokenService.create(userId, secret, opts)
      let validatedUser = await tokenService.validate(
        token,
        'secret',
        {},
        connectionKey
      )
      assert.equal(validatedUser.userId, userId)
    })

    it('succeeds with token for apiKey', async () => {
      let opts = {
        type: 'apiKey',
        connectionKey
      }
      let token = await tokenService.create(userId, secret, opts)
      let validatedUser = await tokenService.validate(
        token,
        'secret',
        {},
        connectionKey
      )
      assert.equal(validatedUser.userId, userId)
    })

    it('throws error when token save fails', async () => {
      mstub(Token, 'save', callback => {
        callback('error')
      })
      try {
        await tokenService.create(userId, secret, { connectionKey })
      } catch (ex) {
        let r = new RegExp(/error/)
        assert.equal(r.test(ex), true)
      } finally {
        munstub(Token, 'save')
      }
    })

    it('throws error if userId not included', async () => {
      try {
        await tokenService.create()
      } catch (ex) {
        let r = new RegExp(/userId/)
        assert.equal(r.test(ex), true)
      }
    })

    it('throws error if userId is invalid object id', async () => {
      try {
        await tokenService.create('1234')
      } catch (ex) {
        let r = new RegExp(/userId/)
        assert.equal(r.test(ex), true)
      }
    })

    it('throws error if secret not included', async () => {
      try {
        await tokenService.create(userId)
      } catch (ex) {
        let r = new RegExp(/secret/)
        assert.equal(r.test(ex), true)
      }
    })

    it('throws error if connectionKey not included', async () => {
      try {
        await tokenService.create(userId, secret)
      } catch (ex) {
        let r = new RegExp(/connectionKey/)
        assert.equal(r.test(ex), true)
      }
    })
  })

  describe('validate', () => {
    it('fails with invalid secret', async () => {
      let token = await tokenService.create(userId, secret, { connectionKey })

      try {
        await tokenService.validate(token, 'invalid secret', {}, connectionKey)
      } catch (ex) {
        return assert.equal(ex.message, 'invalid signature')
      }
      throw new Error('this line should not execute')
    })

    it('fails with modified token', async () => {
      let token = await tokenService.create(userId, secret, { connectionKey })
      token = token.slice(0, -1)
      try {
        await tokenService.validate(token, 'secret', {}, connectionKey)
      } catch (ex) {
        return assert.equal(ex.message, 'invalid signature')
      }
      throw new Error('this line should not execute')
    })

    it('fails when referenced token is not found', async () => {
      sandbox.stub(Token, 'findOne').returns(null)
      let token = await tokenService.create(userId, secret, { connectionKey })

      try {
        await tokenService.validate(token, 'secret', {}, connectionKey)
      } catch (ex) {
        return assert.equal(ex.message, 'invalid token')
      }
      throw new Error('this line should not execute')
    })

    it('fails when Token.findOne throws error', async () => {
      sandbox.stub(Token, 'findOne').throws('error')
      let token = await tokenService.create(userId, secret, { connectionKey })

      try {
        await tokenService.validate(token, 'secret', {}, connectionKey)
      } catch (ex) {
        let r = new RegExp(/error/)
        return assert.equal(r.test(ex), true)
      }
      throw new Error('this line should not execute')
    })

    it('fails when expired', async () => {
      let newDate = new Date()
      let opts = {
        expiresAt: newDate.setTime(newDate.getTime() - 10000000),
        connectionKey
      }
      let token = await tokenService.create(userId, secret, opts)
      try {
        await tokenService.validate(token, 'secret', {}, connectionKey)
      } catch (ex) {
        return assert.equal(ex.name, 'TokenExpiredError')
      }
      throw new Error('this line should not execute')
    })

    it('sets expected expiration', async () => {
      const expected = moment().add(2, 'weeks') // the default expiration
      const token = await tokenService.create(userId, secret, { connectionKey })
      const actual = moment.unix(jwt.decode(token).exp)
      const lowerBound = moment(expected).subtract(1, 'minute')
      const upperBound = moment(expected).add(1, 'minute')

      assert.ok(
        actual.isBetween(lowerBound, upperBound),
        'expiration in token should be CLOSE to the expected value'
      )
    })

    it('sets expected expiration when customized via moment', async () => {
      const expected = moment().add(2, 'months') // the default expiration
      const token = await tokenService.create(userId, secret, {
        expiresAt: expected,
        connectionKey
      })
      const actual = moment.unix(jwt.decode(token).exp)
      const lowerBound = moment(expected).subtract(1, 'minute')
      const upperBound = moment(expected).add(1, 'minute')

      assert.ok(
        actual.isBetween(lowerBound, upperBound),
        'expiration in token should be CLOSE to the expected value'
      )
    })

    it('sets expected expiration when customized via date', async () => {
      const expected = moment().add(2, 'weeks') // the default expiration
      const token = await tokenService.create(userId, secret, {
        expiresAt: expected.toDate(),
        connectionKey
      })
      const actual = moment.unix(jwt.decode(token).exp)
      const lowerBound = moment(expected).subtract(1, 'minute')
      const upperBound = moment(expected).add(1, 'minute')

      assert.ok(
        actual.isBetween(lowerBound, upperBound),
        'expiration in token should be CLOSE to the expected value'
      )
    })

    it('sets expected expiration when customized via millis', async () => {
      const expected = moment().add(2, 'weeks') // the default expiration
      const token = await tokenService.create(userId, secret, {
        expiresAt: expected.valueOf(),
        connectionKey
      })
      const actual = moment.unix(jwt.decode(token).exp)
      const lowerBound = moment(expected).subtract(1, 'minute')
      const upperBound = moment(expected).add(1, 'minute')

      assert.ok(
        actual.isBetween(lowerBound, upperBound),
        'expiration in token should be CLOSE to the expected value'
      )
    })

    it('validates when token id is an imported snowflakeId', async () => {
      let issuer = 'kuali.co'
      let expiresAt = moment().add(2, 'weeks')
      let snowflakeId = '1346972247374804096'
      let token = new Token({
        snowflakeId,
        userId,
        expiresAt
      })
      await token.save()

      let payload = {
        id: token.snowflakeId,
        iss: issuer,
        exp: expiresAt.unix(),
        iat: moment().unix()
      }

      const signedToken = jwt.sign(payload, 'secret')

      let validatedUser = await tokenService.validate(
        signedToken,
        'secret',
        {},
        connectionKey
      )
      assert.equal(validatedUser.userId, userId)
    })
  })

  describe('revoke', () => {
    it('returns true when token found and removed', async () => {
      let token = await Token.create({
        userId: '51c35e5ced18cb901d000001',
        expiresAt: 1
      })
      let result = await tokenService.revoke(
        token.id,
        { id: '123', role: 'admin' },
        connectionKey
      )
      assert.equal(result, true)
      token = await Token.findOne({ userId: '51c35e5ced18cb901d000001' })
      assert.equal(token, null)
    })

    it('returns true when token not found', async () => {
      let token = await Token.create({
        userId: '51c35e5ced18cb901d000001',
        expiresAt: 1
      })
      let result = await tokenService.revoke(
        '51c35e5ced18cb901d000001',
        { id: '123', role: 'admin' },
        connectionKey
      )
      assert.equal(result, true)
      token = await Token.findOne({ userId: '51c35e5ced18cb901d000001' })
      assert.equal(token.userId, '51c35e5ced18cb901d000001')
    })

    it('returns true when token id is invalid objectid', async () => {
      let token = await Token.create({
        userId: '51c35e5ced18cb901d000001',
        expiresAt: 1
      })
      let result = await tokenService.revoke(
        2,
        { id: '123', role: 'admin' },
        connectionKey
      )
      assert.equal(result, true)
      token = await Token.findOne({ userId: '51c35e5ced18cb901d000001' })
      assert.equal(token.userId, '51c35e5ced18cb901d000001')
    })

    it('throws exception if findOneAndRemove throws error', async () => {
      sandbox.stub(Token, 'findOne').returns(Bluebird.resolve(null))
      sandbox.stub(Token, 'findOneAndRemove').throws('Something Broke')
      try {
        await tokenService.revoke(
          2,
          { id: '123', role: 'admin' },
          connectionKey
        )
      } catch (e) {
        assert.equal(e.name, 'Something Broke')
        return
      }
      throw Error('Expected to catch exception')
    })

    it('throws UnauthorizedError if admin does not have access', async () => {
      let token = await Token.create({
        userId: '51c35e5ced18cb901d000001',
        expiresAt: 1
      })
      try {
        await tokenService.revoke(
          token.id,
          { id: '123', role: 'user' },
          connectionKey
        )
      } catch (e) {
        assert.equal(e.name, 'Error')
        return
      }
      throw Error('Expected to catch exception')
    })
  })

  describe('revokeUser', () => {
    it('removes all user tokens', async () => {
      await Token.remove({})
      await Token.create({
        userId: '51c35e5ced18cb901d000002',
        expiresAt: 1
      })
      await Token.create({
        userId: '51c35e5ced18cb901d000002',
        expiresAt: 1
      })
      await Token.create({
        userId: '51c35e5ced18cb901d000002',
        expiresAt: 1,
        type: 'apiKey'
      })
      let response = await tokenService.revokeUser(
        '51c35e5ced18cb901d000002',
        connectionKey
      )
      assert.equal(response, true)
      let tokens = await Token.find({ userId: '51c35e5ced18cb901d000002' })
      assert.equal(tokens.length, 1, 'should only find apiKey token')
    })

    it('succeeds if no tokens found for user', async () => {
      let response = await tokenService.revokeUser(
        '51c35e5ced18cb901d000001',
        connectionKey
      )
      assert.equal(response, true)
    })

    it('fails if find throws error', async () => {
      sandbox.stub(Token, 'find').throws()

      let response = await tokenService.revokeUser(
        '51c35e5ced18cb901d000001',
        connectionKey
      )
      assert.notEqual(response, true)
    })

    it('fails if findOneAndRemove throws error', async () => {
      sandbox.stub(Token, 'findOneAndRemove').throws()
      await Token.create({ userId: '51c35e5ced18cb901d000001', expiresAt: 1 })

      let response = await tokenService.revokeUser(
        '51c35e5ced18cb901d000001',
        connectionKey
      )
      assert.notEqual(response, true)
    })
  })

  describe('fetch', () => {
    beforeEach(() => {
      Token.collection.remove({})
    })

    it('throws error if userId not included', async () => {
      try {
        await tokenService.fetch()
      } catch (ex) {
        let r = new RegExp(/userId/)
        assert.equal(r.test(ex), true)
      }
    })

    it('throws error if userId is invalid object id', async () => {
      try {
        await tokenService.fetch('1234')
      } catch (ex) {
        let r = new RegExp(/userId/)
        assert.equal(r.test(ex), true)
      }
    })

    it('succeeds with valid payload', async () => {
      await tokenService.create(userId, secret, { connectionKey })
      let tokens = await tokenService.fetch(userId, null, connectionKey)
      assert.ok(tokens.length > 0, 'Token should have been found')
    })

    it('succeeds with valid payload specifying type', async () => {
      await tokenService.create(userId, secret, {
        type: 'apiKey',
        name: 'named-token',
        connectionKey
      })
      let tokens = await tokenService.fetch(userId, 'apiKey', connectionKey)
      assert.ok(tokens.length > 0, 'Token should have been found')
      assert.equal(tokens[0].type, 'apiKey')
    })

    it('succeeds but finds nothing with wrong type', async () => {
      await tokenService.create(userId, secret, { connectionKey })
      let tokens = await tokenService.fetch(userId, 'apiKey', connectionKey)
      assert.ok(tokens.length === 0)
    })
  })
})
