/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import express from 'express'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import auth from 'services/auth'
import * as tokenService from '../server/resources/tokens/utils'

let app = express()

app.use(auth)

const connectionKey = 'mongoose-connection-key'

let sandbox

describe('Token Seneca Plug-in', () => {
  beforeEach(() => {
    sandbox = sinon.sandbox.create()
  })
  afterEach(() => {
    sandbox.restore()
  })
  describe('sign', () => {
    it('throws when id is not present', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          connectionKey
        })
      } catch (e) {
        return //expected
      }
      throw new Error('error not thrown')
    })

    it('throws when secret is not present', async () => {
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'sign',
          id: 'id',
          connectionKey
        })
      } catch (e) {
        return //expected
      }
      throw new Error('error not thrown')
    })
  })
  describe('verify', () => {
    it('throws exception on exception', async () => {
      sandbox.stub(tokenService, 'validate').throws()
      try {
        await seneca.actAsync({
          role: 'token',
          cmd: 'verify',
          token: 'blank',
          secret: '',
          connectionKey
        })
      } catch (e) {
        return //expected
      }
      throw new Error('error not thrown')
    })
  })
})
