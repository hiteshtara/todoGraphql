/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { each } from 'lodash'
import auth from 'services/auth'
import express from 'express'
import 'services/users'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getUserModel } from 'services/users/server/resources/users/model'
import sinon from 'sinon'
import request from 'supertest-as-promised'
import institutionLoader from 'shared/institution-loader'
import responseLocals from 'shared/middleware/response-locals'

import { validate as validateToken } from '../server/resources/tokens/utils'

const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)
let sandbox

let authApp = express()
authApp.use((req, res, next) => {
  req.log = {
    audit() {},
    error() {}
  }
  next()
})
authApp.use(responseLocals)
authApp.use(institutionLoader)
authApp.use(auth)

describe('Auth Kuali', () => {

  beforeEach((done) => {
    sandbox = sinon.sandbox.create()
    User.collection.remove({}, done)
  })

  afterEach((done) => {
    sandbox.restore()
    User.collection.remove({}, done)
  })

  it('logs in by username successfully', async () => {
    let password = 'password'
    let user = await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    let res = await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
      .expect(200)
    let token = getTokenFromCookie(res)

    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: 'kuali' },
      connectionKey
    })
    let { userId } = await validateToken(token, value.secret, {}, connectionKey)
    assert.equal(userId, user.id.toString())
  })

  it('logs in by email successfully', async () => {
    let password = 'password'
    let user = await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    let res = await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('test@domain.org', password)
      .expect(200)
    let token = getTokenFromCookie(res)

    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: 'kuali' },
      connectionKey
    })

    let { userId } = await validateToken(token, value.secret, {}, connectionKey)

    assert.equal(userId, user.id.toString())
  })

  it('fails without a password', async () => {
    let password = ''
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
       .expect(401)
  })

  it('unapproved fails', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        approved: false,
        password
      },
      connectionKey })
    await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
       .expect(401)
  })

  it('fails when password is wrong', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('test', 'wrongpassword')
      .expect(401)
  })

  it('fails when username is wrong', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('wrongusername', password)
      .expect(401)
  })

  it('fails on error', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    sandbox.stub(User, 'findOne').yields({ error: true }, null)
    await request(authApp)
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
      .expect(500)
  })

  it('fails on request without institution', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })

    await request(auth)
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
      .expect(500)
  })

  it('fails and logs on request without institution', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    const mockLogger = getMockLogger()
    const spy = sinon.spy()
    mockLogger.setLog(spy)
    let tempAuth = express()
    tempAuth.use(mockLogger)
    tempAuth.use(auth)

    await request(tempAuth)
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
      .expect(500)
    sinon.assert.calledOnce(spy)
  })
})

function getTokenFromCookie(res) {
  let headers = res.headers
  let cookies = headers['set-cookie'][0]
  let result = {}
  let props = cookies.split('; ')
  each(props, p => {
    let kvp = p.split('=')
    result[kvp[0]] = kvp[1]
  })
  return result.authToken
}

function getMockLogger() {
  let log
  const logger = (req, res, next) => {
    req.log = log
    next()
  }
  logger.setLog = error => {
    log = { error }
  }
  return logger
}
