/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import sinon from 'sinon'
import { SamlConfigError } from '../server/strategies/utils/saml-helpers'
import errorHandler from '../server/utils/error-handler'

let sandbox

describe('Error Handler', () => {

  beforeEach( () => {
    sandbox = sinon.sandbox.create()
  })

  afterEach(() => {
    sandbox.restore()
  })
  it('logs non-saml errors', () => {
    let sendSpy = sinon.spy()
    errorHandler({}, {}, { status: () => {
      return { send: sendSpy }
    } })
    assert(sendSpy.called)
  })
  it('send template for saml config errors', () => {
    let errorStub = sandbox.stub(console, 'error')
    let sendSpy = sinon.spy()
    errorHandler(new SamlConfigError(), {},
      { status: () => {
        return { send: sendSpy }
      } }
    )
    assert(!errorStub.called)
    assert(sendSpy.called)
  })
  it('send template for invalid signature errors', () => {
    let errorStub = sandbox.stub(console, 'error')
    let sendSpy = sinon.spy()
    errorHandler(new Error('Invalid signature'), {},
      { status: () => {
        return { send: sendSpy }
      } }
    )
    assert(!errorStub.called)
    assert(sendSpy.called)
  })
})
