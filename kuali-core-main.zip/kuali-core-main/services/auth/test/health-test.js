/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import request from 'supertest-as-promised'
import express from 'express'
import authApp from 'services/auth'
import responseLocals from 'shared/middleware/response-locals'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getTokenModel } from '../server/resources/tokens/model'
import { getInCommonModel } from '../server/resources/in-common/model'

let app

const { connection } = getTestConnectionInfo()

describe('Auth health checks', () => {
  before(async () => {
    app = express()
    app.use(responseLocals)
    app.use(authApp)

    const Token = getTokenModel(connection)
    const InCommon = getInCommonModel(connection)

    await Token.create({
      expiresAt: Date.now(),
      userId: '576dc52575c9366d40be02aa'
    })

    await InCommon.create({
      idp: 'test'
    }).catch((err) => {
      if (err.code === 11000) return
      throw err
    })
  })

  it('returns 204 for /api/v1/auth/health', async () => {
    await request(app)
      .get('/api/v1/auth/health')
      .expect(204)
  })
})
