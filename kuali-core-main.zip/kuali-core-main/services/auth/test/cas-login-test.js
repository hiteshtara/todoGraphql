/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import express from 'express'
import { map } from 'lodash'
import nock from 'nock'
import auth from 'services/auth'
import institutionPlugin from 'services/institution/plugin'
import usersPlugin from 'services/users/server/resources/users/plugin'
import institutionLoader from 'shared/institution-loader'
import responseLocals from 'shared/middleware/response-locals'
import seneca from 'shared/seneca'
import request from 'supertest-as-promised'
import sinon from 'sinon'
import { expect } from 'chai'

const casServiceUrl = 'https://kuali-cas-server.herokuapp.com'
const curUrl = encodeURIComponent('https://kuali.kuali.co/auth/cas')
const validCasResponse = '<serviceresponse><authenticationsuccess>true</authenticationsuccess></serviceresponse>' // eslint-disable-line
const validCas20Response = `<cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'><cas:authenticationSuccess><cas:user>s002673</cas:user></cas:authenticationSuccess></cas:serviceResponse>` // eslint-disable-line
const connectionKey = 'mongoose-connection-key'

let app
let sandbox

describe('Basic CAS Login', () => {
  before(async () => {
    seneca.use(institutionPlugin)
    seneca.use(usersPlugin)
    app = express()
    app.use((req, res, next) => {
      req.log = {
        audit() {},
        error() {}
      }
      next()
    })
    app.use(responseLocals)
    app.use(institutionLoader)
    app.use(auth)
  })
  beforeEach(async () => {
    nock.cleanAll()
    await clearInstitutions()
    await clearUsers()
    sandbox = sinon.sandbox.create()
  })
  afterEach(() => {
    sandbox.restore()
  })
  it('redirects to appropriate host', async () => {
    await saveValidInstitution()
    const res = await request(app)
      .get('/auth')
      .expect(302)
    assert.equal(res.header.location, '/auth/cas')
  })

  describe('CAS1.0', () => {
    it('redirects you to the right url with the right data', async () => {
      await saveValidInstitution()
      const res = await request(app)
        .get('/auth/cas')
        .expect(302)
      assert.equal(
        res.header.location,
        `${casServiceUrl}/login?service=${curUrl}`
      )
    })
    it('properly fetches the token information and processes it', async () => {
      await saveValidInstitution()
      await saveValidUser('johnsmith')
      const ticket = Math.floor(Math.random() * 100000)
      const casCall = nock(casServiceUrl)
        .get(`//validate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, 'yes\njohnsmith')
      const res = await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(302)
      casCall.done()
      assert.equal(res.header.location, '/apps/')
      assert.equal(res.header['set-cookie'][0].indexOf('authToken='), 0)
    })
    it(`creates a user, properly fetches the token information
        and processes it when the user doesn't exist`, async () => {
      await saveValidInstitution()
      const ticket = Math.floor(Math.random() * 100000)
      const casCall = nock(casServiceUrl)
        .get(`//validate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, 'yes\njohnsmith')
      const res = await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(302)
      casCall.done()
      assert.equal(res.header.location, '/apps/')
      assert.equal(res.header['set-cookie'][0].indexOf('authToken='), 0)
      const users = await seneca.actAsync({
        role: 'users',
        cmd: 'list',
        connectionKey
      })
      assert.equal(users[0].username, 'johnsmith')
      assert.equal(users[0].ssoId, 'johnsmith')
    })
    it('creates a user, but notifies that it isn\'t approved', async () => {
      await saveValidInstitution({ approval: 'manual' })
      const ticket = Math.floor(Math.random() * 100000)
      const casCall = nock(casServiceUrl)
        .get(`//validate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, 'yes\njohnsmith')
      const res = await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(302)
      casCall.done()
      const users = await seneca.actAsync({
        role: 'users',
        cmd: 'list',
        connectionKey
      })
      assert.equal(res.header.location, '/auth/kuali/#/needsApproval')
      assert.equal(users[0].username, 'johnsmith')
      assert.equal(users[0].ssoId, 'johnsmith')
    })

    it('throws an error when an error happens', async () => {
      await saveValidInstitution()
      const ticket = Math.floor(Math.random() * 100000)

      let originalAct = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', (pattern) => {
        if (pattern.role === 'users' && pattern.cmd === 'list') {
          return Promise.reject(new Error('error from stub'))
        }
        return originalAct(pattern)
      })
      const casCall = nock(casServiceUrl)
        .get(`//validate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, 'yes\njohnsmith')
      const res = await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(401)
      casCall.done()
      expect(res.text).to.have.string('error from stub')
    })

    it('redirects to cas server on logout', async () => {
      const service = encodeURIComponent('http://kuali.kuali.co/apps/')
      await saveValidInstitution({ casForceLogout: true })
      await request(app)
        .get('/auth/signout')
        .set('referrer', 'http://kuali.kuali.co/apps/')
        .expect(302)
        .expect(
          'Location',
          `https://kuali-cas-server.herokuapp.com/logout?service=${service}`
        )
    })

    it('does not have service= in url if no referrer', async () => {
      await saveValidInstitution({ casForceLogout: true })
      await request(app)
        .get('/auth/signout')
        .expect(302)
        .expect(
          'Location',
          'https://kuali-cas-server.herokuapp.com/logout?service='
        )
    })

    it('redirects to cas server on logout with service', async () => {
      const service = encodeURIComponent('http://example.com/')
      await saveValidInstitution({
        casForceLogout: true
      })
      await request(app)
        .get(`/auth/signout?redirect_to=${service}`)
        .expect(302)
        .expect(
          'Location',
          `https://kuali-cas-server.herokuapp.com/logout?service=${service}`
        )
      await request(app)
        .get(`/auth/signout?return_to=${service}`)
        .expect(302)
        .expect(
          'Location',
          `https://kuali-cas-server.herokuapp.com/logout?service=${service}`
        )
    })
  })

  describe('CAS2.0', () => {
    it('redirects you to the right url with the right data', async () => {
      await saveValidInstitution({ casVersion: 'CAS2.0' })
      const res = await request(app)
        .get('/auth/cas')
        .expect(302)
      assert.equal(
        res.header.location,
        `${casServiceUrl}/login?service=${curUrl}`
      )
    })
    it('properly fetches the token information and processes it', async () => {
      await saveValidInstitution({ casVersion: 'CAS2.0' })
      const ticket = Math.floor(Math.random() * 100000)
      const casCall = nock(casServiceUrl)
        .get(`//serviceValidate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, validCas20Response)
      await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(302)
      casCall.done()
    })
    it('fails if it has not user property', async () => {
      await saveValidInstitution({ casVersion: 'CAS2.0' })
      const ticket = Math.floor(Math.random() * 100000)
      const casCall = nock(casServiceUrl)
        .get(`//serviceValidate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, validCasResponse)
      const res = await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(401)
      casCall.done()
      expect(res.text).to.have.string('Error authenticating')
    })
  })

  describe('CAS3.0', () => {
    it('redirects you to the right url with the right data', async () => {
      await saveValidInstitution({ casVersion: 'CAS3.0' })
      const res = await request(app)
        .get('/auth/cas')
        .expect(302)
      assert.equal(
        res.header.location,
        `${casServiceUrl}/login?service=${curUrl}`
      )
    })
    it('properly fetches the token information and processes it', async () => {
      await saveValidInstitution({ casVersion: 'CAS3.0' })
      const ticket = Math.floor(Math.random() * 100000)
      const casCall = nock(casServiceUrl)
        .get(`//p3/serviceValidate?ticket=${ticket}&service=${curUrl}`)
        .reply(200, validCasResponse)
      const res = await request(app)
        .get('/auth/cas')
        .query({ ticket })
        .expect(401)
      casCall.done()
      expect(res.text).to.have.string('Not Implemented')
    })
  })

})

async function saveValidInstitution(options = {}) {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: Object.assign({
      secret: 'woooooo',
      subdomain: 'kuali',
      name: 'Kuali',
      provider: 'cas',
      casVersion: 'CAS1.0',
      casServiceUrl
    }, options),
    connectionKey
  })
}

async function saveValidUser(uid) {
  await seneca.actAsync({
    role: 'users',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: {
      username: 'person',
      uid
    },
    connectionKey
  })
}

async function clearInstitutions() {
  const institutions = await seneca.actAsync({
    role: 'institutions',
    cmd: 'list',
    connectionKey
  })
  await Promise.all(map(institutions, ({ id }) =>
    seneca.actAsync({
      role: 'institutions',
      currentUser: { id: 'test' },
      cmd: 'remove',
      id,
      connectionKey
    })
  ))
}

async function clearUsers() {
  const users = await seneca.actAsync({
    role: 'users',
    currentUser: { id: 'test' },
    cmd: 'list', connectionKey
  })
  await Promise.all(map(users, ({ id }) =>
    seneca.actAsync({ role: 'users', connectionKey,
    currentUser: { id: 'test' }, cmd: 'remove', id })
  ))
}
