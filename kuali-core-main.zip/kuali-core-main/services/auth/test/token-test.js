/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import sinon from 'sinon'
import { defaultLogger } from 'shared/logging'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getTokenModel } from '../server/resources/tokens/model'

let validToken = {
  userId: '51c35e5ced18cb901d000001',
  expiresAt: tomorrow()
}

const { connection } = getTestConnectionInfo()
let Token = getTokenModel(connection)
let token

describe('Token', () => {
  let sandbox

  beforeEach(done => {
    token = new Token(validToken)
    token.save(done)
    sandbox = sinon.sandbox.create()
  })

  afterEach( () => {
    sandbox.restore()
  })

  describe('Defaults', () => {
    it('sets id', () => {
      assert.notEqual(token.id, null)
    })

    it('sets type to user', () => {
      assert.equal(token.type, 'user')
    })
  })

  it('logs a fatal error on index error', done => {
    const spy = sandbox.spy(defaultLogger, 'fatal')
    Token.emit('index', new Error('test'))
    sinon.assert.calledOnce(spy)
    done()
  })
})

describe('Validations', () => {
  describe('userId', () => {
    it('is required', done => {
      token = new Token()
      token.validate(err => {
        assert.notEqual(err.errors.userId, undefined)
        done()
      }).catch(() => {})
    })
  })

  describe('expiresAt', () => {
    it('is required', done => {
      token = new Token()
      token.validate(err => {
        assert.notEqual(err.errors.expiresAt, undefined)
        done()
      }).catch(() => {})
    })
  })

  describe('type', () => {
    it('must be valid', done => {
      token = new Token({ type: 'bad type' })
      token.validate(err => {
        assert.notEqual(err.errors.type, undefined)
        done()
      }).catch(() => {})
    })
  })
})

function tomorrow() {
  let newDate = new Date()
  return newDate.setDate(newDate.getDate() + 1)
}
