/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import express from 'express'
import { expect } from 'chai'
import { each } from 'lodash'
import request from 'supertest-as-promised'
import seneca from 'shared/seneca'
import auth from 'services/auth'
import institutionLoader from 'shared/institution-loader'
import institutionPlugin from 'services/institution/plugin'
import responseLocals from 'shared/middleware/response-locals'
import sinon from 'sinon'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getInstitutionModel } from 'services/institution/model'
import { getUserModel } from 'services/users/server/resources/users/model'
import * as helpers from 'services/auth/server/strategies/utils/saml-helpers'
import { validate as validateToken } from '../server/resources/tokens/utils'

const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)
let Institution = getInstitutionModel(connection)

let app
describe('LDAP', () => {
  let sandbox
  before(() => {
    seneca.use(institutionPlugin)
    app = express()
    app.use((req, res, next) => {
      req.log = {
        audit() {},
        error() {}
      }
      next()
    })
    app.use(responseLocals)
    app.use(institutionLoader)
    app.use(auth)
  })

  beforeEach(async () => {
    await Institution.remove({})
    await User.collection.remove()
    sandbox = sinon.sandbox.create()
  })

  afterEach( () => {
    sandbox.restore()
  })

  it('redirects to appropriate host', async () => {
    await saveValidInstitution()
    let res = await request(app)
      .get('/auth')
      .expect(302)
    expect(res.header.location).to.equal('/auth/kuali?provider=ldap')
  })

  it('redirects to appropriate host with other query params', async () => {
    await saveValidInstitution()
    let res = await request(app)
      .get('/auth?redirect=duh')
      .expect(302)
    expect(res.header.location).to
      .equal('/auth/kuali?redirect=duh&provider=ldap')
  })

  it('logs in by username successfully', async () => {
    await saveValidInstitution()
    let password = 'password'
    let user = await seneca.actAsync({ role: 'users', cmd: 'save',
      currentUser: { id: 'test' }, data: {
      firstName: 'jerry', lastName: 'seinfeld', uid: 'jerry',
      username: 'jerry', name: 'jerry', email: 'jerry@seinfeld.com',
      role: 'user',
      password
    }, connectionKey })
    sandbox.stub(helpers, 'fetchUser').returns(
      new Promise((accept) => {
        accept(user)
      })
    )
    sandbox.stub(helpers, 'maybeUpdateUser').returns(
      new Promise((accept) => {
        accept(user)
      })
    )
    sandbox.stub(helpers, 'getAttrs').returns(user)
    sandbox.stub(helpers, 'ensure')
    let res = await request(app)
      .post('/api/v1/auth/ldap')
      .send({
        password,
        username: 'username'
      })
      .expect(200)
    let token = getTokenFromCookie(res)

    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: 'kuali' },
      connectionKey
    })

    let tokenId = await validateToken(token, value.secret, {}, connectionKey)
    expect(tokenId).to.exist // eslint-disable-line no-unused-expressions
  })

  it('creates new user successfully', async () => {
    await saveValidInstitution()
    let password = 'password'
    let user = await seneca.actAsync({ role: 'users', cmd: 'save',
      currentUser: { id: 'test' }, data: {
      firstName: 'jerry', lastName: 'seinfeld', uid: 'jerry',
      username: 'jerry', name: 'jerry', email: 'jerry@seinfeld.com',
      role: 'user',
      password
    }, connectionKey })
    sandbox.stub(helpers, 'fetchUser').returns(
      new Promise((accept) => {
        accept(null)
      })
    )
    sandbox.stub(helpers, 'saveUser').returns(
      new Promise((accept) => {
        accept(user)
      })
    )
    sandbox.stub(helpers, 'getAttrs').returns(user)
    sandbox.stub(helpers, 'ensure')
    let res = await request(app)
      .post('/api/v1/auth/ldap')
      .send({
        password,
        username: 'username'
      })
      .expect(200)
    let token = getTokenFromCookie(res)

    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: 'kuali' },
      connectionKey
    })

    let tokenId = await validateToken(token, value.secret, {}, connectionKey)
    expect(tokenId).to.exist // eslint-disable-line no-unused-expressions
  })

  it('creates new user but isn\'t approved', async () => {
    await saveValidInstitution({ approval: 'manual' })
    let password = 'password'
    let user = await seneca.actAsync({ role: 'users', cmd: 'save',
      currentUser: { id: 'test' }, data: {
      firstName: 'jerry', lastName: 'seinfeld', uid: 'jerry',
      username: 'jerry', name: 'jerry', email: 'jerry@seinfeld.com',
      role: 'user',
      password
    }, connectionKey })
    sandbox.stub(helpers, 'fetchUser').returns(
      new Promise((accept) => {
        accept(null)
      })
    )
    sandbox.stub(helpers, 'saveUser').returns(
      new Promise((accept) => {
        accept(user)
      })
    )
    sandbox.stub(helpers, 'getAttrs').returns(user)
    sandbox.stub(helpers, 'ensure')
    const res = await request(app)
      .post('/api/v1/auth/ldap')
      .send({
        password,
        username: 'username'
      })
      .expect(401)
    expect(res).to.have.deep.property('body.redirect',
      '/auth/kuali/#/needsApproval')
  })

  it('returns 401 on exception', async () => {
    await saveValidInstitution()
    let password = 'password'
    sandbox.stub(helpers, 'getAttrs').throws(new Error())
    await request(app)
      .post('/api/v1/auth/ldap')
      .send({
        password,
        username: 'username'
      })
      .expect(401)
  })
})

async function saveValidInstitution(props = {}) {
  await seneca.actAsync({
    role: 'institutions',
    cmd: 'save',
    currentUser: { id: 'test' },
    data: Object.assign({ 'secret':
      'f5542d5480a3b8b184263b2617f08a899570cdaaa1634c2b5dff1ec4559922f74083039c467b98ddf42b7e7618912e6b4586a60fe3913debac38494884a52de9b232f3bd57a4a11f534cfa934f1d374d5dbb416affdde8373f416561edef3767',// eslint-disable-line
      'subdomain': 'kuali', 'name': 'Kuali', 'forceAuthn': false,
      'signInExpiresWithSession': true, 'signInExpiresIn': 1209600000,
      'provider': 'ldap' }, props),
    connectionKey
  })
}

function getTokenFromCookie(res) {
  let headers = res.headers
  let cookies = headers['set-cookie'][0]
  let result = {}
  let props = cookies.split('; ')
  each(props, p => {
    let kvp = p.split('=')
    result[kvp[0]] = kvp[1]
  })
  return result.authToken
}
