/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/*eslint-disable no-unused-expressions*/
import { expect, assert } from 'chai'
import sinon from 'sinon'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getInstitutionModel } from 'services/institution/model'
import { tokenize } from '../server/resources/tokens/utils'

let sandbox
const { connection, connectionKey } = getTestConnectionInfo()
const Institution = getInstitutionModel(connection)

describe('Tokenize middleware', () => {

  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await Institution.collection.remove()
  })

  afterEach( () => {
    sandbox.restore()
  })

  it('sets token and cookie', async () => {
    const institution = await seneca.actAsync({
      role: 'institutions',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        subdomain: 'gotham',
        name: 'Gotham University',
        secret: 'supersecret',
        provider: 'kuali',
        signInExpiresWithSession: true,
        forceAuthn: true
      },
      connectionKey
    })
    let req = {
      user: {
        id: '123456789012345678901234',
        approved: true
      },
      institution,
      log: {
        audit() {},
        error() {}
      }
    }
    const cookies = {}
    let res = {
      cookie(name, value, opts) {
        cookies[name] = { value, opts }
      },
      locals: {
        connection,
        connectionKey
      }
    }
    await tokenize('test')(req, res, err => {
      if (err) throw err
      expect(req.user.token).to.exist
      expect(cookies.authToken.value).to.be.equal(req.user.token)
      expect(cookies.authToken.opts).to.not.contain.key('maxAge')
    })
  })

  it('sets token and cookie with expiration', async () => {
    const institution = await seneca.actAsync({
      role: 'institutions',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        subdomain: 'gotham2',
        name: 'Gotham University',
        secret: 'supersecret',
        provider: 'kuali',
        signInExpiresWithSession: false,
        signInExpiresIn: 1000,
        forceAuthn: true
      },
      connectionKey
    })
    let req = {
      user: {
        id: '123456789012345678901234',
        approved: true
      },
      institution,
      log: {
        audit() {},
        error() {}
      }
    }
    const cookies = {}
    let res = {
      cookie(name, value, opts) {
        cookies[name] = { value, opts }
      },
      locals: {
        connection,
        connectionKey
      }
    }
    await tokenize('test')(req, res, err => {
      if (err) throw err
      expect(req.user.token).to.exist
      expect(cookies.authToken.value).to.be.equal(req.user.token)
      expect(cookies.authToken.opts).to.have.property('maxAge', 1000)
    })
  })

  it('sets token and cookie with default expiration', async () => {
    const institution = await seneca.actAsync({
      role: 'institutions',
      cmd: 'save',
      currentUser: { id: 'test' },
      data: {
        subdomain: 'gotham2',
        name: 'Gotham University',
        secret: 'supersecret',
        provider: 'kuali',
        signInExpiresWithSession: false,
        forceAuthn: true
      },
      connectionKey
    })
    delete institution.signInExpiresIn
    let req = {
      user: {
        id: '123456789012345678901234',
        approved: true
      },
      institution,
      log: {
        audit() {},
        error() {}
      }
    }
    const cookies = {}
    let res = {
      cookie(name, value, opts) {
        cookies[name] = { value, opts }
      },
      locals: {
        connection,
        connectionKey
      }
    }
    await tokenize('test')(req, res, err => {
      if (err) throw err
      expect(req.user.token).to.exist
      expect(cookies.authToken.value).to.be.equal(req.user.token)
      expect(cookies.authToken.opts).to.have.property('maxAge', 1209600)
    })
  })

  it('gives an error when errors occur', done => {
    let req = {
      user: {
        id: '123456789012345678901234'
      },
      institution: {
        subdomain: 'doesntexist'
      }
    }

    let res = {
      cookie(name, value) {
        this._cookieValue = value
      },
      locals: {
        connection,
        connectionKey
      }
    }

    tokenize('test')(req, res, err => {
      assert.notEqual(err, undefined)
      done()
    })
  })
})
/*eslint-enable*/
