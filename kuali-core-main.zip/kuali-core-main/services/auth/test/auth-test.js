/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect, assert } from 'chai'
import auth from 'services/auth'
import express from 'express'
import seneca from 'shared/seneca'
import request from 'supertest-as-promised'
import usersApp from 'services/users'
import { getUserModel } from 'services/users/server/resources/users/model'
import { getTestConnectionInfo } from 'shared/test-helpers'
import institutionLoader from 'shared/institution-loader'
import responseLocals from 'shared/middleware/response-locals'
import { readFile } from 'fs-promise'
import path from 'path'

let app
let authApp
const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)
const samlMeta = readFile(path.resolve(__dirname, '../server/samlMeta.xml'),
  'utf-8')
const samlMeta2 = readFile(path.resolve(__dirname, '../server/samlMeta2.xml'),
  'utf-8')

describe('Auth', () => {

  before(() => {
    app = express()
    app.use(responseLocals)
    app.use(institutionLoader)
    app.use(usersApp)

    authApp = express()
    authApp.use((req, res, next) => {
      req.log = {
        audit() {},
        error() {},
        warn() {}
      }
      next()
    })
    authApp.use(responseLocals)
    authApp.use(institutionLoader)
    authApp.use(auth)
  })

  beforeEach((done) => {
    User.collection.remove({}, done)
  })

  afterEach((done) => {
    User.collection.remove({}, done)
  })

  it('returns SAML meta correctly', async () => {
    let res = await request(authApp).get('/auth/saml/meta').expect(200)
    expect(res.get('content-type')).to.contain('application/xml')
    expect(res.text).to.be.equal(await samlMeta)
  })

  it('returns SAML meta 2 correctly', async () => {
    let res = await request(authApp).get('/auth/saml/meta2').expect(200)
    expect(res.get('content-type')).to.contain('application/xml')
    expect(res.text).to.be.equal(await samlMeta2)
  })

  it('redirects to appropriate host', async () => {
    let res = await request(authApp)
      .get('/auth')
      .expect(302)
    assert.equal(res.header.location, '/auth/kuali')
  })
  it('redirects to appropriate host with query string', async () => {
    let res = await request(authApp)
      .get('/auth?redirect_to=/location')
      .expect(302)
    assert.equal(res.header.location, '/auth/kuali?redirect_to=%2Flocation')
  })
  describe('signout', () => {
    it('signs out the user', async () => {
      let password = 'password'
      await seneca.actAsync({ role: 'users', cmd: 'save',
          currentUser: { id: 'test' }, data: {
          username: 'test',
          email: 'test@domain.org',
          role: 'user',
          password
        },
        connectionKey })
      let res = await request(authApp)
        .post('/api/v1/auth/authenticate')
        .auth('test', password)
        .expect(200)

      let headers = res.headers
      let cookies = headers['set-cookie'][0]
      let req = request(app)
        .get('/api/v1/users/current')
        .set('Authorization', `Bearer ${/authToken=(.+?);/.exec(cookies)[1]}`)
      req.cookies = cookies
      res = await req.expect(200)

      req = request(authApp)
        .get('/auth/signout')
      req.cookies = cookies
      res = await req.expect(302).expect('set-cookie', /authToken=;/)


      assert.equal(res.header.location, '/apps/')
      await request(app)
        .get('/api/v1/users/current')
        .expect(401)
    })
    it('pretends to sign out when there is no user', async () => {
      let req = request(authApp)
        .get('/auth/signout')
      let res = await req.expect(302).expect('set-cookie', /authToken=;/)
      assert.equal(res.header.location, '/apps/')
    })
  })
})
