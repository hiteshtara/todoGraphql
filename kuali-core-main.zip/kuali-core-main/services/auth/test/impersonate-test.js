/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import { each } from 'lodash'
import auth from 'services/auth'
import express from 'express'
import 'services/users'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import request from 'supertest-as-promised'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getInstitutionModel } from 'services/institution/model'
import { getUserModel } from 'services/users/server/resources/users/model'
import * as utils from '../server/resources/tokens/utils'

const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)
let Institution = getInstitutionModel(connection)
let sandbox

const validateToken = utils.validate

let admin, admin2, admin3
let user
let institution1
let authApp = express()
authApp.use((req, res, next) => {
  req.log = {
    audit() {},
    error() {}
  }
  next()
})
authApp.use((req, res, next) => {
  req.institution = institution1
  next()
})
authApp.use(auth)

async function getSecretFor(subdomain) {
  let value = await seneca.actAsync({
    role: 'institutions',
    cmd: 'getSecret',
    data: { subdomain },
    connectionKey
  })

  return value.secret
}

async function getAuthHeader(userId, subdomain) {
  let secret = await getSecretFor(subdomain)

  let token = await seneca.actAsync({
    role: 'token',
    cmd: 'sign',
    id: userId,
    secret,
    connectionKey
  })

  return `Bearer ${token.token}`
}

describe('Impersonate', () => {
  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await User.remove({})
    await Institution.remove({})
    institution1 = await seneca.actAsync({
      role: 'institutions',
      cmd: 'save',
      data: { subdomain: 'kuali.what', name: 'hey', secret: 'secret',
        features: { impersonation: true } },
      currentUser: { id: 'test' },
      connectionKey
    })
    admin = await seneca.actAsync({ role: 'users', cmd: 'save', data: {
      username: 'captain',
      email: 'captain@domain.org',
      role: 'admin'
    }, connectionKey,
      currentUser: { id: 'test' } })
    admin2 = await seneca.actAsync({ role: 'users', cmd: 'save', data: {
      username: 'captain2',
      email: 'captain2@domain.org',
      role: 'admin'
    }, connectionKey,
      currentUser: { id: 'test' } })
    admin3 = await seneca.actAsync({ role: 'users', cmd: 'save', data: {
      username: 'captain3',
      email: 'captain3@domain.org',
      snowflakeId: '1222666434012523114',
      role: 'admin'
    }, connectionKey,
      currentUser: { id: 'test' } })
    user = await seneca.actAsync({ role: 'users', cmd: 'save', data: {
      username: 'private',
      email: 'private@domain.org',
      role: 'user'
    }, connectionKey,
      currentUser: { id: 'test' } })
  })

  afterEach(async () => {
    sandbox.restore()
    await User.remove({})
    await Institution.remove({})
  })
  it('impersonates successfully', async () => {

    let authHeader = await getAuthHeader(admin.id, institution1.subdomain)
    let res = await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user })
      .expect(200)
    let token = getTokenFromCookie(res)

    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: 'kuali.what' },
      connectionKey
    })
    let { userId } = await validateToken(token, value.secret, {}, connectionKey)

    expect(userId.toString()).to.equal(user.id.toString())
  })
  it('impersonates from snowflakeId successfully', async () => {

    let authHeader = await getAuthHeader(admin3.id, institution1.subdomain)
    let res = await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user })
      .expect(200)
    let token = getTokenFromCookie(res)

    let value = await seneca.actAsync({
      role: 'institutions',
      cmd: 'getSecret',
      data: { subdomain: 'kuali.what' },
      connectionKey
    })
    let { userId } = await validateToken(token, value.secret, {}, connectionKey)

    expect(userId.toString()).to.equal(user.id.toString())
  })
  it('cannot impersonate without user', async () => {

    let authHeader = await getAuthHeader(admin.id, institution1.subdomain)
    await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({})
      .expect(400)
  })
  it('cannot impersonate when already impersonating', async () => {

    let authHeader = await getAuthHeader(admin.id, institution1.subdomain)
    let res = await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user: admin2 })
      .expect(200)
    let token = getTokenFromCookie(res)

    await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', `Bearer ${token}`)
      .send({ user })
      .expect(400)
  })
  it('cannot impersonate with user role', async () => {

    let authHeader = await getAuthHeader(user.id, institution1.subdomain)
    await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user: admin })
      .expect(403)
  })
  it('returns error on error', async () => {
    sandbox.stub(utils, 'tokenize').returns((req, res, next) => {
      next(new Error())
    })

    let authHeader = await getAuthHeader(admin.id, institution1.subdomain)
    await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user })
      .expect(500)
  })
  it('returns error and logs error on error', async () => {
    sandbox.stub(utils, 'tokenize').returns((req, res, next) => {
      next(new Error())
    })

    let authHeader = await getAuthHeader(admin.id, institution1.subdomain)
    const mockLogger = getMockLogger()
    const spy = sinon.spy()
    mockLogger.setLog(spy)
    let tempAuth = express()
    tempAuth.use(mockLogger)
    tempAuth.use(authApp)
    await request(tempAuth)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user })
      .expect(500)
  })
  it('is not found if institution lacks impersonate feature', async () => {
    institution1.features = {}
    await seneca.actAsync({
      role: 'institutions',
      cmd: 'save',
      data: institution1,
      currentUser: { id: 'test' },
      connectionKey
    })
    let authHeader = await getAuthHeader(admin.id, institution1.subdomain)
    await request(authApp)
      .post('/api/v1/auth/impersonate')
      .set('Authorization', authHeader)
      .send({ user })
      .expect(404)
  })
})

function getTokenFromCookie(res) {
  let headers = res.headers
  let cookies = headers['set-cookie'][0]
  let result = {}
  let props = cookies.split('; ')
  each(props, p => {
    let kvp = p.split('=')
    result[kvp[0]] = kvp[1]
  })
  return result.authToken
}

function getMockLogger() {
  let log
  const logger = (req, res, next) => {
    req.log = log
    next()
  }
  logger.setLog = error => {
    log = { error }
  }
  return logger
}
