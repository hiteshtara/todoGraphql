/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import auth from 'services/auth'
import express from 'express'
import seneca from 'shared/seneca'
import sinon from 'sinon'
import moment from 'moment'
import request from 'supertest-as-promised'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getUserModel } from 'services/users/server/resources/users/model'
import { getInstitutionModel } from 'services/institution/model'
import { getTokenModel } from 'services/auth/server/resources/tokens/model'
import { getModel as getApplicationModel } from 'services/apps/server/model'
import {
  getRawTemplateModel
} from 'services/notifications/server/models/template'
import ServiceAgent from 'service2service'
import config from 'config'

const { connection, connectionKey } = getTestConnectionInfo()
const Institution = getInstitutionModel(connection)
const User = getUserModel(connection)
const Token = getTokenModel(connection)
const Application = getApplicationModel(connection)
let Template = getRawTemplateModel(connection)
let sandbox
let authApp
let authToken
let institution
let user1, user2, user3, user4
let application

const agent = new ServiceAgent({
  secret: config.get('serviceSecret'),
  expire: 60 // 1 minute
})

describe('Token Routes', () => {
  before(async () => {
    authApp = express()
    authApp.use((req, res, next) => {
      req.log = {
        audit() {},
        error() {}
      }
      next()
    })
    authApp.use(auth)
  })

  beforeEach(async () => {
    await Institution.remove({})
    await Token.remove({})
    await User.remove({})
    await Application.remove({})
    await Template.remove({})
    sandbox = sinon.sandbox.create()
    institution = await Institution.create({
      name: 'test',
      subdomain: 'impersonate-test',
      secret: 'keyboard cat',
      updatedBy: { id: 'test' }
    })
    user1 = await User.create({
      username: 'trtester1',
      firstName: 'Roger',
      email: 'test1@kuali.co',
      role: 'admin',
      updatedBy: { id: 'test' }
    })
    user2 = await User.create({
      username: 'trtester2',
      firstName: 'George',
      email: 'test2@kuali.co',
      role: 'admin',
      updatedBy: { id: 'test' }
    })
    user3 = await User.create({
      username: 'trtester3',
      role: 'admin',
      updatedBy: { id: 'test' }
    })
    user4 = await User.create({
      email: 'trtester4@kuali.co',
      role: 'user',
      updatedBy: { id: 'test' }
    })
    application = await seneca.actAsync({
      role: 'apps',
      cmd: 'create',
      application: { displayName: 'tokens test app' },
      user: { id: 'test' },
      connectionKey
    })
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'create',
      template: {
        displayName: 'user-expiring-keys',
        applicationId: application.id,
        subject: 'Expired Keys',
        templates: {
          email: {
            text: 'These keys have expired:\r\nkeyNames'
          }
        }
      },
      connectionKey,
      currentUser: { id: 'test' }
    })
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'create',
      template: {
        displayName: 'admin-expiring-keys',
        applicationId: application.id,
        subject: 'Expiring Keys',
        templates: {
          email: {
            text: 'These keys are expiring:\r\nkeyNames'
          }
        }
      },
      connectionKey,
      currentUser: { id: 'test' }
    })
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('/api/v1/tokens/notifyUsers', () => {
    beforeEach(async () => {
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().subtract(1, 'days'),
          name: 'Expired Yesterday'
        },
        id: user1.id,
        currentUser: { id: user1.id, role: 'user' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().subtract(1, 'days'),
          name: 'Also Expired Yesterday'
        },
        id: user1.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().subtract(1, 'days'),
          name: 'Expired Yesterday but no email'
        },
        id: user3.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(7, 'days'),
          name: 'Super Stupid Name'
        },
        id: user1.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(7, 'days'),
          name: 'Super Stupid Name'
        },
        id: user4.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(7, 'days'),
          name: 'Other Stupid Name'
        },
        id: user2.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(7, 'days'),
          name: 'Smart Name'
        },
        id: user2.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(14, 'days'),
          name: 'Yet another Stupid Name'
        },
        id: user3.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
    })
    it('notifies each user', async () => {
      let originalAct = seneca.actAsync.bind(seneca)
      let sentNotifications = []
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'notifications' && pattern.cmd === 'create') {
          sentNotifications.push(pattern.notification)
          return {}
        }
        return originalAct(pattern)
      })
      authToken = await agent.generate()
      await request(authApp)
        .post('/api/v1/tokens/notifyUsers')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          daysAhead: 7
        })
        .expect(200)
      const names = ['Roger', 'George', 'trtester4@kuali.co']
      expect(sentNotifications).to.have.property('length', 3)
      expect(sentNotifications[0].variables.firstName).to.be.oneOf(names)
      expect(sentNotifications[1].variables.firstName).to.be.oneOf(names)
      expect(sentNotifications[2].variables.firstName).to.be.oneOf(names)
    })
    it('notifies each user for expired only', async () => {
      let originalAct = seneca.actAsync.bind(seneca)
      let sentNotifications = []
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'notifications' && pattern.cmd === 'create') {
          sentNotifications.push(pattern.notification)
          return {}
        }
        return originalAct(pattern)
      })
      authToken = await agent.generate()
      await request(authApp)
        .post('/api/v1/tokens/notifyUsers')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
      expect(sentNotifications).to.have.property('length', 1)
      expect(sentNotifications).to.have.deep.property(
        '[0].variables.firstName',
        'Roger'
      )
    })
  })

  describe('/api/v1/tokens/notifyAdmins', () => {
    beforeEach(async () => {
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().subtract(1, 'days'),
          name: 'Super Stupid Name'
        },
        id: user1.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().subtract(1, 'days'),
          name: 'Other Stupid Name'
        },
        id: user1.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(1, 'days'),
          name: 'Interesting Name'
        },
        id: user1.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().subtract(1, 'days'),
          name: 'Kiki key'
        },
        id: user2.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
      await seneca.actAsync({
        role: 'token',
        cmd: 'sign',
        type: 'apiKey',
        options: {
          expiresAt: moment().add(1, 'days'),
          name: 'Toke in token'
        },
        id: user4.id,
        currentUser: { id: 'test', role: 'admin' },
        secret: institution.secret,
        connectionKey
      })
    })
    it('returns all expired tokens', async () => {
      let originalAct = seneca.actAsync.bind(seneca)
      let sentNotifications = []
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'notifications' && pattern.cmd === 'create') {
          sentNotifications.push(pattern.notification)
          return {}
        }
        return originalAct(pattern)
      })
      authToken = await agent.generate()
      await request(authApp)
        .post('/api/v1/tokens/notifyAdmins')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
      expect(sentNotifications).to.have.deep.property(
        '[0].addresses[0]',
        'test1@kuali.co'
      )
      expect(sentNotifications).to.have.property('length', 2)
    })

    it("doesn't notify without expiring tokens", async () => {
      await Token.remove({})
      let originalAct = seneca.actAsync.bind(seneca)
      let sentNotifications = []
      sandbox.stub(seneca, 'actAsync', pattern => {
        if (pattern.role === 'notifications' && pattern.cmd === 'create') {
          sentNotifications.push(pattern.notification)
          return {}
        }
        return originalAct(pattern)
      })
      authToken = await agent.generate()
      await request(authApp)
        .post('/api/v1/tokens/notifyAdmins')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
      expect(sentNotifications).to.have.property('length', 0)
    })
  })
})
