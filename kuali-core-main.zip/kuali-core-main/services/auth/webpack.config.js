/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint-disable no-var, import/no-commonjs */

var ExtractTextPlugin = require('extract-text-webpack-plugin')
// var webpack = require('webpack')

module.exports = {
  plugins: [
    //   new webpack.HotModuleReplacementPlugin(),
    new ExtractTextPlugin('style.css', { allChunks: true })
  ],

  entry: './client/app/index.js',
  // 'identity.js': [
  // 'webpack-dev-server/client?http://monsters.kuali.dev:3011',
  // 'webpack/hot/dev-server',
  //   './client-identity/app/index.js'
  // ]
  // },

  output: {
    path: '../../public/auth/kuali/build/',
    filename: 'auth.js',
    publicPath: '/auth/kuali/build/'
  },

  resolve: {
    modulesDirectories: [
      'node_modules',
      `${__dirname}/node_modules`,
      `${__dirname}/../../`
    ],
    extensions: ['', '.js', 'index.js', '.css', 'style.css']
  },

  resolveLoader: {
    modulesDirectories: [
      'node_modules',
      `${__dirname}/node_modules`,
      `${__dirname}/../../`
    ]
  },

  module: {
    preLoaders: [
      {
        test: /\.json$/,
        loader: 'json'
      }
    ],
    loaders: [
      {
        test: /\.js$/,
        loader: 'babel',
        query: {
          presets: [
            'babel-preset-es2015',
            'babel-preset-react',
            'babel-preset-stage-1'
          ],
          plugins: [
            [
              require.resolve('babel-plugin-react-intl'),
              {
                messagesDir: '../../i18n/messages/auth',
                enforceDescriptions: true
              }
            ]
          ]
        },
        exclude: [/node_modules/]
      },
      {
        test: /\.css$/,
        loader: ExtractTextPlugin.extract(
          'style-loader',
          'css?modules&importLoaders=1&localIdentName=[name]__[local]___[hash:base64:5]!postcss'
        ), // eslint-disable-line
        exclude: [/node_modules/]
      },
      {
        test: /\.css$/,
        loader: ExtractTextPlugin.extract('style-loader', 'css-loader'), // eslint-disable-line
        include: [/node_modules/]
      }
    ]
  },

  postcss: [require('autoprefixer')],

  // devServer: {
  //   publicPath: '/build/',
  //   contentBase: 'public/auth/',
  //   hot: true,
  //   quiet: true,
  //   headers: { 'Access-Control-Allow-Origin': '*' }
  // },

  devtool: '#eval'
}
