/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import assert from 'assert'
import express from 'express'
import supertest from 'supertest-as-promised'
import { getTestConnectionInfo } from 'shared/test-helpers'
import sinon from 'sinon'
import { expect } from 'chai'

import groupsApp from 'services/groups'
import {
  getModel,
  getCollection
} from 'services/groups/server/resources/categories/model'

const { connection } = getTestConnectionInfo()
const Categories = getCollection(connection)
const user = { id: 'test', role: 'admin' }
let sandbox

function getTestCategory() {
  return {
    fieldSchemas: [
      {
        id: '4yi0IaLEx',
        name: 'language',
        type: 'text'
      }
    ],
    name: 'ilauk',
    parentId: '5679c0aec24e76f459540886',
    roleSchemas: [
      {
        description: 'Hi',
        id: 'Vyx3UTLVl',
        name: 'Dean'
      },
      {
        description: 'fdsfds',
        id: 'VyLnIaLVe',
        name: 'Council'
      }
    ]
  }
}

async function insertTestCategories() {
  return await Promise.all([
    Categories.save(getTestCategory(), user),
    Categories.save(getTestCategory(), user),
    Categories.save(getTestCategory(), user)
  ])
}

function createApp(mw) {
  const app = express()
  app.use((req, res, next) => {
    req.log = {
      info() {},
      error() {}
    }
    next()
  })
  if (mw) {
    app.use(mw)
  } else {
    app.use((req, res, next) => {
      req.user = user
      next()
    })
  }
  app.use(groupsApp)
  return supertest(app)
}

describe('/api/v1/categories', () => {
  beforeEach(() => {
    sandbox = sinon.sandbox.create()
    getModel(connection).collection.drop()
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('retrieve all categories', async () => {
    const newCategories = await insertTestCategories()
    const request = createApp()
    const res = await request.get('/api/v1/categories').expect(200)
    assert.equal(res.body[0].parentId, newCategories[0].parentId)
    assert.equal(res.body[1].parentId, newCategories[1].parentId)
    assert.equal(res.body[2].parentId, newCategories[2].parentId)
  })

  it('retrieve all categories when there are none', async () => {
    const request = createApp()
    const res = await request.get('/api/v1/categories').expect(200)
    assert.equal(res.body.length, 0)
  })

  it('retrieves all categories with their fields', async () => {
    const request = createApp()
    const testCategory = getTestCategory()
    delete testCategory.fieldSchemas
    await Promise.all([
      Categories.save(testCategory, user),
      Categories.save(testCategory, user),
      Categories.save(testCategory, user)
    ])
    const res = await request.get('/api/v1/categories?fields=id').expect(200)
    assert.equal(res.body.length, 3)
    res.body.forEach(category => {
      expect(category).to.have.keys(['id'])
    })
  })

  it('gets a specific category', async () => {
    const newCategories = await insertTestCategories()
    const request = createApp()
    const res = await request
      .get(`/api/v1/categories/${newCategories[1].id}`)
      .expect(200)
    assert.equal(res.body.parentId, newCategories[1].parentId)
  })

  it('fail retrieving a category that doesnt exist', async () => {
    const request = createApp()
    await request.get('/api/v1/categories/5679c0b0c24e76f459540999').expect(404)
  })

  it('update an existing category', async () => {
    const newCategories = await insertTestCategories()
    let modifiedCategory = newCategories[1]
    modifiedCategory.name = 'modified'
    const request = createApp()
    await request
      .put(`/api/v1/categories/${modifiedCategory.id}`)
      .send(modifiedCategory)
      .expect(200)
    const res = await request
      .get(`/api/v1/categories/${modifiedCategory.id}`)
      .expect(200)
    assert.equal(res.body.name, 'modified')
  })

  it('throws error if name already exists ', async () => {
    const request = createApp()
    const newCategories = await insertTestCategories()
    const modifiedCategory = newCategories[1]
    const otherCategory = newCategories[0]
    otherCategory.id = modifiedCategory.id
    await request
      .put(`/api/v1/categories/${modifiedCategory.id}`)
      .send(otherCategory)
      .expect(422)
  })

  it('takes id from params', async () => {
    const newCategories = await insertTestCategories()
    let modifiedCategory = newCategories[1]
    modifiedCategory.name = 'modified'
    const id = modifiedCategory.id
    delete modifiedCategory.id
    const request = createApp()
    await request
      .put(`/api/v1/categories/${id}`)
      .send(modifiedCategory)
      .expect(200)
    const res = await request.get(`/api/v1/categories/${id}`).expect(200)
    assert.equal(res.body.name, 'modified')
  })

  it('fail updating with ids that dont match', async () => {
    const request = createApp()
    let category = getTestCategory()
    category.id = '1111'
    await request.put('/api/v1/categories/2222').send(category).expect(400)
  })

  it('fail updating a non-existant category', async () => {
    const request = createApp()
    let category = getTestCategory()
    category.id = '5679c0b0c24e76f459540999'
    await request
      .put('/api/v1/categories/5679c0b0c24e76f459540999')
      .send(category)
      .expect(404)
  })

  it('create a new category', async () => {
    const request = createApp()
    const category = getTestCategory()
    const result = await request
      .post('/api/v1/categories/')
      .send(category)
      .expect(201)
    assert.equal(result.body.parentId, category.parentId)
  })

  it('delete an existing category', async () => {
    const newCategories = await insertTestCategories()
    const request = createApp()
    await request
      .delete(`/api/v1/categories/${newCategories[1].id}`)
      .expect(204)
    const result = await request.get('/api/v1/categories/').expect(200)
    assert.equal(result.body.length, 2)
  })

  it('fail deleting a non-existant category', async () => {
    await insertTestCategories()
    const request = createApp()
    await request
      .delete('/api/v1/categories/5679c0b0c24e76f459540999')
      .expect(404)
    const result = await request.get('/api/v1/categories/').expect(200)
    assert.equal(result.body.length, 3)
  })

  it('verifies PUT can only be done by admins', async () => {
    const newCategories = await insertTestCategories()
    let modifiedCategory = newCategories[1]
    modifiedCategory.name = 'modified'
    const request = createApp((req, res, next) => {
      req.user = { role: 'user' }
      next()
    })
    await request
      .put(`/api/v1/categories/${modifiedCategory.id}`)
      .send(modifiedCategory)
      .expect(403)
    const res = await request
      .get(`/api/v1/categories/${modifiedCategory.id}`)
      .expect(200)
    assert.notEqual(res.body.name, 'modified')
  })

  it('verifies POST can only be done by admins', async () => {
    const request = createApp((req, res, next) => {
      req.user = { role: 'user' }
      next()
    })
    const category = getTestCategory()
    await request.post('/api/v1/categories/').send(category).expect(403)
  })

  it('verifies DELETE can only be done by admins', async () => {
    const newCategories = await insertTestCategories()
    const request = createApp((req, res, next) => {
      req.user = { role: 'user' }
      next()
    })
    await request
      .delete(`/api/v1/categories/${newCategories[1].id}`)
      .expect(403)
    const result = await request.get('/api/v1/categories/').expect(200)
    assert.equal(result.body.length, 3)
  })

  it('allows oldId', async () => {
    const request = createApp()
    let category = getTestCategory()
    category.oldId = 'foobar'
    let savedCategory = await Categories.save(category, user)
    const result = await request.get('/api/v1/categories/foobar').expect(200)
    assert.equal(result.body.id, 'foobar')
    assert.equal(result.body.newId, savedCategory.newId.toString())
  })

  it('gets old id back as id when filtering fields', async () => {
    const request = createApp()
    let category = getTestCategory()
    category.oldId = 'foobar'
    await Categories.save(category, user)
    const { body } = await request
      .get('/api/v1/categories/foobar?fields=id,name')
      .expect(200)
    expect(body).to.have.keys('id', 'name')
    expect(body.id).to.be.equal('foobar')
  })

  it('searches for categories with null fields', async () => {
    const request = createApp()
    const createCategories = [1, 2]
      .map(() => getTestCategory())
      .map((category, i) => {
        category.parentId = i ? category.parentId : null
        return Categories.save(category, user)
      })
    await createCategories
    await Promise.delay(100)
    const { body } = await request
      .get('/api/v1/categories?parentId=null')
      .expect(200)
    expect(body).to.have.length(1)
  })

  it('creates a new version (based on date)', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    const newCategory = Object.assign(category, { name: 'foobar' })
    newCategory.startDate = Date.now()
    delete newCategory.versionId
    const { body } = await request
      .post(`/api/v1/categories/${category.id}/versions`)
      .send(newCategory)
      .expect(201)
    expect(body.name).to.be.equal('foobar')
    const { body: getBody } = await request
      .get(`/api/v1/categories/${category.id}`)
      .expect(200)
    expect(getBody.name).to.be.equal('foobar')
  })

  it('fails if category id does not exist', async () => {
    const request = createApp()
    await request
      .post('/api/v1/categories/foobar/versions')
      .send({
        name: 'foobar'
      })
      .expect(404)
  })

  it('gets list of versions', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    const newCategory = Object.assign(category, { name: 'foobar' })
    delete newCategory.startDate
    delete newCategory.versionId
    await request
      .post(`/api/v1/categories/${category.id}/versions`)
      .send(newCategory)
      .expect(201)
    const { body } = await request
      .get(`/api/v1/categories/${category.id}/versions`)
      .expect(200)
    expect(body).to.have.length(2)
    body.forEach(version => {
      expect(version).to.have.keys([
        'versionId',
        'fieldSchemas',
        'name',
        'parentId',
        'roleSchemas',
        'relationshipSchemas',
        'startDate'
      ])
    })
  })

  it('fails to get versions if category does not exist', async () => {
    const request = createApp()
    await request.get('/api/v1/categories/foobar/versions').expect(404)
  })

  it('queries single category by date', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    const newCategory = Object.assign({}, category, { name: 'foobar' })
    newCategory.startDate = Date.now()
    delete newCategory.versionId
    await request
      .post(`/api/v1/categories/${category.id}/versions`)
      .send(newCategory)
      .expect(201)
    const startDate = category.startDate.toISOString()
    const [first, second] = await Promise.all([
      request.get(`/api/v1/categories/${category.id}?date=${startDate}`), // eslint-disable-line max-len
      request.get(`/api/v1/categories/${category.id}`)
    ]).map(({ body: version }) => version)
    expect(first.name).to.be.equal(category.name)
    expect(second.name).to.be.equal(newCategory.name)
  })

  it('queries single category by date to get different versions', async () => {
    const dates = {
      now: new Date().toISOString(),
      latest: new Date(Date.now() + 6e10).toISOString(),
      earliest: new Date(Date.now() - 6e10).toISOString()
    }
    const request = createApp()
    const category = await Categories.save(
      Object.assign(getTestCategory(), {
        startDate: dates.now,
        name: 'now'
      }),
      user
    )
    await Categories.saveVersion(
      category.id,
      {
        startDate: dates.latest,
        name: 'latest'
      },
      user
    )
    await Categories.saveVersion(
      category.id,
      {
        startDate: dates.earliest,
        name: 'earliest'
      },
      user
    )

    const { body } = await request
      .get(`/api/v1/categories/${category.id}?date=${dates.now}`)
      .expect(200)
    expect(body).to.have.property('name', 'now')
    const { body: body2 } = await request
      .get(`/api/v1/categories/${category.id}?date=${dates.latest}`)
      .expect(200)
    expect(body2).to.have.property('name', 'latest')
    const { body: body1 } = await request
      .get(`/api/v1/categories/${category.id}?date=${dates.earliest}`)
      .expect(200)
    expect(body1).to.have.property('name', 'earliest')
  })

  it('queries all categories by date', async () => {
    const request = createApp()
    const categories = await insertTestCategories()
    const dateQuery = new Date(Date.now() - 10000).toISOString()
    await Promise.all(
      categories.map(category => {
        const randomNumber = Math.floor(Math.random() * 100)
        return request
          .post(`/api/v1/categories/${category.id}/versions`)
          .send(
            Object.assign({}, category, {
              name: `${category.name}-foobar-${randomNumber}`,
              startDate: Date.now() - 1000,
              versionId: undefined
            })
          )
          .expect(201)
      })
    )
    let { body: body1 } = await request.get('/api/v1/categories').expect(200)
    expect(body1).to.have.length(3)
    body1.forEach(category => {
      expect(category.name).to.match(/([a-z0-9]*)-foobar-([0-9]*)/)
    })
    let { body: body2 } = await request
      .get(`/api/v1/categories?date=${dateQuery}`)
      .expect(200)
    expect(body2).to.have.length(3)
    body2.forEach(category => {
      expect(category.name).to.match(/ilauk([0-9]?)/)
    })
  })

  it('can delete versions', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    const updated = Object.assign({}, category, { name: 'foobar' })
    delete updated.startDate
    delete updated.versionId
    await request
      .post(`/api/v1/categories/${category.id}/versions`)
      .send(updated)
      .expect(201)
    await request
      .delete(
        `/api/v1/categories/${category.id}/versions/${category.versionId}`
      ) // eslint-disable-line max-len
      .expect(204)
    const { body } = await request
      .get(`/api/v1/categories/${category.id}/versions`)
      .expect(200)
    body.forEach(cat => {
      expect(cat.versionId).to.not.equal(category.versionId)
    })
  })

  it('fails to delete version if category does not exist', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    await request
      .delete(
        `/api/v1/categories/${category.id}a/versions/${category.versionId}`
      ) // eslint-disable-line
      .expect(404)
  })

  it('fails to delete version if version does not exist', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    await request
      .delete(
        `/api/v1/categories/${category.id}/versions/${category.versionId}a`
      ) // eslint-disable-line
      .expect(404)
  })

  it('can update versions', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    const updated = Object.assign({}, category, { name: 'foobar' })
    delete updated.startDate
    delete updated.versionId
    updated.fieldSchemas = null
    await request
      .post(`/api/v1/categories/${category.id}/versions`)
      .send(updated)
      .expect(201)
    await request
      .put(`/api/v1/categories/${category.id}/versions/${category.versionId}`)
      .send({ name: 'test' })
      .expect(200)
    const { body: versions } = await request.get(
      `/api/v1/categories/${category.id}/versions`
    )
    expect(versions).to.have.length(2)
    expect(versions[0]).to.have.property('name', 'test')
    expect(versions[0]).to.have.property('versionId', category.versionId)
    expect(versions[1]).to.have.property('name', 'foobar')
  })

  it('fails update if version id does not exist', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    await request
      .put(`/api/v1/categories/${category.id}/versions/foobar`)
      .send({ name: 'test' })
      .expect(404)
  })

  it('can get specific version', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    const { body } = await request
      .get(`/api/v1/categories/${category.id}/versions/${category.versionId}`)
      .expect(200)
    expect(body).to.have.keys([
      'name',
      'fieldSchemas',
      'parentId',
      'roleSchemas',
      'relationshipSchemas',
      'startDate',
      'versionId'
    ])
  })

  it('fails to get version if category does not exist', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    await request
      .get(`/api/v1/categories/${category.id}a/versions/${category.versionId}`)
      .expect(404)
  })

  it('fails to get version if version does not exist', async () => {
    const request = createApp()
    const category = await Categories.save(getTestCategory(), user)
    await request
      .get(`/api/v1/categories/${category.id}/versions/${category.versionId}a`)
      .expect(404)
  })

  it('filters out non matching current results', async () => {
    const request = createApp()
    const group = await Categories.save(getTestCategory(), user)
    await Categories.saveVersion(
      group.id,
      {
        name: 'foobar',
        startDate: new Date()
      },
      user
    )
    const now = new Date().toISOString()
    const { body: body1 } = await request
      .get(`/api/v1/categories?name=ilauk&date=${now}`)
      .expect('Item-Count', '0')
      .expect(200)
    expect(body1).to.have.length(0)
    const { body: body2 } = await request
      .get(`/api/v1/categories?name=foobar&date=${now}`)
      .expect('Item-Count', '1')
      .expect(200)
    expect(body2).to.have.length(1)
  })

  it("throws error if limit doesn't include all results", async () => {
    const request = createApp()
    const category1 = await Categories.save(
      {
        name: 'foo'
      },
      user
    )
    await Categories.saveVersion(
      category1.id,
      {
        name: 'bar',
        startDate: new Date()
      },
      user
    )
    const category2 = await Categories.save(
      {
        name: 'baz'
      },
      user
    )
    await Categories.saveVersion(
      category2.id,
      {
        name: 'foo',
        startDate: new Date()
      },
      user
    )
    const now = new Date().toISOString()
    const { text } = await request
      .get(`/api/v1/categories?name=foo&date=${now}&limit=1`)
      .expect(500)
    expect(text).to.be.equal('Inconsitent filtering. Increase limit')
  })

  it('is able to search by name', async () => {
    const request = createApp()
    await Categories.save(
      {
        name: 'Department'
      },
      user
    )
    const { body } = await request.get('/api/v1/categories?q=Depa').expect(200)
    expect(body).to.have.length(1)
  })

  it('saves relationship schemas', async () => {
    const request = createApp()
    const cat1 = await Categories.save(
      {
        name: 'Department'
      },
      user
    )
    const cat2 = await Categories.save(
      {
        name: 'Sub Department',
        parentId: cat1.id,
        relationshipSchemas: [
          {
            name: 'Sister Department',
            categoryId: cat1.id
          }
        ]
      },
      user
    )
    const { body } = await request
      .get(`/api/v1/categories/${cat2.id}`)
      .expect(200)
    expect(body).to.have.property('relationshipSchemas')
    expect(body.relationshipSchemas).to.have.length(1)
    expect(body.relationshipSchemas[0]).to.have.property('id')
    expect(body.relationshipSchemas[0]).to.have.property(
      'name',
      'Sister Department'
    )
    expect(body.relationshipSchemas[0]).to.have.property(
      'categoryId',
      String(cat1.id)
    )
  })

  it('returns empty array for relationship schemas if undefined', async () => {
    const request = createApp()
    await Categories.save(
      {
        name: 'test',
        relationshipSchemas: null
      },
      user
    )
    const { body } = await request.get('/api/v1/categories').expect(200)
    expect(body[0].relationshipSchemas).to.be.eql([])
  })
})
