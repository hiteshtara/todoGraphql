/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { expect } from 'chai'
import { getTestConnectionInfo } from 'shared/test-helpers'
import {
  getCollection as getCategories,
  getModel as getCategoryModel
} from 'services/groups/server/resources/categories/model'
import {
  getCollection as getGroups,
  getModel as getGroupModel
} from 'services/groups/server/resources/groups/model'

const { connection } = getTestConnectionInfo()
const Categories = getCategories(connection)
const Groups = getGroups(connection)
const user = { id: 'test' }
function getTestCategory(
  parentId = '5679c0aec24e76f459540886',
  name = 'ilauk'
) {
  return {
    fieldSchemas: [
      {
        id: '4yi0IaLEx',
        name: 'language',
        type: 'text'
      }
    ],
    name,
    parentId,
    roleSchemas: [
      {
        description: 'Hi',
        id: 'Vyx3UTLVl',
        name: 'Dean'
      },
      {
        description: 'fdsfds',
        id: 'VyLnIaLVe',
        name: 'Council'
      }
    ]
  }
}

async function insertTestCategories() {
  return await Promise.all([
    Categories.save(getTestCategory('5679c0aec24e76f458940886'), user),
    Categories.save(
      getTestCategory('5679c0aec34e76f459940886', 'ilauk1'),
      user
    ),
    Categories.save(
      getTestCategory('5679c0aec24e76f429940886', 'ilauk2'),
      user
    ),
    Categories.save(
      getTestCategory('5679c0aec24e76f459942886', 'ilauk3'),
      user
    ),
    Categories.save(getTestCategory('5279c0aec24e76f459940886', 'ilauk4'), user)
  ])
}

describe('Categories Model', () => {
  beforeEach(async () => {
    await getCategoryModel(connection).remove({})
    await getGroupModel(connection).remove({})
  })

  it('save a new category', async () => {
    const category = await Categories.save(getTestCategory(), user)
    assert.equal(category.name, 'ilauk')
  })

  it('save an existing category', async () => {
    let category = await Categories.save(getTestCategory(), user)
    category.name = 'ffd'
    const newCategory = await Categories.save(category, user)
    assert.equal(newCategory.name, 'ffd')
    const { count } = await Categories.query({})
    assert.equal(count, 1)
  })

  it('load an existing category', async () => {
    const category = await Categories.save(getTestCategory(), user)
    const existingCategory = await Categories.load(category.id)
    assert.equal(existingCategory.id.toString(), category.id.toString())
    assert.equal(existingCategory.type, category.type)
  })

  it('load a non-existant category', async () => {
    try {
      await Categories.load('5679c0aec24e76f459940886')
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(/id not found/.test(ex.message))
    }
  })

  it('load all existing categories', async () => {
    await insertTestCategories()
    const { count, result } = await Categories.query({})
    assert.equal(count, 5)
    assert.equal(result.length, 5)
  })

  it('search for an existing subset of categories', async () => {
    await insertTestCategories()
    const { count, result } = await Categories.query({
      parentId: '5679c0aec24e76f459942886'
    })
    assert.equal(count, 1)
    assert.equal(result.length, 1)
    assert.equal(result[0].parentId, '5679c0aec24e76f459942886')
  })

  it('perform a search that should return no results', async () => {
    await insertTestCategories()
    const { count, result } = await Categories.query({
      parentId: '5679c0aec24e76f459942999'
    })
    assert.equal(count, 0)
    assert.equal(result.length, 0)
  })

  it('remove an existing category', async () => {
    await insertTestCategories()
    const { result } = await Categories.query({
      parentId: '5679c0aec24e76f459942886'
    })
    await Categories.remove(result[0].id, user)
    let { count, result: allCategories } = await Categories.query({})
    assert.equal(count, 4)
    assert.equal(allCategories.length, 4)
  })

  it('remove a non-existant category', async () => {
    await insertTestCategories()
    await Categories.remove('5679c0aec24e76f459942999', user)
    let { count, result } = await Categories.query({})
    assert.equal(count, 5)
    assert.equal(result.length, 5)
  })

  it('should not return double ids', async () => {
    let category = await Categories.save(getTestCategory(), user)
    expect(category).to.not.have.deep.property('roleSchemas.0._id')
    expect(category).to.not.have.deep.property('fieldSchemas.0._id')
  })

  it('cannot delete if the category still has groups', async () => {
    const category = await Categories.save(getTestCategory(), user)
    const group = await Groups.save(
      {
        name: 'foo',
        categoryId: category.id
      },
      user
    )
    try {
      await Categories.remove(category.id, user)
    } catch (ex) {
      expect(ex.message).to.match(/still has groups/)
      expect(ex.status).to.be.equal(412)
      await Groups.remove(group.id, user)
      await Categories.remove(category.id, user)
      try {
        await Categories.load(category.id)
      } catch (ex2) {
        expect(ex2).to.be.instanceOf(Error)
        return
      }
    }
    assert.fail('error should have happened')
  })

  it('cannot save category with role id of members', async () => {
    const newCategory = getTestCategory()
    newCategory.roleSchemas.push({
      id: 'members',
      name: 'My Members'
    })
    try {
      await Categories.save(newCategory, user)
    } catch (ex) {
      expect(ex.name).to.equal('ValidationError')
      expect(ex.errors['versions.0.roleSchemas.2.id'].message).to.equal(
        'members is a reserved role name'
      )
      return
    }
    assert.fail('error should have happened')
  })

  it('cannot save category with role id of members', async () => {
    const newCategory = getTestCategory()
    newCategory.roleSchemas.push({
      id: 'rkjye8f',
      name: 'Members'
    })
    try {
      await Categories.save(newCategory, user)
    } catch (ex) {
      expect(ex.name).to.equal('ValidationError')
      expect(ex.errors['versions.0.roleSchemas.2.name'].message).to.equal(
        'Members is a reserved role name'
      )
      return
    }
    assert.fail('error should have happened')
  })
})
