/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { expect } from 'chai'
import request from 'supertest-as-promised'

import app from 'services/groups'

describe('/api/v1/groups/health', () => {

  it('returns a 204', async () => {
    await request(app)
      .get('/api/v1/groups/health')
      .expect(204)
  })

  it('returns a 200 when detail=true', async () => {
    const { body } = await request(app)
      .get('/api/v1/groups/health?detail=true')
      .expect(200)
    expect(body).to.have.property('Status', 'OK')
  })

})

describe('/api/v1/categories/health', () => {

  it('returns a 204', async () => {
    await request(app)
      .get('/api/v1/categories/health')
      .expect(204)
  })

  it('returns a 200 when detail=true', async () => {
    const { body } = await request(app)
      .get('/api/v1/categories/health?detail=true')
      .expect(200)
    expect(body).to.have.property('Status', 'OK')
  })

})
