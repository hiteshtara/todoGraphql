import { expect } from 'chai'
import Bluebird from 'bluebird'
import { getTestConnectionInfo } from 'shared/test-helpers'
import groups from 'services/groups/server/resources/groups/plugin'
import {
  getCollection,
  getModel
} from 'services/groups/server/resources/groups/model'

const { connectionKey, connection } = getTestConnectionInfo()
const Groups = getCollection(connection)
const user = { id: 'test' }

function getTestGroup (categoryId = '5679c0b0c24e76f459540888') {
  return {
    categoryId,
    fields: [
      {
        id: '4yi0IaLEx',
        value: 'English'
      }
    ],
    name: 'cosci',
    parentId: '5679c0b0c24e76f459540887',
    roles: [
      {
        id: 'VyLnIaLVe',
        value: '3485723452'
      },
      {
        id: 'Vyx3UTLVl',
        value: ['3452304582345']
      }
    ]
  }
}
function getTestGroupWithMembers (categoryId = '5679c0b0c24e76f459540888') {
  return {
    categoryId,
    fields: [
      {
        id: '4yi0IaLEx',
        value: 'English'
      }
    ],
    name: 'cosci',
    parentId: '5679c0b0c24e76f459540887',
    roles: [
      {
        id: 'VyLnIaLVe',
        value: '3485723452'
      },
      {
        id: 'members',
        value: '3485723452asas'
      },
      {
        id: 'Vyx3UTLVl',
        value: ['3452304582345']
      }
    ]
  }
}

describe('Groups seneca plugin', () => {
  beforeEach(async () => {
    await getModel(connection).remove({})
  })
  it('gets roles by user', async () => {
    await Groups.save(getTestGroup(), user)
    let func
    const plugin = {
      groups,
      add (pattern, funcIn) {
        if (pattern.cmd === 'getRolesByUser') func = funcIn
      }
    }
    plugin.groups()
    let result
    result = await Bluebird.fromCallback(cb => {
      func({ connectionKey, userId: '3452304582345' }, cb)
    })
    expect(result).to.contain('Vyx3UTLVl')
  })
  it('gets roles by user with members', async () => {
    await Groups.save(getTestGroupWithMembers(), user)
    let func
    const plugin = {
      groups,
      add (pattern, funcIn) {
        if (pattern.cmd === 'getRolesByUser') func = funcIn
      }
    }
    plugin.groups()
    let result
    result = await Bluebird.fromCallback(cb => {
      func({ connectionKey, userId: '3452304582345' }, cb)
    })
    expect(result).to.contain('Vyx3UTLVl')
  })
})
