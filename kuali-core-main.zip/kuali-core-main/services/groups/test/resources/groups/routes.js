/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Promise from 'bluebird'
import assert from 'assert'
import express from 'express'
import sinon from 'sinon'
import supertest from 'supertest-as-promised'
import { getTestConnectionInfo } from 'shared/test-helpers'
import mongoose from 'shared/mongoose'
import { expect } from 'chai'
import shortid from 'shortid'

import groupsApp from 'services/groups'
import {
  getModel,
  getCollection
} from 'services/groups/server/resources/groups/model'
import {
  getCollection as getCategoriesCollection,
  getModel as getCategoriesModel
} from 'services/groups/server/resources/categories/model'

const { connection } = getTestConnectionInfo()
const Groups = getCollection(connection)
const Categories = getCategoriesCollection(connection)
const user = { id: mongoose.Types.ObjectId(), role: 'admin' }
let sandbox

function getTestGroup (name = 'cosci') {
  return {
    categoryId: '5679c0b0c24e76f459540877',
    fields: [
      {
        id: '4yi0IaLEx',
        value: 'English'
      }
    ],
    name,
    parentId: '5679c0b0c24e76f459540887',
    roles: [
      {
        id: 'VyLnIaLVe',
        value: '3485723452'
      },
      {
        id: 'Vyx3UTLVl',
        value: '3452304582345'
      },
      {
        id: 'members',
        value: '3452304582345'
      }
    ]
  }
}

function getTestGroupWithoutMembers (name = 'cosci') {
  return {
    categoryId: '5679c0b0c24e76f459540877',
    fields: [
      {
        id: '4yi0IaLEx',
        value: 'English'
      }
    ],
    name,
    parentId: '5679c0b0c24e76f459540887',
    roles: [
      {
        id: 'VyLnIaLVe',
        value: '3485723452'
      },
      {
        id: 'Vyx3UTLVl',
        value: '3452304582345'
      }
    ]
  }
}

async function insertTestGroups () {
  return await Promise.all([
    Groups.save(getTestGroup(), user),
    Groups.save(getTestGroup('cosci1'), user),
    Groups.save(getTestGroup('cosci2'), user)
  ])
}

async function insertTestGroupsWithoutMembers () {
  return await Promise.all([
    Groups.save(getTestGroupWithoutMembers(), user),
    Groups.save(getTestGroupWithoutMembers('cosci1'), user),
    Groups.save(getTestGroupWithoutMembers('cosci2'), user)
  ])
}

function createApp (mw) {
  const app = express()
  if (mw) {
    app.use(mw)
  } else {
    app.use((req, res, next) => {
      req.log = {
        error () {}
      }
      req.user = user
      next()
    })
  }
  app.use(groupsApp)
  return supertest(app)
}

describe('/api/v1/groups', () => {
  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await getModel(connection).remove()
    await getCategoriesModel(connection).remove()
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('retrieve all groups', async () => {
    let newGroups = await insertTestGroups()
    let request = createApp()
    let res = await request.get('/api/v1/groups').expect(200)
    assert.equal(res.body[0].parentId, newGroups[0].parentId)
    assert.equal(res.body[1].parentId, newGroups[1].parentId)
    assert.equal(res.body[2].parentId, newGroups[2].parentId)
  })

  it('retrieve all groups with all members in role', async () => {
    let newGroups = await insertTestGroups()
    let request = createApp()
    let res = await request
      .get('/api/v1/groups?showAllMembers=true')
      .expect(200)
    assert.equal(res.body[0].parentId, newGroups[0].parentId)
    assert.equal(res.body[1].parentId, newGroups[1].parentId)
    assert.equal(res.body[2].parentId, newGroups[2].parentId)
  })

  it('retrieve all groups with generated member role ', async () => {
    let newGroups = await insertTestGroupsWithoutMembers()
    let request = createApp()
    let res = await request
      .get('/api/v1/groups?showAllMembers=true')
      .expect(200)
    assert.equal(res.body[0].parentId, newGroups[0].parentId)
    assert.equal(res.body[1].parentId, newGroups[1].parentId)
    assert.equal(res.body[2].parentId, newGroups[2].parentId)
  })

  it('retrieve all groups when there are none', async () => {
    let request = createApp()
    let res = await request.get('/api/v1/groups').expect(200)
    assert.equal(res.body.length, 0)
  })

  it('gets a specific group', async () => {
    let newGroups = await insertTestGroups()
    let request = createApp()
    let res = await request.get(`/api/v1/groups/${newGroups[1].id}`).expect(200)
    assert.equal(res.body.parentId, newGroups[1].parentId)
  })

  it('fail retrieving a group that doesnt exist', async () => {
    let request = createApp()
    await request.get('/api/v1/groups/5679c0b0c24e76f459540999').expect(404)
  })

  it('update an existing group', async () => {
    let newGroups = await insertTestGroups()
    let modifiedGroup = newGroups[1]
    modifiedGroup.name = 'modified'
    let request = createApp()
    await request
      .put(`/api/v1/groups/${newGroups[1].id}`)
      .send(modifiedGroup)
      .expect(200)
    let res = await request.get(`/api/v1/groups/${newGroups[1].id}`).expect(200)
    assert.equal(res.body.name, 'modified')
  })

  it('takes id from params', async () => {
    let newGroups = await insertTestGroups()
    let modifiedGroup = newGroups[1]
    modifiedGroup.name = 'modified'
    let id = newGroups[1].id
    delete modifiedGroup.id
    let request = createApp()
    await request.put(`/api/v1/groups/${id}`).send(modifiedGroup).expect(200)
    let res = await request.get(`/api/v1/groups/${id}`).expect(200)
    assert.equal(res.body.name, 'modified')
  })

  it('fail updating with ids that dont match', async () => {
    let request = createApp()
    let group = getTestGroup()
    group.id = '1111'
    await request.put('/api/v1/groups/2222').send(group).expect(400)
  })

  it('fail updating a non-existant group', async () => {
    let request = createApp()
    let group = getTestGroup()
    group.id = '5679c0b0c24e76f459540999'
    await request
      .put('/api/v1/groups/5679c0b0c24e76f459540999')
      .send(group)
      .expect(404)
  })

  it('create a new group', async () => {
    let request = createApp()
    let group = getTestGroup()
    let result = await request.post('/api/v1/groups/').send(group).expect(201)
    assert.equal(result.body.parentId, group.parentId)
  })

  it('defaults field/role schemas to null on create', async () => {
    let request = createApp()
    let group = getTestGroup()
    let result = await request.post('/api/v1/groups/').send(group).expect(201)
    assert.equal(result.body.fieldSchemas, null)
    assert.equal(result.body.roleSchemas, null)
  })

  it('delete an existing group', async () => {
    let newGroups = await insertTestGroups()
    let request = createApp()
    await request.delete(`/api/v1/groups/${newGroups[1].id}`).expect(204)
    let result = await request.get('/api/v1/groups/').expect(200)
    assert.equal(result.body.length, 2)
  })

  it('delete a group by old id', async () => {
    let request = createApp()
    let group = getTestGroup()
    group.oldId = 'foobar'
    group = await Groups.save(group, user)
    assert.equal(group.id, 'foobar')
    await request.delete(`/api/v1/groups/${group.id}`).expect(204)
    await request.get(`/api/v1/groups/${group.id}`).expect(404)
  })

  it('fail deleting a non-existant group', async () => {
    await insertTestGroups()
    let request = createApp()
    await request.delete('/api/v1/groups/5679c0b0c24e76f459540999').expect(404)
    let result = await request.get('/api/v1/groups/').expect(200)
    assert.equal(result.body.length, 3)
  })

  it('verifies PUT can only be done by admins', async () => {
    let newGroups = await insertTestGroups()
    let modifiedGroup = newGroups[1]
    modifiedGroup.name = 'modified'
    let request = createApp((req, res, next) => {
      req.user = { role: 'user' }
      next()
    })
    await request
      .put(`/api/v1/groups/${newGroups[1].id}`)
      .send(modifiedGroup)
      .expect(403)
    let res = await request.get(`/api/v1/groups/${newGroups[1].id}`).expect(200)
    assert.notEqual(res.body.name, 'modified')
  })

  it('verifies POST can only be done by admins', async () => {
    let request = createApp((req, res, next) => {
      req.user = { role: 'user' }
      next()
    })
    let group = getTestGroup()
    await request.post('/api/v1/groups/').send(group).expect(403)
  })

  it('verifies POST does not work with id in body', async () => {
    let request = createApp((req, res, next) => {
      req.user = { role: 'admin' }
      next()
    })
    let group = getTestGroup()
    group.id = '123'
    await request.post('/api/v1/groups/').send(group).expect(400)
  })

  it('verifies DELETE can only be done by admins', async () => {
    let newGroups = await insertTestGroups()
    let request = createApp((req, res, next) => {
      req.user = { role: 'user' }
      next()
    })
    await request.delete(`/api/v1/groups/${newGroups[1].id}`).expect(403)
    let result = await request.get('/api/v1/groups/').expect(200)
    assert.equal(result.body.length, 3)
  })

  it('allows oldId', async () => {
    const request = createApp()
    let group = getTestGroup()
    group.oldId = 'foobar'
    let savedGroup = await Groups.save(group, user)
    const result = await request.get('/api/v1/groups/foobar').expect(200)
    assert.equal(result.body.id, 'foobar')
    assert.equal(result.body.newId, savedGroup.newId)
  })

  it('selects only certian fields', async () => {
    await insertTestGroups()
    const request = createApp()
    const results = await request
      .get('/api/v1/groups?fields=id,name')
      .expect(200)
    expect(results.body).to.have.length(3)
    results.body.forEach(group => {
      expect(group).to.have.keys('id', 'name')
    })
  })

  it('finds by nested id/value', async () => {
    const request = createApp()
    let group1 = getTestGroup()
    let group2 = getTestGroup()
    group1.name = 'foo'
    group1.fields[0] = { id: 'foo', value: 'bar' }
    group2.name = 'bar'
    group2.fields[0] = { id: 'bar', value: 'foo' }
    await Promise.all([Groups.save(group1, user), Groups.save(group2, user)])
    const { body } = await request.get('/api/v1/groups?fields(foo)=bar')
    expect(body).to.have.length(1)
    expect(body[0].name).to.be.equal('foo')
    const { body: body2 } = await request.get('/api/v1/groups?fields(bar)=foo')
    expect(body2).to.have.length(1)
    expect(body2[0].name).to.be.equal('bar')
  })

  it('creates a new version (based on date)', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    const newGroup = Object.assign(group, { name: 'foobar' })
    newGroup.startDate = Date.now()
    delete newGroup.versionId
    const { body } = await request
      .post(`/api/v1/groups/${group.id}/versions`)
      .send(newGroup)
      .expect(201)
    expect(body.name).to.be.equal('foobar')
    const { body: getBody } = await request
      .get(`/api/v1/groups/${group.id}`)
      .expect(200)
    expect(getBody.name).to.be.equal('foobar')
  })

  it('fails if category id does not exist', async () => {
    const request = createApp()
    await request
      .post('/api/v1/groups/foobar/versions')
      .send({
        name: 'foobar'
      })
      .expect(404)
  })

  it('gets list of versions', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    const newGroup = Object.assign(group, { name: 'foobar' })
    delete newGroup.startDate
    delete newGroup.versionId
    await request
      .post(`/api/v1/groups/${group.id}/versions`)
      .send(newGroup)
      .expect(201)
    const { body } = await request
      .get(`/api/v1/groups/${group.id}/versions`)
      .expect(200)
    expect(body).to.have.length(2)
    body.forEach(version => {
      expect(version).to.have.keys([
        'versionId',
        'fieldSchemas',
        'name',
        'parentId',
        'roleSchemas',
        'startDate',
        'categoryId',
        'fields',
        'relationships',
        'roles'
      ])
    })
  })

  it('fails to get versions if category does not exist', async () => {
    const request = createApp()
    await request.get('/api/v1/groups/foobar/versions').expect(404)
  })

  it('queries single category by date', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    const newGroup = Object.assign({}, group, { name: 'foobar' })
    newGroup.startDate = Date.now()
    delete newGroup.versionId
    await request
      .post(`/api/v1/groups/${group.id}/versions`)
      .send(newGroup)
      .expect(201)
    const [first, second] = await Promise.all([
      request.get(
        `/api/v1/groups/${group.id}?date=${group.startDate.toISOString()}`
      ), // eslint-disable-line max-len
      request.get(`/api/v1/groups/${group.id}`)
    ]).map(({ body: version }) => version)
    expect(first.name).to.be.equal(group.name)
    expect(second.name).to.be.equal(newGroup.name)
  })

  it('queries single category by date to get different versions', async () => {
    const dates = {
      now: new Date().toISOString(),
      latest: new Date(Date.now() + 6e10).toISOString(),
      earliest: new Date(Date.now() - 6e10).toISOString()
    }
    const request = createApp()
    const group = await Groups.save(
      Object.assign(getTestGroup(), {
        startDate: dates.now,
        name: 'now'
      }),
      user
    )
    await Groups.saveVersion(
      group.id,
      {
        startDate: dates.latest,
        name: 'latest'
      },
      user
    )
    await Groups.saveVersion(
      group.id,
      {
        startDate: dates.earliest,
        name: 'earliest'
      },
      user
    )

    const { body } = await request
      .get(`/api/v1/groups/${group.id}?date=${dates.now}`)
      .expect(200)
    expect(body).to.have.property('name', 'now')
    const { body: body2 } = await request
      .get(`/api/v1/groups/${group.id}?date=${dates.latest}`)
      .expect(200)
    expect(body2).to.have.property('name', 'latest')
    const { body: body1 } = await request
      .get(`/api/v1/groups/${group.id}?date=${dates.earliest}`)
      .expect(200)
    expect(body1).to.have.property('name', 'earliest')
  })

  it('queries all categories by date', async () => {
    const request = createApp()
    const groups = await insertTestGroups()
    const dateQuery = new Date(Date.now() - 10000).toISOString()
    await Promise.all(
      groups.map(group => {
        return request
          .post(`/api/v1/groups/${group.id}/versions`)
          .send(
            Object.assign({}, group, {
              name: `${group.name}-foobar-${Math.floor(Math.random() * 100)}`,
              startDate: Date.now() - 1000,
              versionId: undefined
            })
          )
          .expect(201)
      })
    )
    let { body: body1 } = await request.get('/api/v1/groups').expect(200)
    expect(body1).to.have.length(3)
    body1.forEach(group => {
      expect(group.name).to.match(/([a-z0-9]*)-foobar-([0-9]*)/)
    })
    let { body: body2 } = await request
      .get(`/api/v1/groups?date=${dateQuery}`)
      .expect(200)
    expect(body2).to.have.length(3)
    body2.forEach(group => {
      expect(group.name).to.match(/cosci([0-9]?)/)
    })
  })

  it('throws error when more than one group has same name', async () => {
    const request = createApp()
    const group = await insertTestGroups()
    await request
      .put(`/api/v1/groups/${group[0].id}`)
      .send({
        categoryId: '5679c0b0c24e76f459540877',
        name: 'cosci2',
        startDate: new Date()
      })
      .expect(422)
  })

  it("doesn't throw if the duplicate group name is blank", async () => {
    const request = createApp()
    const groups = await insertTestGroups()
    await Groups.save(getTestGroup(''), user)
    await request
      .put(`/api/v1/groups/${groups[0].id}`)
      .send({
        categoryId: '5679c0b0c24e76f459540877',
        name: '',
        startDate: new Date()
      })
      .expect(200)
  })

  it('can delete versions', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    const updated = Object.assign({}, group, { name: 'foobar' })
    delete updated.startDate
    delete updated.versionId
    const { body: newGroup } = await request
      .post(`/api/v1/groups/${group.id}/versions`)
      .send(updated)
      .expect(201)
    await request
      .delete(`/api/v1/groups/${group.id}/versions/${group.versionId}`) // eslint-disable-line max-len
      .expect(204)
    const { body } = await request.get(`/api/v1/groups/${group.id}`).expect(200)
    expect(body).to.have.property('versionId', newGroup.versionId)
    expect(body).to.have.property('name', 'foobar')
  })

  it('fails to delete version if category does not exist', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    await request
      .delete(`/api/v1/groups/${group.id}a/versions/${group.versionId}`) // eslint-disable-line
      .expect(404)
  })

  it('fails to delete version if version does not exist', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    await request
      .delete(`/api/v1/groups/${group.id}/versions/${group.versionId}a`) // eslint-disable-line
      .expect(404)
  })

  it('can update versions', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    const updated = Object.assign({}, group, { name: 'foobar' })
    delete updated.startDate
    delete updated.versionId
    updated.fieldSchemas = null
    await request
      .post(`/api/v1/groups/${group.id}/versions`)
      .send(updated)
      .expect(201)
    await request
      .put(`/api/v1/groups/${group.id}/versions/${group.versionId}`)
      .send({ name: 'test' })
      .expect(200)
    const { body: versions } = await request.get(
      `/api/v1/groups/${group.id}/versions`
    )
    expect(versions).to.have.length(2)
    expect(versions[0]).to.have.property('name', 'test')
    expect(versions[0]).to.have.property('versionId', group.versionId)
    expect(versions[1]).to.have.property('name', 'foobar')
  })

  it('fails update if version id does not exist', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    await request
      .put(`/api/v1/groups/${group.id}/versions/foobar`)
      .send({ name: 'test' })
      .expect(404)
  })

  it('can get specific version', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    const { body } = await request
      .get(`/api/v1/groups/${group.id}/versions/${group.versionId}`)
      .expect(200)
    expect(body).to.have.keys([
      'name',
      'fieldSchemas',
      'parentId',
      'roleSchemas',
      'startDate',
      'versionId',
      'categoryId',
      'fields',
      'relationships',
      'roles'
    ])
  })

  it('fails to get version if group does not exist', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    await request
      .get(`/api/v1/groups/${group.id}a/versions/${group.versionId}`)
      .expect(404)
  })

  it('fails to get version if version does not exist', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    await request
      .get(`/api/v1/groups/${group.id}/versions/${group.versionId}a`)
      .expect(404)
  })

  it('filters out non matching current results', async () => {
    const request = createApp()
    const group = await Groups.save(getTestGroup(), user)
    await Groups.saveVersion(
      group.id,
      {
        name: 'foobar',
        startDate: new Date(),
        fields: [
          {
            id: '4yi0IaLEx',
            value: 'bar'
          }
        ]
      },
      user
    )
    const now = new Date().toISOString()
    const { body: body1 } = await request
      .get(`/api/v1/groups?name=cosci&date=${now}`)
      .expect('Item-Count', '0')
      .expect(200)
    expect(body1).to.have.length(0)
    const { body: body2 } = await request
      .get(`/api/v1/groups?name=foobar&date=${now}`)
      .expect('Item-Count', '1')
      .expect(200)
    expect(body2).to.have.length(1)
    const { body: body3 } = await request
      .get(`/api/v1/groups?fields(4yi0IaLEx)=bar&date=${now}`)
      .expect('Item-Count', '1')
      .expect(200)
    expect(body3).to.have.length(1)
    const { body: body4 } = await request
      .get(`/api/v1/groups?fields(4yi0IaLEx)=English&date=${now}`)
      .expect('Item-Count', '0')
      .expect(200)
    expect(body4).to.have.length(0)
  })

  it("throws error if limit doesn't include all results", async () => {
    const request = createApp()
    const group1 = await Groups.save(
      {
        name: 'foobar',
        startDate: new Date(),
        fields: [{ id: '4yi0IaLEx', value: 'foo' }]
      },
      user
    )
    await Groups.saveVersion(
      group1.id,
      {
        name: 'foobar',
        startDate: new Date(),
        fields: [{ id: '4yi0IaLEx', value: 'bar' }]
      },
      user
    )
    const group2 = await Groups.save(
      {
        name: 'foobar',
        startDate: new Date(),
        fields: [{ id: '4yi0IaLEx', value: 'bar' }]
      },
      user
    )
    await Groups.saveVersion(
      group2.id,
      {
        name: 'foobar',
        startDate: new Date(),
        fields: [{ id: '4yi0IaLEx', value: 'foo' }]
      },
      user
    )
    const now = new Date().toISOString()
    const { text } = await request
      .get(`/api/v1/groups?fields(4yi0IaLEx)=foo&date=${now}&limit=1`)
      .expect(500)
    expect(text).to.be.equal('Inconsitent filtering. Increase limit')
  })

  it('is able to search by name', async () => {
    const request = createApp()
    await Groups.save(
      {
        name: 'Digital Media'
      },
      user
    )
    const { body } = await request.get('/api/v1/groups?q=med').expect(200)
    expect(body).to.have.length(1)
  })

  it('saves relationships', async () => {
    const request = createApp()
    const cat1 = await Categories.save(
      {
        name: 'Department'
      },
      user
    )
    const cat2 = await Categories.save(
      {
        name: 'Sub Department',
        parentId: cat1.id,
        relationshipSchemas: [
          {
            name: 'Sister Department',
            categoryId: cat1.id
          }
        ]
      },
      user
    )
    const group1 = await Groups.save(
      {
        categoryId: cat1.id,
        name: 'Computer Science'
      },
      user
    )
    const group2 = await Groups.save(
      {
        categoryId: cat2.id,
        parentId: group1.id,
        name: 'Digital Media',
        relationships: [
          {
            id: cat2.relationshipSchemas[0].id,
            value: group1.id
          }
        ]
      },
      user
    )
    const { body } = await request
      .get(`/api/v1/groups/${group2.id}`)
      .expect(200)
    expect(body).to.have.property('relationships')
    expect(body.relationships).to.have.length(1)
    expect(body.relationships[0]).to.have.property('id')
    expect(body.relationships[0]).to.have.property('value', String(group1.id))
  })

  it('returns empty array for relationship if undefined', async () => {
    const request = createApp()
    await Groups.save(
      {
        name: 'test',
        relationships: null
      },
      user
    )
    const { body } = await request.get('/api/v1/groups').expect(200)
    expect(body[0].relationships).to.be.eql([])
  })
})

describe('/api/v1/categories/id/groups', () => {
  async function addTestGroupWithOptions (name, parentId, categoryId, roles) {
    return await Groups.save(
      {
        categoryId,
        name,
        parentId,
        roles
      },
      user
    )
  }

  function generateRoles (roleIds) {
    return [
      ...roleIds.map(id => ({
        id,
        value: [shortid.generate(), shortid.generate()]
      })),
      { id: 'members', value: [shortid.generate(), shortid.generate()] }
    ]
  }

  let multipleDepartmentUserId
  let univRoles, collegeRoles, departmentRoles
  let univGroup,
    collegeGroup1,
    collegeGroup2,
    department1,
    department2,
    department3

  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await getModel(connection).remove()
    await getCategoriesModel(connection).remove()

    const collegeCategoryId = shortid.generate()
    const departmentCategoryId = shortid.generate()
    multipleDepartmentUserId = shortid.generate()

    univRoles = [shortid.generate(), shortid.generate()]
    collegeRoles = [shortid.generate(), shortid.generate()]
    departmentRoles = [shortid.generate(), shortid.generate()]

    univGroup = await addTestGroupWithOptions(
      'University',
      undefined,
      shortid.generate(),
      generateRoles(univRoles)
    )
    collegeGroup1 = await addTestGroupWithOptions(
      'College 1',
      univGroup.id,
      collegeCategoryId,
      generateRoles(collegeRoles)
    )
    collegeGroup2 = await addTestGroupWithOptions(
      'College 2',
      univGroup.id,
      collegeCategoryId,
      generateRoles(collegeRoles)
    )
    const department1Roles = generateRoles(departmentRoles)
    department1Roles[0].value.push(multipleDepartmentUserId)
    department1 = await addTestGroupWithOptions(
      'Department 1',
      collegeGroup1.id,
      departmentCategoryId,
      department1Roles
    )
    department2 = await addTestGroupWithOptions(
      'Department 2',
      collegeGroup1.id,
      departmentCategoryId,
      generateRoles(departmentRoles)
    )
    const department3Roles = generateRoles(departmentRoles)
    department3Roles[0].value.push(multipleDepartmentUserId)
    department3 = await addTestGroupWithOptions(
      'Department 3',
      collegeGroup2.id,
      departmentCategoryId,
      department3Roles
    )
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('returns all groups in the specific category', async () => {
    let request = createApp()
    let res = await request
      .get(`/api/v1/categories/${collegeGroup1.categoryId}/groups`)
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([
      collegeGroup1.id.toString(),
      collegeGroup2.id.toString()
    ])
  })
  it('returns groups with specific member', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${collegeGroup2.roles[1].value[1]}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([collegeGroup2.id.toString()])
  })
  it('does not return any groups if user does not match', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${shortid.generate()}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([])
  })
  it('returns when subgroups membership matches', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${department2.roles[0].value[0]}` +
          `&roleCategoryId=${department2.categoryId}` +
          `&roleId=${department2.roles[0].id}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([collegeGroup1.id.toString()])
  })
  it('returns nothing when subgroups membership does not match', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${univGroup.roles[0].value[0]}` +
          `&roleCategoryId=${department2.categoryId}` +
          `&roleId=${department2.roles[0].id}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([])
  })
  it('ignores subgroups when categoryId = roleCategoryId', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${department2.roles[0].value[0]}` +
          `&roleCategoryId=${collegeGroup1.categoryId}` +
          `&roleId=${department2.roles[0].id}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([])
  })
  it('ignores subgroups and matches on members', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${collegeGroup1.roles[1].value[0]}` +
          `&roleCategoryId=${collegeGroup1.categoryId}` +
          `&roleId=${collegeGroup1.roles[1].id}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([collegeGroup1.id.toString()])
  })
  it('matches both colleges when subgroup membership matches', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${multipleDepartmentUserId}` +
          `&roleCategoryId=${department1.categoryId}` +
          `&roleId=${department3.roles[0].id}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([
      collegeGroup1.id.toString(),
      collegeGroup2.id.toString()
    ])
  })
  it('defaults to all members if roleId is not provided', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${collegeGroup1.categoryId}` +
          `/groups?userId=${department3.roles[2].value[1]}` +
          `&roleCategoryId=${department1.categoryId}`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([collegeGroup2.id.toString()])
  })
  it('if members role is specified it looks at all roles', async () => {
    let request = createApp()
    let res = await request
      .get(
        `/api/v1/categories/${univGroup.categoryId}` +
          `/groups?userId=${department1.roles[0].value[1]}` +
          `&roleCategoryId=${department1.categoryId}&roleId=members`
      )
      .expect(200)
    expect(res.body.map(g => g.id)).to.be.eql([univGroup.id.toString()])
  })
})
