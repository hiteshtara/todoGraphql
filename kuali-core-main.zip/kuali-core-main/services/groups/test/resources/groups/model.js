/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import { expect } from 'chai'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getCollection, getModel } from
  'services/groups/server/resources/groups/model'
const { connection } = getTestConnectionInfo()
const Groups = getCollection(connection)
const user = { id: 'test' }

function getTestGroup(categoryId = '5679c0b0c24e76f459540888') {
  return {
    categoryId,
    fields: [
      {
        id: '4yi0IaLEx',
        value: 'English'
      }
    ],
    name: 'cosci',
    parentId: '5679c0b0c24e76f459540887',
    roles: [
      {
        id: 'VyLnIaLVe',
        value: '3485723452'
      },
      {
        id: 'Vyx3UTLVl',
        value: '3452304582345'
      }
    ]
  }
}

async function insertTestGroups() {
  return await Promise.all([
    Groups.save(getTestGroup('5679c0b0c24e76f459540881'), user),
    Groups.save(getTestGroup('5679c0b0c24e76f459540882'), user),
    Groups.save(getTestGroup('5679c0b0c24e76f459540883'), user),
    Groups.save(getTestGroup('5679c0b0c24e76f459540884'), user),
    Groups.save(getTestGroup('5679c0b0c24e76f459540885'), user)
  ])
}

describe('Groups Model', () => {
  beforeEach(async () => {
    await getModel(connection).remove({})
  })
  it('save a new group', async () => {
    const group = await Groups.save(getTestGroup(), user)
    assert.equal(group.name, 'cosci')
  })

  it('save an existing group', async () => {
    let group = await Groups.save(getTestGroup(), user)
    group.parentId = '5679c0b0c24e76f459540882'
    const newGroup = await Groups.save(group, user)
    assert.equal(newGroup.parentId, '5679c0b0c24e76f459540882')
    const { count } = await Groups.query({})
    assert.equal(count, 1)
  })

  it('load an existing group', async () => {
    const group = await Groups.save(getTestGroup(), user)
    const existingGroup = await Groups.load(group.id)
    assert.equal(existingGroup.id.toString(), group.id.toString())
    assert.equal(existingGroup.type, group.type)
  })

  it('load a non-existant group', async () => {
    try {
      await Groups.load('5679c0b0c24e76f459540999')
      assert.fail('should have thrown an error')
    } catch (ex) {
      assert(/id not found/.test(ex.message))
    }
  })

  it('load all existing groups', async () => {
    await insertTestGroups()
    const { count, result } = await Groups.query({})
    assert.equal(count, 5)
    assert.equal(result.length, 5)
  })

  it('search for an existing subset of groups', async () => {
    await insertTestGroups()
    const { count, result } = await Groups.query({
      categoryId: '5679c0b0c24e76f459540883'
    })
    assert.equal(count, 1)
    assert.equal(result.length, 1)
    assert.equal(result[0].categoryId, '5679c0b0c24e76f459540883')
  })

  it('perform a search that should return no results', async () => {
    await insertTestGroups()
    const { count, result } = await Groups.query({
      categoryId: '5679c0b0c24e76f459540999'
    })
    assert.equal(count, 0)
    assert.deepEqual(result, [])
  })

  it('remove an existing group', async () => {
    await insertTestGroups()
    const { result } = await Groups.query({
      categoryId: '5679c0b0c24e76f459540882'
    })
    await Groups.remove(result[0].id, user)
    const { count, result: allGroups } = await Groups.query({})
    assert.equal(count, 4)
    assert.equal(allGroups.length, 4)
  })

  it('remove a non-existant group', async () => {
    await insertTestGroups()
    await Groups.remove('5679c0b0c24e76f459540999', user)
    let { count, result } = await Groups.query({})
    assert.equal(count, 5)
    assert.equal(result.length, 5)
  })

  it('should not return double ids', async () => {
    let group = await Groups.save(getTestGroup(), user)
    expect(group).to.not.have.deep.property('roleSchemas.0._id')
    expect(group).to.not.have.deep.property('fieldSchemas.0._id')
    expect(group).to.not.have.deep.property('roles.0._id')
    expect(group).to.not.have.deep.property('fields.0._id')
  })

  it('cannot save category with role id of members', async () => {
    const newGroup = getTestGroup()
    newGroup.roleSchemas = [{
      id: 'members',
      name: 'My Members'
    }]
    try {
      await Groups.save(newGroup, user)
    } catch (ex) {
      expect(ex.name).to.equal('ValidationError')
      expect(ex.errors['versions.0.roleSchemas.0.id'].message)
        .to.equal('members is a reserved role name')
      return
    }
    assert.fail('error should have happened')
  })

  it('cannot save category with role id of members', async () => {
    const newGroup = getTestGroup()
    newGroup.roleSchemas = [{
      id: 'rkjye8f',
      name: 'Members'
    }]
    try {
      await Groups.save(newGroup, user)
    } catch (ex) {
      expect(ex.name).to.equal('ValidationError')
      expect(ex.errors['versions.0.roleSchemas.0.name'].message)
        .to.equal('Members is a reserved role name')
      return
    }
    assert.fail('error should have happened')
  })

})
