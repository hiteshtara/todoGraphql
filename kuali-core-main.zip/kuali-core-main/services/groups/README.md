Groups
======

### Development

To start the app, navigate to the root of core and run:

- `npm start`
- `cd services/groups && npm run watch`

Then point your browser at http://localhost:8080/groups

### Testing

To run the test suite for just groups, navigate to the root of core and run:

- `cd services/groups && npm run test`
- `cd services/groups && npm run report`


### TODO

- [x] HMR doesn't work :(
- [x] Hook up Authentication
- [ ] Make sure typeaheads work (make awesome typeahead)
- [ ] Write client logic for Singleton groups
- [x] Server should be able to save null for inherited groups vs overridden
- [x] Server should not save double IDs for arrays
- [ ] Double check that prod webpack still works
- [ ] finish 100% test coverage on server (admin tests, and data shape, etc)
- [ ] achieve 100% test coverage on client

- [ ] Figure out ExtractTextPlugin (make sure it's performant)
