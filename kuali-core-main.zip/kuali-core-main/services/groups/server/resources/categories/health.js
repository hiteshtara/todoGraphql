/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import healthMiddleware from 'shared/health'
import { getModel as getCategoryModel } from './model'

const health = healthMiddleware({
  name: 'categories',
  models: [
    getCategoryModel
  ],
  getModel(getModel, req, res) {
    return getModel(res.locals.connection)
  }
})

export default function (app) {
  app.get('/api/v1/categories/health', health)

  app.get('/categories/health', health)
}
