/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { Schema } from 'shared/mongoose'
import audit from 'shared/mongoose/plugins/mongoose-audit'
import oldIdPlugin from 'shared/old-id'

import { getCollection as getGroup } from '../groups/model'
import crud from '../../lib/crud'
import { requiredString, reservedRoleName } from '../../lib/validators'

let schema = Schema(
  {
    versions: [
      {
        fieldSchemas: [
          {
            id: {
              type: String,
              required: true
            },
            name: {
              type: String,
              ...requiredString
            },
            type: {
              type: String,
              required: true,
              enum: ['text', 'textarea', 'checkbox']
            }
          }
        ],
        name: {
          type: String,
          ...requiredString
        },
        parentId: String,
        roleSchemas: [
          {
            description: {
              type: String,
              ...requiredString
            },
            id: {
              type: String,
              required: true,
              ...reservedRoleName
            },
            name: {
              type: String,
              ...reservedRoleName
            }
          }
        ],
        relationshipSchemas: [
          {
            name: {
              type: String,
              ...requiredString
            },
            categoryId: {
              type: String
            }
          }
        ],
        startDate: {
          type: Date,
          required: true,
          default: 0
        }
      }
    ]
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: {
      transform(doc, obj) {
        const subDocFields = ['roleSchemas', 'fieldSchemas']
        obj.versions.forEach(version => {
          subDocFields.forEach(field => {
            if (!version[field]) return
            version[field].forEach(subDoc => {
              delete subDoc._id
            })
          })
          version.relationshipSchemas = (version.relationshipSchemas || [])
            .map(relationship => ({
              id: String(relationship._id),
              name: relationship.name,
              categoryId: relationship.categoryId
            }))
          version.versionId = String(version._id)
          delete version._id
        })
        obj.newId = obj.id
        if (obj.oldId) obj.id = obj.oldId
        delete obj.oldId
        return obj
      }
    }
  }
)

schema.plugin(audit)
schema.plugin(oldIdPlugin)

schema.pre('save', async function(next) {
  const index = this.versions.length
  const categoryName = this.versions[index - 1].name
  const results = await this.constructor.aggregate([
    { $unwind: '$versions' },
    { $match: { 'versions.startDate': { $lte: new Date() } } },
    { $sort: { 'versions.startDate': -1 } },
    { $group: { _id: '$_id', currentVersion: { $first: '$versions' } } },
    {
      $match: {
        _id: { $ne: this._id },
        'currentVersion.name': categoryName
      }
    }
  ])
  if (results && results.length > 0 && categoryName !== '') {
    let error = new Error('Unique name constraint violation.')
    error.name = 'ValidationError'
    error.errors = {
      categoryName: 'Category name needs to be unique'
    }
    return next(error)
  }

  return next()
})

const modelMap = {}

export function getModel(connection) {
  if (!modelMap[connection]) {
    let Model = connection.model('Category', schema)

    modelMap[connection] = Model
  }
  return modelMap[connection]
}

const collectionMap = {}

export function getCollection(connection) {
  if (!collectionMap[connection]) {
    collectionMap[connection] = crud(getModel(connection), {
      fields: ['name'],
      defaultLimit: 10,
      maxLimit: 10000,
      removeCondition(_id) {
        return getGroup(connection)
          .query({ categoryId: _id })
          .then(({ count }) => !count)
      }
    })
  }
  return collectionMap[connection]
}
