/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { pick } from 'lodash'
import authenticate from 'shared/middleware/authenticate'
import select from 'shared/api-conventions/select'
import { getConnection } from 'shared/mongoose/pool'
import { getCollection } from './model'
import _wrap from '../../lib/wrap'
import { role } from '../../middlewares/authorization-by-role'

const wrap = fn => _wrap(fn, 'Category not found')
const VERSION_FIELDS = [
  'fieldSchemas',
  'name',
  'parentId',
  'roleSchemas',
  'relationshipSchemas',
  'startDate'
]

export default function(app) {
  app.use('/categories', authenticate())
  app.get('/categories', wrap(getAllCategories))
  app.get('/categories/:id', wrap(getCategory))
  app.put('/categories/:id', role('admin'), wrap(updateCategory))
  app.post('/categories/', role('admin'), wrap(addCategory))
  app.delete('/categories/:id', role('admin'), wrap(removeCategory))

  app.get('/categories/:id/versions', wrap(getAllVersions))
  app.get('/categories/:id/versions/:versionId', wrap(getVersion))
  app.put(
    '/categories/:id/versions/:versionId',
    role('admin'),
    wrap(updateVersion)
  )
  app.post('/categories/:id/versions', role('admin'), wrap(addVersion))
  app.delete(
    '/categories/:id/versions/:versionId',
    role('admin'),
    wrap(removeVersion)
  )
}

async function addCategory(req, res) {
  delete req.body._id
  const category = await getCategories(res).save(req.body, req.user, Date.now())
  res.status(201).send(category)
}

async function updateCategory(req, res) {
  if (req.body.id && req.params.id !== req.body.id) {
    throw new Error('id mismatch')
  }
  if (!req.body.id) req.body.id = req.params.id
  try {
    const result = await getCategories(res).save(req.body, req.user, Date.now())
    res.send(result)
  } catch (e) {
    if (/id not found/.test(e.message)) {
      e.status = 404
    }
    if (e.name === 'ValidationError') {
      e.status = 422
    }
    res.status(e.status).send(e)
  }
}

async function removeCategory(req, res) {
  const result = await getCategories(res).remove(req.params.id, req.user)
  if (!result || result.n === 0) {
    throw new Error('id not found')
  }
  res.sendStatus(204)
}

async function getCategory(req, res) {
  let date = req.query.date
  if (date) date = new Date(date).valueOf()
  const category = await getCategories(res).load(req.params.id, date)
  res.send(select(req.query.fields, category))
}

async function getAllCategories(req, res) {
  let date = req.query.date
  delete req.query.date
  if (date) date = new Date(date).valueOf()
  const { count, result } = await getCategories(res).query(req.query, date)
  res.set('Access-Control-Expose-Headers', 'Item-Count')
  res.set('Item-Count', count)
  res.json(select(req.query.fields, result))
}

async function addVersion(req, res) {
  const { id } = req.params
  const categories = getCategories(res)
  req.body = pick(req.body, VERSION_FIELDS)
  const version = await categories.saveVersion(id, req.body, req.user)
  res.status(201).send(version)
}

async function getAllVersions(req, res) {
  const { id } = req.params
  const categories = getCategories(res)
  const versions = await categories.getVersions(id)
  res.status(200).send(versions)
}

async function removeVersion(req, res) {
  const { id, versionId } = req.params
  const categories = getCategories(res)
  await categories.removeVersion(id, versionId, req.user)
  res.sendStatus(204)
}

async function updateVersion(req, res) {
  const { id, versionId } = req.params
  const categories = getCategories(res)
  req.body = pick(req.body, VERSION_FIELDS)
  req.body.versionId = versionId
  const version = await categories.saveVersion(id, req.body, req.user)
  res.status(200).send(version)
}

async function getVersion(req, res) {
  const { id, versionId } = req.params
  const categories = getCategories(res)
  const version = await categories.loadVersion(id, versionId)
  res.status(200).send(version)
}

function getCategories({ locals }) {
  return getCollection(getConnection(locals.connectionKey))
}
