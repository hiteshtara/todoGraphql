/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { pick, map, flatten, chain, uniq, includes, union } from 'lodash'
import authenticate from 'shared/middleware/authenticate'
import select from 'shared/api-conventions/select'
import { getConnection } from 'shared/mongoose/pool'
import { getCollection } from './model'
import _wrap from '../../lib/wrap'
import { role } from '../../middlewares/authorization-by-role'

const wrap = fn => _wrap(fn, 'Group not found')
const VERSION_FIELDS = [
  'fields',
  'name',
  'categoryId',
  'parentId',
  'roles',
  'fieldSchemas',
  'roleSchemas',
  'relationships',
  'startDate'
]

export default function(app) {
  app.use('/groups', authenticate())
  app.get('/groups', wrap(getAllGroups))
  app.get('/groups/:id', wrap(getGroup))
  app.put('/groups/:id', role('admin'), wrap(updateGroup))
  app.post('/groups/', role('admin'), wrap(addGroup))
  app.delete('/groups/:id', role('admin'), wrap(removeGroup))

  app.get('/groups/:id/versions', wrap(getAllVersions))
  app.get('/groups/:id/versions/:versionId', wrap(getVersion))
  app.put('/groups/:id/versions/:versionId', role('admin'), wrap(updateVersion))
  app.post('/groups/:id/versions', role('admin'), wrap(addVersion))
  app.delete(
    '/groups/:id/versions/:versionId',
    role('admin'),
    wrap(removeVersion)
  )

  app.get('/categories/:id/groups', wrap(getGroupsForCategory))
}

async function addGroup(req, res) {
  delete req.body._id
  // If fieldSchemas/roleSchemas are not set (undefined), mongoose will default
  // them to an empty array, which breaks our assumption of not being
  // overridden. We set them to null on create but allow them to be overridden
  // by req.body
  req.body = Object.assign(
    {
      fieldSchemas: null,
      roleSchemas: null
    },
    req.body
  )
  if (req.body.id) {
    res
      .status(400)
      .send('Id was specified in the body. Did you mean to use PUT?')
    return
  }
  delete req.body.id
  const group = await getGroups(res).save(req.body, req.user, Date.now())
  res.status(201).send(group)
}

async function updateGroup(req, res) {
  if (req.body.id && req.params.id !== req.body.id) {
    throw new Error('id mismatch')
  }
  if (!req.body.id) req.body.id = req.params.id
  try {
    const result = await getGroups(res).save(req.body, req.user, Date.now())
    res.send(result)
  } catch (e) {
    if (/id not found/.test(e.message)) {
      e.status = 404
    }
    if (e.name === 'ValidationError') {
      e.status = 422
    }
    res.status(e.status).send(e)
  }
}

async function removeGroup(req, res) {
  const result = await getGroups(res).remove(req.params.id, req.user)
  if (!result || result.n === 0) {
    throw new Error('id not found')
  }
  res.sendStatus(204)
}

async function getGroup(req, res) {
  let date = req.query.date
  if (date) date = new Date(date).valueOf()
  const group = await getGroups(res).load(req.params.id, date)
  res.send(select(req.query.fields, group))
}

async function getAllGroups(req, res) {
  let date = req.query.date
  delete req.query.date
  const showAllMembers = req.query.showAllMembers
  delete req.query.showAllMembers
  if (date) date = new Date(date).valueOf()
  req.query = customFieldQuery(req.query, ['roles', 'fields'])
  const { count, result } = await getGroups(res).query(req.query, date)
  if (showAllMembers) {
    result.forEach(group => {
      const membersRole = group.roles.reduce((members, r) => {
        return union(members, r.value)
      }, [])
      const foundMembers = group.roles.reduce((found, r) => {
        if (r.id === 'members') {
          r.value = membersRole
          return true
        }
        return found
      }, false)

      if (!foundMembers) {
        group.roles.push({ id: 'members', value: membersRole })
      }
    })
  }
  res.set('Access-Control-Expose-Headers', 'Item-Count')
  res.set('Item-Count', count)
  res.json(select(req.query.fields, result))
}

async function addVersion(req, res) {
  const { id } = req.params
  const groups = getGroups(res)
  req.body = pick(req.body, VERSION_FIELDS)
  const version = await groups.saveVersion(id, req.body, req.user)
  res.status(201).send(version)
}

async function getAllVersions(req, res) {
  const { id } = req.params
  const groups = getGroups(res)
  const versions = await groups.getVersions(id)
  res.status(200).send(versions)
}

async function removeVersion(req, res) {
  const { id, versionId } = req.params
  const groups = getGroups(res)
  await groups.removeVersion(id, versionId, req.user)
  res.sendStatus(204)
}

async function updateVersion(req, res) {
  const { id, versionId } = req.params
  const groups = getGroups(res)
  req.body = pick(req.body, VERSION_FIELDS)
  req.body.versionId = versionId
  const version = await groups.saveVersion(id, req.body, req.user)
  res.status(200).send(version)
}

async function getVersion(req, res) {
  const { id, versionId } = req.params
  const groups = getGroups(res)
  const version = await groups.loadVersion(id, versionId)
  res.status(200).send(version)
}

function subDocMatch(prefix, val) {
  let regex = new RegExp(`^${prefix}\\((.*)\\)$`)
  return (val.match(regex) || [])[1]
}

function customFieldQuery(query, prefixes) {
  return Object.keys(query).reduce((newQuery, key) => {
    prefixes.some(prefix => {
      const id = subDocMatch(prefix, key)
      if (!id) return false
      const value = newQuery[key]
      delete newQuery[key]
      newQuery[`_${prefix}`] = {
        $elemMatch: { id, value }
      }
      return true
    })
    return newQuery
  }, query)
}

function getGroups({ locals }) {
  return getCollection(getConnection(locals.connectionKey))
}

async function getSubgroupMemberships(
  group,
  roleCategoryId,
  roleId,
  groupModel
) {
  const subGroups = await getSubGroups(group, groupModel)
  return chain(subGroups)
    .flatMap(g => buildMembership(g, roleCategoryId, roleId))
    .value()
}

function buildMembership(group, roleCategoryId, roleId) {
  if (!roleCategoryId || roleCategoryId === group.categoryId) {
    return chain(group.roles)
      .filter(r => !roleId || roleId === r.id)
      .flatMap(r => r.value)
      .value()
  }
  return []
}

async function populateAssociatedMemberships(
  group,
  roleCategoryId,
  roleId,
  includeSubGroups,
  groupModel
) {
  let membership = buildMembership(group, roleCategoryId, roleId)
  if (includeSubGroups) {
    const subgroupMembers = await getSubgroupMemberships(
      group,
      roleCategoryId,
      roleId,
      groupModel
    )
    membership = membership.concat(subgroupMembers)
  }
  return { ...group, membership: uniq(membership) }
}

async function getGroupsForCategory(req, res) {
  const query = { categoryId: req.params.id }
  const roleCategoryId = req.query.roleCategoryId
  const roleId = roleCategoryId &&
    req.query.roleId &&
    req.query.roleId !== 'members'
    ? req.query.roleId
    : false
  const userId = req.query.userId
  const groups = await getGroups(res)
    .query(query)
    .then(({ result }) => {
      return Promise.all(
        result.map(g =>
          populateAssociatedMemberships(
            g,
            roleCategoryId,
            roleId,
            roleCategoryId !== req.params.id,
            getGroups(res)
          )
        )
      )
    })
    .then(result => {
      return result.filter(
        g => (userId ? includes(g.membership, userId) : g.membership.length > 0)
      )
    })

  return res.send(
    groups.map(g => pick(g, ['id', 'name', 'categoryId', 'fields']))
  )
}

async function getSubGroups(group, groupModel) {
  const { result: subGroups } = await groupModel.query({
    parentId: group.id.toString()
  })
  if (subGroups && subGroups.length > 0) {
    const subSubGroups = await Promise.all(
      map(subGroups, g => getSubGroups(g, groupModel))
    )
    return [...subGroups, ...flatten(subSubGroups)]
  }
  return []
}
