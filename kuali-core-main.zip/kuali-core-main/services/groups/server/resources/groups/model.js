/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { Schema } from 'shared/mongoose'
import audit from 'shared/mongoose/plugins/mongoose-audit'
import oldId from 'shared/old-id'

import crud from '../../lib/crud'
import { requiredString, reservedRoleName } from '../../lib/validators'

let schema = Schema(
  {
    versions: [
      {
        fields: [
          {
            id: {
              type: String,
              required: true
            },
            value: {
              type: String,
              ...requiredString
            }
          }
        ],
        name: {
          type: String,
          ...requiredString
        },
        categoryId: {
          type: String
        },
        parentId: String,
        roles: [
          {
            id: {
              type: String,
              required: true
            },
            value: [String]
          }
        ],
        relationships: [
          {
            id: {
              type: String,
              ...requiredString
            },
            value: {
              type: String
            }
          }
        ],
        fieldSchemas: [
          {
            id: {
              type: String,
              required: true
            },
            name: {
              type: String,
              ...requiredString
            },
            type: {
              type: String,
              required: true,
              enum: ['text', 'textarea', 'checkbox']
            }
          }
        ],
        roleSchemas: [
          {
            id: {
              type: String,
              required: true,
              ...reservedRoleName
            },
            name: {
              type: String,
              ...reservedRoleName
            },
            description: {
              type: String,
              ...requiredString
            }
          }
        ],
        startDate: {
          type: Date,
          required: true,
          default: 0
        }
      }
    ]
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: {
      transform (doc, obj) {
        const subDocFields = ['fields', 'roles', 'fieldSchemas', 'roleSchemas']
        obj.versions.forEach(version => {
          subDocFields.forEach(field => {
            if (!version[field]) return
            version[field].forEach(subDoc => {
              delete subDoc._id
            })
          })
          version.relationships = (version.relationships || [])
            .map(relationship => ({
              id: String(relationship.id),
              value: relationship.value
            }))
          version.versionId = String(version._id)
          delete version._id
        })
        obj.newId = obj.id
        if (obj.oldId) obj.id = obj.oldId
        delete obj.oldId
        return obj
      }
    }
  }
)

schema.plugin(audit)
schema.plugin(oldId, { oldId: 'oldId' })

schema.pre('save', async function (next) {
  const index = this.versions.length
  const groupName = this.versions[index - 1].name
  if (!groupName) {
    return next()
  }
  const groupCategoryId = this.versions[index - 1].categoryId
  const results = await this.constructor.aggregate([
    { $unwind: '$versions' },
    { $match: { 'versions.startDate': { $lte: new Date() } } },
    { $sort: { 'versions.startDate': -1 } },
    { $group: { _id: '$_id', currentVersion: { $first: '$versions' } } },
    {
      $match: {
        _id: { $ne: this._id },
        'currentVersion.name': groupName,
        'currentVersion.categoryId': groupCategoryId
      }
    }
  ])
  if (results && results.length > 0 && groupCategoryId) {
    let error = new Error('Unique name constraint violation.')
    error.name = 'ValidationError'
    error.errors = {
      groupName: 'Group name needs to be unique'
    }
    return next(error)
  }
  return next()
})

const modelMap = {}

export function getModel (connection) {
  if (!modelMap[connection]) {
    let Model = connection.model('Group', schema)

    modelMap[connection] = Model
  }
  return modelMap[connection]
}

const collectionMap = {}

export function getCollection (connection) {
  if (!collectionMap[connection]) {
    collectionMap[connection] = crud(getModel(connection), {
      fields: ['name'],
      defaultLimit: 10,
      maxLimit: 10000
    })
  }
  return collectionMap[connection]
}
