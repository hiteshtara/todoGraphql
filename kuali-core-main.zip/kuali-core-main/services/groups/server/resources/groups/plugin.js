import { getConnection } from 'shared/mongoose/pool'
import { union } from 'lodash'
import select from 'shared/api-conventions/select'
import { getCollection } from './model'

export default function groups () {
  this.add({ role: 'groups', cmd: 'getRolesByUser' }, (msg, respond) => {
    getRolesByUser(msg).then(result => respond(null, result)).catch(respond)
  })
}

async function getRolesByUser ({ connectionKey, userId }) {
  const groupCollection = await getAllGroups({
    connectionKey,
    query: {
      'roles.value': userId,
      fields: 'roles'
    }
  })
  const roleIds = []
  groupCollection.forEach(group => {
    group.roles.forEach(role => {
      if (role.value.includes(userId)) {
        roleIds.push(role.id)
      }
    })
  })
  return roleIds
}

async function getAllGroups ({ connectionKey, query }) {
  const { result } = await getGroups(connectionKey).query(query)
  result.forEach(group => {
    const membersRole = group.roles.reduce((members, r) => {
      return union(members, r.value)
    }, [])
    const foundMembers = group.roles.reduce((found, r) => {
      if (r.id === 'members') {
        r.value = membersRole
        return true
      }
      return found
    }, false)

    if (!foundMembers) {
      group.roles.push({ id: 'members', value: membersRole })
    }
  })
  return select(query.fields, result)
}

function getGroups (connectionKey) {
  return getCollection(getConnection(connectionKey))
}
