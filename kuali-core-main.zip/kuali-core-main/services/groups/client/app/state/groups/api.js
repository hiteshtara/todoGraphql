/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import axios from 'axios'

// TODO this should be removed in the future and replaced with actual user
// enabled pagination. Refer to the users app to implement a pagination
// component.
const LIMIT = 10000
let groupCancel, categoryCancel

export function getCategories() {
  return axios
    .get('/api/v1/categories/', {
      params: {
        limit: LIMIT,
        sort: 'name'
      }
    })
    .then(res => res.data)
    .catch(() => null)
}

export function getCategory(id) {
  return axios
    .get(`/api/v1/categories/${id}/`)
    .then(res => res.data)
    .catch(() => null)
}

export function addCategory(category) {
  return axios
    .post('/api/v1/categories/', category)
    .then(res => res.data)
    .catch(() => null)
}

export function updateCategory(id, category) {
  const CancelToken = axios.CancelToken

  if (categoryCancel) categoryCancel()
  let url = `/api/v1/categories/${id}/`
  return axios
    .put(url, category, {
      cancelToken: new CancelToken(c => {
        categoryCancel = c
      })
    })
    .then(res => {
      categoryCancel = undefined
      return res.data
    })
}

export function deleteCategory(id) {
  return axios
    .delete(`/api/v1/categories/${id}/`)
    .then(res => res.data)
    .catch(() => null)
}

export function getGroups() {
  return axios
    .get('/api/v1/groups/', {
      params: {
        limit: LIMIT,
        sort: 'name'
      }
    })
    .then(res => res.data)
    .catch(() => null)
}

export function getGroupsByCategory(categoryId) {
  return axios
    .get('/api/v1/groups/', {
      params: {
        limit: LIMIT,
        sort: 'name',
        categoryId
      }
    })
    .then(res => res.data)
    .catch(() => null)
}

export function getGroup(id) {
  return axios
    .get(`/api/v1/groups/${id}/`)
    .then(res => res.data)
    .catch(() => null)
}

export function addGroup(group) {
  return axios
    .post('/api/v1/groups/', group)
    .then(res => res.data)
    .catch(() => null)
}

export function updateGroup(id, group) {
  const CancelToken = axios.CancelToken

  if (groupCancel) groupCancel()
  let url = `/api/v1/groups/${id}/`
  return axios
    .put(url, group, {
      cancelToken: new CancelToken(c => {
        groupCancel = c
      })
    })
    .then(res => {
      groupCancel = undefined
      return res.data
    })
}

export function deleteGroup(id) {
  return axios
    .delete(`/api/v1/groups/${id}/`)
    .then(res => res.data)
    .catch(() => null)
}
