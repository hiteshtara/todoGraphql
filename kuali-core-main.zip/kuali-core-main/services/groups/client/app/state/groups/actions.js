/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import AppDispatcher from '../dispatcher'
import * as c from './constants'

export function addCategory() {
  AppDispatcher.dispatch({
    actionType: c.ADD_CATEGORY
  })
}

export function updateCategory(id, category) {
  AppDispatcher.dispatch({
    actionType: c.UPDATE_CATEGORY,
    id,
    category
  })
}

export function deleteCategory(id) {
  AppDispatcher.dispatch({
    actionType: c.DELETE_CATEGORY,
    id
  })
}

export function addGroup(categoryId) {
  AppDispatcher.dispatch({
    actionType: c.ADD_GROUP,
    categoryId
  })
}

export function updateGroup(id, group) {
  AppDispatcher.dispatch({
    actionType: c.UPDATE_GROUP,
    id,
    group
  })
}

export function deleteGroup(id) {
  AppDispatcher.dispatch({
    actionType: c.DELETE_GROUP,
    id
  })
}

export function clearErrors() {
  AppDispatcher.dispatch({
    actionType: c.CLEAR_ERRORS
  })
}
