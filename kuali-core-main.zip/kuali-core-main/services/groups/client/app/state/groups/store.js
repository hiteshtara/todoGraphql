/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { EventEmitter } from 'events'
import { assign, filter, find, findIndex, reject } from 'lodash'

import * as api from './api'
import * as c from './constants'
import AppDispatcher from '../dispatcher'

const CHANGE_EVENT = 'change'

let _categories = []

let _groups = []

let _errors = {}

let GroupsStore = assign({}, EventEmitter.prototype, {
  async setup() {
    let cats = await api.getCategories()
    let grps = await api.getGroups()
    _categories = cats
    _groups = grps
  },

  categories() {
    return _categories
  },

  category(id) {
    return find(_categories, { id })
  },

  groups() {
    return _groups
  },

  groupsBy(categoryId) {
    return filter(_groups, { categoryId })
  },

  group(id) {
    return find(_groups, { id })
  },

  errors() {
    return _errors
  },

  emitChange() {
    this.emit(CHANGE_EVENT)
  },

  addChangeListener(callback) {
    this.on(CHANGE_EVENT, callback)
  },

  removeChangeListener(callback) {
    this.removeListener(CHANGE_EVENT, callback)
  }
})

GroupsStore.setup().then(() => GroupsStore.emitChange())

AppDispatcher.register(action => {
  switch (action.actionType) {
    case c.ADD_CATEGORY:
      const newCategory = createCategory()
      api.addCategory(newCategory).then(category => {
        _categories.push(category)
        window.location = `#/category/${category.id}/new`
        GroupsStore.emitChange()
      })
      break

    case c.UPDATE_CATEGORY:
      api
        .updateCategory(action.id, action.category)
        .then(updatedCategory => {
          _categories = _categories.map(category => {
            if (category.id === updatedCategory.id) {
              return updatedCategory
            }
            return category
          })
          _errors = {}
          GroupsStore.emitChange()
        })
        .catch(err => {
          if (err && err.data.errors) {
            _errors = err.data.errors
          }
          GroupsStore.emitChange()
        })
      break

    case c.DELETE_CATEGORY:
      api.deleteCategory(action.id).then(() => {
        _categories = reject(_categories, { id: action.id })
        _groups = reject(_groups, { categoryId: action.id })
        window.location = '#/'
        GroupsStore.emitChange()
      })
      break

    case c.ADD_GROUP:
      const newGroup = createGroup(action.categoryId)
      api.addGroup(newGroup).then(group => {
        _groups.push(group)
        const url = `#/category/${action.categoryId}/group/${group.id}/new`
        window.location = url
        GroupsStore.emitChange()
      })
      break

    case c.UPDATE_GROUP:
      api
        .updateGroup(action.id, action.group)
        .then(() => {
          const j = findIndex(_groups, { id: action.id })
          _groups[j] = action.group
          _errors = {}
          GroupsStore.emitChange()
        })
        .catch(err => {
          if (err && err.data && err.data.errors) {
            _errors = err.data.errors
          }
          GroupsStore.emitChange()
        })
      break

    case c.DELETE_GROUP:
      api.deleteGroup(action.id).then(() => {
        _groups = reject(_groups, { id: action.id })
        window.location = '#/'
        GroupsStore.emitChange()
      })
      break

    case c.CLEAR_ERRORS:
      _errors = {}
      GroupsStore.emitChange()
      break

    default:
    // no op
  }
})

export default GroupsStore

function createCategory() {
  return {
    name: '',
    parentId: null,
    roleSchemas: [],
    fieldSchemas: []
  }
}

function createGroup(categoryId) {
  return {
    name: '',
    parentId: null,
    categoryId,
    fields: [],
    roles: []
  }
}
