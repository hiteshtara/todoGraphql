/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import axios from 'axios'
import { filter, includes, map } from 'lodash'

export function getCurrentUser() {
  return get('/api/v1/users/current/')
}

export function getById(id) {
  return get(`/api/v1/users/${id}/`)
    .then(format)
}

export function getAll(curValues) {
  return get('/api/v1/users/?limit=20')
    .then(users => map(users, format))
    .then(users => excludeIds(users, curValues))
}

export function searchByName(curValues, name) {
  return get(`/api/v1/users/?limit=20&q=${name}`)
    .then(users => map(users, format))
    .then(users => excludeIds(users, curValues))
}

function get(url) {
  return axios.get(url)
    .then(res => res.data)
    .catch(() => null)
}

function format(user) {
  return { id: user.id, name: user.displayName }
}

function excludeIds(users, ids) {
  return filter(users, user => !includes(ids, user.id))
}
