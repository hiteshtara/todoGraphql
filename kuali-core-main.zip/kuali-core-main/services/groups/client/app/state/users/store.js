/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { EventEmitter } from 'events'
import { assign, find, pick } from 'lodash'
import LDClient from 'ldclient-js'

import { getCurrentUser } from './api'
import AppDispatcher from '../dispatcher'

const CHANGE_EVENT = 'change'

let _users = []

let _curUser = null

let ldClient = null

let ldUser = {}

let UsersStore = assign({}, EventEmitter.prototype, {
  setup() {
    return getCurrentUser().then(user => {
      _curUser = user
      this.initializeLD(user)
      this.emitChange()
    })
  },

  users() {
    return _users
  },

  user(id) {
    return find(_users, { id })
  },

  curUser() {
    return _curUser
  },

  featureEnabled(feature) {
    return ldClient.variation(feature, false)
  },

  emitChange() {
    this.emit(CHANGE_EVENT)
  },

  addChangeListener(callback) {
    this.on(CHANGE_EVENT, callback)
  },

  removeChangeListener(callback) {
    this.removeListener(CHANGE_EVENT, callback)
  },

  initializeLD(user) {
    const key = `${user.username}@${getSubdomain()}`
    const anonymous = false
    ldUser = {
      ...pick(user, ['firstName', 'lastName', 'email']),
      name: user.fullName,
      key,
      anonymous,
      custom: {
        user,
        username: user.userName,
        tenant: getSubdomain()
      }
    }
    ldClient = LDClient.initialize('590cabe118f55909e8580714', ldUser)
    ldClient.on('ready', () => this.emitChange())
    ldClient.on('change', () => this.emitChange())
  }

})

function getSubdomain() {
  return window.location.hostname.split('.').slice(0, -2).join('.')
}

UsersStore.setup()

AppDispatcher.register(action => {
  switch (action.actionType) {
    default:
      // no op
  }
})

export default UsersStore
