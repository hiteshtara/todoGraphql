/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { EventEmitter } from 'events'
import { assign } from 'lodash'

import { fetchInstitution } from './api'
import AppDispatcher from '../dispatcher'

const CHANGE_EVENT = 'change'

let _institution = null

let InstitutionStore = assign({}, EventEmitter.prototype, {

  setup() {
    return fetchInstitution()
      .then(inst => {
        _institution = inst
        return inst
      })
  },

  institution() {
    return _institution
  },

  emitChange() {
    this.emit(CHANGE_EVENT)
  },

  addChangeListener(callback) {
    this.on(CHANGE_EVENT, callback)
  },

  removeChangeListener(callback) {
    this.removeListener(CHANGE_EVENT, callback)
  }

})

InstitutionStore.setup()
  .then(() => InstitutionStore.emitChange())

AppDispatcher.register(action => {
  switch (action.actionType) {
    default:
      // no op
  }
})

export default InstitutionStore
