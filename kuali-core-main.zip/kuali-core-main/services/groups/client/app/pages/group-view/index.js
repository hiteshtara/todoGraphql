/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { get } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Preloader } from 'shared/kuali-common'

import GroupView from './component'
import { deleteGroup } from '../../state/groups/actions'
import Store from '../../state/groups/store'

function getState({ categoryId, groupId }) {
  let category = Store.category(categoryId)
  let parentCatId = get(category, 'parentId')
  let parentCategory = Store.category(parentCatId)
  let group = Store.group(groupId)
  let parentGrpId = get(group, 'parentId')
  let parentGroup = Store.group(parentGrpId)
  return { category, group, parentCategory, parentGroup }
}

export default class extends Component {

  displayName: 'GroupViewContainer';

  static propTypes = {
    params: PropTypes.shape({
      categoryId: PropTypes.string.isRequired,
      groupId: PropTypes.string.isRequired
    }).isRequired
  };

  constructor(props) {
    super(props)
    this.state = getState(this.props.params)
    this.remove = this.remove.bind(this)
    this._onChange = this._onChange.bind(this)
  }

  componentDidMount() {
    Store.addChangeListener(this._onChange)
  }

  componentWillReceiveProps({ params }) {
    const { category, group } = this.state
    if (get(category, 'id') !== params.categoryId
      || get(group, 'id') !== params.groupId) {
      this.setState(getState(params))
    }
  }

  componentWillUnmount() {
    Store.removeChangeListener(this._onChange)
  }

  _onChange() {
    this.setState(getState(this.props.params))
  }

  remove() {
    const { groupId } = this.props.params
    deleteGroup(groupId)
  }

  render() {
    const { params } = this.props
    const { category, group, parentCategory, parentGroup } = this.state
    const hasCategory = get(category, 'id') || params.categoryId === 'null'
    const hasGroup = get(group, 'id')
    if (!hasCategory || !hasGroup) {
      return <Preloader/>
    }
    return (
      <GroupView
        category={category}
        group={group}
        parentCategory={parentCategory}
        parentGroup={parentGroup}
        remove={this.remove}
      />
    )
  }

}
