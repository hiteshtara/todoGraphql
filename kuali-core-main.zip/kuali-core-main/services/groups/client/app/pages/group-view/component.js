/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { find, get, map, assign } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Link } from 'react-router'
import { injectIntl, intlShape } from 'react-intl'

import { labels as sharedLabels } from 'shared/i18n'
import { labels as appLabels } from '../../messages'
import { labels as pageLabels, a11y, titles } from '../messages'

import styles from './style'
import Header from '../../common/header'
import Spacer from '../../common/spacer'
import StylishNav from '../../common/stylish-nav'
import getTypeaheadFor from '../../common/group-by-category-typeahead'
import Panel from '../../components/panel'
import { UsersTypeaheadView } from '../../common/users-typeahead'
import GenericMultiselectView from '../../components/generic-multiselect/view'
import { CategoryType, GroupType } from '../../prop-types'
import UsersStore from '../../state/users/store'

const labels = assign({}, sharedLabels, appLabels, pageLabels)

export class _GroupView extends Component {
  displayName: 'GroupView'

  static propTypes = {
    category: CategoryType,
    group: GroupType.isRequired,
    intl: intlShape.isRequired,
    parentCategory: CategoryType,
    parentGroup: GroupType,
    remove: PropTypes.func.isRequired
  }

  constructor(props) {
    super(props)
    this.renderRole = this.renderRole.bind(this)
    this.renderField = this.renderField.bind(this)
  }

  componentDidMount() {
    UsersStore.addChangeListener(this._onChange)
  }

  componentWillUnmount() {
    UsersStore.removeChangeListener(this._onChange)
  }

  _onChange = () => {
    this.forceUpdate()
  }

  renderUser(user) {
    return <li key={user.id}>{user.displayName || '--'}</li>
  }

  renderRole(roleSchema) {
    const role = find(this.props.group.roles, { id: roleSchema.id }) || {}
    return (
      <div key={roleSchema.id} style={{ width: '25%' }}>
        <label className={styles.label}>{roleSchema.name || '--'}</label>
        <GenericMultiselectView
          TypeaheadView={UsersTypeaheadView}
          value={role.value || []}
        />
      </div>
    )
  }

  renderField(fieldSchema) {
    let field = find(this.props.group.fields, { id: fieldSchema.id }) || {}
    return (
      <div key={fieldSchema.id} style={{ width: '25%' }}>
        <label className={styles.label}>{fieldSchema.name || '--'}</label>
        <div>{field.value || '--'}</div>
      </div>
    )
  }

  renderHierarchyParent() {
    const { group, parentCategory, parentGroup, category } = this.props
    let categoryId = parentCategory && parentCategory.id
    let groupId = get(parentGroup, 'id')
    const { GroupTypeaheadView } = getTypeaheadFor(category.id)
    return (
      <div>
        {parentCategory
          ? <div>
              <label className={styles.label}>
                {parentCategory.name || '--'}
              </label>
              {categoryId && groupId
                ? <Link
                  children={parentGroup.name || '--'}
                  to={`category/${categoryId}/group/${groupId}/view`}
                  />
                : <div>--</div>}
            </div>
          : <span />}
        <div>
          {category.relationshipSchemas.map(schema => {
            const catId = schema.categoryId
            const relationship = find(group.relationships, { id: schema.id })
            const relationshipGroupId = relationship && relationship.value
            const link = `category/${catId}/group/${relationshipGroupId}/view`
            return (
              <div className={styles.hierarchySection} key={schema.id}>
                <label className={styles.label}>
                  {schema.name}
                </label>
                {relationship
                  ? <GroupTypeaheadView
                    link={link}
                    value={relationshipGroupId}
                    />
                  : <div>--</div>}
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  render() {
    const { category, group, parentCategory, remove } = this.props
    const format = this.props.intl.formatMessage

    let roleSchemas = group.roleSchemas || get(category, 'roleSchemas', [])
    if (UsersStore.featureEnabled('cor-groups-members-role')) {
      roleSchemas = [{ id: 'members', name: 'Members' }, ...roleSchemas]
    }
    let fieldSchemas = group.fieldSchemas || get(category, 'fieldSchemas', [])
    let catName = category ? category.name || '--' : 'Unassigned'
    let title = `${group.name || '--'} (${catName})`
    let editIcon = (
      <img
        alt={format(labels.edit)}
        className={styles.icon}
        src="img/edit.svg"
      />
    )
    let retireIcon = (
      <img
        alt={format(a11y.retire)}
        className={styles.icon}
        src="img/retire.svg"
      />
    )
    const subtitle =
      group.roleSchemas &&
      group.categoryId &&
      <span style={{ color: '#e00', fontSize: 16 }}>
        ({format(labels.overridden)})
      </span>
    let categoryId = get(category, 'id', 'null')
    return (
      <div>
        <Header name={title} />
        <div style={{ display: 'flex' }}>
          <div style={{ flex: 1, marginLeft: '2em' }}>
            <Panel title={<div>Roles {subtitle}</div>}>
              <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                {map(roleSchemas, s => this.renderRole(s, false))}
              </div>
            </Panel>
            <Panel title={format(labels.fields)}>
              <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                {map(fieldSchemas, this.renderField)}
              </div>
            </Panel>
            {((group.categoryId &&
              (parentCategory || category.relationshipSchemas.length)) ||
              null) &&
              <Panel title={format(titles.hierarchy)}>
                {this.renderHierarchyParent()}
              </Panel>}
          </div>
          <div style={{ padding: '0 2em' }}>
            {UsersStore.curUser().role === 'admin' &&
              <StylishNav
                children={format(labels.editGroup)}
                icon={editIcon}
                to={`category/${categoryId}/group/${group.id}/edit`}
                type="link"
              />}
            <StylishNav
              children={format(labels.deleteGroup)}
              icon={retireIcon}
              to={remove}
              type="button"
            />
            {!get(category, 'isDefault') &&
              get(category, 'id') &&
              <div>
                <Spacer />
                <StylishNav
                  children={format(labels.viewCategory)}
                  icon="eye"
                  to={`category/${category.id}/view`}
                  type="link"
                />
              </div>}
          </div>
        </div>
      </div>
    )
  }
}
export default injectIntl(_GroupView)
