/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import { apps } from 'shared/i18n'
import { Header, Preloader } from 'shared/kuali-common'

import Store from '../../state/users/store'
import NotificationModal from '../../components/notifications'

function getState() {
  return { user: Store.curUser() }
}

export class _Main extends Component {

  displayName: 'Main';

  constructor() {
    super()
    this.state = getState()
    this._onChange = this._onChange.bind(this)
  }

  componentDidMount() {
    Store.addChangeListener(this._onChange)
  }

  componentWillUnmount() {
    Store.removeChangeListener(this._onChange)
  }

  _onChange() {
    this.setState(getState())
  }

  render() {
    let { children } = this.props
    let { user } = this.state
    if (!user) {
      return <Preloader/>
    }
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <NotificationModal/>
        <Header
          logo="img/kualigroups.svg"
          title={this.props.intl.formatMessage(apps.groups)}
          user={user}/>
        {children}
      </div>
    )
  }

}

_Main.propTypes = {
  children: PropTypes.node.isRequired,
  intl: intlShape.isRequired
}

export default injectIntl(_Main)
