/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const titles = defineMessages({
  group: {
    id: 'groups.titles.groups',
    description: 'Header title for groups',
    defaultMessage: '{isNew, select, true {New} false {Edit}} Group'
  },
  category: {
    id: 'groups.titles.category',
    description: 'Header title for group categories',
    defaultMessage: '{isNew, select, true {New} false {Edit}} Category'
  },
  roles: {
    id: 'groups.titles.roles',
    description: 'Title for roles panel',
    defaultMessage: 'Roles'
  },
  hierarchy: {
    id: 'groups.categories.titles.hierarchy',
    description: 'Title for category hierarchy panel',
    defaultMessage: 'Hierarchy'
  },
  fields: {
    id: 'groups.titles.fields',
    description: 'Column/section header for a group of fields',
    defaultMessage: 'Fields'
  },
  membersRole: {
    id: 'groups.titles.membersRole',
    description: 'Title for implicit members role panel',
    defaultMessage: 'Members'
  }
})

export const a11y = defineMessages({
  retire: {
    id: 'groups.alt.retireCategory',
    description: 'Alt text for retire category',
    defaultMessage: 'Retire'
  },
  groupName: {
    id: 'groups.labels.groupName',
    description: 'Accessibility label for group name input',
    defaultMessage: 'Group Name'
  }
})

export const links = defineMessages({
  deleteCategory: {
    id: 'groups.links.deleteCategory',
    description: 'Link text for deleting category',
    defaultMessage: 'Delete Category'
  }
})

export const labels = defineMessages({
  parent: {
    id: 'groups.labels.parentCategory',
    description: 'Label for selection of parent category in hierarchy',
    defaultMessage: 'Parent Category'
  },
  relationships: {
    id: 'groups.labels.relationships',
    description: 'Label for creation of other relationships',
    defaultMessage: 'Other Relationships'
  },
  viewCategory: {
    id: 'groups.labels.viewCategory',
    description: 'Link text for viewing category details',
    defaultMessage: 'View Category'
  },
  deleteGroup: {
    id: 'groups.labels.deleteGroup',
    description: 'Button/link text for deleting a group',
    defaultMessage: 'Delete Group'
  },
  editGroup: {
    id: 'groups.labels.editGroup',
    description: 'Button/link text for editing a group',
    defaultMessage: 'Edit Group'
  },
  overridden: {
    id: 'groups.labels.overridden',
    description: 'Label marking a group as overridden',
    defaultMessage: 'Overridden'
  }
})

export default { titles, a11y, links }
