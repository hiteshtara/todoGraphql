/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { get, isEmpty, debounce } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Preloader } from 'shared/kuali-common'

import CategoryEdit from './component'
import {
  deleteCategory,
  updateCategory,
  clearErrors
} from '../../state/groups/actions'
import Store from '../../state/groups/store'

function getState(id) {
  if (!isEmpty(Store.errors())) {
    return {
      errors: Store.errors()
    }
  }
  return {
    categories: Store.categories(),
    category: Store.category(id),
    errors: Store.errors()
  }
}

export default class CategoryEditContainer extends Component {
  displayName: 'CategoryEditContainer'

  static propTypes = {
    params: PropTypes.shape({
      categoryId: PropTypes.string.isRequired
    }).isRequired,
    route: PropTypes.shape({
      path: PropTypes.string.isRequired
    }).isRequired
  }

  constructor(props) {
    super(props)
    this.state = getState(this.expectedId())
    this.remove = this.remove.bind(this)
    this.update = this.update.bind(this)
    this._onChange = this._onChange.bind(this)
  }

  componentDidMount() {
    Store.addChangeListener(this._onChange)
  }

  componentWillReceiveProps({ params }) {
    if (params.categoryId !== this.actualId()) {
      this.setState(getState(params.categoryId))
    }
  }

  componentWillUnmount() {
    clearErrors()
    Store.removeChangeListener(this._onChange)
  }

  _onChange() {
    this.setState(getState(this.expectedId()))
  }

  expectedId() {
    return this.props.params.categoryId
  }

  actualId() {
    return get(this.state, 'category.id')
  }

  remove() {
    deleteCategory(this.expectedId())
  }

  update(category) {
    this.setState({ category })
    this.debouncedUpdate(this.expectedId(), category)
  }

  debouncedUpdate = debounce((groupId, group) => {
    updateCategory(groupId, group)
  }, 600)

  isNew({ path }) {
    return path === 'category/:categoryId/new'
  }

  render() {
    if (!this.actualId()) {
      return <Preloader />
    }
    return (
      <CategoryEdit
        categories={this.state.categories}
        category={this.state.category}
        errors={this.state.errors}
        isNew={this.isNew(this.props.route)}
        remove={this.remove}
        update={this.update}
      />
    )
  }
}
