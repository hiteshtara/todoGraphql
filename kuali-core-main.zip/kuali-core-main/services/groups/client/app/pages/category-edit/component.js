/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map, reject, assign, isEmpty, get } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'
import { labels as sharedLabels } from 'shared/i18n'

import styles from './style'
import {
  titles as appTitles,
  a11y,
  links,
  labels as appLabels
} from '../messages' //eslint-disable-line max-len
import { titles as localTitles } from './messages'
import EditFields from '../../common/edit-fields'
import EditRoles from '../../common/edit-roles'
import EditRelationships from '../../common/edit-relationships'
import Header from '../../common/header'
import StylishNav from '../../common/stylish-nav'
import Panel from '../../components/panel'
import { CategoryType } from '../../prop-types'
import UsersStore from '../../state/users/store'

const labels = assign({}, sharedLabels, appLabels)
const titles = assign({}, appTitles, localTitles)

export class _CategoryEdit extends Component {
  displayName: 'CategoryEdit'

  static propTypes = {
    categories: PropTypes.arrayOf(CategoryType.isRequired).isRequired,
    category: CategoryType.isRequired,
    errors: PropTypes.object, //eslint-disable-line react/forbid-prop-types
    intl: intlShape.isRequired,
    isNew: PropTypes.bool.isRequired,
    remove: PropTypes.func.isRequired,
    update: PropTypes.func.isRequired
  }

  componentWillMount() {
    if (UsersStore.curUser().role !== 'admin') {
      const { category } = this.props
      window.location = `#/category/${category.id}/view`
    }
  }

  updateParent(obj) {
    const { category, update } = this.props
    update({ ...category, ...obj })
  }

  filterRoles(roles) {
    if (UsersStore.featureEnabled('cor-groups-members-role')) {
      return roles.slice(1)
    }
    return roles
  }

  render() {
    const { categories, category, isNew, remove, update, errors } = this.props
    const fmt = this.props.intl.formatMessage
    let retireIcon = (
      <img
        alt={fmt(a11y.retire)}
        className={styles.icon}
        src="img/retire.svg"
      />
    )
    let roleSchemas = category.roleSchemas || get(category, 'roleSchemas', [])
    if (UsersStore.featureEnabled('cor-groups-members-role')) {
      roleSchemas = [
        { id: 'members', name: 'Members', readOnly: true },
        ...roleSchemas
      ]
    }
    let choices = reject(categories, { id: category.id })
    return (
      <div>
        <Header name={fmt(titles.category, { isNew })} />
        <div className={styles.container}>
          <div className={styles.main}>
            {!isEmpty(errors) &&
              <div className="alert alert-danger">
                <ul>
                  {map(errors, (err, key) => <li key={key}>{err}</li>)}
                </ul>
              </div>}

            <div className={styles.title}>
              <label className={styles.label}>{fmt(labels.name)}</label>
              <input
                aria-label={fmt(labels.name)}
                className="form-control"
                onChange={e => update({ ...category, name: e.target.value })}
                type="text"
                value={category.name}
              />
            </div>
            <Panel title={fmt(titles.roles)}>
              <EditRoles
                categoryId={category.id}
                errors={errors}
                onChange={roles =>
                  update({ ...category, roleSchemas: this.filterRoles(roles) })}
                value={roleSchemas}
              />
            </Panel>
            <Panel title={fmt(titles.fields)}>
              <EditFields
                onChange={fieldSchemas => update({ ...category, fieldSchemas })}
                value={category.fieldSchemas}
              />
            </Panel>
            <Panel title={fmt(titles.hierarchy)}>
              <label>{fmt(labels.parent)}</label>
              <select
                className="form-control"
                onChange={e => this.updateParent({ parentId: e.target.value })}
                value={category.parentId || ''}
              >
                <option value="">--</option>
                {map(choices, cat => (
                  <option
                    children={cat.name || '--'}
                    key={cat.id}
                    value={cat.id}
                  />
                ))}
              </select>
              <br />
              <label>{fmt(labels.relationships)}</label>
              <EditRelationships
                categories={categories}
                onChange={relationshipSchemas => {
                  return update({ ...category, relationshipSchemas })
                }}
                value={category.relationshipSchemas}
              />
            </Panel>
          </div>
          <div className={styles.sidebar}>
            <StylishNav
              children={fmt(labels.done)}
              icon="check"
              to={`category/${category.id}/view`}
              type="link"
            />
            <StylishNav
              children={fmt(links.deleteCategory)}
              icon={retireIcon}
              to={remove}
              type="button"
            />
          </div>
        </div>
      </div>
    )
  }
}
export default injectIntl(_CategoryEdit)
