/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const labels = defineMessages({
  group: {
    id: 'groups.labels.groupSingular',
    description: 'Singular of groups',
    defaultMessage: 'Group'
  },
  newCategory: {
    id: 'groups.labels.newCategory',
    description: 'Button text for new category in search',
    defaultMessage: 'New Category'
  },
  category: {
    id: 'groups.labels.categorySingular',
    description: 'Singular category',
    defaultMessage: 'Category'
  },
  categories: {
    id: 'groups.labels.categories',
    description: 'Plural of category',
    defaultMessage: 'Categories'
  },
  newThing: {
    id: 'groups.labels.newThing',
    description: 'Create a new thing',
    defaultMessage: 'New {thing}'
  }
})

export const a11y = defineMessages({
  newCategory: {
    id: 'groups.a11y.newCategory',
    description: 'Accessibility label for new category button',
    defaultMessage: 'Create a new Category'
  },
  newThing: {
    id: 'groups.a11y.newThing',
    description: 'Generic accessibility label for creating something',
    defaultMessage: 'Create a new {thing}'
  },
  clearFilter: {
    id: 'groups.a11y.clearFilter',
    description: 'Accessibility label from clearing search filter',
    defaultMessage: 'Clear the search filter'
  },
  applyFilter: {
    id: 'groups.a11y.filter',
    description: 'Accessibility label for filtering search results',
    defaultMessage: 'Filter search results to {thing}'
  },
  searchPrompt: {
    id: 'groups.a11y.searchPrompt',
    description: 'Accessibility label for search field',
    defaultMessage: 'Type to search Groups'
  }
})

export default {}
