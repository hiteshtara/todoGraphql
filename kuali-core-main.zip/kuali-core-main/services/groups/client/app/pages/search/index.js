/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import cx from 'classnames'
import { filter, find, map, assign } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Link } from 'react-router'
import { Button } from 'react-bootstrap'
import { injectIntl, intlShape } from 'react-intl'

import { labels as sharedLabels } from 'shared/i18n'
import { labels as appLabels } from '../../messages'
import { labels as pageLabels } from '../messages'
import { labels as localLabels, a11y } from './messages'

import styles from './style'
import Sidebar from '../../common/sidebar'
import Table from '../../common/table'
import Icon from '../../components/icon'
import { Column } from '../../components/list'
import { addCategory, addGroup } from '../../state/groups/actions'
import Store from '../../state/groups/store'

const labels = assign({}, sharedLabels, appLabels, pageLabels, localLabels)

function getState() {
  return {
    categories: Store.categories(),
    groups: Store.groups()
  }
}

export class _Search extends Component {
  displayName: "Search";

  static propTypes = {
    history: PropTypes.shape({
      push: PropTypes.func.isRequired
    }).isRequired,
    intl: intlShape.isRequired,
    params: PropTypes.shape({
      categoryId: PropTypes.string
    }).isRequired
  };

  constructor(props) {
    super(props)
    this.state = {
      searchStr: '',
      sortBy: null,
      ...getState()
    }
    this.createGroup = this.createGroup.bind(this)
    this._onChange = this._onChange.bind(this)
  }

  componentDidMount() {
    Store.addChangeListener(this._onChange)
  }

  componentWillUnmount() {
    Store.removeChangeListener(this._onChange)
  }

  _onChange() {
    this.setState(getState())
  }

  getSortDetails(key) {
    if (!key) {
      return { key: null, dir: null }
    }
    return key.charAt(0) == '-'
      ? { key: key.substr(1), dir: -1 }
      : { key, dir: 1 }
  }

  sortBy(newKey) {
    return () => {
      const curKey = this.state.sortBy
      const { key, dir } = this.getSortDetails(curKey)
      if (key == newKey && dir == 1) {
        newKey = `-${newKey}`
      }
      this.setState({ sortBy: newKey })
    }
  }

  createGroup() {
    let { categoryId } = this.props.params
    addGroup(categoryId || null)
  }

  formatResults() {
    return map(this.state.groups, group => {
      const overridden = group.roleSchemas && group.categoryId
      const category = find(this.state.categories, {
        id: group.categoryId
      }) || {}
      return {
        id: group.id,
        category: group.categoryId ? category.name || '' : 'Unassigned',
        categoryId: group.categoryId,
        group: group.name || '',
        groupId: group.id,
        overridden
      }
    })
  }

  render() {
    const { params } = this.props
    const format = this.props.intl.formatMessage
    const { categories, searchStr } = this.state

    let results = this.formatResults()
    let id = params.categoryId
    let category = find(categories, { id })
    if (id) {
      results = filter(results, g => {
        return g.categoryId == id
      })
    }
    if (searchStr) {
      let regex = new RegExp(searchStr, 'i')
      results = filter(results, g => {
        return g.category.match(regex) || g.group.match(regex)
      })
    }
    if (this.state.sortBy) {
      const { key, dir } = this.getSortDetails(this.state.sortBy)
      results = results.sort((a, b) => {
        return a[key] > b[key] ? dir : -dir
      })
    }
    let catName = category ? category.name || '--' : format(labels.group)
    return (
      <div className={styles.wrapper}>
        <Sidebar className={styles.sidebar}>
          <div className={styles.btnWrapper}>
            <Button
              aria-label={format(a11y.newCategory)}
              bsSize="large"
              bsStyle="primary"
              children={format(labels.newCategory)}
              className={styles.sidebarButton}
              onClick={addCategory}
            />
            <Button
              aria-label={format(a11y.newThing, { thing: catName })}
              bsSize="large"
              bsStyle="primary"
              children={format(labels.newThing, { thing: catName })}
              className={styles.sidebarButton}
              onClick={this.createGroup}
            />
          </div>
          <div className={styles.navHeader}>{format(labels.categories)}</div>
          <Link
            aria-label={format(a11y.clearFilter)}
            children={format(labels.all)}
            className={cx(styles.link, { [styles.isActive]: !id })}
            to="/"
          />
          {map(categories, cat => (
            <Link
              aria-label={format(a11y.applyFilter, { thing: cat.name })}
              children={cat.name || '--'}
              className={cx(styles.link, { [styles.isActive]: cat.id == id })}
              key={cat.id}
              to={`search/${cat.id}`}
            />
          ))}
        </Sidebar>
        <div className={styles.mainContainer}>
          {category &&
            <div className={styles.header}>
              <span style={{ fontSize: 30 }}>{category.name || '--'}</span>
              <Link
                children={format(labels.viewCategory)}
                className={styles.viewCatLink}
                to={`category/${category.id}/view`}
              />
            </div>}
          <div style={{ paddingTop: 20 }}>
            <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
              <div className={styles.searchContainer}>
                <div className={styles.search}>
                  <Icon className={styles.searchIcon} name="search" />
                  <input
                    aria-label={format(a11y.searchPrompt)}
                    className={cx('form-control', styles.searchInput)}
                    id="search-box"
                    onChange={e => this.setState({ searchStr: e.target.value })}
                    type="text"
                    value={searchStr}
                  />
                </div>
              </div>
              <Table results={results} urlForItem={getUrl}>
                <Column
                  label={format(labels.group)}
                  onClick={this.sortBy('group')}
                  render={result => (
                    <span className={styles.td}>
                      {result.group || '--'}
                      {result.overridden &&
                        <div className={styles.override}>Overridden</div>}
                    </span>
                  )}
                />
                {!category &&
                  <Column
                    label={format(labels.category)}
                    onClick={this.sortBy('category')}
                    render={result => (
                      <span className={styles.td}>
                        {result.category || '--'}
                      </span>
                    )}
                  />}
              </Table>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

function getUrl(res) {
  return `#/category/${res.categoryId || null}/group/${res.groupId}/view`
}

export default injectIntl(_Search)
