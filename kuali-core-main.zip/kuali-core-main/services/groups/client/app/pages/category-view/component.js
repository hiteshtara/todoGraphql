/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map, assign } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Link } from 'react-router'
import { injectIntl, intlShape } from 'react-intl'
import { labels as sharedLabels } from 'shared/i18n'

import styles from './style'
import { fieldTypes as types } from '../../messages'
import { titles, labels as sectionLabels, a11y, links } from '../messages'
import { labels as localLabels } from './messages'
import Header from '../../common/header'
import Spacer from '../../common/spacer'
import StylishNav from '../../common/stylish-nav'
import AsyncTemplate from '../../components/async-template'
import Panel from '../../components/panel'
import { CategoryType } from '../../prop-types'
import { getCategory } from '../../state/groups/api'
import UsersStore from '../../state/users/store'

const labels = assign({}, sharedLabels, sectionLabels, localLabels)

export class _CategoryView extends Component {
  displayName: 'CategoryView'

  static propTypes = {
    category: CategoryType.isRequired,
    createGroup: PropTypes.func.isRequired,
    intl: intlShape.isRequired,
    parentCategory: CategoryType,
    remove: PropTypes.func.isRequired
  }

  render() {
    const { category, createGroup, parentCategory, remove } = this.props
    const fmt = this.props.intl.formatMessage
    return (
      <div>
        <Header name={category.name || '--'} />
        <div style={{ display: 'flex' }}>
          <div style={{ marginLeft: '2em', flex: 1 }}>
            <Panel title={fmt(titles.roles)}>
              <ul className={styles.list}>
                {UsersStore.featureEnabled('cor-groups-members-role') &&
                  <li style={{ width: '50%' }}>
                    <div>Members</div>
                    <div />
                  </li>}
                {map(category.roleSchemas, role => (
                  <li key={role.id} style={{ width: '50%' }}>
                    <div>{role.name}</div>
                    <div>{role.description}</div>
                  </li>
                ))}
              </ul>
            </Panel>
            <Panel title={fmt(titles.fields)}>
              <ul className={styles.list}>
                {map(category.fieldSchemas, field => (
                  <li key={field.id} style={{ width: '50%' }}>
                    {field.name} ({fmt(types[field.type])})
                  </li>
                ))}
              </ul>
            </Panel>
            <Panel title={fmt(titles.hierarchy)}>
              <div style={{ display: 'flex' }}>
                <div style={{ width: '50%' }}>
                  <label>{fmt(labels.parent)}</label>
                  <div>
                    {parentCategory && parentCategory.id
                      ? <Link
                        className={styles.parentLink}
                        to={`category/${parentCategory.id}/view`}
                        >
                          {parentCategory.name || '--'}
                        </Link>
                      : <span>--</span>}
                  </div>
                  <div>
                    {map(category.relationshipSchemas, relationship => (
                      <div
                        className={styles.relationship}
                        key={relationship.id}
                      >
                        <label>{relationship.name || '--'}</label>
                        <AsyncTemplate
                          default={<div>{fmt(labels.noCategory)}</div>}
                          load={() => {
                            if (relationship.categoryId === null) {
                              return Promise.resolve(false)
                            }
                            return getCategory(relationship.categoryId)
                          }}
                          tmpl={item => {
                            if (item === false) {
                              return <div>{fmt(labels.noCategory)}</div>
                            }
                            if (!item) return null
                            return (
                              <Link
                                className={styles.parentLink}
                                key={relationship.id}
                                to={`category/${relationship.categoryId}/view`}
                              >
                                {item.name || '--'}
                              </Link>
                            )
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Panel>
          </div>
          <div style={{ padding: '0 2em' }}>
            {UsersStore.curUser().role === 'admin' &&
              <StylishNav
                children={fmt(labels.editCategory)}
                icon={
                  <img
                    alt={fmt(sharedLabels.edit)}
                    className={styles.icon}
                    src="img/edit.svg"
                  />
                }
                to={`category/${category.id}/edit`}
                type="link"
              />}
            <StylishNav
              children={fmt(links.deleteCategory)}
              icon={
                <img
                  alt={fmt(a11y.retire)}
                  className={styles.icon}
                  src="img/retire.svg"
                />
              }
              to={remove}
              type="button"
            />
            <Spacer />
            <StylishNav
              children={fmt(labels.newGroup)}
              icon="plus-circle"
              to={createGroup}
              type="button"
            />
          </div>
        </div>
      </div>
    )
  }
}
export default injectIntl(_CategoryView)
