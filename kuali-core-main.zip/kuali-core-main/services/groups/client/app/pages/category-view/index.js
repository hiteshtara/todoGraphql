/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { get } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Preloader } from 'shared/kuali-common'

import CategoryView from './component'
import { addGroup, deleteCategory } from '../../state/groups/actions'
import Store from '../../state/groups/store'

function getState(id) {
  let category = Store.category(id)
  let parentId = get(category, 'parentId')
  let parentCategory = Store.category(parentId)
  return { category, parentCategory }
}

export default class CategoryViewContainer extends Component {

  displayName: 'CategoryViewContainer';

  static propTypes = {
    params: PropTypes.shape({
      categoryId: PropTypes.string.isRequired
    }).isRequired
  };

  constructor(props) {
    super(props)
    this.state = getState(this.expectedId())
    this.createGroup = this.createGroup.bind(this)
    this.remove = this.remove.bind(this)
    this._onChange = this._onChange.bind(this)
  }

  componentDidMount() {
    Store.addChangeListener(this._onChange)
  }

  componentWillReceiveProps({ params }) {
    if (params.categoryId !== this.actualId()) {
      this.setState(getState(params.categoryId))
    }
  }

  componentWillUnmount() {
    Store.removeChangeListener(this._onChange)
  }

  _onChange() {
    this.setState(getState(this.expectedId()))
  }

  expectedId() {
   return this.props.params.categoryId
  }

  actualId() {
    return get(this.state, 'category.id')
  }

  remove() {
    deleteCategory(this.expectedId())
  }

  createGroup() {
    let categoryId = this.props.params.categoryId || 'default'
    addGroup(categoryId)
  }

  render() {
    if (!this.actualId()) {
      return <Preloader/>
    }
    return (
      <CategoryView
        category={this.state.category}
        createGroup={this.createGroup}
        parentCategory={this.state.parentCategory}
        remove={this.remove}
      />
    )
  }

}
