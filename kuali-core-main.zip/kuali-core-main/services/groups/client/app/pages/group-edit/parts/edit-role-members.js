
import { findIndex } from 'lodash'
import React, { PropTypes } from 'react'

import { UsersTypeahead } from '../../../common/users-typeahead'
import GenericMultiselect from '../../../components/generic-multiselect'
import { RoleSchemaType, RoleType } from '../../../prop-types'

export default function EditRoleMembers(
  { role, roleSchema, onChange, style, value, hideLabel }) {
  return (
    <div key={roleSchema.id} style={style}>
      {!hideLabel && <div>{roleSchema.name || '--'}</div>}
      <GenericMultiselect
        Typeahead={UsersTypeahead}
        onChange={val => {
          let i = findIndex(value, { id: roleSchema.id })
          if (i === -1) {
            value.push({ id: roleSchema.id })
            i = value.length - 1
          }
          value[i].value = val
          onChange(value)
        }}
        taProps={{ placeholder: 'Search Users' }}
        value={role.value || []}
      />
    </div>
  )
}

EditRoleMembers.propTypes = {
  hideLabel: PropTypes.bool,
  onChange: PropTypes.func.isRequired,
  role: RoleType.isRequired,
  roleSchema: RoleSchemaType.isRequired,
  style: PropTypes.object, //eslint-disable-line react/forbid-prop-types
  value: PropTypes.arrayOf(
    RoleType.isRequired
  ).isRequired
}
