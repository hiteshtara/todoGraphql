/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { cloneDeep, find, findIndex, map } from 'lodash'
import React, { Component, PropTypes } from 'react'

import styles from '../style'
import getTypeaheadFor from '../../../common/group-by-category-typeahead'
import {
  RelationshipSchemaType,
  RelationshipType
} from '../../../prop-types'

export default class EditRelationshipValues extends Component {

  displayName: 'EditRelationshipValues';

  static propTypes = {
    onChange: PropTypes.func.isRequired,
    relationshipSchemas: PropTypes.arrayOf(
      RelationshipSchemaType.isRequired,
    ).isRequired,
    value: PropTypes.arrayOf(
      RelationshipType.isRequired
    ).isRequired
  };

  constructor(props) {
    super(props)
    this.renderRelationship = this.renderRelationship.bind(this)
  }

  renderRelationship(relationshipSchema) {
    const { value, onChange } = this.props
    const { GroupTypeahead } = getTypeaheadFor(relationshipSchema.categoryId)
    const relationship = find(value, { id: relationshipSchema.id }) || {}
    return (
      <div className={styles.relationship} key={relationshipSchema.id}>
        <label className={styles.label}>
          {relationshipSchema.name || '--'}
        </label>
        <GroupTypeahead
          onChange={groupId => {
            let newValue = cloneDeep(value)
            let i = findIndex(value, { id: relationshipSchema.id })
            if (i === -1) {
              newValue.push({ id: relationshipSchema.id })
              i = newValue.length - 1
            }
            newValue[i].value = groupId
            onChange(newValue)
          }}
          value={relationship.value || ''}
        />
        <br />
      </div>
    )
  }

  render() {
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {map(this.props.relationshipSchemas, this.renderRelationship)}
      </div>
    )
  }

}
