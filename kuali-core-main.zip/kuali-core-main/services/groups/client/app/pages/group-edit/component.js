/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map, clone, assign, get, isEmpty } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Button } from 'react-bootstrap'
import { injectIntl, intlShape } from 'react-intl'

import { labels as sharedLabels } from 'shared/i18n'
import { labels as appLabels } from '../../messages'
import { labels as componentLabels, titles, a11y } from '../messages'
import { labels as localLabels } from './messages'

import EditFieldValues from './parts/edit-field-values'
import EditRoleValues from './parts/edit-role-values'
import EditRelationshipValues from './parts/edit-relationship-values'
import styles from './style'
import EditFields from '../../common/edit-fields'
import EditRoles from '../../common/edit-roles'
import Header from '../../common/header'
import getTypeaheadFor from '../../common/parent-group-typeahead'
import StylishNav from '../../common/stylish-nav'
import Flip from '../../components/flip'
import Panel from '../../components/panel'
import { CategoryType, GroupType } from '../../prop-types'
import UsersStore from '../../state/users/store'

const labels = assign({}, sharedLabels, appLabels, componentLabels, localLabels)

export class _GroupEdit extends Component {
  static displayName = 'GroupEdit'

  static propTypes = {
    category: CategoryType,
    errors: PropTypes.object, //eslint-disable-line react/forbid-prop-types
    group: GroupType.isRequired,
    intl: intlShape.isRequired,
    isNew: PropTypes.bool.isRequired,
    onReset: PropTypes.func.isRequired,
    parentCategory: CategoryType,
    parentGroups: PropTypes.arrayOf(GroupType.isRequired),
    remove: PropTypes.func.isRequired,
    update: PropTypes.func.isRequired
  }

  componentDidMount() {
    UsersStore.addChangeListener(this._onChange)
    if (UsersStore.curUser().role !== 'admin') {
      const { group } = this.props
      window.location = `#/category/${group.categoryId}/group/${group.id}/view`
    }
  }

  componentWillUnmount() {
    UsersStore.removeChangeListener(this._onChange)
  }

  _onChange = () => {
    this.forceUpdate()
  }

  filterRoles(roles) {
    if (UsersStore.featureEnabled('cor-groups-members-role')) {
      return roles.slice(1)
    }
    return roles
  }

  renderRoles() {
    const { category, group, update, errors, onReset } = this.props
    const format = this.props.intl.formatMessage
    const lbl = format(
      group.roleSchemas || !group.categoryId
        ? labels.modifyTemplate
        : labels.overrideTemplate
    )
    let roleSchemas = group.roleSchemas || get(category, 'roleSchemas', [])
    if (UsersStore.featureEnabled('cor-groups-members-role')) {
      roleSchemas = [
        { id: 'members', name: 'Members', readOnly: true },
        ...roleSchemas
      ]
    }
    const subtitle =
      group.roleSchemas &&
      group.categoryId &&
      <span style={{ color: '#e00', fontSize: 16 }}>
        ({format(labels.overridden)})
      </span>
    return (
      <Flip
        back={toggle => (
          <Panel
            rightContent={
              <div>
                {group.categoryId &&
                  <Button
                    children={format(labels.clear)}
                    onClick={() => {
                      update({ ...group, roleSchemas: null })
                      toggle()
                    }}
                  />}
                <Button
                  onClick={() => {
                    onReset()
                    toggle()
                  }}
                  style={{ marginLeft: '1em' }}
                >
                  {format(labels.done)}
                </Button>
              </div>
            }
            title={format(labels.rolesTemplate)}
          >
            <EditRoles
              errors={errors}
              onChange={r =>
                update({ ...group, roleSchemas: this.filterRoles(r) })}
              value={roleSchemas}
            />
          </Panel>
        )}
        direction="vertical"
        front={toggle => (
          <Panel
            rightContent={
              <Button
                children={lbl}
                onClick={() => {
                  if (!group.roleSchemas) {
                    update({
                      ...group,
                      roleSchemas: clone(get(category, 'roleSchemas', []))
                    })
                  }
                  toggle()
                }}
              />
            }
            title={<div>{format(titles.roles)} {subtitle}</div>}
          >
            <EditRoleValues
              onChange={roles => update({ ...group, roles })}
              roleSchemas={roleSchemas}
              value={group.roles}
            />
          </Panel>
        )}
        style={{ position: 'relative', zIndex: 1 }}
      />
    )
  }

  renderFields() {
    const { category, group, update } = this.props
    const format = this.props.intl.formatMessage

    let fieldSchemas = group.fieldSchemas || get(category, 'fieldSchemas', [])
    return (
      <Flip
        back={toggle => (
          <Panel
            rightContent={
              <Button onClick={toggle}>{format(labels.done)}</Button>
            }
            title={format(labels.fieldsTemplate)}
          >
            <EditFields
              onChange={f => update({ ...group, fieldSchemas: f })}
              value={fieldSchemas}
            />
          </Panel>
        )}
        direction="vertical"
        front={toggle => (
          <Panel
            rightContent={
              !group.categoryId &&
                <Button onClick={toggle}>
                  {format(labels.modifyTemplate)}
                </Button>
            }
            title={format(labels.fields)}
          >
            <EditFieldValues
              fieldSchemas={fieldSchemas}
              onChange={fields => update({ ...group, fields })}
              value={group.fields}
            />
          </Panel>
        )}
      />
    )
  }

  renderHierarchyParent() {
    const { group, parentCategory, parentGroups, update, category } = this.props
    const format = this.props.intl.formatMessage
    const { ParentGroupTypeahead } = getTypeaheadFor(parentGroups)
    if (!group.categoryId) {
      return null
    }
    return (
      <div>
        <Panel title={format(titles.hierarchy)}>
          {parentCategory
            ? <div>
                <label>{parentCategory.name || '--'}</label>
                <ParentGroupTypeahead
                  onChange={parentId => update({ ...group, parentId })}
                  value={group.parentId || ''}
                />
              </div>
            : <span />}
          <br />
          <EditRelationshipValues
            onChange={relationships => update({ ...group, relationships })}
            relationshipSchemas={category.relationshipSchemas}
            value={group.relationships || []}
          />
        </Panel>
      </div>
    )
  }

  render() {
    const { category, isNew, group, remove, update, errors } = this.props
    const format = this.props.intl.formatMessage

    const subtitle = `(${category ? category.name || '--' : 'Unassigned'})`
    let title = `${format(titles.group, { isNew })} ${subtitle}`
    let retireIcon = (
      <img
        alt={format(a11y.retire)}
        className={styles.icon}
        src="img/retire.svg"
      />
    )
    let categoryId = get(category, 'id', 'null')
    return (
      <div>
        <Header name={title} />
        <div style={{ display: 'flex' }}>
          <div style={{ flex: 1, marginLeft: '2em' }}>
            {!isEmpty(errors) &&
              <div className="alert alert-danger">
                <ul>
                  {map(errors, (err, key) => <li key={key}>{err}</li>)}
                </ul>
              </div>}

            <label className={styles.label}>{format(labels.name)}</label>
            <input
              aria-label={format(a11y.groupName)}
              className={`form-control ${styles.nameInput}`}
              id="groupName"
              onChange={e => update({ ...group, name: e.target.value })}
              type="text"
              value={group.name}
            />
            {this.renderRoles()}
            {this.renderFields()}
            {this.renderHierarchyParent()}
          </div>
          <div style={{ padding: '0 2em' }}>
            <StylishNav
              children={format(labels.done)}
              icon="check"
              to={`category/${categoryId}/group/${group.id}/view`}
              type="link"
            />
            <StylishNav
              children={format(labels.deleteGroup)}
              icon={retireIcon}
              to={remove}
              type="button"
            />
          </div>
        </div>
      </div>
    )
  }
}

export default injectIntl(_GroupEdit)
