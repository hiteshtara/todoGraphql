/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const a11y = defineMessages({
  addUser: {
    id: 'groups.a11y.addUser',
    description: 'Accessibility text for an add user button',
    defaultMessage: 'Add User'
  },
  removeUser: {
    id: 'groups.a11y.removeUser',
    description: 'Accessibility text for a remove user button',
    defaultMessage: 'Remove User'
  },
  unselectParentGroup: {
    id: 'groups.a11y.unselectParentGroup',
    description: 'Accessibility text for remvoe parent group button',
    defaultMessage: 'Unselect Parent Group'
  }
})
export const placeholders = defineMessages({
  addParent: {
    id: 'groups.placeholders.addParentGroup',
    description: 'Placeholder text for adding a parent group',
    defaultMessage: 'Add Parent Group'
  }
})

export const labels = defineMessages({
  clear: {
    id: 'groups.labels.clearOverride',
    description: 'Button text for clearing an override',
    defaultMessage: 'Clear Override'
  },
  rolesTemplate: {
    id: 'groups.labels.rolesTemplate',
    description: 'Panel title for roles template section',
    defaultMessage: 'Roles Template'
  },
  fieldsTemplate: {
    id: 'groups.labels.fieldsTemplate',
    description: 'Panel title for fields template section',
    defaultMessage: 'Fields Template'
  },
  deleteGroup: {
    id: 'groups.labels.deleteGroup',
    description: 'Button/link text for deleting a group',
    defaultMessage: 'Delete Group'
  },
  modifyTemplate: {
    id: 'groups.labels.modifyTemplate',
    description: 'Labl for modifying a template',
    defaultMessage: 'Modify Template'
  },
  editPermissions: {
    id: 'groups.labels.edit.permissions',
    description: 'Button/link text for editing permissions',
    defaultMessage: 'Edit Permissions'
  },
  overrideTemplate: {
    id: 'groups.labels.overrideTemplate',
    description: 'Label for overriding an existing template',
    defaultMessage: 'Override Template'
  }
})

export default { a11y, placeholders }
