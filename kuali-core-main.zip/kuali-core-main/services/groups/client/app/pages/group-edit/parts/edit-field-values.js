/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { cloneDeep, find, findIndex, map } from 'lodash'
import React, { Component, PropTypes } from 'react'

import styles from '../style'
import { FieldSchemaType, FieldType } from '../../../prop-types'

export default class EditFieldValues extends Component {

  displayName: 'EditFieldValues';

  static propTypes = {
    fieldSchemas: PropTypes.arrayOf(
      FieldSchemaType.isRequired
    ).isRequired,
    onChange: PropTypes.func.isRequired,
    value: PropTypes.arrayOf(
      FieldType.isRequired
    ).isRequired
  };

  constructor(props) {
    super(props)
    this.renderField = this.renderField.bind(this)
  }

  link(fieldSchema, isTextField) {
    const { onChange, value } = this.props
    const field = find(value, { id: fieldSchema.id }) || {}
    return {
      value: isTextField ? field.value : field.value === 'true',
      requestChange(val) {
        let newValue = cloneDeep(value)
        let i = findIndex(value, { id: fieldSchema.id })
        if (i === -1) {
          newValue.push({ id: fieldSchema.id })
          i = newValue.length - 1
        }
        newValue[i].value = '' + val // eslint-disable-line prefer-template
        onChange(newValue)
      }
    }
  }

  getFieldContent(fieldSchema) {
    switch (fieldSchema.type) {
      case 'text':
        return <input type="text" valueLink={this.link(fieldSchema, true)}/>
      case 'textarea':
        return <textarea valueLink={this.link(fieldSchema, true)}/>
      case 'checkbox':
        return <input checkedLink={this.link(fieldSchema)} type="checkbox"/>
      default:
        return null
    }
  }

  renderField(fieldSchema) {
    return (
      <div key={fieldSchema.id} style={{ width: '25%' }}>
        <label className={styles.label}>{fieldSchema.name || '--'}</label>
        {this.getFieldContent(fieldSchema)}
      </div>
    )
  }

  render() {
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {map(this.props.fieldSchemas, this.renderField)}
      </div>
    )
  }

}
