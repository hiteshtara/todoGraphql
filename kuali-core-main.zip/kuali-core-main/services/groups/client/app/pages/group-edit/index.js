/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { get, isEmpty, debounce } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Preloader } from 'shared/kuali-common'

import GroupEdit from './component'
import {
  deleteGroup,
  updateGroup,
  clearErrors
} from '../../state/groups/actions'
import Store from '../../state/groups/store'

function getState({ categoryId, groupId }, resetToStore) {
  let category = Store.category(categoryId)
  let group = Store.group(groupId)
  let parentId = get(category, 'parentId')
  let parentCategory = Store.category(parentId)
  let parentGroups = Store.groupsBy(parentId)
  let errors = Store.errors()
  if (isEmpty(errors) || resetToStore) {
    return { category, group, parentCategory, parentGroups, errors }
  }
  return { errors }
}

export default class GroupEditContainer extends Component {
  displayName: 'GroupEditContainer'

  static propTypes = {
    params: PropTypes.shape({
      categoryId: PropTypes.string.isRequired,
      groupId: PropTypes.string.isRequired
    }).isRequired,
    route: PropTypes.shape({
      path: PropTypes.string.isRequired
    }).isRequired
  }

  constructor(props) {
    super(props)
    this.state = getState(this.props.params)
    this.remove = this.remove.bind(this)
    this.update = this.update.bind(this)
    this._onChange = this._onChange.bind(this)
    this.resetToStore = this.resetToStore.bind(this)
  }

  componentDidMount() {
    Store.addChangeListener(this._onChange)
  }

  componentWillReceiveProps({ params }) {
    let { category, group } = this.state
    if (
      get(category, 'id') !== params.categoryId ||
      get(group, 'id') !== params.groupId
    ) {
      this.setState(getState(params))
    }
  }

  componentWillUnmount() {
    clearErrors()
    Store.removeChangeListener(this._onChange)
  }

  _onChange() {
    this.setState(getState(this.props.params))
  }

  resetToStore() {
    this.setState(getState(this.props.params, true))
  }

  remove() {
    const { groupId } = this.props.params
    deleteGroup(groupId)
  }

  update(group) {
    const { groupId } = this.props.params
    this.setState({ group })
    this.debouncedUpdate(groupId, group)
  }

  debouncedUpdate = debounce((groupId, group) => {
    updateGroup(groupId, group)
  }, 600)

  isNew({ path }) {
    return path === 'category/:categoryId/group/:groupId/new'
  }

  render() {
    const { route, params } = this.props
    const { category, group, parentCategory, parentGroups, errors } = this.state
    const hasCategory = get(category, 'id') || params.categoryId === 'null'
    const hasGroup = get(group, 'id')
    if (!hasCategory || !hasGroup) {
      return <Preloader />
    }
    return (
      <GroupEdit
        category={category}
        errors={errors}
        group={group}
        isNew={this.isNew(route)}
        onReset={this.resetToStore}
        parentCategory={parentCategory}
        parentGroups={parentGroups}
        remove={this.remove}
        update={this.update}
      />
    )
  }
}
