/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import cx from 'classnames'
import React, { Component, PropTypes } from 'react'
import { Popover } from 'react-bootstrap'

import focus from './focus'
import hover from './hover'
import { preserve } from './utils'
import KEYS from './keys'
import styles from '../styles'

export default focus(hover(class Typeahead extends Component {

  static displayName = 'Typeahead';

  static propTypes = {
    children: PropTypes.element.isRequired,
    focusable: PropTypes.func.isRequired,
    formatItem: PropTypes.func.isRequired,
    hoverable: PropTypes.func.isRequired,
    isFocused: PropTypes.bool.isRequired,
    isHovered: PropTypes.bool.isRequired,
    onChange: PropTypes.func.isRequired,
    onSelect: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props)
    this.state = {
      hideDropdown: false,
      results: [],
      selected: 0,
      value: ''
    }
  }

  onEnter(i) {
    this.setState({ selected: i })
  }

  onSelect(i) {
    const selectedItem = this.state.results[i]
    if (selectedItem) {
      this.props.onSelect(selectedItem)
      this.setState({ value: '', hideDropdown: true })
    }
  }

  onKeyDown(e) {
    const { results, selected } = this.state
    if (e.keyCode === KEYS.down) {
      this.setState({
        selected: (selected + 1) % results.length,
        hideDropdown: false
      })
    } else if (e.keyCode === KEYS.up) {
      this.setState({
        selected: (selected - 1 + results.length) % results.length,
        hideDropdown: false
      })
    } else if (!this.state.hideDropdown && e.keyCode === KEYS.enter) {
      this.onSelect(selected)
    } else if (e.keyCode === KEYS.escape) {
      this.setState({ hideDropdown: true })
    } else {
      this.setState({ hideDropdown: false })
    }
  }

  loadResults(value) {
    this.setState({ hideDropdown: false })
    this.props.onChange(value)
      .then(results => {
        this.setState({
          value: value || '',
          results: results || [],
          selected: 0
        })
      })
  }

  onChange(e) {
    this.loadResults(e.target.value)
  }

  onFocus() {
    this.loadResults(this.state.value)
  }

  renderItem(data, i) {
    const btnStyle = cx(styles.itemButton, {
      [styles.active]: this.state.selected === i
    })
    return (
      <li className={styles.item} key={i} onMouseEnter={() => this.onEnter(i)}>
        <button className={btnStyle} onClick={() => this.onSelect(i)}>
          {this.props.formatItem(data, i, this.state.value)}
        </button>
      </li>
    )
  }

  renderPopover() {
    const { hoverable, isFocused, isHovered } = this.props
    const { hideDropdown, results } = this.state
    if (!results.length || hideDropdown || !(isFocused || isHovered)) {
      return null
    }
    return hoverable(
      <Popover
        arrowOffsetLeft={25}
        id="category-selection"
        placement="bottom"
        positionLeft={0}
        positionTop="auto"
      >
        <ul className={styles.results}>
          {results.map(this.renderItem.bind(this))}
        </ul>
      </Popover>
    )
  }

  render() {
    return (
      <div className={styles.wrapper} >
        {this.props.focusable(
          React.cloneElement(...preserve(this.props.children, {
            autoComplete: 'off',
            onChange: this.onChange.bind(this),
            onFocus: this.onFocus.bind(this),
            onKeyDown: this.onKeyDown.bind(this)
          }))
        )}
        {this.renderPopover()}
      </div>
    )
  }

}))
