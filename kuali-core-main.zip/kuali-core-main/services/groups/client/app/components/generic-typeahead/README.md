Generic Typeahead
==================

A low level component for rapidly building Typeaheads.

## Data Definitions

```
type ItemID = string;

type Item = {
  id: ItemID;
  name: string;
}
```

## Edit Mode

```js
import Typeahead from 'components/generic-typeahead'
import {searchUserByName, getAllUsers, getUserById} from './some-user-store'

export default const UserTypeahead = (onChange, placeholder, value) => (
  <Typeahead
    onChange={onChange}
    searchByName={searchUserByName}
    getAll={getAllUsers}
    getById={getUserById}
    notFoundMsg="User Deleted"
    ariaLabel="Add User"
    placeholder={placeholder}
    value={value}
  />
)
```

#### Required Props

* `onChange` `ItemID -> void`: Called when an item is selected.
* `searchByName` `string -> Promise<Array<Item>>`: A function that searches for items.
* `getAll` `() -> Promise<Array<Item>>`: A function that fetches all items.
* `getById` `ItemID -> Promise<Item>`: A function that takes an ID and fetches data.
* `notFoundMsg` `string`: The message to show when a value doesn't exist.
* `ariaLabel` `string`: The aria label to describe the input.

#### Optional Props

* `placeholder` `string`: The placeholder string for the input.
* `value` `ItemID`: The ID saved for this typeahead.

## View Mode

```js
import TypeaheadView from 'components/generic-typeahead/view'
import {getUserById} from './some-user-store'

export default const UserTypeaheadView = (value) => (
  <TypeaheadView
    getById={getUserById}
    notFoundMsg="User Deleted"
    noValueMsg="No User Selected"
    value={value}
  />
)
```

#### Required Props

* `getById` `ItemID -> Promise<Item>`: A function that takes an ID and fetches data.
* `notFoundMsg` `string`: The message to show when a value doesn't exist.
* `noValueMsg` `string`: The message to show when no value has been chosen.

#### Optional Props

* `value` `ItemID`: The ID saved for this typeahead.
