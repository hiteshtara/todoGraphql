/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component } from 'react'

import { preserve } from './utils'

export default OldComponent => {
  return class Focusable extends Component {

    displayName: 'Focusable';

    constructor(props) {
      super(props)
      this.state = { isFocused: false }
    }

    onFocus() {
      this.setState({ isFocused: true })
    }

    onBlur() {
      this.setState({ isFocused: false })
    }

    attach(cmp) {
      return React.cloneElement(...preserve(cmp, {
        onFocus: this.onFocus.bind(this),
        onBlur: this.onBlur.bind(this)
      }))
    }

    render() {
      return (
        <OldComponent
          {...this.props}
          focusable={this.attach.bind(this)}
          isFocused={this.state.isFocused}
        />
      )
    }

  }
}
