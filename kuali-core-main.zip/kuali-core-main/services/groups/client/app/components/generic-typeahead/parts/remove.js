/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { Button } from 'react-bootstrap'

import Icon from '../../icon'
import styles from '../styles'

export default class Remove extends Component {

  static displayName = 'Remove';

  static propTypes = {
    aria: PropTypes.string,
    label: PropTypes.string,
    onClick: PropTypes.func.isRequired
  };

  render() {
    const { aria, label, onClick } = this.props
    return (
      <Button aria-label={aria} className={styles.remove} onClick={onClick}>
        <Icon name="trash"/> {label}
      </Button>
    )
  }

}
