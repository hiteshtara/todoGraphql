/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map, pick } from 'lodash'
import React, { Component, PropTypes } from 'react'

import Typeahead from './parts/typeahead'
import Remove from './parts/remove'
import styles from './styles'
import AsyncTemplate from '../async-template'

function formatItems(items) {
  return map(items, item => pick(item, ['id', 'name']))
}

export default class _Typeahead extends Component {

  static displayName = 'Typeahead';

  static propTypes = {
    ariaLabel: PropTypes.string.isRequired,
    getAll: PropTypes.func.isRequired,
    getById: PropTypes.func.isRequired,
    notFoundMsg: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    placeholder: PropTypes.string,
    searchByName: PropTypes.func.isRequired,
    value: PropTypes.string
  };

  constructor(props) {
    super(props)
    this.state = { text: '' }
  }

  render() {
    const { ariaLabel, notFoundMsg, onChange, placeholder, value } = this.props
    const { searchByName, getAll, getById } = this.props
    const onSelect = ({ id }) => {
      onChange(id)
      this.setState({ text: '' })
    }
    const _onChange = text => {
      this.setState({ text })
      const promise = text ? searchByName(text) : getAll()
      return promise.then(formatItems)
    }
    const template = name => (
      <div className={styles.tag}>
        {name && <span>{name}</span>}
        {!name && <span style={{ color: '#e74c3c' }}>{notFoundMsg}</span>}
        <Remove onClick={() => onChange(null)}/>
      </div>
    )
    if (value) {
      return (
        <div>
          <AsyncTemplate
            default="..."
            error={template()}
            load={getById.bind(null, value)}
            tmpl={item => template(item.name || '--')}
          />
        </div>
      )
    }
    return (
      <Typeahead
        formatItem={item => item.name}
        onChange={_onChange}
        onSelect={onSelect}
      >
        <input
          aria-label={ariaLabel}
          className="form-control"
          placeholder={placeholder}
          value={this.state.text}
        />
      </Typeahead>
    )
  }

}
