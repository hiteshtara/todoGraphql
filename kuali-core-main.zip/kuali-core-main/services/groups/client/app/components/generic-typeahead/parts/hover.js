/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component } from 'react'

import { preserve } from './utils'

export default OldComponent => {
  return class Hoverable extends Component {

    displayName: 'Hoverable';

    constructor(props) {
      super(props)
      this.state = { isHovered: false }
    }

    onHover() {
      this.setState({ isHovered: true })
    }

    onLeave() {
      this.setState({ isHovered: false })
    }

    attach(cmp) {
      return React.cloneElement(...preserve(cmp, {
        onMouseEnter: this.onHover.bind(this),
        onMouseLeave: this.onLeave.bind(this)
      }))
    }

    render() {
      return (
        <OldComponent
          {...this.props}
          hoverable={this.attach.bind(this)}
          isHovered={this.state.isHovered}
        />
      )
    }

  }
}
