/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import classNames from 'classnames/bind'
import { merge } from 'lodash'
import React, { Component, PropTypes } from 'react'

import styles from './style'

const cx = classNames.bind(styles)

export default class Flip extends Component {

  displayName: 'Flip';

  static propTypes = {
    back: PropTypes.func.isRequired,
    className: PropTypes.string,
    direction: PropTypes.oneOf(['horizontal', 'vertical']),
    front: PropTypes.func.isRequired,
    style: PropTypes.shape({
      position: PropTypes.string,
      zIndex: PropTypes.number
    })
  };

  static defaultProps = {
    className: '',
    direction: 'horizontal',
    style: {}
  };

  constructor(props) {
    super(props)
    this.state = { flipped: false }
    this.flip = this.flip.bind(this)
    this.unflip = this.unflip.bind(this)
  }

  componentDidMount() {
    this.setInitialHeight()
  }

  componentWillReceiveProps() {
    setTimeout(() => {
      this.setState({ height: this.getHeight(this.state.flipped) })
    }, 0)
  }

  toggle() {
    this.setFlip(!this.state.flipped)
  }

  flip() {
    this.setFlip(true)
  }

  unflip() {
    this.setFlip(false)
  }

  setFlip(flipped) {
    this.setState({
      flipped,
      height: this.getHeight(flipped)
    })
  }

  setInitialHeight() {
    this.setState({
      height: this.getHeight(this.state.flipped)
    })
  }

  getHeight(flipped) {
    let which = flipped ? 'back' : 'front'
    let el = this.refs[which].children[0]
    if (!el) {
      return 'auto'
    }
    let _styles = getComputedStyle(el)
    return parseInt(_styles.height, 10) +
           parseInt(_styles.marginTop, 10) +
           parseInt(_styles.marginBottom, 10)
  }

  render() {
    let { back, className, direction, front, style } = this.props
    let innerClasses = cx('inner', { flipped: this.state.flipped })
    return (
      <div
        className={`${cx(['container', direction])} ${className}`}
        style={merge({}, style, { height: this.state.height })}
      >
        <div className={innerClasses}>
          <div
            aria-hidden={this.state.flipped}
            children={front(this.flip)}
            className={cx(['front', 'tile'])}
            ref="front"
          />
          <div
            aria-hidden={!this.state.flipped}
            children={back(this.unflip)}
            className={cx(['back', 'tile'])}
            ref="back"
          />
        </div>
      </div>
    )
  }

}
