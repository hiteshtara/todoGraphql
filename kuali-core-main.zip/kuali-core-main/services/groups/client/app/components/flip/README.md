Flip
====

This component takes in two sets of markup and will render them as if they were on two sides of a card. It will animate smoothly between each side by flipping.

#### How to use:

```js
import Flip from 'components/flip'

render() {
  return (
    <Flip
      ref="flip"
      direction="vertical"
      front={toggle => <div>The front <button onClick={toggle}>Flip me</button></div>}
      back={() => <div>The Back</div>}
    />
  );
}

flipCard() {
  this.refs.flip.toggle()
}
```

#### Instance Methods

If you grab a reference to the rendered Flip component, you can call these instance methods on it:

* `toggle` `Function`: Flip the card to it's next state
* `flip` `Function`: Flip the card to the back if it is not already there
* `unflip` `Function`: Flip the card to the front if it is not already there

#### Required Props

* `front` `(toggle: Function) => ReactElement`: a function that takes in a toggle parameter and returns the markup to display on the front
* `back` `(toggle: Function) => ReactElement`: a function that takes in a toggle parameter and returns the markup to display on the back

#### Optional Props

The following props may also be used.  Default values are shown inside [].

* `className` `?string`: [ '' ] Any css classes you want to apply
* `direction` `?string`: [ 'horizontal' ] The direction to flip (may be vertical or horizontal)
* `style` `?Object`: [ {} ] A css styles object
