/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'

import styles from './style'

let Panel = ({ children, rightContent, title }) => (
  <div className={styles.wrapperStyle}>
    <div className={styles.headerStyle}>
      <div className={styles.panelHeader}>
        <div>{title}</div>
        {rightContent}
      </div>
    </div>
    <div className={styles.contentBoxStyle}>
      {children}
    </div>
  </div>
)

export default Panel

Panel.displayName = 'Panel'

Panel.propTypes = {
  children: PropTypes.node.isRequired,
  rightContent: PropTypes.node,
  title: PropTypes.node.isRequired
}
