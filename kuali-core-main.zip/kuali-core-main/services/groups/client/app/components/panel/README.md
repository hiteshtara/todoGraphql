Panel
=====

This is our default look and feel panel.

#### How to use:

```js
import Panel from 'components/panel'

render() {
  return (
    <Panel title="Roles (Override)" rightContent={<button>Close</button>}>
      content goes here
    </Panel>
  );
}
```

#### Required Props

* `children` `ReactElement | string`: The contents of the panel
* `title` `ReactElement | string`: The title of the panel which is displayed in the upper left

#### Optional Props

The following props may also be used.  Default values are shown inside [].

* `rightContent` `?(ReactElement | string)`: [ null ] Any markup you'd like to appear in the upper right
