Async Template
==============

This component is an easy way to defer rendering. It takes in a promise and a function. Once the promise resolves, the function is called with the resolved value. The result of that function is then rendered. There are also props to set the default value or error state.

#### How to use:

```js
import AsyncTemplate from 'components/async-template'

render() {
  return (
    <AsyncTemplate
      default="..."
      error="Could not load course"
      load={loadCourse.bind(null, '123')}
      tmpl={course => <div>{course.title}</div>}
    />
  );
}
```

#### Required Props

* `default` `ReactElement | String`: The markup to show while load is resolving
* `load` `() => Promise<T>`: A promise of some data
* `tmpl` `(val: T) => ReactElement | String`: A function that takes in data and returns the markup to render for it

#### Optional Props

The following props may also be used.  Default values are shown inside [].

* `error` `?(ReactElement | string)`: [ 'Error!' ] The markup to show if the promise was rejected.
