/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map } from 'lodash'
import React, { PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'

import styles from './style'
import { labels } from './messages'
import Remove from '../remove'

export const _List = ({ children, items, remove, intl, disableRemove }) => {
  if (!items.length) {
    return <div />
  }
  return (
    <div>
      <div className={styles.row}>
        {React.Children.map(children, (child, i) => (
          <div className={styles.column} key={i}>
            <label className={styles.label}>
              {child && child.props.label}
            </label>
          </div>
        ))}
      </div>
      {map(items, (f, i) => (
        <div className={styles.row} key={i}>
          {React.Children.map(children, (child, j) => (
            <div className={styles.column} key={j}>
              {child && child.props.render(f, i)}
            </div>
          ))}
          {disableRemove &&
            !disableRemove(i) &&
            <Remove
              aria={intl.formatMessage(labels.removeSection)}
              onClick={() => remove(i)}
            />}
        </div>
      ))}
    </div>
  )
}

_List.displayName = 'List'

_List.propTypes = {
  children: PropTypes.node.isRequired,
  disableRemove: PropTypes.func,
  intl: intlShape.isRequired,
  items: PropTypes.arrayOf(PropTypes.any).isRequired,
  remove: PropTypes.func.isRequired
}
export const List = injectIntl(_List)

export const Column = () => {}

Column.displayName = 'Column'

Column.propTypes = {
  label: PropTypes.string.isRequired,
  render: PropTypes.func.isRequired
}
