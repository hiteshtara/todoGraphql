/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'
import { Button } from 'react-bootstrap'

import styles from './style'
import Icon from '../icon'

let Remove = ({ aria, label, onClick }) => (
  <Button aria-label={aria} className={styles.remove} onClick={onClick}>
    <Icon name="trash" /> {label}
  </Button>
)

Remove.propTypes = {
  aria: PropTypes.string.isRequired,
  label: PropTypes.string,
  onClick: PropTypes.func.isRequired
}

Remove.displayName = 'Remove'

export default Remove
