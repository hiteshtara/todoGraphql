/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import classNames from 'classnames'
import { isEqual } from 'lodash'
import React, { Component, PropTypes } from 'react'

export default class Icon extends Component {

  displayName: 'Icon';

  shouldComponentUpdate(nextProps) {
    return !isEqual(this.props, nextProps)
  }

  render() {
    let { name, spin, pulse, className } = this.props
    let classes = classNames('fa', `fa-${name}`, className, {
      'fa-pulse': pulse,
      'fa-spin': spin
    })
    return <i className={classes} />
  }

}

Icon.propTypes = {
  className: PropTypes.string,
  name: PropTypes.string.isRequired,
  pulse: PropTypes.bool,
  spin: PropTypes.bool
}
