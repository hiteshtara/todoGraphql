/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint react/forbid-prop-types: 0 */

import { map } from 'lodash'
import React, { Component, PropTypes } from 'react'

export default class MultiselectView extends Component {

  static displayName = 'MultiselectView';

  static propTypes = {
    TypeaheadView: PropTypes.func.isRequired,
    taProps: PropTypes.object,
    value: PropTypes.array
  };

  render() {
    let { taProps, TypeaheadView, value } = this.props
    value = value || []
    taProps = taProps || {}
    return (
      <div>
        {map(value, (id, i) => (
          <div key={i}>
            <TypeaheadView value={id} {...taProps}/>
          </div>
        ))}
      </div>
    )
  }

}
