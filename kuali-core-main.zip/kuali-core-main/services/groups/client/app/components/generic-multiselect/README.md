Multiselect
============

A Generic Multiselect component.

#### How to use:

```js
import Multiselect from 'components/generic-multiselect'
import UserTypeahead from 'components/user-typeahead'

<Multiselect
  onChange={ids => save(ids)}
  Typeahead={UserTypeahead}
  taProps={{placeholder: 'Search Users'}}
  value={ids}
/>
```

```js
import MultiselectView from 'components/generic-multiselect/view'
import UserTypeaheadView from 'components/user-typeahead/view'

<MultiselectView
  TypeaheadView={UserTypeaheadView}
  value={ids}
/>
```

#### Required Props

* `onChange` `ItemID[] -> void`: Called when the Item list changes.
* `Typeahead` `ReactElement`: A Typeahead component to wrap.
* `TypeaheadView` `ReactElement`: A Typeahead component to wrap.

#### Optional Props

* `taProps`: `Object`: extra props to pass in to the typeahead.
* `value` `ItemID[]`: The ItemIDs saved for this multiselect.
