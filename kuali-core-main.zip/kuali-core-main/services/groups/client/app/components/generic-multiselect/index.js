/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint react/forbid-prop-types: 0 */

import { map, uniq, without } from 'lodash'
import React, { Component, PropTypes } from 'react'

export default class Multiselect extends Component {

  static displayName = 'Multiselect';

  static propTypes = {
    Typeahead: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    taProps: PropTypes.object,
    value: PropTypes.array
  };

  render() {
    let { onChange, taProps, Typeahead, value } = this.props
    value = value || []
    taProps = taProps || {}
    const save = id => onChange(uniq([...value, id]))
    return (
      <div>
        <Typeahead curValues={value} onChange={save} {...taProps}/>
        <div>
          {map(value, (id) => (
            <div key={id}>
              <Typeahead
                onChange={() => onChange(without(value, id))}
                value={id} {...taProps}
              />
            </div>
          ))}
        </div>
      </div>
    )
  }

}
