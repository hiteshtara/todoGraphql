/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const titles = defineMessages({
  success: {
    id: 'groups.notifications.success',
    description: 'Title for success notification',
    defaultMessage: 'Success!'
  },
  error: {
    id: 'groups.notifications.error',
    description: 'Title for error notification',
    defaultMessage: 'Error!'
  }
})

export const labels = defineMessages({
  close: {
    id: 'groups.notifications.close',
    description: 'Accessibility label for closing a notification',
    defaultMessage: 'Close Notice'
  }
})

export default { titles }
