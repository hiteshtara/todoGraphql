/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import cx from 'classnames'
import React, { Component, PropTypes } from 'react'
import { injectIntl, intlShape } from 'react-intl'

import styles from './notice.css'
import { labels } from '../messages'
import Icon from '../../icon'

const ICONS = {
  success: <Icon className={styles.icon} name="check"/>,
  warning: <Icon className={styles.icon} name="exclamation-triangle"/>,
  error: <Icon className={styles.icon} name="ban"/>
}

export class _Notice extends Component {

  displayName: 'Notice';

  constructor(props) {
    super(props)
    this.state = { closeButtonHovered: false, closed: false }
  }

  toggleHoverCloseButton() {
    this.setState({
      closeButtonHovered: !this.state.closeButtonHovered
    })
  }

  close() {
    if (this.props.onClose) {
      this.props.onClose()
    } else {
      this.setState({ closed: true })
    }
  }

  render() {
    let { children, className, closeButton, title, type } = this.props
    if (closeButton && this.state.closed) {
      return null
    }
    return (
      <div
        className={cx(styles.container, styles[type], className)}
        role="alert"
      >
        {ICONS[type]}
        <div className={styles.bodyWrapper}>
          <div className={styles.title}>{title}</div>
          <div className={styles.body}>{children}</div>
        </div>
        <div className={styles.closeButtonWrapper}>
          {closeButton && (
            <button
              aria-label={this.props.intl.formatMessage(labels.close)}
              children={<Icon name="times"/>}
              className={styles.closeButton}
              onBlur={this.toggleHoverCloseButton}
              onClick={this.close}
              onFocus={this.toggleHoverCloseButton}
              onMouseEnter={this.toggleHoverCloseButton}
              onMouseLeave={this.toggleHoverCloseButton}
              style={{ opacity: this.state.closeButtonHovered ? 1 : .5 }}
            />
          )}
        </div>
      </div>
    )
  }

}

_Notice.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  closeButton: PropTypes.bool,
  intl: intlShape.isRequired,
  onClose: PropTypes.func,
  title: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired
}

export default injectIntl(_Notice)
