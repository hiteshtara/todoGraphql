/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint import/no-unresolved: 0 */
/* global expect */
import { noop } from 'lodash'
import React from 'react/addons'

import NotificationModal from '../notification-modal'
import asyncTest from '../../__tests__/helpers'

let TestUtils = React.addons.TestUtils

describe('NotificationModal', () => {
  it('renders a button', () => {
    let container = TestUtils.renderIntoDocument(
      <NotificationModal registerCallback={noop}/>
    )
    let button = TestUtils.findRenderedDOMComponentWithTag(container, 'button')
    expect(button).toBeDefined()
  })

  it('initially renders as hidden', () => {
    let container = TestUtils.renderIntoDocument(
      <NotificationModal registerCallback={noop}/>
    )
    let node = TestUtils.findRenderedDOMComponentWithClass(
      container, 'notification-modal')
    expect(node.props['aria-hidden']).toBe(true)
  })

  it('shows itself when its registerCallback fn is called', done => {
    let toCall = noop
    function cb(myCb) {
      toCall = myCb
    }
    let container = TestUtils.renderIntoDocument(
      <NotificationModal registerCallback={cb}/>
    )
    toCall('Some Error oh no')
    asyncTest(() => {
      let node = TestUtils.findRenderedComponentWithType(
        container, NotificationModal)
      expect(node.state.showing).toBe(true)
      expect(node.state.contents.length > 0).toBe(true)
    }).done(done)
  })

  it('hides itself when the close button is clicked', done => {
    let container = getShowingContainer()
    let button = TestUtils.findRenderedDOMComponentWithTag(container, 'button')
    let node = TestUtils.findRenderedComponentWithType(
      container, NotificationModal)
    expect(node.state.showing).toBe(true)
    TestUtils.Simulate.click(button, {})
    asyncTest(() => {
      node = TestUtils.findRenderedComponentWithType(
        container, NotificationModal)
      expect(node.state.showing).toBe(false)
    }).done(done)
  })
})

function getShowingContainer() {
  let toCall = noop
  function cb(myCb) {
    toCall = myCb
  }
  let container = TestUtils.renderIntoDocument(
    <NotificationModal registerCallback={cb}/>
  )
  toCall('Some Error oh no')
  return container
}
