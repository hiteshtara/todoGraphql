/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import classNames from 'classnames/bind'
import React, { Component } from 'react'
import { injectIntl, intlShape } from 'react-intl'

import styles from './style'
import { titles } from './messages'
import Notice from './parts/notice'

const cx = classNames.bind(styles)

let timeoutId = null

export class _NotificationModal extends Component {

  displayName: 'NotificationModal';

  constructor(props: any) {
    super(props)
    this.state = {
      contents: '',
      show: false,
      title: '',
      type: 'success'
    }
    this.hide = this.hide.bind(this)
  }

  componentDidMount() {
    registerErrorCallback(contents => {
      this.displayNotification({
        contents,
        title: this.props.intl.formatMessage(titles.error),
        type: 'error'
      })
    })
    registerSuccessCallback(contents => {
      this.displayNotification({
        contents,
        title: this.props.intl.formatMessage(titles.success),
        type: 'success'
      })
    })
  }

  displayNotification(state) {
    clearTimeout(timeoutId)
    state.show = true
    this.setState(state)
    timeoutId = setTimeout(() => {
      this.setState({ show: false })
    }, 5000)
  }

  hide() {
    this.setState({ show: false })
  }

  render() {
    return (
      <div
        aria-hidden={!this.state.show}
        className={cx('container', { show: this.state.show })}
      >
        <Notice
          children={this.state.contents}
          className={styles.noticeOverrides}
          closeButton
          onClose={this.hide}
          title={this.state.title}
          type={this.state.type}
        />
      </div>
    )
  }

}

_NotificationModal.propTypes = {
  intl: intlShape.isRequired
}

export default injectIntl(_NotificationModal)

let errorCb
let successCb

export function showError(error) {
  console.log('error is', error) //eslint-disable-line
  errorCb(error)
}

function registerErrorCallback(cb) {
  errorCb = cb
}

export function showSuccess(success) {
  successCb(success)
}

function registerSuccessCallback(cb) {
  successCb = cb
}
