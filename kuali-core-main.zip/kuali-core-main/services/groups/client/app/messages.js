/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const fieldTypes = defineMessages({
  text: {
    id: 'groups.options.textType',
    description: 'Option text for fields of type "text"',
    defaultMessage: 'Text'
  },
  textarea: {
    id: 'groups.options.textareaType',
    description: 'Option text for fields of type "textarea"',
    defaultMessage: 'Textarea'
  },
  checkbox: {
    id: 'groups.options.checkboxType',
    description: 'Option text for fields of type "checkbox"',
    defaultMessage: 'Checkbox'
  }
})

export const labels = defineMessages({
  fields: {
    id: 'groups.labels.fields',
    description: 'Column/section header for a group of fields',
    defaultMessage: 'Fields'
  }
})

export default { fieldTypes, labels }
