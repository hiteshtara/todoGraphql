/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { IntlProvider } from 'react-intl'
import { Router, IndexRoute, Route } from 'react-router'
import { NotFound } from 'shared/kuali-common'

import './styles'
import './common/fix-axios'
import Main from './pages/main'
import CategoryView from './pages/category-view'
import CategoryEdit from './pages/category-edit'
import GroupView from './pages/group-view'
import GroupEdit from './pages/group-edit'
import Search from './pages/search'

export default class App extends Component {

  displayName = 'App';

  static propTypes = {
    history: PropTypes.shape({}).isRequired,
    messages: React.PropTypes.shape({})
  };

  render() {
    return (
      <IntlProvider locale="en" messages={this.props.messages || {}}>
        <Router history={this.props.history}>
          <Route component={Main} path="/">
            <IndexRoute component={Search}/>
            <Route component={Search} path="search/:categoryId"/>
            <Route path="category/:categoryId/">
              <Route component={CategoryView} path="view"/>
              <Route component={CategoryEdit} path="edit"/>
              <Route component={CategoryEdit} path="new"/>
              <Route path="group/:groupId/">
                <Route component={GroupView} path="view"/>
                <Route component={GroupEdit} path="edit"/>
                <Route component={GroupEdit} path="new"/>
              </Route>
            </Route>
          </Route>
          <Route component={NotFound} path="*"/>
        </Router>
      </IntlProvider>
    )
  }

}
