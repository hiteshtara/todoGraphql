/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint react/prop-types: 0, react/no-multi-comp: 0 */

import React from 'react'
import axios from 'axios'

import Typeahead from '../components/generic-typeahead'
import TypeaheadView from '../components/generic-typeahead/view'

export default function getTypeaheadFor(categoryId) {

  function getById(id) {
    return axios.get(`/api/v1/groups/${id}`)
      .then((response) => response.data)
  }

  function getAll() {
    return axios.get(`/api/v1/groups/?categoryId=${categoryId}`)
      .then((response) => response.data)
  }

  function searchByName(name) {
    return axios.get(`/api/v1/groups/?categoryId=${categoryId}&q=${name}`)
      .then((response) => response.data)
  }

  const GroupTypeahead = ({ onChange, placeholder, value }) => (
    <Typeahead
      ariaLabel="Add Group"
      getAll={getAll}
      getById={getById}
      notFoundMsg="Group Deleted"
      onChange={onChange}
      placeholder={placeholder}
      searchByName={searchByName}
      value={value}
    />
  )

  const GroupTypeaheadView = ({ value, link }) => (
    <TypeaheadView
      getById={getById}
      link={link}
      noValueMsg="No Group Selected"
      notFoundMsg="Group Deleted"
      value={value}
    />
  )

  return { GroupTypeahead, GroupTypeaheadView }
}
