/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint react/prop-types: 0, react/no-multi-comp: 0 */

import React from 'react'

import Typeahead from '../components/generic-typeahead'
import TypeaheadView from '../components/generic-typeahead/view'
import * as UsersStore from '../state/users/api'

export const UsersTypeahead = ({ curValues, onChange, placeholder, value }) => (
  <Typeahead
    ariaLabel="Add User"
    getAll={UsersStore.getAll.bind(null, curValues)}
    getById={UsersStore.getById}
    notFoundMsg="User Deleted"
    onChange={onChange}
    placeholder={placeholder}
    searchByName={UsersStore.searchByName.bind(null, curValues)}
    value={value}
  />
)

export const UsersTypeaheadView = ({ value }) => (
  <TypeaheadView
    getById={UsersStore.getById}
    noValueMsg="No User Selected"
    notFoundMsg="User Deleted"
    value={value}
  />
)
