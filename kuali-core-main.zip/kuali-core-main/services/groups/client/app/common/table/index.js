/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import cx from 'classnames'
import { map } from 'lodash'
import React, { Component, PropTypes } from 'react'

import styles from './style'

export default class KualiTable extends Component {

  displayName: 'KualiTable';

  static propTypes = {
    children: PropTypes.node,
    results: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string.isRequired
      }).isRequired
    ).isRequired,
    urlForItem: PropTypes.func.isRequired
  };

  render() {
    const { children, results, urlForItem } = this.props
    return (
      <table className={cx('table', 'table-hover', styles.table)}>
        <thead>
          <tr className={styles.tableHeader}>
            {React.Children.map(children, child => (child &&
              <th className={styles.stripPadding}>
                <button className={styles.th} onClick={child.props.onClick}>
                  {child.props.label}
                </button>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {map(results, result => (
            <tr className={styles.row} key={result.id}>
              {React.Children.map(children, child => (child &&
                <td className={styles.stripPadding}>
                  <a className={styles.link} href={urlForItem(result)}>
                    {child.props.render(result)}
                  </a>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    )
  }

}
