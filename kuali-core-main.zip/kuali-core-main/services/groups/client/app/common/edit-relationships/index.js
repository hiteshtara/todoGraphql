/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { map } from 'lodash'
import React, { Component, PropTypes } from 'react'
import { Button } from 'react-bootstrap'
import { injectIntl, intlShape } from 'react-intl'

import styles from './style'
import { labels, columns } from './messages'
import { Column, List } from '../../components/list'
import { RelationshipSchemaType, CategoryType } from '../../prop-types'

export class _EditRelationships extends Component {

  static displayName: 'EditRelationship';

  static propTypes = {
    categories: PropTypes.arrayOf(
      CategoryType.isRequired
    ).isRequired,
    intl: intlShape.isRequired,
    onChange: PropTypes.func.isRequired,
    value: PropTypes.arrayOf(
      RelationshipSchemaType.isRequired
    ).isRequired
  }

  render() {
    const { onChange, value, categories } = this.props
    const fmt = this.props.intl.formatMessage
    return (
      <div>
        <List items={value} remove={(i) => {
          value.splice(i, 1)
          onChange(value)
        }}>
          <Column label={fmt(columns.name)} render={(field, i) => (
            <input
              aria-label={fmt(labels.nameLabel)}
              className="form-control"
              onChange={e => {
                value[i].name = e.target.value
                onChange(value)
              }}
              type="text"
              value={field.name}
            />
          )}/>
          <Column label={fmt(columns.category)} render={(field, i) => (
            <select
              className="form-control"
              onChange={e => {
                const val = e.target.value
                value[i].categoryId = val === 'null' ? null : val
                onChange(value)
              }}
              value={value[i].categoryId || ''}
            >
              <option
                children={fmt(labels.noCategoryLabel)}
                key="null"
                value="null"
              />
              {map(categories, (category) => (
                <option
                  children={category.name || '--'}
                  key={category.id}
                  value={category.id}
                />
              ))}
            </select>
          )}/>
        </List>
        <Button className={styles.button}
          onClick={() => onChange([...value, createField()])}>
          {fmt(labels.addRelationship)}
        </Button>
      </div>
    )
  }

}

function createField() {
  return {
    name: '',
    categoryId: null
  }
}

export default injectIntl(_EditRelationships)
