/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const labels = defineMessages({
  addRelationship: {
    id: 'groups.buttons.addRelationship',
    description: 'Button text for adding a relationship',
    defaultMessage: 'Add Relationship'
  },
  nameLabel: {
    id: 'groups.labels.relationshipName',
    description: 'Accessbility label for text input of relationship names',
    defaultMessage: 'Relationship Name'
  },
  noCategoryLabel: {
    id: 'groups.labels.noCategory',
    description: 'The No Category Label in Category Selection',
    defaultMessage: '<No Category>'
  }
})

export const columns = defineMessages({
  name: {
    id: 'groups.columns.relationshipName',
    description: 'Column title for the column of relationship names',
    defaultMessage: 'Name'
  },
  category: {
    id: 'groups.columns.relationshipCategory',
    description: 'Column title for the column of relationship category',
    defaultMessage: 'Category'
  }
})

export default { labels, columns }
