/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'

import styles from './style'

let Sidebar = ({ children, className }) => (
  <nav className={`${styles.sidebar} ${className}`}>
    {children}
  </nav>
)

Sidebar.displayName = 'Sidebar'

Sidebar.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string
}

export default Sidebar
