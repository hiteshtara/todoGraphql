/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'
import { Link } from 'react-router'

import styles from './style'

export default function Container({ aria, children, to, type }) {
  if (type === 'link') {
    return (
      <Link
        aria-label={aria}
        children={children}
        to={to}
      />
    )
  }
  return (
    <button
      aria-label={aria}
      children={children}
      className={styles.nakedButton}
      onClick={to}
    />
  )
}
Container.displayName = 'Container'
Container.propTypes = {
  aria: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired,
  to: PropTypes.oneOfType([
    PropTypes.func.isRequired,
    PropTypes.string.isRequired
  ]).isRequired,
  type: PropTypes.oneOf(['link', 'button']).isRequired
}
