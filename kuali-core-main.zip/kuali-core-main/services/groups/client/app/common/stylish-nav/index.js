/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'

import Container from './container'
import styles from './style'
import Icon from '../../components/icon'

export default function StylishNav({ children, icon, to, type }) {
  icon = typeof icon == 'string'
    ? <Icon className={styles.icon} name={icon}/>
    : icon
  return (
    <div className={styles.linkContainer}>
      <Container aria={children} to={to} type={type}>
        <div className={styles.content}>
          {icon}
          <span className={styles.link}>
            {children}
          </span>
        </div>
      </Container>
    </div>
  )
}

StylishNav.displayName = 'StylishNav'

StylishNav.propTypes = {
  children: PropTypes.string,
  icon: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.element
  ]),
  to: PropTypes.oneOfType([
    PropTypes.func.isRequired,
    PropTypes.string.isRequired
  ]).isRequired,
  type: PropTypes.oneOf(['link', 'button']).isRequired
}
