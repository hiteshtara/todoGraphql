/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { PropTypes } from 'react'
import { Link } from 'react-router'
import { FormattedMessage } from 'react-intl'

import styles from './style.css'
import { links } from './messages'

let Header = ({ name }) => (
  <div className={styles.header}>
    <div className={styles.upper}>
      <Link to="/">
        <i className="fa fa-arrow-left"/>
        <span className={styles.linkText}>
          <FormattedMessage {...links.backHome}/>
        </span>
      </Link>
    </div>
    <h1>{name}</h1>
  </div>
)

Header.displayName = 'Header'

Header.propTypes = {
  name: PropTypes.string.isRequired
}

export default Header
