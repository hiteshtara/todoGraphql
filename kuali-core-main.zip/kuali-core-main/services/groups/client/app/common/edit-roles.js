/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { Button } from 'react-bootstrap'
import { injectIntl, intlShape, FormattedMessage } from 'react-intl'
import shortid from 'shortid'
import { labels as sharedLabels } from 'shared/i18n'
import { assign } from 'lodash'
import cx from 'classnames'

import { labels as localLabels, columns } from './messages'
import { Column, List } from '../components/list'
import { RoleSchemaType } from '../prop-types'
import UsersStore from '../state/users/store'

const labels = assign({}, sharedLabels, localLabels)

export class _EditRoles extends Component {
  displayName: "EditRoles"

  static propTypes = {
    categoryId: PropTypes.string.isRequired,
    errors: PropTypes.object, //eslint-disable-line react/forbid-prop-types
    intl: intlShape.isRequired,
    onChange: PropTypes.func.isRequired,
    value: PropTypes.arrayOf(RoleSchemaType.isRequired).isRequired
  }

  onChange = (i, property, newValue) => {
    const { onChange, value } = this.props
    onChange([
      ...value.slice(0, i),
      { ...value[i], [property]: newValue },
      ...value.slice(i + 1)
    ])
  }

  render() {
    const { onChange, value, errors, categoryId } = this.props
    const fmt = this.props.intl.formatMessage

    return (
      <div>
        <List
          disableRemove={i => value[i].readOnly}
          items={value}
          remove={i => {
            onChange([...value.slice(0, i), ...value.slice(i + 1)])
          }}
        >
          <Column
            label={fmt(columns.name)}
            render={(
              role,
              i // eslint-disable-line
            ) => (
              <div
                className={cx({
                  'has-error': errors && errors[`roleSchemas.${i}.name`]
                })}
              >
                {role.readOnly
                  ? <div>{role.name}</div>
                  : <input
                    aria-label={fmt(labels.name)}
                    className="form-control"
                    onChange={e => this.onChange(i, 'name', e.target.value)}
                    type="text"
                    value={role.name}
                    />}
                {errors &&
                  errors[`roleSchemas.${i}.name`] &&
                  <div className="alert alert-danger">
                    {errors[`roleSchemas.${i}.name`]}
                  </div>}
              </div>
            )}
          />
          <Column
            label={fmt(columns.description)}
            render={(
              role,
              i // eslint-disable-line
            ) =>
              (role.readOnly
                ? <div>{role.description}</div>
                : <textarea
                  aria-label={fmt(labels.desc)}
                  className="form-control"
                  onChange={e =>
                      this.onChange(i, 'description', e.target.value)}
                  value={role.description}
                  />)}
          />
          {UsersStore.featureEnabled('cor-groups-members-role') &&
            <Column
              label={fmt(labels.editPermissions)}
              render={(
                role,
                i // eslint-disable-line
              ) => (
                <a
                  className="btn btn-primary"
                  href={`/cor/permissions/#/roles/${categoryId}::${role.id}`}
                >
                  <FormattedMessage {...labels.editPermissions} />
                </a>
              )}
            />}
        </List>
        <Button onClick={() => onChange([...value, createNewRole()])}>
          {fmt(labels.addRole)}
        </Button>
      </div>
    )
  }
}

function createNewRole() {
  return {
    id: shortid.generate(),
    name: '',
    description: ''
  }
}

export default injectIntl(_EditRoles)
