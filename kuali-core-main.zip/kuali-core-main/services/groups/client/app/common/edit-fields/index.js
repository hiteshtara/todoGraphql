/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import React, { Component, PropTypes } from 'react'
import { Button } from 'react-bootstrap'
import { injectIntl, intlShape } from 'react-intl'
import shortid from 'shortid'

import styles from './style'
import { labels, columns } from './messages'
import { fieldTypes as types } from '../../messages'
import { Column, List } from '../../components/list'
import { FieldSchemaType } from '../../prop-types'

export class _EditFields extends Component {

  displayName: 'EditFields';

  static propTypes = {
    intl: intlShape.isRequired,
    onChange: PropTypes.func.isRequired,
    value: PropTypes.arrayOf(
      FieldSchemaType.isRequired
    ).isRequired
  };

  render() {
    const { onChange, value } = this.props
    const fmt = this.props.intl.formatMessage
    return (
      <div>
        <List items={value} remove={i => {
          value.splice(i, 1)
          onChange(value)
        }}
        >
          <Column label={fmt(columns.label)} render={(field, i) => ( // eslint-disable-line
            <input
              aria-label={fmt(labels.fieldLabel)}
              className="form-control"
              onChange={e => {
                value[i].name = e.target.value
                onChange(value)
              }}
              type="text"
              value={field.name}
            />
          )}/>
          <Column label={fmt(columns.type)} render={(field, i) => ( // eslint-disable-line
            <select
              className="form-control"
              onChange={e => {
                value[i].type = e.target.value
                onChange(value)
              }}
              value={field.type}
            >
              <option value="text">{fmt(types.text)}</option>
              <option value="textarea">{fmt(types.textarea)}</option>
              <option value="checkbox">{fmt(types.checkbox)}</option>
            </select>
          )}/>
        </List>
        <Button className={styles.button}
          onClick={() => onChange([...value, createField()])}>
          {fmt(labels.addField)}
        </Button>
      </div>
    )
  }

}

function createField() {
  return {
    id: shortid.generate(),
    name: '',
    type: 'text'
  }
}

export default injectIntl(_EditFields)
