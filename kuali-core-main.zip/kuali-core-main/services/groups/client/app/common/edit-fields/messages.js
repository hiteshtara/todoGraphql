/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { defineMessages } from 'react-intl'

export const labels = defineMessages({
  addField: {
    id: 'groups.buttons.addField',
    description: 'Button text for adding a field',
    defaultMessage: 'Add Field'
  },
  fieldLabel: {
    id: 'groups.labels.fieldLabel',
    description: 'Accessbility label for text input of field labels',
    defaultMessage: 'Field Label'
  }
})

export const columns = defineMessages({
  label: {
    id: 'groups.columns.label',
    description: 'Column title for the column of labels',
    defaultMessage: 'Label'
  },
  type: {
    id: 'groups.columns.type',
    description: 'Column title for the column of types',
    defaultMessage: 'Type'
  }
})

export default { labels, columns }
