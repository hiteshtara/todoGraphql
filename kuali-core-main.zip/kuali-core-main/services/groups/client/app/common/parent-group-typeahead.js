/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint react/prop-types: 0, react/no-multi-comp: 0 */

import Promise from 'bluebird'
import { filter, find } from 'lodash'
import React from 'react'

import Typeahead from '../components/generic-typeahead'
import TypeaheadView from '../components/generic-typeahead/view'

export default function getTypeaheadFor(groups) {

  function getById(id) {
    return Promise.resolve(find(groups, { id }))
  }

  function getAll() {
    return Promise.resolve(groups)
  }

  function searchByName(name) {
    const regex = new RegExp(name, 'i')
    const vals = filter(groups, group => (group.name || '').match(regex))
    return Promise.resolve(vals)
  }

  const ParentGroupTypeahead = ({ onChange, placeholder, value }) => (
    <Typeahead
      ariaLabel="Add Parent Group"
      getAll={getAll}
      getById={getById}
      notFoundMsg="Parent Group Deleted"
      onChange={onChange}
      placeholder={placeholder}
      searchByName={searchByName}
      value={value}
    />
  )

  const ParentGroupTypeaheadView = ({ value }) => (
    <TypeaheadView
      getById={getById}
      noValueMsg="No Parent Group Selected"
      notFoundMsg="Parent Group Deleted"
      value={value}
    />
  )

  return { ParentGroupTypeahead, ParentGroupTypeaheadView }
}
