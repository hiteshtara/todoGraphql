/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { throttle } from 'lodash'
import React, { Component } from 'react'

const breakpoints = {
  sm: 768,
  md: 992,
  lg: 1200
}

function getSize() {
  let width = window.innerWidth
  if (width <= breakpoints.sm) {
    return 'small'
  } else if (width <= breakpoints.md) {
    return 'medium'
  } else if (width <= breakpoints.lg) {
    return 'large'
  }
  return 'huge'
}

export default OldComponent => class MedaiQueryify extends Component {

  displayName: 'MediaQueryHoc';

  constructor() {
    super()
    this.state = { mq: getSize() }
  }

  componentDidMount() {
    this.setupListeners()
  }

  setupListeners() {
    this.onResize = throttle(() => {
      this.setState({ mq: getSize() })
    }, 100)
    window.addEventListener('resize', this.onResize)
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.onResize)
  }

  render() {
    return <OldComponent mq={this.state.mq} {...this.props}/>
  }

}
