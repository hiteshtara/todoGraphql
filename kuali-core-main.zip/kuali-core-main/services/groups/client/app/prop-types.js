/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { PropTypes } from 'react'

const { arrayOf, shape, string, oneOf } = PropTypes

export const RoleSchemaType = shape({
  id: string.isRequired,
  name: string.isRequired,
  description: string.isRequired
})

export const RoleType = shape({
  id: string.isRequired,
  value: arrayOf(
    string.isRequired
  ).isRequired
})

export const FieldSchemaType = shape({
  id: string.isRrequired,
  type: oneOf(['text', 'textarea', 'checkbox']).isRequired,
  name: string.isRequired
})

export const FieldType = shape({
  id: string.isRequired,
  value: string.isRequired
})

export const RelationshipSchemaType = shape({
  id: string,
  name: string.isRequired,
  categoryId: string
})

export const RelationshipType = shape({
  id: string,
  value: string
})

export const CategoryType = shape({
  id: string.isRequired,
  created: string,
  updated: string,
  name: string.isRequired,
  parentId: string,
  roleSchemas: arrayOf(
    RoleSchemaType.isRequired
  ).isRequired,
  fieldSchemas: arrayOf(
    FieldSchemaType.isRequired
  ).isRequired
})

export const GroupType = shape({
  id: string.isRequired,
  created: string,
  updated: string,
  name: string.isRequired,
  parentId: string,
  categoryId: string,
  roleSchemas: arrayOf(
    RoleSchemaType.isRequired
  ),
  roles: arrayOf(
    RoleType.isRequired
  ).isRequired,
  fieldSchemas: arrayOf(
    FieldSchemaType.isRequired
  ),
  fields: arrayOf(
    FieldType.isRequired
  ).isRequired
})
