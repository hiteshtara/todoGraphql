/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import Ajv from 'ajv'
import { editTypes, workflowTypes, logTypes } from './model'

const ajv = new Ajv({ allErrors: true })
const ANY_TYPE = [
  'number',
  'integer',
  'string',
  'boolean',
  'array',
  'object',
  'null'
]

const editSchema = {
  $schema: 'http://json-schema.org/draft-04/schema#',
  type: 'object',
  properties: {
    userId: { type: 'string' },
    itemId: { type: 'string' },
    type: {
      type: 'string',
      enum: editTypes
    },
    old: { type: ANY_TYPE },
    new: { type: ANY_TYPE },
    field: { type: 'string' }
  },
  additionalProperties: false,
  required: [
    'userId',
    'itemId',
    'type',
    'old',
    'new',
    'field'
  ]
}

const _validateEdit = ajv.compile(editSchema)
const validateEdit = makeGoodValidator(_validateEdit)

const workflowSchema = {
  $schema: 'http://json-schema.org/draft-04/schema#',
  type: 'object',
  properties: {
    userId: { type: 'string' },
    itemId: { type: 'string' },
    type: {
      type: 'string',
      enum: workflowTypes
    },
    comment: { type: 'string' }
  },
  additionalProperties: false,
  required: [
    'userId',
    'itemId',
    'type'
  ]
}

const _validateWorkflow = ajv.compile(workflowSchema)
const validateWorkflow = makeGoodValidator(_validateWorkflow)

export default function validate(log) {
  if (editTypes.includes(log.type)) {
    return validateEdit(log)
  } else if (workflowTypes.includes(log.type)) {
    return validateWorkflow(log)
  }
  return [{ message: `type must be of type: ${logTypes.join(', ')}` }]
}

function makeGoodValidator(validator) {
  return function(data) {
    const valid = validator(data)
    if (valid) {
      return null
    }
    return validator.errors
  }
}
