/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import bodyParser from 'body-parser'
import express from 'express'
import secure from 'shared/secure'
import seneca from 'shared/seneca'
import { errorHandler } from 'shared/errors'
import health from './health'
import logsApi from './api-v1'
import logs from './plugin'

const app = express()
app.use(secure)
app.use(bodyParser.json())
app.use('/api/v1/logs', logsApi)
app.use(errorHandler)
health(app)

seneca.use(logs)

export default app
