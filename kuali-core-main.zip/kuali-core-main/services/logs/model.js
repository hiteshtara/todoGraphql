/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import mongoose from 'shared/mongoose'
import audit from 'shared/mongoose/plugins/mongoose-audit'

export const editTypes = ['edit', 'adminEdit']
export const workflowTypes = ['workflowApprove', 'workflowReject']
export const logTypes = editTypes.concat(workflowTypes)
const schema = mongoose.Schema({
  type: {
    type: String,
    enum: logTypes,
    required: true
  },

  userId: {
    type: String,
    required: true
  },

  userName: {
    type: String,
    required: true
  },

  isApiRequest: {
    type: Boolean,
    default: false
  },

  comment: String,

  // the id of the item being logged
  itemId: {
    type: String,
    index: true,
    required: true
  }

})

schema.plugin(audit)

const modelMap = {}

export function getModel(connection) {
  if (!modelMap[connection]) {
    modelMap[connection] = connection.model('Log', schema)
  }
  return modelMap[connection]
}
