/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import express from 'express'
import institutionLoader from 'shared/institution-loader'
import responseLocals from 'shared/middleware/response-locals'
import request from 'supertest'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import logsApp from 'services/logs'
import { getModel } from '../model'
import healthRoutes from '../health'


const { connection, connectionKey } = getTestConnectionInfo()
const Job = getModel(connection)

describe('API V1 logs', () => {
  let app, mockedUser

  before(async () => {
    mockedUser = await createUser({
      email: 'foo@logs.com',
      phone: '8011231234',
      provider: 'Verizon',
      username: 'foobar',
      firstName: 'Yolo',
      lastName: 'Swaggins'
    })

    // Creates an institution for the tests to use.
    await seneca.actAsync({
      role: 'institutions',
      cmd: 'load',
      data: { subdomain: 'kuali', name: 'Kuali' },
      connectionKey
    })

    app = express()
    app.use(responseLocals)
    app.use(institutionLoader)
    healthRoutes(app)
    app.use(logsApp)
  })

  beforeEach(async () => {
    await Job.remove({})
  })

  describe('health route |', () => {
    it('returns a health status code', async () => {
      let { text } = await request(app).get('/api/v1/logs/health')
        .set('Authorization', await getAuthHeader(mockedUser.id))
        .expect(204)
      assert.equal(text, '')
    })

    it('returns health status detail', async () => {
      let { text } = await request(app).get('/api/v1/logs/health?detail=true')
        .set('Authorization', await getAuthHeader(mockedUser.id))
        .expect(200)
      assert.notEqual(text, '')
    })
  })

  describe('save route', () => {
    it('saves a log and returns the saved log', async () => {
      const someLog = {
        userId: mockedUser.id,
        itemId: '123',
        type: 'edit',
        new: 'foo',
        old: 'bar',
        field: 'Subject Code'
      }

      let { body: log } = await request(app).post('/api/v1/logs')
        .set('Authorization', await getAuthHeader(mockedUser.id))
        .send(someLog)
        .expect(201)

      assert(log._id)
      assert(log.userName)
    })

    it('returns a 400 error when given malformed data', async () => {
      const someLog = {
        type: 'BEANS'
      }

      await request(app).post('/api/v1/logs')
        .set('Authorization', await getAuthHeader(mockedUser.id))
        .send(someLog)
        .expect(400, {
          errors: [
            'type must be of type: edit, adminEdit, ' +
            'workflowApprove, ' +
            'workflowReject'
          ]
        })
    })

    it('400s when given a userId for a nonexistent user', async () => {
      const someLog = {
        userId: '5762f4708043c26732010b6a',
        itemId: '123',
        type: 'edit',
        new: 'foo',
        old: 'bar',
        field: 'Subject Code'
      }

      await request(app).post('/api/v1/logs')
        .set('Authorization', await getAuthHeader(mockedUser.id))
        .send(someLog)
        .expect(400, {
          errors: [`No user found for userId ${someLog.userId}`]
        })
    })
  })

  describe('load route', () => {
    it('returns all logs with a matching itemId', async () => {
      const ITEM_ID = 'SOME ITEM ID'

      const someLog = {
        userId: mockedUser.id,
        type: 'adminEdit',
        itemId: ITEM_ID,
        new: 'foo',
        old: 'bar',
        field: 'Subject Code'
      }

      await makeLog(app, mockedUser.id, someLog)
      await makeLog(app, mockedUser.id, someLog)
      await makeLog(app, mockedUser.id, someLog)

      let { body: logs } = await request(app).get('/api/v1/logs')
        .set('Authorization', await getAuthHeader(mockedUser.id))
        .query({ itemId: ITEM_ID })
        .expect(200)

      assert.equal(logs.count, 3)
    })
  })
})

async function makeLog(app, userId, log) {
  let { body } = await request(app).post('/api/v1/logs')
    .set('Authorization', await getAuthHeader(userId))
    .send(log)
    .expect(201)

  return body
}

async function getSecretFor(subdomain) {
  let value = await seneca.actAsync({
    role: 'institutions',
    cmd: 'getSecret',
    data: { subdomain },
    connectionKey
  })

  return value.secret
}

async function getAuthHeader(userId) {
  let secret = await getSecretFor('kuali')

  let token = await seneca.actAsync({
    role: 'token',
    cmd: 'sign',
    id: userId,
    secret,
    connectionKey
  })

  return `Bearer ${token.token}`
}

async function createUser(data) {
  return await seneca.actAsync({
    role: 'users',
    cmd: 'save',
    currentUser: { id: 'test' },
    data,
    connectionKey
  })
}
