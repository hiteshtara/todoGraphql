/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import assert from 'assert'
import validate from '../validate'

describe('log schema validation', () => {
  describe('edit logs', () => {
    it('validates a valid edit log', () => {
      const log = {
        userId: '123',
        itemId: '123',
        type: 'edit',
        old: null,
        new: '1234',
        field: 'Credits'
      }

      const errors = validate(log)
      assert.equal(errors, null)
    })

    it('errors when something isn\'t a valid edit log', () => {
      const log = {
        userId: '123',
        itemId: '123',
        type: 'edit',
        old: null
      }

      const errors = validate(log)
      assert.equal(errors.length, 2)
    })

    it('errors when a log has the wrong keyword', () => {
      const log = {
        userId: '123',
        itemId: '123',
        type: 'beans',
        old: null,
        new: '1234',
        field: '123'
      }

      const errors = validate(log)
      assert.equal(errors.length, 1)
    })
  })

  describe('workflow log', () => {
    it('validates a valid workflow log', () => {
      const log = {
        userId: '123',
        itemId: '123',
        type: 'workflowApprove',
        comment: 'foo'
      }

      const errors = validate(log)
      assert.equal(errors, null)
    })

    it('errors when something isn\'t a valid edit log', () => {
      const log = {
        userId: '123',
        itemId: '123',
        type: 'workflowApprove',
        comment: null
      }

      const errors = validate(log)
      assert.equal(errors.length, 1)
    })

    it('errors when a log has the wrong keyword', () => {
      const log = {
        userId: '123',
        itemId: '123',
        type: 'notGoingToPass',
        comment: 'bar'
      }

      const errors = validate(log)
      assert.equal(errors.length, 1)
    })
  })
})


