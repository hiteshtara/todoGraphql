/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { getSenecaContext } from 'shared/seneca'
import plugin from 'services/logs/plugin'
import assert from 'assert'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getModel } from '../model'

const { connection, connectionKey } = getTestConnectionInfo()
const Job = getModel(connection)

function getUserWithName(msg, respond) {
  respond(null, { displayName: 'test' })
}

function getUserWithoutName(msg, respond) {
  respond(null, {})
}

function dbIsOnFire(msg, respond) {
  respond(new Error('the database is on fire!'))
}

describe('logs plugin', () => {
  let si

  beforeEach(async () => {
    si = getSenecaContext()
    si.use(plugin)
    si.add({ role: 'users', cmd: 'load' }, getUserWithName)
    await Job.remove()
  })

  afterEach((done) => {
    // Seneca keeps event listeners around. Clean them up
    // to avoid eventemitter leak warnings.
    // If you get these errors go clean up the sandboxed seneca instances
    // created in tests below.
    si.close(done)
  })

  it('saves a log with user information', async () => {
    const result = await si.actAsync({
      role: 'logs',
      cmd: 'save',
      data: {
        userId: '1234',
        itemId: '4567',
        type: 'workflowApprove'
      },
      currentUser: { id: 'test' },
      connectionKey
    })
    assert(result)
  })

  describe('when passing in no data', () => {
    it('throws an error', async () => {
      const seneca = getSenecaContext()
      seneca.use(plugin)
      let thrown = false
      try {
        await seneca.actAsync({ role: 'logs', cmd: 'save', connectionKey })
      } catch (e) {
        thrown = true
      }
      assert(thrown)
    })
  })

  describe('when saving a log for a user without a display name', () => {
    it('stores the userName as ---', async () => {
      const seneca = getSenecaContext()
      seneca.use(plugin)
      seneca.add({ role: 'users', cmd: 'load' }, getUserWithoutName)
      const result = await seneca.actAsync({
        role: 'logs',
        cmd: 'save',
        data: {
          userId: '1234',
          itemId: '4567',
          type: 'workflowApprove'
        },
        currentUser: { id: 'test' },
        connectionKey
      })
      assert.equal(result.userName, '---')
    })
  })

  describe('when saving a log when the use plugin errors', () => {
    it('throws an error', async () => {
      const seneca = getSenecaContext()
      seneca.use(plugin)
      seneca.add({ role: 'users', cmd: 'load' }, dbIsOnFire)
      let thrown = false
      try {
        await seneca.actAsync({
          role: 'logs',
          cmd: 'save',
          data: {
            userId: '1234',
            itemId: '4567',
            type: 'workflowApprove'
          },
          currentUser: { id: 'test' },
          connectionKey
        })
      } catch (e) {
        thrown = true
      }
      assert(thrown)
    })
  })

  describe('when saving a log with a userId without a matching user', () => {
    function noUser(msg, respond) {
      respond(
        new Error('why is this even an error, this is an expected thing'),
        null
      )
    }

    it('throws an error', async () => {
      const seneca = getSenecaContext()
      seneca.use(plugin)
      seneca.add({ role: 'users', cmd: 'load' }, noUser)
      let thrown = false
      try {
        await seneca.actAsync({
          role: 'logs',
          cmd: 'save',
          data: {
            userId: '1234',
            type: 'edit',
            itemId: 'beans'
          },
          connectionKey
        })
      } catch (e) {
        thrown = true
      }
      assert(thrown)
    })
  })

  it('returns all logs matching an itemId', async () => {
    const itemId = 'STUFF'

    await si.actAsync({
      role: 'logs',
      cmd: 'save',
      data: {
        userId: '1234',
        itemId,
        type: 'workflowApprove'
      },
      currentUser: { id: 'test' },
      connectionKey
    })

    const logs = await si.actAsync({
      role: 'logs',
      cmd: 'query',
      query: {
        itemId
      },
      connectionKey
    })

    assert.equal(logs.count, 1)
    assert.equal(logs.result[0].itemId, itemId)
  })
})
