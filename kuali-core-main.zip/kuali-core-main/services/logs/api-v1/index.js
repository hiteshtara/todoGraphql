/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import authenticate from 'shared/middleware/authenticate'
import express from 'express'
import seneca from 'shared/seneca'
import wrapAsync from 'shared/wrap-async'

const router = express.Router()

export default router

router.use(authenticate())

router.post('/', wrapAsync( async (req, res) => {
  const result = await seneca.actAsync({
    role: 'logs',
    cmd: 'save',
    data: req.body,
    currentUser: req.user,
    connectionKey: res.locals.connectionKey
  })
  res.status(201).json(result)
}))

router.get('/', wrapAsync( async (req, res) => {
  const result = await seneca.actAsync({
    role: 'logs',
    cmd: 'query',
    query: req.query,
    connectionKey: res.locals.connectionKey
  })
  return res.json(result)
}))
