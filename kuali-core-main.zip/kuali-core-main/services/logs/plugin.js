/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import crud from 'shared/crud'
import users from 'services/users/server/resources/users/plugin'
import { BadRequestError } from 'shared/errors'
import validate from './validate'
import { getModel } from './model'

const role = 'logs'

export default function logs() {
  this.use(crud, { role, getModel })
  this.use(users)
  this.add({ role, cmd: 'save' }, saveLog)
  this.add({ role, cmd: 'save' }, validateLog)

  return role
}

function validateLog(msg, respond) {
  const data = msg.data || {}
  const logValidations = validate(data)

  if (logValidations) {
    const err = new BadRequestError('invalid log')
    err.errors = logValidations.map((validation) => validation.message)
    return respond(err)
  }

  return this.prior(msg, respond)
}

async function saveLog(msg, respond) {
  const { userId } = msg.data
  let user
  try {
    user = await this.actAsync({ role: 'users', cmd: 'load',
      id: userId, connectionKey: msg.connectionKey })
    const log = {
      userName: user.displayName || '---',
      ...msg.data
    }
    const logParam = {
      role,
      cmd: 'save',
      data: log,
      currentUser: msg.currentUser,
      connectionKey: msg.connectionKey
    }
    return this.prior(logParam, respond)
  } catch (err) {
    if (err.msg && /cmd:load,role:users failed: id not found/.test(err.msg)) {
      const errorMsg = `No user found for userId ${userId}`
      const newError = new BadRequestError(errorMsg)
      newError.errors = [errorMsg]
      return respond(newError)
    }
    return respond(err)
  }
}
