/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import config from 'config'
import express from 'express'
import institutionLoader from 'shared/institution-loader'
import institution from 'services/institution'
import users from 'services/users'
import groups from 'services/groups'
import auth from 'services/auth'
import applications from 'services/apps'
import jobs from 'services/jobs'
import notifications from 'services/notifications'
import actions from 'services/actions'
import logs from 'services/logs'
import wrapAsync from 'shared/wrap-async'
import alreadyLoggedIn from 'shared/middleware/already-logged-in'
import refererAsDefault from 'shared/middleware/referer-as-default'
import requestMiddleware from 'shared/middleware/request'
import cookieParser from 'cookie-parser'
import bodyParser from 'body-parser'
import { errorHandler } from 'shared/errors'
import { defaultLogger as logger, middleware as loggerMW }
  from 'shared/logging'
import responseLocalsMW from 'shared/middleware/response-locals'
import secure from 'shared/secure'
import { register as registerEventListeners } from 'shared/events/listeners'

const app = express()

app.use(secure)

app.use(loggerMW(logger))

app.use(bodyParser.json({
  type: ['json', 'application/csp-report']
}))

app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok' })
})

app.post('/apps/content-security-policy-violation', (req, res) => {
  req.log.info('Content Security Policy Violation: ', req.body)
  res.sendStatus(204)
})

app.use(cookieParser())

app.get(
  /\/auth\/?$|\/auth\/kuali\/?$/,
  cookieParser(),
  responseLocalsMW,
  institutionLoader,
  refererAsDefault,
  wrapAsync(alreadyLoggedIn)
)

app.get('/', (req, res) => res.redirect('/apps/'))

app.use(express.static(`${__dirname}/public`))

app.use(responseLocalsMW)
app.use(institutionLoader)
app.use(requestMiddleware)
app.use(institution)
app.use(users)
app.use(groups)
app.use(auth)
app.use(applications)
app.use(notifications)
app.use(jobs)
app.use(actions)
app.use(logs)

app.use(errorHandler)
registerEventListeners()

app.listen(config.port, () => {
  logger.info({ port: config.port }, '««« CORE »»» : Server Started')
})

module.exports = app //eslint-disable-line import/no-commonjs
