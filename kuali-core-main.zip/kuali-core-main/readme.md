# Core

[![bitHound Score](https://www.bithound.io/projects/badges/2f40f7e0-8f0a-11e5-9805-e52878c06f03/score.svg)](https://www.bithound.io/github/KualiCo/core)
[![bitHound Code](https://www.bithound.io/projects/badges/2f40f7e0-8f0a-11e5-9805-e52878c06f03/code.svg)](https://www.bithound.io/github/KualiCo/core)
[![bitHound Dependencies](https://www.bithound.io/projects/badges/2f40f7e0-8f0a-11e5-9805-e52878c06f03/dependencies.svg)](https://www.bithound.io/github/KualiCo/core/master/dependencies/npm)
[![codecov](https://codecov.io/gh/KualiCo/cor-main/branch/master/graph/badge.svg?token=bceKhonapI)](https://codecov.io/gh/KualiCo/cor-main)
[![Circle CI](https://circleci.com/gh/KualiCo/cor-main.svg?style=shield&circle-token=8178f4b8534ea21f06b097340d419c2c99c8869a)](https://circleci.com/gh/KualiCo/core)


# Installation and Startup

Prerequisites:
- [Latest LTS version of node](https://nodejs.org/en/download/)
- [MongoDB](https://docs.mongodb.com/manual/installation/)

Clone the repository
```sh
git clone https://github.com/KualiCo/cor-main.git
cd core

# Update `npm` to the latest version:

```sh
npm install -g npm@3
```

# Install dependencies:

```sh
npm install
```

# Run Build process

```sh
npm run build
```

# Make sure mongo is running. In development use (in a new tab/process/terminal window):

```sh
mongod
```

# Start the App (in a new tab/process/terminal window)

```sh
npm start
# or
node dist/index
```

# Start the Jobs runner (in a new tab/process/terminal window)

The jobs scheduler is a singleton service, which is used for scheduled tasks
like weekly emails and such. It's essentially `cron-as-a-service`. It is in a
singleton process so that jobs don't get run twice. In the future, this will be
a separate service. Out of the box, jobs is used for notifications of expiring
API keys. If you don't need this, you don't need to run this process.

The jobs api runs in the main CORE process. It's responsibility is to store
and retrieve information pertaining to those repeating tasks. This extra process
is for actually running and processing the repeating tasks, querying the
database for the next tasks to be run, and so on.

```sh
npm run jobs_scheduler
# or
node dist/services/jobs/scripts/scheduler
```

After starting the app for the first time, visit the app. With the default
config, you can visit `http://localhost:3000`, and sign in with username `admin`
and password `admin`. Be sure to visit the users app and change the password as
soon as you can! If you want to recreate the admin user, you must remove all
users from the database and run the following curl command:

```
curl -X POST http://localhost:3000/api/v1/users/seed
```

That endpoint only works if there are no users in the database.

## Setting up a proxy

If you are running cor-main behind a proxy, you'll want to map up some specific
endpoints to the running app instance. Below is a mapping of the URL paths that
should be routed (`cor-main` is a placeholder for the host where you are hosting
this server):

```
/img -> http://cor-main/img
/js -> http://cor-main/js
/css -> http://cor-main/css
/font -> http://cor-main/font
/core-assets -> http://cor-main/cor-assets
/apps -> http://cor-main/apps
/api/v1/apps -> http://cor-main/api/v1/apps
/api/v1/institution -> http://cor-main/api/v1/institution
/users -> http://cor-main/users
/api/v1/users -> http://cor-main/api/v1/users
/api/v1/tokens -> http://cor-main/api/v1/tokens
/auth -> http://cor-main/auth
/api/v1/auth -> http://cor-main/api/v1/auth
/api/v1/jobs -> http://cor-main/api/v1/jobs
/api/v1/notification-templates -> http://cor-main/api/v1/notification-templates
/api/v1/notifications -> http://cor-main/api/v1/notifications
/groups -> http://cor-main/groups
/api/v1/groups -> http://cor-main/api/v1/groups
/api/v1/categories -> http://cor-main/api/v1/categories
/actions -> http://cor-main/actions
/api/v1/actions -> http://cor-main/api/v1/actions
```

## Health Checks

There are several health check endpoints to determine the health of the systems.
Most of them are pretty rudimentary, and if any one of them is failing, likely
all of them are failing, but because eventually all of these services could
likely be split out into separate servers in the future, each service has their
own set of health checks.

Health check endpoints will return a `2xx` status code (200 or 204) for a
healthy service. Below are a list of the current health check endpoints:

```
/apps/health/
/api/v1/apps/health/
/api/v1/institution/health
/users/health
/api/v1/auth/health
/api/v1/notification-templates/health
/api/v1/notifications/health
/api/v1/groups/health
/api/v1/categories/health
/actions/health
/api/v1/actions/health
```

You'll probably notice some inconsistencies in which routes have health checks.
There are more than those available, but for some reason require authentication.
We have some work to do to make this more consistent and have created several
tickets for us to clean this up.

## Migrations

Migrations are fairly structured (now), and should be fairly easy to manage.

To update to the latest migration, run `npm run migrate:up`. This will create a
new collection in your mongo database called `_migrations`. This collection is
used to keep track of which migrations have been run and which ones have not. If
your app is starting using `npm run start`, then this command is run for you
before your app starts. If you start your app bypassing npm, then you need to
run this on your own.

To rollback, run `npm run migrate:down`.

To create a new migration file, run
`npm run migrate:create -- [name of migration]`. This will create a new file
under the `migrations/` directory. In that file, there are two exports:
`exports.migrate` and `exports.rollback`. Each of those methods is called with
two arguments: `client`, and `done` respectively. `client` contains the database
connection stuff for mongo. You can access the `mongodb` client using
`client.db`. There are also helper methods in the `migrations/helpers/`
directory to make it easier to write consistent migrations. Feel free to add
utility methods as your migrations need them.

## Config

You can insert your own configuration values. Make a copy of `config/default.js`
and call it `config/local.js`. Change your configuration values and then run
the build and start steps.

If you make changes to any of the existing files do not commit them unless you
are purposefully changing the defaults or adding in new configuration keys. We
don't want your specific config values.

### Config values

The following section details the available configuration values you can modify
for your specific running environment. As mentioned above, you should make a
`config/local.js` for sensitive credentials. The configuration is run by
[this module](https://github.com/lorenwest/node-config). Basically, `default.js`
is the default config that everything will fall back to. If you specify a
`NODE_ENV` environment variable, it will use the corresponding
`[environment].js` file for its config, and fallback to default.js for config
keys that aren't specified in the `[environment].js`. `local.js` will override
`[environment].js`

The following section outlines available configuration values. While reading
this, it may be helpful to be looking at `config/default.js`, so you can see how
you might make changes for your environment. The following list will use the
following format when describing configuration options:

```
- `port` [`3000`] PORT - The port that the app listens on.
  │      │        │      │
  │      │        │      └─ The description of what the configuration option is for
  │      │        └──────── The environment variable (if any) you can use to control the value
  │      └───────────────── The default value of the configuration
  └──────────────────────── The path to the config value
```

- `port` [`3000`] PORT - The port that the app listens on.
- `serviceSecret` SERVICE_SECRET_1, SERVICE_SECRET_2 - The secret to use when
  signing service-to-service requests. In some services/apis, we make cross-api
  requests in which we don't have a user in the context, so normal
  authentication fails. We use this to sign authentication tokens to services
  that also have this same secret. This is how the jobs service currently makes
  requests.
- `baseUrl` [`'http://localhost:3000'`] - Used to create links in emails and
  other external communications.
- `seneca` - Options to pass to the seneca module. You shouldn't need to mess
  with this.
- `log.level` [`'dev'`] LOG_LEVEL - The lowest level of logs to log to stdout.
  Valid log levels include: trace, verbose, debug, info, warn, error, fatal,
  dev, none, audit.
- `log.name` [`'cor-main'`] - The namespace of the logs
- `cookieOpts` - Options.passed into our cookie parsing/setting library.
- `cookieOpts.httpOnly` [`false`] - If true, cookies are not accessible to
  JavaScript.
- `cookieOpts.secure` [`false`] - If true, cookies are only accessible to https.
- `cookieOpts.domain` [`''`] - The domain that the cookies should be restricted
  to.
- `cookieOpts.path` [`/`] - The path that the cookies are accessible at.
- `cookieOpts.maxAge` [`1209600000`] - Time in milliseconds that cookies are
  good for. Default is about 2 weeks.
- `db.uri` [`'mongodb://localhost/core-development'`] MONGO_URI - The uri to use
  when connecting to the database.
- `db.options` - Options to pass to the mongo connection. If you wish to
  authenticate with username/password, pass in an object like this:
  ```js
  {
    user: 'your username',
    pass: 'your password'
  }
  ```
- `elasticsearch.host` [`null`] ELASTICSEARCH_HOST - The elasticsearch host
  to use (experimental, not officially supported)
- `elasticsearch.httpAuth` ELASTICSEARCH_AUTH - The elasticsearch authentication
  information (experimental, not officially supported).
  format `{username}:{password}`
- `elasticsearch.apiVersion` ELASTICSEARCH_VERSION - The elasticsearch api version
  (experimental, not officially supported)
- `auth.casCallbackUrl` [`'http://localhost:3000'`] - The server url to return to
  after authenticating with cas
- `auth.samlCallbackUrl` [`'https://saml1-tst.kuali.co/auth/saml/consume'`] -
  The url to use when saml requests come back
- `auth.samlMeta` [`'./services/auth/server/samlMeta.xml'`] - The path to the
  SAML meta xml file.
- `auth.samlMeta2` - same as above, but used as a fallback
- `auth.samlKeys.v0` SAML_KEY_V0 - SAML v0 saml key
- `auth.samlKeys.v2` SAML_KEY_v2 - SAML v2 saml key
- `notifications.smtp` - The SMTP configuration
- `notifications.dkim` - DKIM configuration.
  [http://www.dkim.org/][http://www.dkim.org/]
- `jobs.eachInterval` [`1000`] JOBS_EACH_INTERVAL - In order to not DOS yourself
  you need to set this in order to split up the jobs updates.
- `jobs.interal` [`60000`] JOBS_INTERVAL - The interval at which to run all
  pending jobs, in milliseconds. Runs every 1 minute.
- `jobs.statusUrl` [`'http://example.com'`] JOBS_STATUS_URL - A url to call to
  report its status. The extra jobs process is a separate process from the main
  core process. It is a long-running, glorified cron service. This configuration
  option is a url to call to verify that the cron service is up and running.
  This option isn't required if the status of this service doesn't matter to
  you.
- `jobs.hostMatch` [`'^https?://'`] HOST_MATCH - The regex rule to use when
  allowing external hosts into the creation of jobs. The jobs model has a url
  that it calls on each job iteration. This option is used to validate the
  allowed urls in case you only want the jobs service to make http calls to a
  specific domain.

Right now, the config is kind of painful. In the future, we'll make it easier
for all configuration to be available via environment variables.

# Testing

### 100% Code Coverage

100% test coverage is required for the project. Less than 100% coverage will
break the build and prevent deployment of the project.

### Code Standards

[ESLint](http://eslint.org) is used to enforce coding standards for the project.
Linting is enforced in the build process. Not following the standards will break
the build and prevent deployment.

# Dev Environment Setup

## Run Tests
At this point you should be able to run `npm test`

## Build Client Code
Run `npm run build_client` to build front end code

## Edit Your Hosts File
Add this line to your hosts file `127.0.0.1       greendale-local.kuali.co`

## Install and run Tunnels for local https
In a separate terminal
* Run `gem install tunnels`
* Tunnel local 443 traffic to port 3000 `sudo tunnels 443 3000`

## Run App
First, make sure `pwd` shows the root of your source directory

To run the app, run `npm run start_dev`

You should be able to navigate to the app at https://greendale-local.kuali.co/apps.

If you want to run the databases required locally, here are some handy docker
commands you can use:

```sh
# elasticsearch (not required)
docker run -p 9200:9200 -e "http.host=0.0.0.0" -e "transport.host=127.0.0.1" docker.elastic.co/elasticsearch/elasticsearch:5.5.1
# mongo
docker run -p 27017:27017 mongo:latest
# redis (not required)
docker run -p 6379:6379 redis:alpine
```

# Architecture

Core is a collection of shared web services that can be run as one application,
but are designed and developed as isolated, modular, decoupled applications. The
following services are now in development:

* Auth
* Users
* Institution
* Files
* Notifications
* Jobs
* Groups
* Workflows
* Actions
* Forms

Each service is created as a standalone Express application that is hosted as
Express middleware inside the parent core application. See ./index.js to see how
each service is loaded as middleware. Each service may have one or more Mongo
database collections. [Seneca.js](http://senecajs.org) is used to send and
receive messages between services. This will help us keep the services isolated,
decoupled and ready to be separated with little effort.

**IMPORTANT:** A service should **never** access the collections or data of
another service directly. Also, a service should **never** directly access
modules or resources in another service. Use Seneca.

## Structure

* **./services** -- Holds the individual services
* **./shared** -- Holds small shared modules that can be reused across the
  services

## Service Structure

Each service should have its own index.js file as well as a test folder with its
own tests. It should also have its own package.json with its dependencies
declared. You should be able to run ```npm test``` or ```mocha``` in the root
folder of any service and have its tests run and pass. Should is good.

```
./
  test
  index.js
  package.json
```

NOTE: If you add a dependency to a service package.json, be sure to add it to
the root package.json as these service level package.json files are ignored.

## I18n

We are using [react-intl](https://github.com/yahoo/react-intl). It has a lot of
cool features and everyone should probably read through their documentation.
Here are the basics:

### Root App

The root react component needs to be wrapped in an `<IntlProvider>` tag to be
able to populate the `intl` field for components using `injectIntl` (explained
later) and to have the locale info set for the whole app. Here's what it looks
like, assuming that `msgs` is a json file with the translationed string:

```diff
-ReactDOM.render(<Preloader/>, el)
+ReactDOM.render(<IntlProvider locale="en-US" messages={msgs}><Preloader/><IntlProvider>, el)
```

### Content Prep

Since the default language is English, we are going to embed the default English
strings into the code and use the babel-plugin to extrac them into JSON files
that can go to translators. The plugin automatically extracts messages from
`FormattedXXX` tag attributes as well as calls to `defineMessages` from
`react-intl`. Here's an example of using `defineMessages`:

```javascript
const msgs = defineMessages({
  first: {
    id: 'uniqueId',
    description: 'Context for helping with translation',
    defaultMessage: 'English content'
  }
})
```

This pattern makes the code easier to read too, using ES7 object rest/spread:

```diff
  render() {
+    return (<FormattedMessage ...msgs.first/>
-    return (<FormattedMessage id="first"
-      description="Context...."
-      defaultMessage="English content"/>
  }
```

### Translating/Formatting Content - Special Tags

If you are just formatting content of HTML tags, it's really easy: just wrap the
`FormattedXXX` tag.

Example:

```diff
 ...
 render() {
-  return (<div>Raw content</div>)
+  return (<div><FormattedMessage id='rawContent' defaultMessage='Raw content'</FormattedMessage></div>)
 }
```

### Translating/Formatting Attributes - HOC for React components

We have to wrap any react component that needs to i18n/l10n attributes (or any
direct formatting) with a higher-order-component (HOC). Here's how:

```diff
 import React from 'react'
+import { injectIntl, intlShape } from 'react-intl'

-export default class MyComponent extends React.Component {
+class MyComponent extends React.Component {
 }

 MyComponent.propTypes = {
+  intl: intlShape.isRequired
 }

+export default injectIntl(MyComponent)
```

This will give you access to several methods for formatting messages based on
ocale settings in the app.
