/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import { find } from 'lodash'

export async function seed(connectionKey) {
  const apps = await seneca.actAsync({
    role: 'apps',
    cmd: 'list',
    connectionKey
  })
  let app = find(apps.result, { displayName: 'core' })
  if (!app) {
    app = await seneca.actAsync({
      role: 'apps',
      cmd: 'create',
      application: {
        displayName: 'core'
      },
      user: { id: 'system-user' },
      connectionKey
    })
  }
  return app.id
}
