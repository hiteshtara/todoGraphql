/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint-disable no-console */
import seneca from 'shared/seneca'
import jobsPlugin from 'services/jobs/server/resources/jobs/plugin'
import templatePlugin from
  'services/notifications/server/plugins/templates'
import appsPlugin from 'services/apps/server/plugin'
import { getConnection } from 'shared/mongoose/pool'
import * as jobs from './jobs'
import * as notifications from './notifications'
import * as applications from './applications'

seneca.use(jobsPlugin)
seneca.use(templatePlugin, { role: 'notification-templates' })
seneca.use(appsPlugin, { role: 'apps' })

async function run(connectionKey, options) {
  const appId = await applications.seed(connectionKey)
  await notifications.seed(connectionKey, appId)
  await jobs.seed(connectionKey, appId, options)
}

export default async (connectionKey, options) => {
  const connection = getConnection(connectionKey)
  await run(connection, options)
}
