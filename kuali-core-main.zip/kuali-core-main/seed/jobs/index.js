/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import moment from 'moment'
import getBaseUrl from 'shared/base-url'

export async function seed(connectionKey, coreAppId, options) {
  await seedAdminExpiredKeysNotificationJob(connectionKey, coreAppId, options)
  await seedUserExpiredKeysNotificationJob(connectionKey, coreAppId, options)
  await seedExpiringKeysNotificationJob(connectionKey, coreAppId, options)
}

async function seedAdminExpiredKeysNotificationJob(connectionKey, coreAppId, options) { // eslint-disable-line max-len
  const typeId = 'adminExpiredTokensEmail'
  const { jobs } = await seneca.actAsync({
    role: 'jobs',
    cmd: 'query',
    data: {
      typeId
    },
    connectionKey
  })
  const jobExists = jobs.length > 0
  let job = jobs[0] || {}
  job = Object.assign({
    startTimestamp: moment().day(1).hour(8).minute(0).toDate()
  }, job, {
    typeId,
    name: 'Notify admins of expired api keys',
    appId: coreAppId,
    createdBy: coreAppId,
    active: true,
    endTimestamp: moment().add(100, 'years').toDate(),
    url: `${getBaseUrl(options)}/api/v1/tokens/notifyAdmins`,
    recurrenceType: 'week'
  })
  const cmd = jobExists ? 'update' : 'create'
  await seneca.actAsync({
    role: 'jobs',
    cmd,
    data: job,
    currentUser: { id: 'system-user' },
    connectionKey
  })
}

async function seedUserExpiredKeysNotificationJob(connectionKey, coreAppId, options) { // eslint-disable-line max-len
  const typeId = 'userExpiredTokensEmail'
  const { jobs } = await seneca.actAsync({
    role: 'jobs',
    cmd: 'query',
    data: {
      typeId
    },
    connectionKey
  })
  const jobExists = jobs.length > 0
  let job = jobs[0] || {}
  job = Object.assign({
    startTimestamp: moment().day(1).hour(8).minute(0).toDate()
  }, job, {
    typeId,
    name: 'Notify users of expired api keys',
    appId: coreAppId,
    createdBy: coreAppId,
    active: true,
    endTimestamp: moment().add(100, 'years').toDate(),
    url: `${getBaseUrl(options)}/api/v1/tokens/notifyUsers`,
    recurrenceType: 'week'
  })
  const cmd = jobExists ? 'update' : 'create'
  await seneca.actAsync({
    role: 'jobs',
    cmd,
    data: job,
    currentUser: { id: 'system-user' },
    connectionKey
  })
}

async function seedExpiringKeysNotificationJob(connectionKey, coreAppId, options) { // eslint-disable-line max-len
  await seedExpiringKeysJob(connectionKey, coreAppId, 30, options)
  await seedExpiringKeysJob(connectionKey, coreAppId, 14, options)
  await seedExpiringKeysJob(connectionKey, coreAppId, 4, options)
  await seedExpiringKeysJob(connectionKey, coreAppId, 1, options)
  await seedExpiringKeysJob(connectionKey, coreAppId, 0, options)
}

async function seedExpiringKeysJob(connectionKey, coreAppId, daysAhead, options) { // eslint-disable-line max-len
  const typeId = `keyExpiringIn${daysAhead}Days`
  const { jobs } = await seneca.actAsync({
    role: 'jobs',
    cmd: 'query',
    data: {
      typeId
    },
    connectionKey
  })
  const jobExists = jobs.length > 0
  let job = jobs[0] || {}
  job = Object.assign({
    startTimestamp: moment().day(1).hour(8).minute(0).toDate()
  }, job, {
    typeId,
    name: `Notify users of api keys expiring in ${daysAhead} days`,
    appId: coreAppId,
    createdBy: coreAppId,
    active: true,
    payload: {
      daysAhead
    },
    endTimestamp: moment().add(100, 'years').toDate(),
    url: `${getBaseUrl(options)}/api/v1/tokens/notifyUsers`,
    recurrenceType: 'day',
    connectionKey
  })
  const cmd = jobExists ? 'update' : 'create'
  await seneca.actAsync({
    role: 'jobs',
    cmd,
    data: job,
    currentUser: { id: 'system-user' },
    connectionKey
  })
}
