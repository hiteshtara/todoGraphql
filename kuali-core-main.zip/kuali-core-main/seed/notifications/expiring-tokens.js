/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import fs from 'fs'
import path from 'path'

export const notifyAdminName = 'admin-expiring-keys'
export const notifyUsersName = 'user-expiring-keys'

export async function seed(connectionKey, coreAppId) {
  let templates = await seneca.actAsync({
    role: 'notification-templates',
    cmd: 'list',
    query: {
      displayName: notifyAdminName
    },
    connectionKey
  })
  const notifyAdmin = templates[0]
  templates = await seneca.actAsync({
    role: 'notification-templates',
    cmd: 'list',
    query: {
      displayName: notifyUsersName
    },
    connectionKey
  })
  const notifyUsers = templates[0]
  const adminHTML = fs.readFileSync(
    path.resolve(__dirname,
      'expiring-tokens-admin-email.html'), 'utf8')
  const newnotifyAdmin = Object.assign({}, notifyAdmin, {
    displayName: notifyAdminName,
    applicationId: coreAppId,
    subject: 'Expiring Keys',
    templates: {
      email: {
        html: adminHTML,
        text: 'There are api keys that are expired or are expiring soon for ' +
          'your Kuali account. Please log in and create new ones.'
      }
    }
  })
  const userHTML = fs.readFileSync(
    path.resolve(__dirname,
      'expiring-tokens-user-email.html'), 'utf8')
  const newnotifyUsers = Object.assign({}, notifyUsers, {
    displayName: notifyUsersName,
    applicationId: coreAppId,
    subject: 'Expiring Keys',
    templates: {
      email: {
        html: userHTML,
        text: 'There are api keys that are expired or are expiring soon for ' +
          'your Kuali account. Please log in and create new ones.'
      }
    }
  })
  if (notifyAdmin) {
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'update',
      template: newnotifyAdmin,
      currentUser: { id: 'system-user' },
      connectionKey
    })
  } else {
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'create',
      template: newnotifyAdmin,
      currentUser: { id: 'system-user' },
      connectionKey
    })
  }
  if (notifyUsers) {
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'update',
      template: newnotifyUsers,
      currentUser: { id: 'system-user' },
      connectionKey
    })
  } else {
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'create',
      template: newnotifyUsers,
      currentUser: { id: 'system-user' },
      connectionKey
    })
  }
}
