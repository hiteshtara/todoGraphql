/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import seneca from 'shared/seneca'
import fs from 'fs'
import path from 'path'
import { seed as seedTokenNotifications } from './expiring-tokens'

export async function seed(connectionKey, coreAppId) {
  await seedTokenNotifications(connectionKey, coreAppId)
  await seedUserApprovalEmail(connectionKey, coreAppId)
}

async function seedUserApprovalEmail(connectionKey, coreAppId) {
  const notifyAdminName = 'user-approval-notify-admin'
  let templates = await seneca.actAsync({
    role: 'notification-templates',
    cmd: 'list',
    query: {
      displayName: notifyAdminName
    },
    connectionKey
  })
  const notifyAdmin = templates[0]
  const adminHTML = fs.readFileSync(
    path.resolve(__dirname,
      'approve-user-admin-email.html'), 'utf8')
  const newnotifyAdmin = Object.assign({}, notifyAdmin, {
    displayName: notifyAdminName,
    applicationId: coreAppId,
    subject: 'User Approval Required',
    templates: {
      email: {
        html: adminHTML,
        text: 'displayName is waiting to be approved ' +
          'for access to Kuali. userUrl'
      }
    }
  })
  if (notifyAdmin) {
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'update',
      template: newnotifyAdmin,
      currentUser: { id: 'system-user' },
      connectionKey
    })
  } else {
    await seneca.actAsync({
      role: 'notification-templates',
      cmd: 'create',
      template: newnotifyAdmin,
      currentUser: { id: 'system-user' },
      connectionKey
    })
  }
}
