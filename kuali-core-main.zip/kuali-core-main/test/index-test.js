/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

// TODO: Test all health endpoints here
/*eslint-disable no-unused-expressions*/
import request from 'supertest-as-promised'
import sinon from 'sinon'
import { each } from 'lodash'
import { expect } from 'chai'
import seneca from 'shared/seneca'
import { getTestConnectionInfo } from 'shared/test-helpers'
import { getInstitutionModel } from 'services/institution/model'
import { getUserModel } from 'services/users/server/resources/users/model'

const { connection, connectionKey } = getTestConnectionInfo()
let User = getUserModel(connection)
let Institution = getInstitutionModel(connection)
let sandbox

async function getSecretFor(subdomain) {
  let value = await seneca.actAsync({
    role: 'institutions',
    cmd: 'getSecret',
    data: { subdomain },
    connectionKey
  })

  return value.secret
}

async function getAuthHeader(userId) {
  let secret = await getSecretFor('kuali')

  let token = await seneca.actAsync({
    role: 'token',
    cmd: 'sign',
    id: userId,
    secret,
    connectionKey
  })

  return `Bearer ${token.token}`
}

describe('Core Server', () => {
  before(function() {
    this.timeout(10000)
    require('../index') // eslint-disable-line import/no-commonjs
  })

  beforeEach(async () => {
    sandbox = sinon.sandbox.create()
    await Institution.collection.remove({})
    await User.collection.remove({})
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('should redirect to /apps/', async () => {
    const res = await request('http://localhost:3000')
      .get('/')
      .redirects(0)
      .expect(302)
    expect(res.headers.location).to.be.equal('/apps/')
  })

  it('should get health', async () => {
    await request('http://localhost:3000')
      .get('/api/v1/health')
      .expect(200, { status: 'ok' })
  })

  describe('Error Handler', () => {

    it('handles 404 errors', async () => {
      const actAsync = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', (pattern) => {
        if (pattern.role === 'institutions' && pattern.cmd === 'load') {
          return Promise.reject(new Error('error from stub'))
        }
        return actAsync(pattern)
      })
      await request('http://localhost:3000')
        .get('/auth/')
        .expect(404)
    })

    it('handles missing institution as a 404 error', async () => {
      const actAsync = seneca.actAsync.bind(seneca)
      sandbox.stub(seneca, 'actAsync', (pattern) => {
        if (pattern.role === 'institutions' && pattern.cmd === 'load') {
          return null
        }
        return actAsync(pattern)
      })
      await request('http://localhost:3000')
        .get('/auth/')
        .expect(404)
    })

    it('handles 500 errors', async () => {
      await seneca.actAsync({
        role: 'institutions',
        cmd: 'load',
        data: { subdomain: 'kuali', name: 'Kuali' },
        connectionKey
      })
      let res = await seneca.actAsync({
        role: 'users',
        cmd: 'save',
        currentUser: { id: 'test' },
        data: { username: 'Test', email: 'test@domain.org', role: 'user' },
        connectionKey
      })

      let authHeader = await getAuthHeader(res.id)

      const act = seneca.act.bind(seneca)
      sandbox.stub(seneca, 'act', (pattern, callback) => {
        if (pattern.role === 'users' && pattern.cmd === 'query') {
          return callback(new Error('stub error'), null)
        }
        return act(pattern, callback)
      })

      await request('http://localhost:3000')
        .get('/api/v1/users')
        .set('Authorization', authHeader)
        .expect(500)
    })
    it('handles 404 errors', async () => {

      await request('http://localhost:3000')
        .get('/api/v1/captainamerica')
        .expect(404)
    })
  })

  it('redirects to apps if logged in', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    let res1 = await request('http://localhost:3000')
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
      .expect(200)
    let token = getTokenFromCookie(res1)

    await request('http://localhost:3000')
      .get('/auth')
      .set('Authorization', `Bearer ${token}`)
      .expect(302)
      .expect('location', '/apps')
  })

  it('redirects to redirect url if logged in', async () => {
    let password = 'password'
    await seneca.actAsync({ role: 'users', cmd: 'save',
        currentUser: { id: 'test' }, data: {
        username: 'test',
        email: 'test@domain.org',
        role: 'user',
        password
      },
      connectionKey })
    let res1 = await request('http://localhost:3000')
      .post('/api/v1/auth/authenticate')
      .auth('test', password)
      .expect(200)
    let token = getTokenFromCookie(res1)

    await request('http://localhost:3000')
      .get('/auth?return_to=/return')
      .set('Authorization', `Bearer ${token}`)
      .expect(302)
      .expect('location', '/return')
  })

})


function getTokenFromCookie(res) {
  let headers = res.headers
  let cookies = headers['set-cookie'][0]
  let result = {}
  let props = cookies.split('; ')
  each(props, p => {
    let kvp = p.split('=')
    result[kvp[0]] = kvp[1]
  })
  return result.authToken
}
/*eslint-enable*/
