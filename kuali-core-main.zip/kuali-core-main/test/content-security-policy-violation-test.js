/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import request from 'supertest-as-promised'

describe('Content Security Policy Violation Report', () => {
  before(function() {
    this.timeout(10000)
    require('../index') // eslint-disable-line import/no-commonjs
  })

  it('returns 204 when body is included', async () => {
    await request('http://localhost:3000')
      .post('/apps/content-security-policy-violation')
      .send(JSON.stringify({ policy: 'violated' }))
      .set('Content-Type', 'application/csp-report')
      .expect(204)
  })

  it('returns 204 when body NOT included', async () => {
    await request('http://localhost:3000')
      .post('/apps/content-security-policy-violation')
      .set('Content-Type', 'application/csp-report')
      .expect(204)
  })
})
