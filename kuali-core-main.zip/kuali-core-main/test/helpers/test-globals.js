/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

import { initDefaults } from 'shared/logging'
import config from 'config'
import mockery from 'mockery'
import trace from 'trace-line' // eslint-disable-line no-unused-vars

initDefaults(config.log || {})
mockery.enable({
    warnOnReplace: true,
    warnOnUnregistered: false
})
mockery.registerMock('passport-ldapauth', class {
  constructor(options, callback) {
    this.options = options
    this.callback = callback
  }
  authenticate(req) {
    req.log = {
      audit() {},
      error() {}
    }
    return this.callback(
      req,
      { username: 'jerry' },
      (erk, user, info) => {
        return this.success(user, info)
      }
    )
  }
})
