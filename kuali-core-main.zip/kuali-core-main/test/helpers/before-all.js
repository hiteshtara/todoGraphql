import cache from 'shared/cache'

beforeEach(async () => {
  await cache.resetAsync()
})
