const messages = {
  //Title text for service
  'apps.title': 'Apps',
  //Welcome message for front page
  'apps.welcome': 'Welcome to {institution}',
  //Button/link text for signing in
  'label.signIn': 'Sign In',
  //Button/link text for signing out
  'label.signOut': 'Sign Out',
  //Button/link text for returning to the "home" screen
  'label.home': 'Home',
  //Button/link text for canceling
  'label.cancel': 'Cancel',
  //Button/link text for saving
  'label.save': 'Save',
  //Label for password fields
  'label.password': 'Password',
  //Button/link text for searching
  'label.search': 'Search',
  //Button/link text for editing something
  'label.edit': 'Edit',
  //Button/link text for editing permissions
  'label.edit.permissions': 'Edit Permissions', //eslint-disable-line,
  //Button/link text for being finished with something
  'label.done': 'Done',
  //Label/header text for somethings name
  'label.name': 'Name',
  //Button/link text for the complete something
  'label.all': 'All',
  //Button/link text for a contextual creation
  'label.new': 'New',
  //Button/link text for copying something to the clipboard
  'label.copy': 'Copy',
  //Button/link text for going to the next page of a list
  'label.next': 'Next',
  //Button/link text for going to the previous page of a list
  'label.prev': 'Prev', //eslint-disable-line,
  //Name of the Core product
  'apps.core': 'Core',
  //Name of Users application
  'apps.users': 'Users',
  //Name of Groups application
  'apps.groups': 'Groups',
  //Name of the Actions application
  'apps.actions': 'Actions',
  //Name of Workflow application
  'apps.workflow': 'Workflow',
  //Name of Curriculum application
  'apps.curriculum': 'Curriculum',
  //Number of records per page on paginated list
  'paging.pageSize': '{count} Per Page', //eslint-disable-line,
  //Current page in total pages
  'paging.current': '{page} of {totalPages}',
  //Range of records with a total on a paginated list
  'paging.range': '{total, plural, =0 {No Results} one {One Result} other {{pageStart} - {pageEnd} of #}}', //eslint-disable-line,
  //Generic, simple error message with no details
  'errors.simple': 'An error occurred', //eslint-disable-line,
  //Link text for Action List
  'header.link.actionList': 'Action List',
  //Link text for user settings
  'header.link.settings': 'User Settings',
  //Default link text for user profile
  'header.link.profile': 'Profile',
  //Alt text for menu icon
  'header.alt.menu': 'Show App Menu',
  //Alt text for nav menu icon
  'header.alt.nav': 'Open Nav Menu',
  //Page content for 401 Not Authenticated
  'notAuthenticated.content': 'We were unable to authenticate you successfully. Please try again.', //eslint-disable-line,
  //Title content for 401 Not Authorized
  'notAuthenticated.title': 'Not Authenticated (401)', //eslint-disable-line,
  //Page content for 403 Not Found
  'forbidden.content': 'You are not authorized to access this part of the application.', //eslint-disable-line,
  //Title content for 403 Forbiden
  'forbidden.title': 'Not Authorized (403)',
  //Page content for 404 Not Found
  'notfound.content': 'Looks like you have found yourself between a rock and a hard place', //eslint-disable-line,
  //Alt text for loading animation
  'preloader.alt': 'A loading animation',
  //Main content for loading placeholder
  'preloader.main': 'Loading, please wait.', //eslint-disable-line,
  //Placeholder for text field for logging in with username/email
  'auth.placeholders.usernameOrEmail': 'Username / Email', //eslint-disable-line,
  //Error message display on invalid username/password
  'auth.errors.invalid': 'Invalid username/password', //eslint-disable-line,
  //Error message display on unapproved user
  'auth.errors.unapproved': 'A request to approve your account has been sent to your admin. If approved you will be able to log in. Thank you for your patience.', //eslint-disable-line,
  //Error message title to show that admin approval is in progress
  'auth.errors.unapprovedTitle': 'Admin approval in progress', //eslint-disable-line,
  //Title message for ipd selection page
  'auth.idp.select': 'Select Campus',
  //Button text for adding a field
  'groups.buttons.addField': 'Add Field',
  //Accessbility label for text input of field labels
  'groups.labels.fieldLabel': 'Field Label', //eslint-disable-line,
  //Column title for the column of labels
  'groups.columns.label': 'Label',
  //Column title for the column of types
  'groups.columns.type': 'Type',
  //Button text for adding a relationship
  'groups.buttons.addRelationship': 'Add Relationship', //eslint-disable-line,
  //Accessbility label for text input of relationship names
  'groups.labels.relationshipName': 'Relationship Name', //eslint-disable-line,
  //The No Category Label in Category Selection
  'groups.labels.noCategory': '<No Category>', //eslint-disable-line,
  //Column title for the column of relationship names
  'groups.columns.relationshipName': 'Name', //eslint-disable-line,
  //Column title for the column of relationship category
  'groups.columns.relationshipCategory': 'Category', //eslint-disable-line,
  //Link text to return "home"
  'groups.header.backHome': 'Back to Home',
  //Button text for adding a role
  'groups.buttons.addRole': 'Add Role',
  //Accessbility label for text input of role names
  'groups.labels.roleName': 'Role Name', //eslint-disable-line,
  //Accessibility label for text input of role description
  'groups.labels.roleDescription': 'Role Description', //eslint-disable-line,
  //Column title for the column of names
  'groups.columns.name': 'Name',
  //Column title for the column of role descriptions
  'groups.columns.description': 'Description', //eslint-disable-line,
  //Accesibility label for the remove component
  'groups.labels.removeSection': 'Remove Section', //eslint-disable-line,
  //Title for success notification
  'groups.notifications.success': 'Success!',
  //Title for error notification
  'groups.notifications.error': 'Error!',
  //Accessibility label for closing a notification
  'groups.notifications.close': 'Close Notice', //eslint-disable-line,
  //Column header for the display id of an action
  'actions.labels.id': 'Id',
  //Column header for the display title of an action
  'actions.labels.title': 'Title', //eslint-disable-line,
  //Column header for the display description of an action
  'actions.labels.description': 'Description', //eslint-disable-line,
  //Column header for the display type of an action
  'actions.labels.type': 'Type', //eslint-disable-line,
  //Column header for the created date of an action
  'actions.labels.created': 'Created On', //eslint-disable-line,
  //Column header for the requested action for an action
  'actions.labels.actionsRequested': 'Action Requested', //eslint-disable-line,
  //Option text for fields of type "text"
  'groups.options.textType': 'Text',
  //Option text for fields of type "textarea"
  'groups.options.textareaType': 'Textarea', //eslint-disable-line,
  //Option text for fields of type "checkbox"
  'groups.options.checkboxType': 'Checkbox', //eslint-disable-line,
  //Column/section header for a group of fields
  'groups.labels.fields': 'Fields',
  //Header title for group categories
  'groups.categories.titles.category': '{isNew, select, true {New} false {Edit}} Category', //eslint-disable-line,
  //Link text for editing a category
  'groups.categories.editCategory': 'Edit Category', //eslint-disable-line,
  //Link text for creating new groups
  'groups.createNew': 'New Group',
  //Display that a null category has been selected
  'groups.noCategory': '<No Category>', //eslint-disable-line,
  //Accessibility text for an add user button
  'groups.a11y.addUser': 'Add User',
  //Accessibility text for a remove user button
  'groups.a11y.removeUser': 'Remove User', //eslint-disable-line,
  //Accessibility text for remvoe parent group button
  'groups.a11y.unselectParentGroup': 'Unselect Parent Group', //eslint-disable-line,
  //Placeholder text for adding a parent group
  'groups.placeholders.addParentGroup': 'Add Parent Group', //eslint-disable-line,
  //Button text for clearing an override
  'groups.labels.clearOverride': 'Clear Override', //eslint-disable-line,
  //Panel title for roles template section
  'groups.labels.rolesTemplate': 'Roles Template', //eslint-disable-line,
  //Panel title for fields template section
  'groups.labels.fieldsTemplate': 'Fields Template', //eslint-disable-line,
  //Button/link text for deleting a group
  'groups.labels.deleteGroup': 'Delete Group', //eslint-disable-line,
  //Labl for modifying a template
  'groups.labels.modifyTemplate': 'Modify Template', //eslint-disable-line,
  //Button/link text for editing permissions
  'groups.labels.edit.permissions': 'Edit Permissions', //eslint-disable-line,
  //Label for overriding an existing template
  'groups.labels.overrideTemplate': 'Override Template', //eslint-disable-line,
  //Header title for groups
  'groups.titles.groups': '{isNew, select, true {New} false {Edit}} Group', //eslint-disable-line,
  //Header title for group categories
  'groups.titles.category': '{isNew, select, true {New} false {Edit}} Category', //eslint-disable-line,
  //Title for roles panel
  'groups.titles.roles': 'Roles',
  //Title for category hierarchy panel
  'groups.categories.titles.hierarchy': 'Hierarchy', //eslint-disable-line,
  //Column/section header for a group of fields
  'groups.titles.fields': 'Fields',
  //Title for implicit members role panel
  'groups.titles.membersRole': 'Members',
  //Alt text for retire category
  'groups.alt.retireCategory': 'Retire',
  //Accessibility label for group name input
  'groups.labels.groupName': 'Group Name', //eslint-disable-line,
  //Link text for deleting category
  'groups.links.deleteCategory': 'Delete Category', //eslint-disable-line,
  //Label for selection of parent category in hierarchy
  'groups.labels.parentCategory': 'Parent Category', //eslint-disable-line,
  //Label for creation of other relationships
  'groups.labels.relationships': 'Other Relationships', //eslint-disable-line,
  //Link text for viewing category details
  'groups.labels.viewCategory': 'View Category', //eslint-disable-line,
  //Button/link text for editing a group
  'groups.labels.editGroup': 'Edit Group',
  //Label marking a group as overridden
  'groups.labels.overridden': 'Overridden',
  //Singular of groups
  'groups.labels.groupSingular': 'Group',
  //Button text for new category in search
  'groups.labels.newCategory': 'New Category', //eslint-disable-line,
  //Singular category
  'groups.labels.categorySingular': 'Category',
  //Plural of category
  'groups.labels.categories': 'Categories',
  //Create a new thing
  'groups.labels.newThing': 'New {thing}',
  //Accessibility label for new category button
  'groups.a11y.newCategory': 'Create a new Category', //eslint-disable-line,
  //Generic accessibility label for creating something
  'groups.a11y.newThing': 'Create a new {thing}', //eslint-disable-line,
  //Accessibility label from clearing search filter
  'groups.a11y.clearFilter': 'Clear the search filter', //eslint-disable-line,
  //Accessibility label for filtering search results
  'groups.a11y.filter': 'Filter search results to {thing}', //eslint-disable-line,
  //Accessibility label for search field
  'groups.a11y.searchPrompt': 'Type to search Groups', //eslint-disable-line,
  //Alternate name for display purposes
  'users.fields.display': 'Display Name',
  //User email
  'users.fields.email': 'Email',
  //Username for login
  'users.fields.username': 'Username',
  //Given name of the user
  'users.fields.givenName': 'First name',
  //Family name of the user
  'users.fields.familyName': 'Last name',
  //Whether the user is approved
  'users.fields.approved': 'Approved',
  //Permissions role
  'users.fields.role': 'Role',
  //The Primary Group that this user belongs to
  'users.fields.groupId': 'Primary Group', //eslint-disable-line,
  //Normal user role
  'users.roles.user': 'User',
  //Adminstrative user role
  'users.roles.admin': 'Admin',
  //Service (not a person) role
  'users.roles.service': 'Service',
  //CM Admin
  'users.roles.cmadmin': 'CM Admin',
  //External User
  'users.roles.external': 'External User',
  //Column header for the creation dates of API keys
  'users.headers.created': 'Created', //eslint-disable-line,
  //Column header for the expiration dates of API keys
  'users.headers.expires': 'Expires', //eslint-disable-line,
  //Button text for revoking API keys
  'users.labels.revoke': 'Revoke',
  //Message for empty table if no API keys exist
  'users.labels.noKeys': 'This account has no API Keys.', //eslint-disable-line,
  //Button text for showing form to create new API keys
  'users.labels.newKey': '{size, select, small {+} other {Create KEY}}', //eslint-disable-line,
  //Button text to actually create an API key with a name
  'users.labels.createKey': 'Create Key', //eslint-disable-line,
  //Placeholder text of input field for API key name
  'users.placeholders.apiKeyName': 'Enter API Key Name', //eslint-disable-line,
  //Error message if API key creation failed
  'users.errors.failedToCreate': 'Unable to create API key', //eslint-disable-line,
  //Error message if API key creation is attempted without a name
  'users.errors.noKeyName': '"Name" is required', //eslint-disable-line,
  //Partial section title for API keys
  'users.titles.apiKeys': 'API Keys',
  //Title for the warning when new api keys are created
  'users.apiKeys.warningTitle': 'Warning - READ ME!', //eslint-disable-line,
  //HTML content for warning when new api keys are created
  'users.apiKeys.warningContent': '<span style="font-weight:600;">Copy</span> and <span style="font-weight:600;">Save</span> this API key now, it cannot be displayed again!', //eslint-disable-line,
  //Return to the full list of users
  'users.links.userList': '< Back to User List', //eslint-disable-line,
  //User Account Information
  'users.links.accountInfo': 'Account Information',
  //User API Key Management
  'users.links.apiKeys': 'API Keys',
  //Title for edit page of a user
  'users.edit.title': '{isNew, select, true {New} false {Edit}} User', //eslint-disable-line,
  //Placeholder for password verification field
  'users.edit.passwordConfirmMsg': 'Re-Enter Password', //eslint-disable-line,
  //Error message for email validation error
  'users.edit.invalidEmailMsg': 'Oops not an email', //eslint-disable-line,
  //Error message for username validation error
  'users.edit.invalidUsernameMsg': 'Invalid username', //eslint-disable-line,
  //Error message for duplicate field error
  'users.edit.duplicateFieldMsg': '{field} already in use', //eslint-disable-line,
  //Password validation error
  'users.edit.invalidPasswordMsg': 'Password must be at least 8 characters', //eslint-disable-line,
  //Number of users in list
  'users.list.count': '{count, plural, one {# User} other {# Users}}', //eslint-disable-line,
  //Placeholder for search box in user list
  'users.list.search': 'Search Users',
  //Link text to add a new user
  'users.list.add': '+ Add User',
  //Delete the currently viewed user
  'user.view.delete': 'Delete User',
  //Approve the currently viewed user
  'user.view.approve': 'Approve User',
  //Ask the user to confirm deletion
  'user.view.confirmDelete': 'Are you sure you want to delete this user?', //eslint-disable-line,
  //Impersonate the user
  'user.view.impersonate': 'Impersonate'
}

window.messages = messages
