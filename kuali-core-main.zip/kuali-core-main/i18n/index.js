/* Copyright © 2016 Kuali, Inc. - All Rights Reserved
 * You may use and modify this code under the terms of the Kuali, Inc.
 * Pre-Release License Agreement. You may not distribute it.
 *
 * You should have received a copy of the Kuali, Inc. Pre-Release License
 * Agreement with this file. If not, please write to license@kuali.co.
 */

/* eslint-disable no-console */
import { ensureDir, writeFile, readFile, readdir, lstat } from 'fs-promise'
import { normalize, join } from 'path'
import { flattenDeep, chain, isEqual } from 'lodash'

async function loadMessages() {
  const files = await walk('./messages')
  const messages = await Promise.all(files.map(f => readFile(f, 'utf-8')))

  return flattenDeep(messages.map(JSON.parse))
}

async function walk(start) {
  start = normalize(start)
  const stat = await lstat(start)

  if (stat.isDirectory()) {
    let currentLevel = await readdir(start)
    let results = await Promise.all(currentLevel
      .map(f => join(start, f))
      .map(normalize)
      .map(walk)
    )
    return flattenDeep(results)
  }

  return [normalize(start)]
}

function uniqueify(messages) {
  return chain(messages).groupBy('id').values().map(desc => {
    if (desc.length > 1) {
      const allTheSame = desc.map(isEqual.bind(null, desc[0]))
        .reduce((res, v) => res && v, true)
      if (allTheSame) {
        return desc[0]
      }
      throw new Error(`Duplicated message id with differing content: ${desc[0].id}`) //eslint-disable-line
    }
    return desc[0]
  })

}

function buildString(messages) {
  const insides = messages
    .map(m => {
      const line = `//${m.description}\n  '${m.id}': '${m.defaultMessage.replace(/'/, "\'")}'` //eslint-disable-line
      if (line.length > 80) {
        return `${line}, //eslint-disable-line`
      }
      return line
    })
    .join(',\n  ')

  return `const messages = {\n  ${insides}\n}\n\nwindow.messages = messages\n`
}

ensureDir('../public/js/i18n')
  .then(loadMessages)
  .then(uniqueify)
  .then(buildString)
  .then(contents => writeFile('../public/apps/js/i18n/en.js', contents))
  .then(() => console.log('Finished building i18n english content'))
  .catch((err) => console.error('Failed to build i18n english content', err))
